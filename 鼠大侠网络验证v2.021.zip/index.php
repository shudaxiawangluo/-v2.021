<?php
// 自动跳转到后台登录页面
header('Location: admin/login.php');
exit;
