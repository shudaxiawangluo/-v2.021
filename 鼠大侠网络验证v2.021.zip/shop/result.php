<?php
require_once '../api/config.php';
$db = getDB();

$orderNo = $_GET['out_trade_no'] ?? '';
$order = null;
$authCodes = [];

if ($orderNo) {
    $stmt = $db->prepare("SELECT * FROM orders WHERE order_no = ?");
    $stmt->execute([$orderNo]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order && $order['status'] == 1 && $order['auth_codes']) {
        $authCodes = json_decode($order['auth_codes'], true);
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>支付结果 - 鼠大侠授权系统</title>
    <link rel="stylesheet" href="https://unpkg.com/element-plus/dist/index.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://unpkg.com/element-plus"></script>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .result-card {
            background: #fff;
            border-radius: 12px;
            padding: 40px;
            max-width: 500px;
            width: 100%;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        .success-icon { font-size: 64px; margin-bottom: 20px; }
        .title { font-size: 24px; font-weight: 600; margin-bottom: 10px; }
        .subtitle { color: #909399; margin-bottom: 30px; }
        .codes-box {
            background: #f5f7fa;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
            text-align: left;
        }
        .code-item {
            font-family: monospace;
            font-size: 14px;
            padding: 8px;
            background: #fff;
            border-radius: 4px;
            margin-bottom: 8px;
            word-break: break-all;
        }
        .code-item:last-child { margin-bottom: 0; }
    </style>
</head>
<body>
    <div id="app">
        <div class="result-card">
            <?php if ($order && $order['status'] == 1): ?>
            <div class="success-icon">✅</div>
            <div class="title">支付成功</div>
            <div class="subtitle">您的授权码已生成，请妥善保管</div>
            
            <div class="codes-box">
                <?php foreach ($authCodes as $code): ?>
                <div class="code-item"><?= htmlspecialchars($code) ?></div>
                <?php endforeach; ?>
            </div>
            
            <el-button type="primary" @click="copyAll">复制全部授权码</el-button>
            <el-button @click="goBack">返回购买</el-button>
            <?php elseif ($order && $order['status'] == 0): ?>
            <div class="success-icon">⏳</div>
            <div class="title">等待支付</div>
            <div class="subtitle">订单尚未支付，请完成支付</div>
            <el-button type="primary" @click="goBack">返回重试</el-button>
            <?php else: ?>
            <div class="success-icon">❌</div>
            <div class="title">订单不存在</div>
            <div class="subtitle">请检查订单号是否正确</div>
            <el-button type="primary" @click="goBack">返回购买</el-button>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    const { createApp } = Vue;
    createApp({
        methods: {
            copyAll() {
                const codes = <?= json_encode($authCodes) ?>;
                navigator.clipboard.writeText(codes.join('\n')).then(() => {
                    ElementPlus.ElMessage.success('已复制到剪贴板');
                });
            },
            goBack() {
                window.location.href = './';
            }
        }
    }).use(ElementPlus).mount('#app');
    </script>
</body>
</html>
