<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');

try {
    require_once '../api/config.php';
    $db = getDB();
    autoFixDatabase(); // 自动修复数据库
} catch (Exception $e) {
    echo json_encode(['code' => 1, 'msg' => '数据库连接失败']);
    exit;
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'products':
        try {
            $softwareId = intval($_GET['software_id'] ?? 0);
            if ($softwareId <= 0) {
                echo json_encode(['code' => 1, 'msg' => '参数错误']);
                break;
            }
            // 获取商品列表，并实时计算库存（从关联的未使用卡密数量）
            $stmt = $db->prepare("SELECT p.*, 
                (SELECT COUNT(*) FROM auth_codes WHERE product_id = p.id AND status = 0) as real_stock 
                FROM products p 
                WHERE p.software_id = ? AND p.status = 1 
                ORDER BY p.sort_order DESC, p.id ASC");
            $stmt->execute([$softwareId]);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 用实时库存替换stock字段
            foreach ($products as &$p) {
                $p['stock'] = intval($p['real_stock']);
                unset($p['real_stock']);
            }
            unset($p);
            
            echo json_encode(['code' => 0, 'data' => $products]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '查询失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'create_order':
        try {
            $input = json_decode(file_get_contents('php://input'), true);
            
            $softwareId = intval($input['software_id'] ?? 0);
            $productId = intval($input['product_id'] ?? 0);
            $quantity = max(1, min(100, intval($input['quantity'] ?? 1)));
            $payType = $input['pay_type'] ?? '';
            $buyerEmail = trim($input['buyer_email'] ?? '');
            
            if ($softwareId <= 0 || $productId <= 0) {
                echo json_encode(['code' => 1, 'msg' => '参数错误']);
                break;
            }
            
            // 获取商品信息
            $stmt = $db->prepare("SELECT * FROM products WHERE id = ? AND software_id = ? AND status = 1");
            $stmt->execute([$productId, $softwareId]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$product) {
                echo json_encode(['code' => 1, 'msg' => '商品不存在或已下架']);
                break;
            }
            
            // 检查库存
            $stock = intval($product['stock'] ?? 0);
            if ($stock < $quantity) {
                echo json_encode(['code' => 1, 'msg' => '库存不足，当前库存: ' . $stock]);
                break;
            }
            
            // 生成订单号
            $orderNo = date('YmdHis') . mt_rand(100000, 999999);
            $totalAmount = $product['price'] * $quantity;
            $unitPrice = $product['price'];
            
            // 创建订单
            $cardType = $product['card_type'] ?? 'month';
            $duration = intval($product['duration'] ?? $product['days'] ?? 30);
            $buyerIp = $_SERVER['REMOTE_ADDR'] ?? '';
            $ipLocation = getIpLocationSimple($buyerIp);
            
            // 免费商品直接发货
            if ($totalAmount <= 0) {
                // 获取关联的卡密
                $limitQty = intval($quantity);
                $stmt = $db->prepare("SELECT id, code FROM auth_codes WHERE product_id = ? AND status = 0 LIMIT {$limitQty}");
                $stmt->execute([$productId]);
                $availableCodes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (count($availableCodes) < $quantity) {
                    echo json_encode(['code' => 1, 'msg' => '库存不足']);
                    break;
                }
                
                $db->beginTransaction();
                try {
                    // 创建订单
                    $stmt = $db->prepare("INSERT INTO orders (order_no, software_id, product_id, product_name, quantity, unit_price, amount, pay_type, buyer_contact, buyer_ip, ip_location, card_type, duration, status, pay_time, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, 'free', ?, ?, ?, ?, ?, 1, NOW(), NOW())");
                    $stmt->execute([
                        $orderNo, $softwareId, $productId, $product['name'], $quantity, $unitPrice, $totalAmount, $buyerEmail, $buyerIp, $ipLocation, $cardType, $duration
                    ]);
                    
                    // 标记卡密为已使用并记录
                    $authCodes = [];
                    $codeIds = [];
                    foreach ($availableCodes as $code) {
                        $authCodes[] = $code['code'];
                        $codeIds[] = $code['id'];
                    }
                    
                    // 更新卡密状态
                    $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
                    $stmt = $db->prepare("UPDATE auth_codes SET status = 1, used_time = NOW(), remark = CONCAT(IFNULL(remark,''), ' 订单:{$orderNo}') WHERE id IN ($placeholders)");
                    $stmt->execute($codeIds);
                    
                    // 更新订单授权码
                    $stmt = $db->prepare("UPDATE orders SET auth_codes = ? WHERE order_no = ?");
                    $stmt->execute([json_encode($authCodes), $orderNo]);
                    
                    // 更新商品库存和销量
                    $stmt = $db->prepare("UPDATE products SET stock = stock - ?, sales = sales + ? WHERE id = ?");
                    $stmt->execute([$quantity, $quantity, $productId]);
                    
                    $db->commit();
                    
                    echo json_encode(['code' => 0, 'data' => [
                        'order_no' => $orderNo,
                        'is_free' => true,
                        'auth_codes' => $authCodes
                    ]]);
                } catch (Exception $e) {
                    $db->rollBack();
                    echo json_encode(['code' => 1, 'msg' => '领取失败: ' . $e->getMessage()]);
                }
                break;
            }
            
            // 付费商品需要支付方式
            if (empty($payType)) {
                echo json_encode(['code' => 1, 'msg' => '请选择支付方式']);
                break;
            }
            
            // 获取支付配置
            $stmt = $db->prepare("SELECT * FROM payment_configs WHERE pay_type = ? AND status = 1");
            $stmt->execute([$payType]);
            $payConfig = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$payConfig) {
                echo json_encode(['code' => 1, 'msg' => '支付方式不可用']);
                break;
            }
            
            $stmt = $db->prepare("INSERT INTO orders (order_no, software_id, product_id, product_name, quantity, unit_price, amount, pay_type, buyer_contact, buyer_ip, ip_location, card_type, duration, expire_time, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE), NOW())");
            $result_insert = $stmt->execute([
                $orderNo, $softwareId, $productId, $product['name'], $quantity, $unitPrice, $totalAmount, $payType, $buyerEmail, $buyerIp, $ipLocation, $cardType, $duration
            ]);
            
            if (!$result_insert) {
                echo json_encode(['code' => 1, 'msg' => '创建订单失败: 数据库插入失败']);
                break;
            }
            
            // 验证订单是否创建成功
            $stmt = $db->prepare("SELECT id FROM orders WHERE order_no = ?");
            $stmt->execute([$orderNo]);
            if (!$stmt->fetch()) {
                echo json_encode(['code' => 1, 'msg' => '创建订单失败: 订单未保存']);
                break;
            }
            
            $config = json_decode($payConfig['extra_config'] ?: '{}', true);
            $result = ['order_no' => $orderNo];
            
            // 动态生成回调URL（关键！确保回调能正确到达）
            $baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
            $scriptPath = dirname($_SERVER['SCRIPT_NAME']); // /shop
            $siteRoot = dirname($scriptPath); // 网站根目录
            if ($siteRoot === '\\' || $siteRoot === '/') $siteRoot = '';
            
            // 根据支付类型调用对应的支付接口
            if ($payType === 'wechat') {
                require_once '../api/pay/wechat.php';
                // 设置正确的回调URL
                $config['notify_url'] = $baseUrl . $siteRoot . '/api/pay/notify_wechat.php';
                $wechat = new WechatNativePay($config);
                $payResult = $wechat->createQrCode($orderNo, $totalAmount, $product['name'], $_SERVER['REMOTE_ADDR']);
                if ($payResult['code'] === 0) {
                    $result['qr_code'] = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($payResult['qr_code']);
                } else {
                    echo json_encode(['code' => 1, 'msg' => $payResult['msg'] ?? '创建微信支付失败']);
                    break;
                }
            } elseif ($payType === 'alipay') {
                require_once '../api/pay/alipay.php';
                // 设置正确的回调URL
                $config['notify_url'] = $baseUrl . $siteRoot . '/api/pay/notify_alipay.php';
                $alipay = new AlipayFacePay($config);
                $payResult = $alipay->createQrCode($orderNo, $totalAmount, $product['name']);
                if ($payResult['code'] === 0) {
                    $result['qr_code'] = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($payResult['qr_code']);
                } else {
                    echo json_encode(['code' => 1, 'msg' => $payResult['msg'] ?? '创建支付宝支付失败']);
                    break;
                }
            } elseif ($payType === 'epay') {
                require_once '../api/pay/epay.php';
                $config['notify_url'] = $baseUrl . $siteRoot . '/api/pay/notify_epay.php';
                $config['return_url'] = $baseUrl . $siteRoot . '/shop/result.php';
                $epay = new EpayClient($config);
                $result['pay_url'] = $epay->createPayUrl($orderNo, $totalAmount, $product['name'], 'alipay');
            } elseif ($payType === 'usdt') {
                require_once '../api/pay/usdt.php';
                $config['notify_url'] = $baseUrl . $siteRoot . '/api/pay/notify_usdt.php';
                $usdt = new UsdtPay($config);
                $payResult = $usdt->createOrder($orderNo, $totalAmount, $product['name']);
                if ($payResult['code'] === 0) {
                    $result['usdt_amount'] = $payResult['amount'];
                    $result['usdt_address'] = $payResult['address'];
                    $result['usdt_mode'] = $payResult['mode'] ?? 'gateway';
                    $result['usdt_network'] = $payResult['network'] ?? '';
                    $result['usdt_tip'] = $payResult['tip'] ?? '';
                    if (!empty($payResult['qr_code'])) {
                        $result['qr_code'] = $payResult['qr_code'];
                    } elseif (!empty($payResult['pay_url'])) {
                        $result['pay_url'] = $payResult['pay_url'];
                    } elseif (!empty($payResult['address'])) {
                        // 生成USDT地址二维码
                        $result['qr_code'] = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($payResult['address']);
                    }
                } else {
                    echo json_encode(['code' => 1, 'msg' => $payResult['msg'] ?? '创建USDT支付失败']);
                    break;
                }
            } else {
                echo json_encode(['code' => 1, 'msg' => '不支持的支付方式']);
                break;
            }
            
            echo json_encode(['code' => 0, 'data' => $result]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '创建订单失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'check_order':
        try {
            $orderNo = trim($_GET['order_no'] ?? '');
            if (empty($orderNo)) {
                echo json_encode(['code' => 1, 'msg' => '订单号不能为空']);
                break;
            }
            
            $stmt = $db->prepare("SELECT * FROM orders WHERE order_no = ?");
            $stmt->execute([$orderNo]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                // 调试：检查订单是否真的不存在
                $stmt = $db->query("SELECT COUNT(*) FROM orders");
                $totalOrders = $stmt->fetchColumn();
                echo json_encode(['code' => 1, 'msg' => '订单不存在', 'debug' => ['order_no' => $orderNo, 'total_orders' => $totalOrders]]);
                break;
            }
            
            // 如果订单未支付，主动查询支付状态
            if ($order['status'] == 0) {
                $stmt = $db->prepare("SELECT * FROM payment_configs WHERE pay_type = ? AND status = 1");
                $stmt->execute([$order['pay_type']]);
                $payConfig = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($payConfig) {
                    $config = json_decode($payConfig['extra_config'] ?: '{}', true);
                    $isPaid = false;
                    $tradeNo = '';
                    
                    if ($order['pay_type'] === 'wechat') {
                        require_once '../api/pay/wechat.php';
                        $wechat = new WechatNativePay($config);
                        $queryResult = $wechat->queryOrder($orderNo);
                        if ($queryResult['code'] === 0 && $queryResult['trade_state'] === 'SUCCESS') {
                            $isPaid = true;
                            $tradeNo = $queryResult['transaction_id'];
                        }
                    } elseif ($order['pay_type'] === 'alipay') {
                        require_once '../api/pay/alipay.php';
                        $alipay = new AlipayFacePay($config);
                        $queryResult = $alipay->queryOrder($orderNo);
                        // 支付宝交易状态：WAIT_BUYER_PAY等待付款、TRADE_CLOSED交易关闭、TRADE_SUCCESS支付成功、TRADE_FINISHED交易完成
                        if ($queryResult['code'] === 0) {
                            $tradeStatus = $queryResult['trade_status'] ?? '';
                            if (in_array($tradeStatus, ['TRADE_SUCCESS', 'TRADE_FINISHED'])) {
                                $isPaid = true;
                                $tradeNo = $queryResult['trade_no'] ?? '';
                            }
                        }
                    } elseif ($order['pay_type'] === 'epay') {
                        require_once '../api/pay/epay.php';
                        $epay = new EpayClient($config);
                        $queryResult = $epay->queryOrder($orderNo);
                        if ($queryResult['code'] === 0 && $queryResult['status'] == 1) {
                            $isPaid = true;
                            $tradeNo = $queryResult['trade_no'];
                        }
                    } elseif ($order['pay_type'] === 'usdt') {
                        require_once '../api/pay/usdt.php';
                        $usdt = new UsdtPay($config);
                        $queryResult = $usdt->queryOrder($orderNo);
                        if ($queryResult['code'] === 0 && $queryResult['status'] == 1) {
                            $isPaid = true;
                            $tradeNo = $queryResult['trade_no'];
                        }
                    }
                    
                    if ($isPaid) {
                        processOrderPayment($db, $order, $tradeNo);
                        $stmt = $db->prepare("SELECT * FROM orders WHERE order_no = ?");
                        $stmt->execute([$orderNo]);
                        $order = $stmt->fetch(PDO::FETCH_ASSOC);
                    }
                }
            }
            
            $authCodes = [];
            if ($order['status'] == 1 && $order['auth_codes']) {
                $authCodes = json_decode($order['auth_codes'], true);
            }
            
            echo json_encode(['code' => 0, 'data' => ['status' => intval($order['status']), 'auth_codes' => $authCodes]]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '查询失败: ' . $e->getMessage()]);
        }
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}

function processOrderPayment($db, $order, $tradeNo) {
    try {
        $db->beginTransaction();
        
        $stmt = $db->prepare("UPDATE orders SET status = 1, trade_no = ?, pay_time = NOW() WHERE order_no = ? AND status = 0");
        $stmt->execute([$tradeNo, $order['order_no']]);
        
        if ($stmt->rowCount() > 0) {
            $productId = $order['product_id'];
            $quantity = intval($order['quantity']);
            
            // 从商品关联的卡密中获取
            $limitQty = intval($quantity);
            $stmt = $db->prepare("SELECT id, code FROM auth_codes WHERE product_id = ? AND status = 0 LIMIT {$limitQty}");
            $stmt->execute([$productId]);
            $availableCodes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (count($availableCodes) < $quantity) {
                // 库存不足，回滚
                $db->rollBack();
                error_log('订单发货失败: 库存不足, order_no=' . $order['order_no']);
                return;
            }
            
            $authCodes = [];
            $codeIds = [];
            foreach ($availableCodes as $code) {
                $authCodes[] = $code['code'];
                $codeIds[] = $code['id'];
            }
            
            // 更新卡密状态为已使用
            $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
            $stmt = $db->prepare("UPDATE auth_codes SET status = 1, used_time = NOW(), remark = CONCAT(IFNULL(remark,''), ' 订单:{$order['order_no']}') WHERE id IN ($placeholders)");
            $stmt->execute($codeIds);
            
            // 更新订单授权码
            $stmt = $db->prepare("UPDATE orders SET auth_codes = ? WHERE order_no = ?");
            $stmt->execute([json_encode($authCodes), $order['order_no']]);
            
            // 更新商品库存和销量
            if ($productId) {
                $stmt = $db->prepare("UPDATE products SET stock = stock - ?, sales = sales + ? WHERE id = ?");
                $stmt->execute([$quantity, $quantity, $productId]);
            }
        }
        
        $db->commit();
    } catch (Exception $e) {
        $db->rollBack();
        error_log('处理订单支付失败: ' . $e->getMessage());
    }
}
