<?php
require_once '../api/config.php';
$db = getDB();

// 自动清理重复的支付配置（只执行一次）
try {
    $db->exec("DELETE p1 FROM payment_configs p1 INNER JOIN payment_configs p2 WHERE p1.id > p2.id AND p1.pay_type = p2.pay_type");
} catch (Exception $e) {}

// 检查发卡页面是否启用
$stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'shop_enabled'");
$stmt->execute();
$shopEnabled = $stmt->fetchColumn();
if ($shopEnabled === '0') {
    die('<h1 style="text-align:center;margin-top:100px;">发卡页面已关闭</h1>');
}

// 获取软件列表
$stmt = $db->query("SELECT id, name FROM software WHERE status = 1 ORDER BY id");
$softwareList = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 获取支付方式，按指定顺序：微信、支付宝、USDT、易支付（自动去重）
$stmt = $db->query("SELECT pay_type, pay_name FROM payment_configs WHERE status = 1 GROUP BY pay_type ORDER BY FIELD(pay_type, 'wechat', 'alipay', 'usdt', 'epay'), MIN(sort_order)");
$paymentList = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>自助购卡 - 鼠大侠授权系统</title>
    <link rel="stylesheet" href="https://unpkg.com/element-plus/dist/index.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://unpkg.com/element-plus"></script>
    <script src="https://unpkg.com/@element-plus/icons-vue"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; }
        body { font-family: 'Microsoft YaHei', Arial, sans-serif; background-color: #f5f7fa; }
        .shop-container { display: flex; min-height: 100vh; }
        .shop-left { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 60px; position: relative; }
        .page-logo { position: absolute; top: 30px; left: 40px; font-size: 18px; font-weight: 500; color: #303133; }
        .shop-left-content { text-align: center; }
        .shop-left img { max-width: 400px; max-height: 400px; object-fit: contain; }
        .shop-left-text { margin-top: 30px; }
        .shop-left-text h2 { font-size: 24px; font-weight: 500; margin-bottom: 12px; color: #303133; }
        .shop-left-text p { font-size: 14px; color: #909399; }
        .shop-right { flex: 1; background: linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%); display: flex; align-items: center; justify-content: center; padding: 40px; position: relative; overflow: hidden; }
        .shop-right::before { content: ''; position: absolute; top: -150px; right: -150px; width: 350px; height: 350px; background: linear-gradient(135deg, rgba(64,158,255,0.15) 0%, rgba(103,126,234,0.1) 100%); border-radius: 50%; }
        .shop-right::after { content: ''; position: absolute; bottom: -120px; left: -80px; width: 300px; height: 300px; background: linear-gradient(135deg, rgba(245,108,108,0.1) 0%, rgba(230,162,209,0.15) 100%); border-radius: 50%; }
        .shop-form-wrapper { position: relative; z-index: 1; width: 100%; max-width: 480px; }
        .shop-form-card { background: white; border-radius: 16px; padding: 32px; box-shadow: 0 10px 40px rgba(0,0,0,0.08); border: 1px solid rgba(255,255,255,0.8); }
        .shop-title { font-size: 22px; font-weight: 600; color: #1a1a2e; margin-bottom: 6px; text-align: center; }
        .shop-subtitle { color: #909399; text-align: center; margin-bottom: 28px; font-size: 13px; }
        .step-item { margin-bottom: 18px; }
        .step-label { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #303133; }
        .product-grid { display: flex; flex-direction: column; gap: 8px; }
        .product-item { border: 1px solid #e8e8e8; border-radius: 6px; padding: 10px 12px; cursor: pointer; transition: all 0.2s; display: flex; align-items: center; justify-content: space-between; background: #fff; }
        .product-item:hover { border-color: #409eff; }
        .product-item.selected { border-color: #409eff; background: #f5f9ff; }
        .product-item.disabled { opacity: 0.6; cursor: not-allowed; background: #f5f5f5; }
        .product-left { flex: 1; min-width: 0; }
        .product-name { font-size: 13px; font-weight: 500; color: #303133; }
        .product-desc { font-size: 11px; color: #909399; margin-top: 2px; }
        .product-right { text-align: right; flex-shrink: 0; margin-left: 12px; }
        .product-price { font-size: 16px; color: #f56c6c; font-weight: 600; }
        .product-original { font-size: 11px; color: #c0c4cc; text-decoration: line-through; }
        .pay-methods { display: flex; gap: 8px; }
        .pay-item { flex: 1; display: flex; align-items: center; justify-content: center; gap: 6px; padding: 8px 0; border: 1px solid #e8e8e8; border-radius: 6px; cursor: pointer; transition: all 0.2s; background: #fff; }
        .pay-item:hover { border-color: #409eff; }
        .pay-item.selected { border-color: #409eff; background: #f5f9ff; }
        .pay-icon { width: 18px; height: 18px; flex-shrink: 0; }
        .pay-icon img { width: 100%; height: 100%; object-fit: contain; }
        .pay-name { font-size: 12px; color: #303133; }
        .order-summary { background: #f8f9fa; border-radius: 8px; padding: 14px 16px; margin: 16px 0; }
        .order-row { display: flex; justify-content: space-between; font-size: 13px; color: #606266; margin-bottom: 6px; }
        .order-row:last-child { margin-bottom: 0; }
        .order-total { font-size: 18px; color: #f56c6c; font-weight: 700; }
        .submit-btn { width: 100%; height: 42px; font-size: 14px; font-weight: 500; border-radius: 8px; background: #1a1a2e !important; border: none !important; }
        .submit-btn:hover { background: #2d2d44 !important; }
        .submit-btn:disabled { background: #c0c4cc !important; }
        .shop-footer { text-align: center; margin-top: 16px; color: #909399; font-size: 11px; }
        [v-cloak] { display: none; }
        @media (max-width: 900px) {
            .shop-container { flex-direction: column; }
            .shop-left { display: none; }
            .shop-right { padding: 20px; }
            .shop-form-card { padding: 20px; }
        }
    </style>
</head>
<body>
    <div id="app" v-cloak>
        <div class="shop-container">
            <div class="shop-left">
                <div class="page-logo">鼠大侠网络验证</div>
                <div class="shop-left-content">
                    <img src="../img/登录背景.png" alt="购卡插画">
                    <div class="shop-left-text">
                        <h2>自助购卡中心</h2>
                        <p>安全快捷，自动发货，7×24小时服务</p>
                    </div>
                </div>
            </div>
            
            <div class="shop-right">
                <div class="shop-form-wrapper">
                    <div class="shop-form-card">
                        <h2 class="shop-title">购买授权码</h2>
                        <p class="shop-subtitle">选择套餐，完成支付后自动发货</p>
                        
                        <div class="step-item">
                            <div class="step-label">选择软件</div>
                            <el-select v-model="selectedSoftware" placeholder="请选择软件" style="width: 100%;" size="default" @change="loadProducts">
                                <?php foreach ($softwareList as $s): ?>
                                <el-option label="<?= htmlspecialchars($s['name']) ?>" :value="<?= $s['id'] ?>"></el-option>
                                <?php endforeach; ?>
                            </el-select>
                        </div>
                        
                        <div class="step-item">
                            <div class="step-label">选择套餐</div>
                            <div class="product-grid" v-if="products.length > 0">
                                <div v-for="p in products" :key="p.id" class="product-item" :class="{ selected: selectedProduct && selectedProduct.id === p.id, disabled: p.stock <= 0 }" @click="p.stock > 0 && (selectedProduct = p)">
                                    <div class="product-left">
                                        <div class="product-name">{{ p.name }}</div>
                                        <div class="product-desc">
                                            {{ p.description || getCardTypeName(p.card_type, p.duration) }}
                                            <span v-if="p.stock <= 0" style="color: #f56c6c; margin-left: 6px;">已售罄</span>
                                            <span v-else style="color: #67c23a; margin-left: 6px;">库存: {{ p.stock }}</span>
                                        </div>
                                    </div>
                                    <div class="product-right">
                                        <div class="product-price">¥{{ p.price }}</div>
                                        <div class="product-original" v-if="p.original_price && parseFloat(p.original_price) > parseFloat(p.price)">¥{{ p.original_price }}</div>
                                    </div>
                                </div>
                            </div>
                            <el-empty v-else description="请先选择软件" :image-size="50"></el-empty>
                        </div>
                        
                        <div class="step-item">
                            <div class="step-label">购买数量</div>
                            <el-input-number v-model="quantity" :min="1" :max="100" size="default" style="width: 120px;"></el-input-number>
                        </div>
                        
                        <div class="step-item" v-if="parseFloat(totalAmount) > 0">
                            <div class="step-label">支付方式</div>
                            <div class="pay-methods">
                                <?php foreach ($paymentList as $p): ?>
                                <div class="pay-item" :class="{ selected: payType === '<?= $p['pay_type'] ?>' }" @click="payType = '<?= $p['pay_type'] ?>'">
                                    <div class="pay-icon">
                                        <?php if ($p['pay_type'] === 'wechat'): ?><img src="../img/微信支付.png"><?php elseif ($p['pay_type'] === 'alipay'): ?><img src="../img/支付宝支付.png"><?php elseif ($p['pay_type'] === 'usdt'): ?><img src="../img/USDT.png"><?php else: ?><img src="../img/网易支付.png"><?php endif; ?>
                                    </div>
                                    <div class="pay-name"><?= htmlspecialchars($p['pay_name']) ?></div>
                                </div>
                                <?php endforeach; ?>
                                <?php if (empty($paymentList)): ?>
                                <div style="color:#909399;font-size:13px;text-align:center;padding:10px;">暂无可用支付方式</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="step-item" v-if="parseFloat(totalAmount) <= 0 && selectedProduct">
                            <el-alert type="success" :closable="false" show-icon>
                                <template #title>免费商品，点击下方按钮直接领取</template>
                            </el-alert>
                        </div>
                        
                        <div class="step-item">
                            <div class="step-label">联系方式（选填）</div>
                            <el-input v-model="buyerEmail" placeholder="邮箱地址，用于接收授权码" size="default"></el-input>
                        </div>
                        
                        <div class="order-summary" v-if="selectedProduct">
                            <div class="order-row"><span>商品</span><span>{{ selectedProduct.name }} × {{ quantity }}</span></div>
                            <div class="order-row"><span>单价</span><span>¥{{ selectedProduct.price }}</span></div>
                            <div class="order-row"><span>应付金额</span><span class="order-total">¥{{ totalAmount }}</span></div>
                        </div>
                        
                        <el-button type="primary" size="default" class="submit-btn" :disabled="!canSubmit" :loading="submitting" @click="submitOrder">
                            {{ parseFloat(totalAmount) <= 0 ? '立即领取' : '立即支付 ¥' + totalAmount }}
                        </el-button>
                        
                        <div class="shop-footer">© 2026 鼠大侠网络验证 · 安全可靠</div>
                    </div>
                </div>
            </div>
        </div>
        
        <el-dialog v-model="showPayDialog" title="扫码支付" width="420px" :close-on-click-modal="false" @close="stopPolling">
            <div style="text-align: center;">
                <div v-if="qrCodeUrl" style="margin-bottom: 12px;"><img :src="qrCodeUrl" style="width: 180px; height: 180px;" /></div>
                <p style="color: #909399; margin-bottom: 12px; font-size: 13px;">请使用{{ payTypeName }}扫码支付</p>
                <div v-if="usdtInfo.amount">
                    <p style="font-size: 22px; color: #f56c6c; font-weight: 600;">{{ usdtInfo.amount }} USDT</p>
                    <p style="color: #909399; font-size: 12px; margin-top: 4px;">≈ ¥{{ totalAmount }}</p>
                    <div v-if="usdtInfo.address" style="margin-top: 10px; padding: 10px; background: #f5f7fa; border-radius: 6px;">
                        <p style="font-size: 12px; color: #606266; margin-bottom: 4px;">{{ usdtInfo.network || 'USDT' }} 收款地址：</p>
                        <p style="font-size: 11px; color: #303133; word-break: break-all; font-family: monospace;">{{ usdtInfo.address }}</p>
                        <el-button size="small" type="primary" link @click="copyAddress" style="margin-top: 6px;">复制地址</el-button>
                    </div>
                </div>
                <div v-else>
                    <p style="font-size: 22px; color: #f56c6c; font-weight: 600;">¥{{ totalAmount }}</p>
                </div>
                <p style="color: #909399; font-size: 12px; margin-top: 6px;">订单号：{{ currentOrderNo }}</p>
            </div>
            <template #footer>
                <el-button @click="showPayDialog = false" size="default">取消支付</el-button>
                <el-button type="primary" @click="checkPayStatus" :loading="checking" size="default">我已支付</el-button>
            </template>
        </el-dialog>
        
        <el-dialog v-model="showSuccessDialog" title="支付成功" width="450px">
            <el-result icon="success" title="支付成功" sub-title="您的授权码已生成">
                <template #extra>
                    <div style="background: #f5f7fa; padding: 12px; border-radius: 6px; margin-bottom: 12px;">
                        <div v-for="(code, index) in authCodes" :key="index" style="font-family: monospace; font-size: 13px; margin-bottom: 6px; word-break: break-all;">{{ code }}</div>
                    </div>
                    <el-button type="primary" @click="copyAuthCodes" size="default">复制授权码</el-button>
                </template>
            </el-result>
        </el-dialog>
    </div>
    
    <script>
    var app = Vue.createApp({
        data: function() {
            return {
                selectedSoftware: null,
                selectedProduct: null,
                products: [],
                quantity: 1,
                payType: '<?= $paymentList[0]['pay_type'] ?? '' ?>',
                buyerEmail: '',
                submitting: false,
                showPayDialog: false,
                showSuccessDialog: false,
                qrCodeUrl: '',
                currentOrderNo: '',
                checking: false,
                authCodes: [],
                pollTimer: null,
                usdtInfo: { amount: '', address: '', network: '', mode: '' }
            };
        },
        computed: {
            canSubmit: function() { 
                // 免费商品不需要选择支付方式
                if (this.selectedSoftware && this.selectedProduct && parseFloat(this.totalAmount) <= 0) {
                    return true;
                }
                return this.selectedSoftware && this.selectedProduct && this.payType; 
            },
            totalAmount: function() { return this.selectedProduct ? (this.selectedProduct.price * this.quantity).toFixed(2) : '0.00'; },
            payTypeName: function() { return { wechat: '微信', alipay: '支付宝', epay: '支付APP', usdt: 'USDT' }[this.payType] || '支付APP'; }
        },
        methods: {
            loadProducts: function() {
                var self = this;
                if (!self.selectedSoftware) { self.products = []; return; }
                fetch('api.php?action=products&software_id=' + self.selectedSoftware)
                    .then(function(res) { return res.json(); })
                    .then(function(data) { if (data.code === 0) { self.products = data.data; self.selectedProduct = null; } })
                    .catch(function(e) { console.error(e); });
            },
            getCardTypeName: function(type, duration) {
                if (type === 'permanent') return '永久授权';
                // duration存的是天数，根据card_type显示正确的单位
                var d = parseInt(duration) || 0;
                switch (type) {
                    case 'minute': return d + '分钟';
                    case 'hour': return d + '小时';
                    case 'day': return d + '天';
                    case 'week': return Math.round(d / 7) + '周';
                    case 'month': return Math.round(d / 30) + '个月';
                    case 'quarter': return Math.round(d / 90) + '季度';
                    case 'year': return Math.round(d / 365) + '年';
                    default: return d + '天';
                }
            },
            submitOrder: function() {
                var self = this;
                if (!self.canSubmit) return;
                self.submitting = true;
                self.usdtInfo = { amount: '', address: '', network: '', mode: '' };
                
                // 免费商品不需要支付方式
                var postPayType = self.payType;
                if (parseFloat(self.totalAmount) <= 0) {
                    postPayType = 'free';
                }
                
                fetch('api.php?action=create_order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ software_id: self.selectedSoftware, product_id: self.selectedProduct.id, quantity: self.quantity, pay_type: postPayType, buyer_email: self.buyerEmail })
                })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.code === 0) {
                        self.currentOrderNo = data.data.order_no;
                        
                        // 免费商品直接显示授权码
                        if (data.data.is_free && data.data.auth_codes) {
                            self.authCodes = data.data.auth_codes;
                            self.showSuccessDialog = true;
                            self.submitting = false;
                            return;
                        }
                        
                        // USDT支付信息
                        if (data.data.usdt_amount) {
                            self.usdtInfo = {
                                amount: data.data.usdt_amount,
                                address: data.data.usdt_address || '',
                                network: data.data.usdt_network || '',
                                mode: data.data.usdt_mode || 'gateway'
                            };
                        }
                        if (data.data.qr_code) { 
                            self.qrCodeUrl = data.data.qr_code; 
                            self.showPayDialog = true;
                            self.startPolling();
                        }
                        else if (data.data.pay_url) { window.location.href = data.data.pay_url; }
                    } else { ElementPlus.ElMessage.error(data.msg || '创建订单失败'); }
                    self.submitting = false;
                })
                .catch(function(e) { ElementPlus.ElMessage.error('创建订单失败'); self.submitting = false; });
            },
            checkPayStatus: function() {
                var self = this;
                self.checking = true;
                fetch('api.php?action=check_order&order_no=' + self.currentOrderNo)
                    .then(function(res) { return res.json(); })
                    .then(function(data) {
                        if (data.code === 0 && data.data.status === 1) {
                            self.showPayDialog = false;
                            self.authCodes = data.data.auth_codes || [];
                            self.showSuccessDialog = true;
                            if (self.pollTimer) { clearInterval(self.pollTimer); self.pollTimer = null; }
                        } else {
                            ElementPlus.ElMessage.warning('订单未支付，请完成支付后再试');
                        }
                        self.checking = false;
                    })
                    .catch(function(e) { ElementPlus.ElMessage.error('查询失败'); self.checking = false; });
            },
            startPolling: function() {
                var self = this;
                if (self.pollTimer) clearInterval(self.pollTimer);
                self.pollTimer = setInterval(function() {
                    fetch('api.php?action=check_order&order_no=' + self.currentOrderNo)
                        .then(function(res) { return res.json(); })
                        .then(function(data) {
                            if (data.code === 0 && data.data.status === 1) {
                                clearInterval(self.pollTimer);
                                self.pollTimer = null;
                                self.showPayDialog = false;
                                self.authCodes = data.data.auth_codes || [];
                                self.showSuccessDialog = true;
                            }
                        });
                }, 3000);
            },
            stopPolling: function() {
                if (this.pollTimer) { clearInterval(this.pollTimer); this.pollTimer = null; }
            },
            copyAuthCodes: function() {
                var self = this;
                navigator.clipboard.writeText(self.authCodes.join('\n')).then(function() { 
                    ElementPlus.ElMessage.success('已复制到剪贴板，页面即将刷新');
                    // 1.5秒后刷新页面
                    setTimeout(function() {
                        window.location.reload();
                    }, 1500);
                });
            },
            copyAddress: function() {
                var self = this;
                if (self.usdtInfo.address) {
                    navigator.clipboard.writeText(self.usdtInfo.address).then(function() { ElementPlus.ElMessage.success('地址已复制'); });
                }
            }
        }
    });
    app.use(ElementPlus);
    app.mount('#app');
    </script>
</body>
</html>
