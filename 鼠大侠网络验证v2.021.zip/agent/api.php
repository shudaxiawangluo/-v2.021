<?php
session_start();
header('Content-Type: application/json');

require_once '../api/config.php';

$action = $_GET['action'] ?? '';
$db = getDB();

// 自动修复数据库
autoFixDatabase();

// 需要登录的操作
$needLogin = ['info', 'refresh', 'stats', 'recentOrders', 'dashboard', 'software', 'products', 'buy', 'orders', 'codes', 'withdraw', 'withdraws', 'profile', 'batchExport', 'batchDisable', 'batchEnable', 'batchDelete', 'enableCode', 'disableCode', 'deleteCode'];
if (in_array($action, $needLogin) && !isset($_SESSION['agent_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

switch ($action) {
    case 'login':
        $input = json_decode(file_get_contents('php://input'), true);
        $username = trim($input['username'] ?? '');
        $password = $input['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            echo json_encode(['code' => 1, 'msg' => '账号和密码不能为空']);
            break;
        }
        
        $stmt = $db->prepare("SELECT * FROM agents WHERE username = ? AND status = 1");
        $stmt->execute([$username]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$agent || !password_verify($password, $agent['password'])) {
            echo json_encode(['code' => 1, 'msg' => '账号或密码错误']);
            break;
        }
        
        $_SESSION['agent_id'] = $agent['id'];
        $_SESSION['agent_name'] = $agent['nickname'] ?: $agent['username'];
        $_SESSION['agent_level'] = $agent['level'];
        
        // 更新登录信息
        $stmt = $db->prepare("UPDATE agents SET login_ip = ?, login_time = NOW() WHERE id = ?");
        $stmt->execute([$_SERVER['REMOTE_ADDR'], $agent['id']]);
        
        echo json_encode(['code' => 0, 'msg' => '登录成功']);
        break;
    
    case 'logout':
        session_destroy();
        echo json_encode(['code' => 0, 'msg' => '已退出']);
        break;
    
    case 'info':
        $stmt = $db->prepare("SELECT id, username, nickname, level, balance, total_income, total_withdraw, discount, qq, email, create_time FROM agents WHERE id = ?");
        $stmt->execute([$_SESSION['agent_id']]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(['code' => 0, 'data' => $agent]);
        break;
    
    case 'refresh':
        $stmt = $db->prepare("SELECT id, username, nickname, level, balance, total_income, total_withdraw, discount, qq, email, create_time FROM agents WHERE id = ?");
        $stmt->execute([$_SESSION['agent_id']]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(['code' => 0, 'data' => $agent]);
        break;
    
    case 'stats':
        $agentId = $_SESSION['agent_id'];
        
        // 今日销售
        $stmt = $db->prepare("SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM agent_orders WHERE agent_id = ? AND DATE(create_time) = CURDATE() AND status = 1");
        $stmt->execute([$agentId]);
        $today = $stmt->fetch(PDO::FETCH_NUM);
        
        // 本月销售
        $stmt = $db->prepare("SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM agent_orders WHERE agent_id = ? AND DATE_FORMAT(create_time, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m') AND status = 1");
        $stmt->execute([$agentId]);
        $month = $stmt->fetch(PDO::FETCH_NUM);
        
        // 总销售
        $stmt = $db->prepare("SELECT COUNT(*) FROM agent_orders WHERE agent_id = ? AND status = 1");
        $stmt->execute([$agentId]);
        $totalOrders = $stmt->fetchColumn();
        
        // 卡密总数
        $stmt = $db->prepare("SELECT COUNT(*) FROM auth_codes WHERE agent_id = ?");
        $stmt->execute([$agentId]);
        $totalCodes = $stmt->fetchColumn();
        
        echo json_encode(['code' => 0, 'data' => [
            'todayOrders' => intval($today[0]),
            'todayIncome' => floatval($today[1]),
            'monthOrders' => intval($month[0]),
            'monthIncome' => floatval($month[1]),
            'totalOrders' => intval($totalOrders),
            'totalCodes' => intval($totalCodes)
        ]]);
        break;
    
    case 'recentOrders':
        $agentId = $_SESSION['agent_id'];
        $stmt = $db->prepare("SELECT o.id, o.order_no, o.product_name, o.quantity, o.amount, o.create_time 
            FROM agent_orders o 
            WHERE o.agent_id = ? AND o.status = 1 
            ORDER BY o.create_time DESC 
            LIMIT 5");
        $stmt->execute([$agentId]);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
    
    case 'software':
        $agentId = $_SESSION['agent_id'];
        
        // 获取代理允许的软件
        $stmt = $db->prepare("SELECT allowed_software FROM agents WHERE id = ?");
        $stmt->execute([$agentId]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        $allowedSoftware = $agent['allowed_software'] ? json_decode($agent['allowed_software'], true) : null;
        
        // 获取软件列表
        $sql = "SELECT id, name FROM software WHERE status = 1";
        if ($allowedSoftware && count($allowedSoftware) > 0) {
            $placeholders = implode(',', array_fill(0, count($allowedSoftware), '?'));
            $sql .= " AND id IN ($placeholders)";
            $stmt = $db->prepare($sql);
            $stmt->execute($allowedSoftware);
        } else {
            $stmt = $db->query($sql);
        }
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
    
    case 'dashboard':
        $agentId = $_SESSION['agent_id'];
        
        // 获取代理信息
        $stmt = $db->prepare("SELECT balance, total_income, discount FROM agents WHERE id = ?");
        $stmt->execute([$agentId]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // 今日销售
        $stmt = $db->prepare("SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM agent_orders WHERE agent_id = ? AND DATE(create_time) = CURDATE() AND status = 1");
        $stmt->execute([$agentId]);
        $today = $stmt->fetch(PDO::FETCH_NUM);
        
        // 本月销售
        $stmt = $db->prepare("SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM agent_orders WHERE agent_id = ? AND DATE_FORMAT(create_time, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m') AND status = 1");
        $stmt->execute([$agentId]);
        $month = $stmt->fetch(PDO::FETCH_NUM);
        
        // 总销售
        $stmt = $db->prepare("SELECT COUNT(*) FROM agent_orders WHERE agent_id = ? AND status = 1");
        $stmt->execute([$agentId]);
        $totalOrders = $stmt->fetchColumn();
        
        echo json_encode(['code' => 0, 'data' => [
            'balance' => floatval($agent['balance']),
            'total_income' => floatval($agent['total_income']),
            'discount' => floatval($agent['discount']),
            'today_orders' => intval($today[0]),
            'today_amount' => floatval($today[1]),
            'month_orders' => intval($month[0]),
            'month_amount' => floatval($month[1]),
            'total_orders' => intval($totalOrders)
        ]]);
        break;
    
    case 'products':
        $softwareId = intval($_GET['software_id'] ?? 0);
        if ($softwareId <= 0) {
            echo json_encode(['code' => 0, 'data' => []]);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 获取代理折扣和允许的软件
        $stmt = $db->prepare("SELECT discount, allowed_software FROM agents WHERE id = ?");
        $stmt->execute([$agentId]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        $discount = floatval($agent['discount']);
        $allowedSoftware = $agent['allowed_software'] ? json_decode($agent['allowed_software'], true) : null;
        
        // 检查是否有权限
        if ($allowedSoftware && count($allowedSoftware) > 0 && !in_array($softwareId, $allowedSoftware)) {
            echo json_encode(['code' => 0, 'data' => []]);
            break;
        }
        
        // 获取商品列表，实时计算库存（从关联的未使用卡密数量）
        $stmt = $db->prepare("SELECT p.*, 
                (SELECT COUNT(*) FROM auth_codes WHERE product_id = p.id AND status = 0) as real_stock
                FROM products p 
                WHERE p.software_id = ? AND p.status = 1 
                ORDER BY p.sort_order DESC, p.id ASC");
        $stmt->execute([$softwareId]);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 计算代理价格，用实时库存替换stock字段
        foreach ($list as &$item) {
            // 优先使用商品设置的代理价格，如果没有则用原价乘以折扣
            $agentPrice = floatval($item['agent_price'] ?? 0);
            if ($agentPrice <= 0) {
                $agentPrice = round($item['price'] * $discount, 2);
            }
            $item['agent_price'] = $agentPrice;
            $item['stock'] = intval($item['real_stock']);
            unset($item['real_stock']);
        }
        
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
    
    case 'buy':
        $input = json_decode(file_get_contents('php://input'), true);
        $productId = intval($input['product_id'] ?? 0);
        $quantity = max(1, min(100, intval($input['quantity'] ?? 1)));
        
        if ($productId <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 获取代理信息
        $stmt = $db->prepare("SELECT * FROM agents WHERE id = ?");
        $stmt->execute([$agentId]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // 获取商品信息
        $stmt = $db->prepare("SELECT p.*, s.name as software_name FROM products p LEFT JOIN software s ON p.software_id = s.id WHERE p.id = ? AND p.status = 1");
        $stmt->execute([$productId]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$product) {
            echo json_encode(['code' => 1, 'msg' => '商品不存在或已下架']);
            break;
        }
        
        // 检查是否有权限购买该软件
        $allowedSoftware = $agent['allowed_software'] ? json_decode($agent['allowed_software'], true) : null;
        if ($allowedSoftware && !in_array($product['software_id'], $allowedSoftware)) {
            echo json_encode(['code' => 1, 'msg' => '无权购买该软件的授权码']);
            break;
        }
        
        // 实时检查库存（从关联的未使用卡密数量）
        $stmt = $db->prepare("SELECT COUNT(*) FROM auth_codes WHERE product_id = ? AND status = 0");
        $stmt->execute([$productId]);
        $stock = intval($stmt->fetchColumn());
        
        if ($stock < $quantity) {
            echo json_encode(['code' => 1, 'msg' => '库存不足，当前库存: ' . $stock]);
            break;
        }
        
        // 计算价格 - 优先使用商品的代理价格，如果没有则用原价乘以折扣
        $agentPrice = floatval($product['agent_price'] ?? 0);
        if ($agentPrice <= 0) {
            // 如果没有设置代理价格，使用原价乘以代理折扣
            $agentPrice = round($product['price'] * floatval($agent['discount']), 2);
        }
        $unitPrice = $agentPrice;
        $totalAmount = $unitPrice * $quantity;
        
        if ($agent['balance'] < $totalAmount) {
            echo json_encode(['code' => 1, 'msg' => '余额不足，请先充值']);
            break;
        }
        
        try {
            $db->beginTransaction();
            
            // 扣除余额
            $stmt = $db->prepare("UPDATE agents SET balance = balance - ? WHERE id = ?");
            $stmt->execute([$totalAmount, $agentId]);
            
            // 从已有卡密中发放（获取关联该商品的未使用卡密）
            $limitNum = intval($quantity);
            $stmt = $db->prepare("SELECT id, code FROM auth_codes WHERE product_id = ? AND status = 0 LIMIT $limitNum");
            $stmt->execute([$productId]);
            $availableCodes = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (count($availableCodes) < $quantity) {
                $db->rollBack();
                echo json_encode(['code' => 1, 'msg' => '库存不足，请稍后重试']);
                break;
            }
            
            $codes = [];
            $codeIds = [];
            foreach ($availableCodes as $codeRow) {
                $codes[] = $codeRow['code'];
                $codeIds[] = $codeRow['id'];
            }
            
            // 标记卡密归属代理商，并从商品库存中移除（设置product_id=NULL）
            // 这样商品库存会实时减少
            $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
            $stmt = $db->prepare("UPDATE auth_codes SET product_id = NULL, agent_id = ? WHERE id IN ($placeholders)");
            $stmt->execute(array_merge([$agentId], $codeIds));
            
            // 创建代理商订单
            $orderNo = 'A' . date('YmdHis') . mt_rand(1000, 9999);
            $stmt = $db->prepare("INSERT INTO agent_orders (order_no, agent_id, software_id, product_id, product_name, quantity, unit_price, amount, auth_codes, status, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())");
            $stmt->execute([$orderNo, $agentId, $product['software_id'], $productId, $product['name'], $quantity, $unitPrice, $totalAmount, json_encode($codes)]);
            
            // 同时创建总后台订单记录（让总后台也能看到代理商的订单）
            $mainOrderNo = 'AG' . date('YmdHis') . mt_rand(1000, 9999);
            $buyerInfo = json_encode(['type' => 'agent', 'agent_id' => $agentId, 'agent_name' => $agent['nickname'] ?: $agent['username']], JSON_UNESCAPED_UNICODE);
            $stmt = $db->prepare("INSERT INTO orders (order_no, software_id, product_id, product_name, quantity, amount, pay_amount, status, pay_time, auth_codes, buyer_info, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW(), ?, ?, NOW())");
            $stmt->execute([$mainOrderNo, $product['software_id'], $productId, $product['name'], $quantity, $totalAmount, $totalAmount, json_encode($codes), $buyerInfo]);
            
            // 更新商品销量
            $stmt = $db->prepare("UPDATE products SET sales = sales + ? WHERE id = ?");
            $stmt->execute([$quantity, $productId]);

            $db->commit();
            
            // 获取新余额（从数据库重新读取确保准确）
            $stmt = $db->prepare("SELECT balance FROM agents WHERE id = ?");
            $stmt->execute([$agentId]);
            $newBalance = floatval($stmt->fetchColumn());
            
            echo json_encode(['code' => 0, 'msg' => '购买成功', 'balance' => $newBalance, 'data' => ['codes' => $codes, 'order_no' => $orderNo]]);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '购买失败: ' . $e->getMessage()]);
        }
        break;
    
    case 'orders':
        $agentId = $_SESSION['agent_id'];
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = 20;
        $offset = ($page - 1) * $pageSize;
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM agent_orders WHERE agent_id = ?");
        $stmt->execute([$agentId]);
        $total = $stmt->fetchColumn();
        
        $stmt = $db->prepare("SELECT o.*, s.name as software_name FROM agent_orders o LEFT JOIN software s ON o.software_id = s.id WHERE o.agent_id = ? ORDER BY o.id DESC LIMIT $offset, $pageSize");
        $stmt->execute([$agentId]);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        break;
    
    case 'codes':
        $agentId = $_SESSION['agent_id'];
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(10, min(100, intval($_GET['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;
        
        // 直接通过agent_id查询卡密（更高效）
        $where = "c.agent_id = ?";
        $params = [$agentId];
        
        // 软件筛选
        if (!empty($_GET['software_id'])) {
            $where .= " AND c.software_id = ?";
            $params[] = intval($_GET['software_id']);
        }
        
        // 状态筛选
        if (isset($_GET['status']) && $_GET['status'] !== '') {
            $where .= " AND c.status = ?";
            $params[] = intval($_GET['status']);
        }
        
        // 关键词搜索
        if (!empty($_GET['keyword'])) {
            $keyword = '%' . $_GET['keyword'] . '%';
            $where .= " AND (c.code LIKE ? OR c.machine_code LIKE ?)";
            $params[] = $keyword;
            $params[] = $keyword;
        }
        
        // 获取总数
        $stmt = $db->prepare("SELECT COUNT(*) FROM auth_codes c WHERE $where");
        $stmt->execute($params);
        $total = intval($stmt->fetchColumn());
        
        // 获取分页数据
        $stmt = $db->prepare("SELECT c.*, s.name as software_name FROM auth_codes c LEFT JOIN software s ON c.software_id = s.id WHERE $where ORDER BY c.id DESC LIMIT $offset, $pageSize");
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        break;
    
    case 'withdraw':
        $input = json_decode(file_get_contents('php://input'), true);
        $amount = floatval($input['amount'] ?? 0);
        $accountType = trim($input['account_type'] ?? '支付宝');
        $accountName = trim($input['real_name'] ?? '');
        $accountNo = trim($input['account'] ?? '');
        
        // 转换提现方式
        $typeMap = ['支付宝' => 'alipay', '微信' => 'wechat', '银行卡' => 'bank'];
        $withdrawType = $typeMap[$accountType] ?? 'alipay';
        
        if ($amount < 10) {
            echo json_encode(['code' => 1, 'msg' => '最低提现金额为10元']);
            break;
        }
        if (empty($accountNo) || empty($accountName)) {
            echo json_encode(['code' => 1, 'msg' => '请填写收款账号和真实姓名']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 检查余额
        $stmt = $db->prepare("SELECT balance FROM agents WHERE id = ?");
        $stmt->execute([$agentId]);
        $balance = floatval($stmt->fetchColumn());
        
        if ($balance < $amount) {
            echo json_encode(['code' => 1, 'msg' => '余额不足']);
            break;
        }
        
        // 计算手续费（2%）
        $fee = round($amount * 0.02, 2);
        $actualAmount = $amount - $fee;
        
        try {
            $db->beginTransaction();
            
            // 扣除余额
            $stmt = $db->prepare("UPDATE agents SET balance = balance - ? WHERE id = ?");
            $stmt->execute([$amount, $agentId]);
            
            // 创建提现记录
            $stmt = $db->prepare("INSERT INTO agent_withdraws (agent_id, amount, fee, actual_amount, withdraw_type, account_type, account_name, account_no, status, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, NOW())");
            $stmt->execute([$agentId, $amount, $fee, $actualAmount, $withdrawType, $accountType, $accountName, $accountNo]);
            
            $db->commit();
            
            // 发送通知
            require_once __DIR__ . '/../api/notifier.php';
            $notifier = new Notifier($db);
            $notifier->send('withdraw_apply', '代理商提现申请', 
                "代理商ID: {$agentId}\n提现金额: ¥{$amount}\n手续费: ¥{$fee}\n实际到账: ¥{$actualAmount}\n收款方式: {$accountType}\n收款账号: {$accountNo}\n收款人: {$accountName}");
            
            // 返回新余额
            $newBalance = $balance - $amount;
            echo json_encode(['code' => 0, 'msg' => '提现申请已提交，请等待审核', 'balance' => $newBalance]);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '提现失败: ' . $e->getMessage()]);
        }
        break;
    
    case 'withdraws':
        $agentId = $_SESSION['agent_id'];
        
        $stmt = $db->prepare("SELECT * FROM agent_withdraws WHERE agent_id = ? ORDER BY id ASC LIMIT 50");
        $stmt->execute([$agentId]);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 转换字段名以适配前端
        $typeMap = ['alipay' => '支付宝', 'wechat' => '微信', 'bank' => '银行卡'];
        foreach ($list as &$item) {
            $item['status'] = intval($item['status']);
            $item['account_type'] = $typeMap[$item['withdraw_type']] ?? $item['withdraw_type'];
            $item['account'] = $item['account_no'];
            $item['real_name'] = $item['account_name'];
        }
        
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
    
    case 'profile':
        $input = json_decode(file_get_contents('php://input'), true);
        $agentId = $_SESSION['agent_id'];
        
        $sql = "UPDATE agents SET nickname = ?, qq = ?, email = ?";
        $params = [
            $input['nickname'] ?? '',
            $input['qq'] ?? '',
            $input['email'] ?? ''
        ];
        
        // 如果有密码则更新
        if (!empty($input['password'])) {
            $sql .= ", password = ?";
            $params[] = password_hash($input['password'], PASSWORD_DEFAULT);
        }
        
        $sql .= " WHERE id = ?";
        $params[] = $agentId;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        $_SESSION['agent_name'] = $input['nickname'] ?: $_SESSION['agent_name'];
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
    
    case 'batchExport':
        $input = json_decode(file_get_contents('php://input'), true);
        $codeIds = $input['ids'] ?? [];
        
        if (empty($codeIds)) {
            echo json_encode(['code' => 1, 'msg' => '请选择要导出的卡密']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 直接通过agent_id验证并获取卡密详情
        $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
        $stmt = $db->prepare("SELECT c.*, s.name as software_name FROM auth_codes c LEFT JOIN software s ON c.software_id = s.id WHERE c.id IN ($placeholders) AND c.agent_id = ?");
        $stmt->execute(array_merge($codeIds, [$agentId]));
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
    
    case 'batchDisable':
        $input = json_decode(file_get_contents('php://input'), true);
        $codeIds = $input['ids'] ?? [];
        
        if (empty($codeIds)) {
            echo json_encode(['code' => 1, 'msg' => '请选择要封禁的卡密']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 直接通过agent_id验证并封禁
        $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
        $stmt = $db->prepare("UPDATE auth_codes SET status = 2 WHERE id IN ($placeholders) AND agent_id = ?");
        $stmt->execute(array_merge($codeIds, [$agentId]));
        $count = $stmt->rowCount();
        
        if ($count == 0) {
            echo json_encode(['code' => 1, 'msg' => '没有可封禁的卡密']);
            break;
        }
        
        echo json_encode(['code' => 0, 'msg' => "成功封禁 {$count} 个卡密"]);
        break;
    
    case 'batchEnable':
        $input = json_decode(file_get_contents('php://input'), true);
        $codeIds = $input['ids'] ?? [];
        
        if (empty($codeIds)) {
            echo json_encode(['code' => 1, 'msg' => '请选择要解禁的卡密']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 直接通过agent_id验证并解禁
        $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
        $stmt = $db->prepare("UPDATE auth_codes SET status = 0 WHERE id IN ($placeholders) AND agent_id = ? AND status = 2");
        $stmt->execute(array_merge($codeIds, [$agentId]));
        $count = $stmt->rowCount();
        
        if ($count == 0) {
            echo json_encode(['code' => 1, 'msg' => '没有可解禁的卡密']);
            break;
        }
        
        echo json_encode(['code' => 0, 'msg' => "成功解禁 {$count} 个卡密"]);
        break;
    
    case 'enableCode':
        $input = json_decode(file_get_contents('php://input'), true);
        $codeId = intval($input['id'] ?? 0);
        
        if ($codeId <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 直接通过agent_id验证并启用
        $stmt = $db->prepare("UPDATE auth_codes SET status = 0 WHERE id = ? AND agent_id = ? AND status = 2");
        $stmt->execute([$codeId, $agentId]);
        
        if ($stmt->rowCount() == 0) {
            echo json_encode(['code' => 1, 'msg' => '无权操作该卡密或卡密状态不正确']);
            break;
        }
        
        echo json_encode(['code' => 0, 'msg' => '启用成功']);
        break;
    
    case 'disableCode':
        $input = json_decode(file_get_contents('php://input'), true);
        $codeId = intval($input['id'] ?? 0);
        
        if ($codeId <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 直接通过agent_id验证并禁用
        $stmt = $db->prepare("UPDATE auth_codes SET status = 2 WHERE id = ? AND agent_id = ?");
        $stmt->execute([$codeId, $agentId]);
        
        if ($stmt->rowCount() == 0) {
            echo json_encode(['code' => 1, 'msg' => '无权操作该卡密']);
            break;
        }
        
        echo json_encode(['code' => 0, 'msg' => '禁用成功']);
        break;
    
    case 'deleteCode':
        $input = json_decode(file_get_contents('php://input'), true);
        $codeId = intval($input['id'] ?? 0);
        
        if ($codeId <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 直接通过agent_id验证并删除
        $stmt = $db->prepare("DELETE FROM auth_codes WHERE id = ? AND agent_id = ?");
        $stmt->execute([$codeId, $agentId]);
        
        if ($stmt->rowCount() == 0) {
            echo json_encode(['code' => 1, 'msg' => '无权操作该卡密']);
            break;
        }
        
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    case 'batchDelete':
        $input = json_decode(file_get_contents('php://input'), true);
        $codeIds = $input['ids'] ?? [];
        
        if (empty($codeIds)) {
            echo json_encode(['code' => 1, 'msg' => '请选择要删除的卡密']);
            break;
        }
        
        $agentId = $_SESSION['agent_id'];
        
        // 直接通过agent_id验证并删除
        $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
        $stmt = $db->prepare("DELETE FROM auth_codes WHERE id IN ($placeholders) AND agent_id = ?");
        $stmt->execute(array_merge($codeIds, [$agentId]));
        $count = $stmt->rowCount();
        
        if ($count == 0) {
            echo json_encode(['code' => 1, 'msg' => '没有可删除的卡密']);
            break;
        }
        
        echo json_encode(['code' => 0, 'msg' => "成功删除 {$count} 个卡密"]);
        break;
    
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
