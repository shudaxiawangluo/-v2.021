<?php
session_start();
if (!isset($_SESSION['agent_id'])) {
    header('Location: login.php');
    exit;
}
require_once '../api/config.php';
$db = getDB();

// 获取代理信息并检查状态
$stmt = $db->prepare("SELECT * FROM agents WHERE id = ?");
$stmt->execute([$_SESSION['agent_id']]);
$agent = $stmt->fetch(PDO::FETCH_ASSOC);

// 如果代理不存在或已被禁用，强制退出
if (!$agent || $agent['status'] != 1) {
    session_destroy();
    header('Location: login.php?msg=disabled');
    exit;
}

// 确保数值字段有默认值
$agent['balance'] = floatval($agent['balance'] ?? 0);
$agent['discount'] = floatval($agent['discount'] ?? 1);
$agent['total_income'] = floatval($agent['total_income'] ?? 0);
$agent['total_withdraw'] = floatval($agent['total_withdraw'] ?? 0);

$currentPage = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>代理商后台 - 鼠大侠网络验证</title>
    <link rel="stylesheet" href="../admin/assets/libs/element-plus.min.css">
    <link rel="stylesheet" href="../admin/assets/libs/dark.css">
    <script src="../admin/assets/libs/vue.min.js"></script>
    <script src="../admin/assets/libs/element-plus.min.js"></script>
    <script src="../admin/assets/libs/icons-vue.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; }
        html.dark { color-scheme: dark; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif; background: var(--el-bg-color-page); }
        [v-cloak] { display: none; }
        .layout { display: flex; height: 100vh; }
        .sidebar { width: 220px; background: var(--el-bg-color); border-right: 1px solid var(--el-border-color); display: flex; flex-direction: column; flex-shrink: 0; }
        .logo { height: 56px; display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 15px; font-weight: 500; color: var(--el-text-color-primary); padding: 0 16px; }
        .logo img { height: 32px; width: 32px; object-fit: contain; }
        .el-menu { border: none; flex: 1; overflow-y: auto; padding: 8px 12px; }
        .el-menu-item { height: 40px !important; line-height: 40px !important; border-radius: 6px !important; margin-bottom: 4px !important; font-size: 14px !important; }
        .el-menu-item.is-active { background-color: #e6f7ff !important; color: #1890ff !important; font-weight: 500 !important; }
        .el-menu-item:hover { background-color: #f5f7fa !important; }
        html.dark .el-menu-item:hover { background-color: rgba(255, 255, 255, 0.05) !important; }
        html.dark .el-menu-item.is-active { background-color: rgba(64, 158, 255, 0.15) !important; }
        .main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .header { height: 56px; background: var(--el-bg-color); padding: 0 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--el-border-color-light); }
        .content { flex: 1; padding: 16px; overflow-y: auto; background: var(--el-bg-color-page); }
        .user-avatar { width: 28px; height: 28px; border-radius: 4px; background: var(--el-color-primary); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 14px; }
        
        /* 统计卡片样式 - 和总后台一致 */
        .stat-item { 
            padding: 16px 20px; 
            background: var(--el-bg-color-overlay); 
            border-radius: 8px; 
            border: 1px solid var(--el-border-color-lighter);
            transition: all 0.3s;
        }
        .stat-item:hover {
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
            transform: translateY(-2px);
        }
        .stat-item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }
        .stat-title { font-size: 13px; color: var(--el-text-color-secondary); font-weight: 400; }
        .stat-icon {
            width: 36px; height: 36px; border-radius: 8px;
            display: flex; align-items: center; justify-content: center; font-size: 18px;
        }
        .stat-value { font-size: 28px; font-weight: 600; margin-bottom: 10px; line-height: 1; color: var(--el-text-color-primary); }
        .stat-footer { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--el-text-color-secondary); }
        .color-blue { color: #409eff; }
        .color-green { color: #67c23a; }
        .color-orange { color: #e6a23c; }
        .color-purple { color: #9c27b0; }
        .bg-blue { background-color: rgba(64, 158, 255, 0.1); }
        .bg-green { background-color: rgba(103, 194, 58, 0.1); }
        .bg-orange { background-color: rgba(230, 162, 60, 0.1); }
        .bg-purple { background-color: rgba(156, 39, 176, 0.1); }
    </style>
</head>
<body>
    <div id="app" v-cloak>
        <div class="layout">
            <div class="sidebar">
                <div class="logo">
                    <img src="../img/鼠大侠logo.png" alt="Logo">
                    <span>代理商后台</span>
                </div>
                <el-menu :default-active="currentPage" @select="handleMenuSelect">
                    <el-menu-item index="dashboard"><el-icon><Odometer /></el-icon><span>控制台</span></el-menu-item>
                    <el-menu-item index="buy"><el-icon><shopping-cart /></el-icon><span>购买授权码</span></el-menu-item>
                    <el-menu-item index="orders"><el-icon><List /></el-icon><span>我的订单</span></el-menu-item>
                    <el-menu-item index="codes"><el-icon><Key /></el-icon><span>授权码管理</span></el-menu-item>
                    <el-menu-item index="withdraw"><el-icon><Wallet /></el-icon><span>提现管理</span></el-menu-item>
                    <el-menu-item index="profile"><el-icon><User /></el-icon><span>个人中心</span></el-menu-item>
                </el-menu>
            </div>

            <div class="main">
                <div class="header">
                    <div style="font-size: 14px; color: var(--el-text-color-regular);">
                        余额：<span style="color: #e6a23c; font-weight: 500;">¥{{ agentInfo.balance || 0 }}</span>
                        &nbsp;&nbsp;|&nbsp;&nbsp;
                        折扣：<span style="color: #409eff;">{{ formatDiscount(agentInfo.discount) }}%</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 20px;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span style="font-size: 13px; color: var(--el-text-color-secondary);">切换主题</span>
                            <el-switch v-model="isDark" size="small" @change="toggleDark" />
                        </div>
                        <el-dropdown @command="handleCommand">
                            <span style="cursor: pointer; display: flex; align-items: center; gap: 8px;">
                                <div class="user-avatar"><el-icon><User /></el-icon></div>
                                <span style="font-size: 13px;">{{ agentInfo.nickname || agentInfo.username }}</span>
                                <el-icon :size="12"><ArrowDown /></el-icon>
                            </span>
                            <template #dropdown>
                                <el-dropdown-menu>
                                    <el-dropdown-item command="profile"><el-icon><User /></el-icon>个人中心</el-dropdown-item>
                                    <el-dropdown-item divided command="logout"><el-icon><SwitchButton /></el-icon>退出登录</el-dropdown-item>
                                </el-dropdown-menu>
                            </template>
                        </el-dropdown>
                    </div>
                </div>

                <div class="content">
                    <!-- 控制台 -->
                    <div v-if="currentPage === 'dashboard'">
                        <el-row :gutter="16" style="margin-bottom: 16px;">
                            <el-col :span="4">
                                <div class="stat-item">
                                    <div class="stat-item-header">
                                        <span class="stat-title">账户余额</span>
                                        <div class="stat-icon bg-orange color-orange"><el-icon><wallet /></el-icon></div>
                                    </div>
                                    <div class="stat-value">¥{{ (agentInfo.balance || 0).toFixed(2) }}</div>
                                    <div class="stat-footer"><span>可用余额</span></div>
                                </div>
                            </el-col>
                            <el-col :span="4">
                                <div class="stat-item">
                                    <div class="stat-item-header">
                                        <span class="stat-title">我的折扣</span>
                                        <div class="stat-icon bg-purple color-purple"><el-icon><discount /></el-icon></div>
                                    </div>
                                    <div class="stat-value">{{ formatDiscount(agentInfo.discount) }}%</div>
                                    <div class="stat-footer"><span>进货折扣率</span></div>
                                </div>
                            </el-col>
                            <el-col :span="4">
                                <div class="stat-item">
                                    <div class="stat-item-header">
                                        <span class="stat-title">今日订单</span>
                                        <div class="stat-icon bg-blue color-blue"><el-icon><shopping-cart /></el-icon></div>
                                    </div>
                                    <div class="stat-value">{{ stats.todayOrders }}</div>
                                    <div class="stat-footer"><span>今日购买</span></div>
                                </div>
                            </el-col>
                            <el-col :span="4">
                                <div class="stat-item">
                                    <div class="stat-item-header">
                                        <span class="stat-title">累计订单</span>
                                        <div class="stat-icon bg-green color-green"><el-icon><list /></el-icon></div>
                                    </div>
                                    <div class="stat-value">{{ stats.totalOrders }}</div>
                                    <div class="stat-footer"><span>历史总计</span></div>
                                </div>
                            </el-col>
                            <el-col :span="4">
                                <div class="stat-item">
                                    <div class="stat-item-header">
                                        <span class="stat-title">卡密总数</span>
                                        <div class="stat-icon bg-blue color-blue"><el-icon><key /></el-icon></div>
                                    </div>
                                    <div class="stat-value">{{ stats.totalCodes || 0 }}</div>
                                    <div class="stat-footer"><span>拥有卡密</span></div>
                                </div>
                            </el-col>
                            <el-col :span="4">
                                <div class="stat-item">
                                    <div class="stat-item-header">
                                        <span class="stat-title">累计提现</span>
                                        <div class="stat-icon bg-green color-green"><el-icon><coin /></el-icon></div>
                                    </div>
                                    <div class="stat-value">¥{{ (agentInfo.total_withdraw || 0).toFixed(2) }}</div>
                                    <div class="stat-footer"><span>历史提现</span></div>
                                </div>
                            </el-col>
                        </el-row>
                        <el-row :gutter="16" style="margin-bottom: 16px;">
                            <el-col :span="12">
                                <el-card shadow="hover">
                                    <template #header>
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <span>今日销售</span>
                                            <el-tag type="success" size="small">{{ stats.todayOrders }}单</el-tag>
                                        </div>
                                    </template>
                                    <div style="text-align: center; padding: 30px 0;">
                                        <div style="font-size: 36px; color: #67c23a; font-weight: 500;">¥{{ stats.todayIncome }}</div>
                                        <div style="color: #909399; margin-top: 8px;">今日销售额</div>
                                    </div>
                                </el-card>
                            </el-col>
                            <el-col :span="12">
                                <el-card shadow="hover">
                                    <template #header>
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <span>本月销售</span>
                                            <el-tag type="primary" size="small">{{ stats.monthOrders }}单</el-tag>
                                        </div>
                                    </template>
                                    <div style="text-align: center; padding: 30px 0;">
                                        <div style="font-size: 36px; color: #409eff; font-weight: 500;">¥{{ stats.monthIncome }}</div>
                                        <div style="color: #909399; margin-top: 8px;">本月销售额</div>
                                    </div>
                                </el-card>
                            </el-col>
                        </el-row>
                        <el-row :gutter="16">
                            <el-col :span="16">
                                <el-card shadow="hover">
                                    <template #header>
                                        <div style="display: flex; justify-content: space-between; align-items: center;">
                                            <span>最近订单</span>
                                            <el-button type="primary" size="small" text @click="currentPage='orders'">查看全部</el-button>
                                        </div>
                                    </template>
                                    <el-table :data="recentOrders" v-loading="loadingRecent" size="small">
                                        <el-table-column prop="order_no" label="订单号" min-width="160">
                                            <template #default="scope">
                                                <span style="font-family: monospace; font-size: 12px;">{{ scope.row.order_no }}</span>
                                            </template>
                                        </el-table-column>
                                        <el-table-column prop="product_name" label="商品" min-width="100"></el-table-column>
                                        <el-table-column prop="quantity" label="数量" width="60" align="center"></el-table-column>
                                        <el-table-column label="金额" width="90" align="right">
                                            <template #default="scope">
                                                <span style="color: #e6a23c;">¥{{ scope.row.amount }}</span>
                                            </template>
                                        </el-table-column>
                                        <el-table-column prop="create_time" label="时间" width="150"></el-table-column>
                                    </el-table>
                                    <el-empty v-if="!loadingRecent && recentOrders.length === 0" description="暂无订单" :image-size="80"></el-empty>
                                </el-card>
                            </el-col>
                            <el-col :span="8">
                                <el-card shadow="hover">
                                    <template #header>快捷操作</template>
                                    <div style="display: flex; gap: 12px; justify-content: space-between;">
                                        <el-button type="primary" style="flex: 1;" @click="currentPage='buy'">
                                            <el-icon><shopping-cart /></el-icon>
                                            <span>购买授权码</span>
                                        </el-button>
                                        <el-button type="success" style="flex: 1;" @click="currentPage='codes'">
                                            <el-icon><key /></el-icon>
                                            <span>卡密管理</span>
                                        </el-button>
                                    </div>
                                    <div style="display: flex; gap: 12px; justify-content: space-between; margin-top: 12px;">
                                        <el-button type="warning" style="flex: 1;" @click="currentPage='withdraw'">
                                            <el-icon><wallet /></el-icon>
                                            <span>申请提现</span>
                                        </el-button>
                                        <el-button type="info" style="flex: 1;" @click="currentPage='profile'">
                                            <el-icon><user /></el-icon>
                                            <span>个人中心</span>
                                        </el-button>
                                    </div>
                                </el-card>
                            </el-col>
                        </el-row>
                    </div>

                    <!-- 购买授权码 -->
                    <div v-if="currentPage === 'buy'">
                        <el-card shadow="hover">
                            <template #header>购买授权码</template>
                            <el-form :model="buyForm" label-width="100px" style="max-width: 500px;">
                                <el-form-item label="选择软件">
                                    <el-select v-model="buyForm.software_id" placeholder="请选择软件" style="width: 100%;" @change="loadProducts">
                                        <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
                                    </el-select>
                                </el-form-item>
                                <el-form-item label="选择套餐">
                                    <el-select v-model="buyForm.product_id" placeholder="请选择套餐" style="width: 100%;">
                                        <el-option v-for="p in productList" :key="p.id" :label="p.name + ' - ¥' + p.agent_price + ' (库存:' + p.stock + ')'" :value="p.id" :disabled="p.stock <= 0"></el-option>
                                    </el-select>
                                </el-form-item>
                                <el-form-item label="当前库存" v-if="selectedProduct">
                                    <span :style="{color: selectedProduct.stock > 0 ? '#67c23a' : '#f56c6c', fontWeight: '500'}">{{ selectedProduct.stock }}</span>
                                    <span v-if="selectedProduct.stock <= 0" style="color: #f56c6c; margin-left: 10px;">库存不足，无法购买</span>
                                </el-form-item>
                                <el-form-item label="购买数量">
                                    <el-input-number v-model="buyForm.quantity" :min="1" :max="selectedProduct ? Math.min(100, selectedProduct.stock) : 100" :disabled="!selectedProduct || selectedProduct.stock <= 0"></el-input-number>
                                </el-form-item>
                                <el-form-item label="应付金额">
                                    <span style="font-size: 24px; color: #e6a23c; font-weight: 500;">¥{{ calculateTotal }}</span>
                                </el-form-item>
                                <el-form-item>
                                    <el-button type="primary" @click="handleBuy" :loading="buying" :disabled="!selectedProduct || selectedProduct.stock <= 0">立即购买</el-button>
                                </el-form-item>
                            </el-form>
                        </el-card>
                    </div>

                    <!-- 我的订单 -->
                    <div v-if="currentPage === 'orders'">
                        <el-card shadow="hover">
                            <el-table :data="orderList" v-loading="loading" stripe>
                                <el-table-column prop="id" label="ID" width="60"></el-table-column>
                                <el-table-column prop="order_no" label="订单号" min-width="180"></el-table-column>
                                <el-table-column prop="software_name" label="软件" min-width="100"></el-table-column>
                                <el-table-column prop="product_name" label="套餐" min-width="100"></el-table-column>
                                <el-table-column prop="quantity" label="数量" width="60"></el-table-column>
                                <el-table-column label="金额" width="100">
                                    <template #default="scope"><span style="color: #e6a23c;">¥{{ scope.row.amount }}</span></template>
                                </el-table-column>
                                <el-table-column label="状态" width="80">
                                    <template #default="scope">
                                        <el-tag :type="scope.row.status == 1 ? 'success' : 'info'" size="small">{{ scope.row.status == 1 ? '已完成' : '待处理' }}</el-tag>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="create_time" label="时间" min-width="150"></el-table-column>
                                <el-table-column label="操作" width="100">
                                    <template #default="scope">
                                        <el-button type="primary" size="small" @click="viewOrderCodes(scope.row)" v-if="scope.row.status == 1">查看卡密</el-button>
                                    </template>
                                </el-table-column>
                            </el-table>
                            <div style="margin-top: 16px; text-align: right;">
                                <el-pagination background layout="prev, pager, next" :total="orderTotal" :page-size="20" v-model:current-page="orderPage" @current-change="loadOrders"></el-pagination>
                            </div>
                        </el-card>
                    </div>

                    <!-- 授权码管理 -->
                    <div v-if="currentPage === 'codes'">
                        <el-card shadow="hover">
                            <div style="margin-bottom: 16px; display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
                                <el-select v-model="codeSearch.software_id" placeholder="选择软件" clearable style="width: 140px;" @change="loadCodes">
                                    <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
                                </el-select>
                                <el-select v-model="codeSearch.status" placeholder="状态" clearable style="width: 100px;" @change="loadCodes">
                                    <el-option label="未使用" :value="0"></el-option>
                                    <el-option label="已激活" :value="1"></el-option>
                                    <el-option label="已禁用" :value="2"></el-option>
                                    <el-option label="已过期" :value="3"></el-option>
                                </el-select>
                                <el-input v-model="codeSearch.keyword" placeholder="搜索卡密/机器码" clearable style="width: 180px;" @keyup.enter="loadCodes">
                                    <template #prefix><el-icon><Search /></el-icon></template>
                                </el-input>
                                <el-button type="primary" @click="loadCodes">搜索</el-button>
                                <div style="flex: 1;"></div>
                                <el-button type="success" @click="handleBatchCopy" :disabled="selectedCodes.length === 0">批量复制</el-button>
                                <el-button @click="handleBatchExport" :disabled="selectedCodes.length === 0">导出</el-button>
                                <el-button :type="batchToggleType" @click="handleBatchToggle" :disabled="selectedCodes.length === 0">{{ batchToggleText }}</el-button>
                                <el-button type="danger" @click="handleBatchDelete" :disabled="selectedCodes.length === 0">批量删除</el-button>
                            </div>
                            <el-table :data="codeList" v-loading="loading" stripe @selection-change="handleCodeSelectionChange" table-layout="auto">
                                <el-table-column type="selection" width="40" align="center"></el-table-column>
                                <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
                                <el-table-column prop="code" label="授权码" min-width="160" align="center">
                                    <template #default="scope">
                                        <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                                            <el-tooltip :content="scope.row.code" placement="top">
                                                <span style="font-family: monospace; font-size: 12px; color: #409eff;">{{ scope.row.code.substring(0, 12) }}...</span>
                                            </el-tooltip>
                                        </div>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="software_name" label="软件" min-width="80" align="center">
                                    <template #default="scope">
                                        <el-tooltip :content="scope.row.software_name" placement="top" v-if="scope.row.software_name && scope.row.software_name.length > 6">
                                            <span>{{ scope.row.software_name.substring(0, 6) }}...</span>
                                        </el-tooltip>
                                        <span v-else>{{ scope.row.software_name || '-' }}</span>
                                    </template>
                                </el-table-column>
                                <el-table-column label="有效期/点数" min-width="90" align="center">
                                    <template #default="scope">
                                        <el-tag v-if="scope.row.is_point_card == 1" size="small" type="warning">
                                            {{ scope.row.remaining_points || 0 }}/{{ scope.row.total_points || 0 }}点
                                        </el-tag>
                                        <el-tag v-else size="small" :type="getCardTypeColor(scope.row.card_type)">
                                            {{ formatDuration(scope.row) }}
                                        </el-tag>
                                    </template>
                                </el-table-column>
                                <el-table-column label="机器码" min-width="90" align="center">
                                    <template #default="scope">
                                        <template v-if="scope.row.machine_code">
                                            <el-tooltip :content="scope.row.machine_code" placement="top">
                                                <span style="font-family: monospace; font-size: 12px; color: #67c23a;">{{ scope.row.machine_code.substring(0, 8) }}...</span>
                                            </el-tooltip>
                                        </template>
                                        <span v-else style="color:#c0c4cc;">-</span>
                                    </template>
                                </el-table-column>
                                <el-table-column label="设备" min-width="50" align="center">
                                    <template #default="scope">
                                        <span>{{ scope.row.max_devices || 1 }}台</span>
                                    </template>
                                </el-table-column>
                                <el-table-column label="换绑" min-width="50" align="center">
                                    <template #default="scope">
                                        <template v-if="scope.row.allow_unbind">
                                            <span>{{ scope.row.unbind_count || 0 }}/{{ scope.row.max_unbind || 0 }}</span>
                                        </template>
                                        <span v-else style="color:#c0c4cc;">-</span>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="status" label="状态" min-width="70" align="center">
                                    <template #default="scope">
                                        <el-tag :type="getStatusType(scope.row.status)" size="small">{{ getStatusText(scope.row.status) }}</el-tag>
                                    </template>
                                </el-table-column>
                                <el-table-column label="生效时间" min-width="140" align="center">
                                    <template #default="scope">
                                        <span v-if="scope.row.activate_time">{{ scope.row.activate_time }}</span>
                                        <span v-else style="color: #c0c4cc;">未激活</span>
                                    </template>
                                </el-table-column>
                                <el-table-column label="到期时间" min-width="140" align="center">
                                    <template #default="scope">
                                        <span v-if="scope.row.expire_time">{{ scope.row.expire_time }}</span>
                                        <span v-else style="color: #c0c4cc;">-</span>
                                    </template>
                                </el-table-column>
                                <el-table-column label="操作" width="180" fixed="right" align="center">
                                    <template #default="scope">
                                        <div style="display: flex; gap: 4px; justify-content: center; flex-wrap: nowrap;">
                                            <el-button type="primary" size="small" @click="copyCode(scope.row.code)">复制</el-button>
                                            <el-button :type="scope.row.status == 2 ? 'success' : 'warning'" size="small" @click="handleToggleStatus(scope.row)">{{ scope.row.status == 2 ? '启用' : '禁用' }}</el-button>
                                            <el-button type="danger" size="small" @click="handleDeleteCode(scope.row)">删除</el-button>
                                        </div>
                                    </template>
                                </el-table-column>
                            </el-table>
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
                                <div style="display: flex; align-items: center; gap: 16px;">
                                    <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ codeTotal }}</b> 条</span>
                                    <el-select v-model="codePageSize" style="width: 110px;" @change="codePage = 1; loadCodes()">
                                        <el-option :value="20" label="20条/页"></el-option>
                                        <el-option :value="50" label="50条/页"></el-option>
                                        <el-option :value="100" label="100条/页"></el-option>
                                    </el-select>
                                </div>
                                <el-pagination background layout="prev, pager, next" :total="codeTotal" :page-size="codePageSize" v-model:current-page="codePage" @current-change="loadCodes"></el-pagination>
                            </div>
                        </el-card>
                    </div>

                    <!-- 提现管理 -->
                    <div v-if="currentPage === 'withdraw'">
                        <el-card shadow="hover" style="margin-bottom: 16px;">
                            <el-row :gutter="16">
                                <el-col :span="8">
                                    <el-statistic title="可提现余额" :value="agentInfo.balance" prefix="¥" :precision="2"></el-statistic>
                                </el-col>
                                <el-col :span="8">
                                    <el-statistic title="累计提现" :value="agentInfo.total_withdraw" prefix="¥" :precision="2"></el-statistic>
                                </el-col>
                                <el-col :span="8">
                                    <el-button type="primary" @click="showWithdrawDialog = true">申请提现</el-button>
                                </el-col>
                            </el-row>
                        </el-card>
                        <el-card shadow="hover">
                            <template #header>提现记录</template>
                            <el-table :data="withdrawList" v-loading="loading" stripe>
                                <el-table-column prop="id" label="ID" min-width="50"></el-table-column>
                                <el-table-column label="提现金额" min-width="90">
                                    <template #default="scope"><span style="color: #e6a23c;">¥{{ scope.row.amount }}</span></template>
                                </el-table-column>
                                <el-table-column label="手续费" min-width="70">
                                    <template #default="scope">¥{{ scope.row.fee }}</template>
                                </el-table-column>
                                <el-table-column label="实际到账" min-width="90">
                                    <template #default="scope"><span style="color: #67c23a;">¥{{ scope.row.actual_amount }}</span></template>
                                </el-table-column>
                                <el-table-column prop="account_type" label="方式" min-width="70"></el-table-column>
                                <el-table-column prop="account" label="账号" min-width="120"></el-table-column>
                                <el-table-column label="状态" min-width="80">
                                    <template #default="scope">
                                        <el-tag :type="{0:'warning',1:'success',2:'danger',3:'primary'}[scope.row.status]" size="small">{{ {0:'待审核',1:'已完成',2:'已拒绝',3:'处理中'}[scope.row.status] }}</el-tag>
                                    </template>
                                </el-table-column>
                                <el-table-column prop="create_time" label="申请时间" min-width="150"></el-table-column>
                                <el-table-column label="审核时间" min-width="150">
                                    <template #default="scope">{{ scope.row.audit_time || '-' }}</template>
                                </el-table-column>
                                <el-table-column label="备注" min-width="100">
                                    <template #default="scope">
                                        <span v-if="scope.row.status === 2" style="color: #f56c6c;">{{ scope.row.audit_remark || '-' }}</span>
                                        <span v-else>{{ scope.row.audit_remark || '-' }}</span>
                                    </template>
                                </el-table-column>
                            </el-table>
                        </el-card>
                    </div>

                    <!-- 个人中心 -->
                    <div v-if="currentPage === 'profile'">
                        <el-card shadow="hover">
                            <template #header>个人信息</template>
                            <el-form :model="profileForm" label-width="100px" style="max-width: 500px;">
                                <el-form-item label="账号">
                                    <el-input v-model="agentInfo.username" disabled></el-input>
                                </el-form-item>
                                <el-form-item label="昵称">
                                    <el-input v-model="profileForm.nickname" placeholder="请输入昵称"></el-input>
                                </el-form-item>
                                <el-form-item label="QQ">
                                    <el-input v-model="profileForm.qq" placeholder="请输入QQ"></el-input>
                                </el-form-item>
                                <el-form-item label="邮箱">
                                    <el-input v-model="profileForm.email" placeholder="请输入邮箱"></el-input>
                                </el-form-item>
                                <el-form-item label="新密码">
                                    <el-input v-model="profileForm.password" type="password" placeholder="留空不修改" show-password></el-input>
                                </el-form-item>
                                <el-form-item>
                                    <el-button type="primary" @click="saveProfile">保存修改</el-button>
                                </el-form-item>
                            </el-form>
                        </el-card>
                    </div>
                </div>
            </div>
        </div>

        <!-- 提现对话框 -->
        <el-dialog v-model="showWithdrawDialog" title="申请提现" width="450px">
            <el-form :model="withdrawForm" label-width="100px">
                <el-form-item label="可提现余额">
                    <span style="font-size: 20px; color: #e6a23c;">¥{{ agentInfo.balance }}</span>
                </el-form-item>
                <el-form-item label="提现金额">
                    <el-input-number v-model="withdrawForm.amount" :min="10" :max="agentInfo.balance" :precision="2" style="width: 200px;"></el-input-number>
                </el-form-item>
                <el-form-item label="提现方式">
                    <el-radio-group v-model="withdrawForm.account_type">
                        <el-radio label="支付宝">支付宝</el-radio>
                        <el-radio label="微信">微信</el-radio>
                        <el-radio label="银行卡">银行卡</el-radio>
                    </el-radio-group>
                </el-form-item>
                <el-form-item label="收款账号">
                    <el-input v-model="withdrawForm.account" placeholder="请输入收款账号"></el-input>
                </el-form-item>
                <el-form-item label="真实姓名">
                    <el-input v-model="withdrawForm.real_name" placeholder="请输入真实姓名"></el-input>
                </el-form-item>
            </el-form>
            <template #footer>
                <el-button @click="showWithdrawDialog = false">取消</el-button>
                <el-button type="primary" @click="submitWithdraw">提交申请</el-button>
            </template>
        </el-dialog>

        <!-- 查看卡密对话框 -->
        <el-dialog v-model="showCodesDialog" title="订单卡密" width="600px">
            <el-input type="textarea" :model-value="orderCodes" :rows="10" readonly style="font-family: monospace;"></el-input>
            <template #footer>
                <el-button @click="copyOrderCodes">复制全部</el-button>
                <el-button type="primary" @click="showCodesDialog = false">关闭</el-button>
            </template>
        </el-dialog>
    </div>

    <script>
        var app = Vue.createApp({
            data: function() {
                return {
                    isDark: false,
                    currentPage: '<?php echo $currentPage; ?>',
                    agentInfo: <?php echo json_encode($agent); ?>,
                    loading: false,
                    buying: false,
                    loadingRecent: false,
                    stats: { todayOrders: 0, totalOrders: 0, todayIncome: 0, monthIncome: 0, monthOrders: 0, totalCodes: 0 },
                    recentOrders: [],
                    softwareList: [],
                    productList: [],
                    buyForm: { software_id: '', product_id: '', quantity: 1 },
                    orderList: [],
                    orderPage: 1,
                    orderTotal: 0,
                    codeList: [],
                    codePage: 1,
                    codePageSize: 20,
                    codeTotal: 0,
                    codeSearch: { software_id: '', status: '', keyword: '' },
                    selectedCodes: [],
                    withdrawList: [],
                    showWithdrawDialog: false,
                    withdrawForm: { amount: 100, account_type: '支付宝', account: '', real_name: '' },
                    profileForm: { nickname: '', qq: '', email: '', password: '' },
                    showCodesDialog: false,
                    orderCodes: ''
                };
            },
            computed: {
                selectedProduct: function() {
                    var self = this;
                    if (!this.buyForm.product_id) return null;
                    return this.productList.find(function(p) { return p.id == self.buyForm.product_id; });
                },
                calculateTotal: function() {
                    var product = this.selectedProduct;
                    if (product) {
                        return (product.agent_price * this.buyForm.quantity).toFixed(2);
                    }
                    return '0.00';
                },
                batchToggleType: function() {
                    if (this.selectedCodes.length === 0) return 'warning';
                    var hasDisabled = this.selectedCodes.some(function(c) { return c.status == 2; });
                    return hasDisabled ? 'success' : 'warning';
                },
                batchToggleText: function() {
                    if (this.selectedCodes.length === 0) return '批量禁用';
                    var hasDisabled = this.selectedCodes.some(function(c) { return c.status == 2; });
                    return hasDisabled ? '批量启用' : '批量禁用';
                }
            },
            mounted: function() {
                var darkMode = localStorage.getItem('dark-mode');
                if (darkMode === 'true') {
                    this.isDark = true;
                    document.documentElement.classList.add('dark');
                }
                this.refreshAgentInfo();
                this.loadStats();
                this.loadSoftware();
                this.profileForm.nickname = this.agentInfo.nickname || '';
                this.profileForm.qq = this.agentInfo.qq || '';
                this.profileForm.email = this.agentInfo.email || '';
                if (this.currentPage === 'orders') this.loadOrders();
                if (this.currentPage === 'codes') this.loadCodes();
                if (this.currentPage === 'withdraw') this.loadWithdraws();
            },
            methods: {
                formatDiscount: function(discount) {
                    if (discount === null || discount === undefined || isNaN(discount)) return 100;
                    return Math.round(parseFloat(discount) * 100);
                },
                refreshAgentInfo: function() {
                    var self = this;
                    fetch('api.php?action=refresh').then(function(r) { return r.json(); }).then(function(data) {
                        if (data.code === 0) {
                            // 确保数值字段有默认值
                            var agentData = data.data;
                            agentData.balance = parseFloat(agentData.balance) || 0;
                            agentData.discount = parseFloat(agentData.discount) || 1;
                            agentData.total_income = parseFloat(agentData.total_income) || 0;
                            agentData.total_withdraw = parseFloat(agentData.total_withdraw) || 0;
                            
                            self.agentInfo = agentData;
                            self.profileForm.nickname = agentData.nickname || '';
                            self.profileForm.qq = agentData.qq || '';
                            self.profileForm.email = agentData.email || '';
                        }
                    });
                },
                toggleDark: function() {
                    if (this.isDark) {
                        document.documentElement.classList.add('dark');
                        localStorage.setItem('dark-mode', 'true');
                    } else {
                        document.documentElement.classList.remove('dark');
                        localStorage.setItem('dark-mode', 'false');
                    }
                },
                handleMenuSelect: function(index) {
                    this.currentPage = index;
                    window.history.pushState({}, '', '?page=' + index);
                    if (index === 'orders') this.loadOrders();
                    if (index === 'codes') this.loadCodes();
                    if (index === 'withdraw') this.loadWithdraws();
                },
                handleCommand: function(cmd) {
                    if (cmd === 'logout') window.location.href = 'logout.php';
                    else if (cmd === 'profile') this.handleMenuSelect('profile');
                },
                loadStats: function() {
                    var self = this;
                    fetch('api.php?action=stats').then(function(r) { return r.json(); }).then(function(data) {
                        if (data.code === 0) self.stats = data.data;
                    });
                    // 加载最近订单
                    if (this.currentPage === 'dashboard') {
                        this.loadingRecent = true;
                        fetch('api.php?action=recentOrders').then(function(r) { return r.json(); }).then(function(data) {
                            self.loadingRecent = false;
                            if (data.code === 0) self.recentOrders = data.data;
                        }).catch(function() {
                            self.loadingRecent = false;
                        });
                    }
                },
                loadSoftware: function() {
                    var self = this;
                    fetch('api.php?action=software').then(function(r) { return r.json(); }).then(function(data) {
                        if (data.code === 0) self.softwareList = data.data;
                    });
                },
                loadProducts: function() {
                    var self = this;
                    this.buyForm.product_id = '';
                    if (!this.buyForm.software_id) { this.productList = []; return; }
                    fetch('api.php?action=products&software_id=' + this.buyForm.software_id).then(function(r) { return r.json(); }).then(function(data) {
                        if (data.code === 0) self.productList = data.data;
                    });
                },
                handleBuy: function() {
                    var self = this;
                    if (!this.buyForm.software_id || !this.buyForm.product_id) {
                        ElementPlus.ElMessage.error('请选择软件和套餐');
                        return;
                    }
                    if (!this.selectedProduct || this.selectedProduct.stock <= 0) {
                        ElementPlus.ElMessage.error('库存不足');
                        return;
                    }
                    this.buying = true;
                    fetch('api.php?action=buy', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(this.buyForm)
                    }).then(function(r) { return r.json(); }).then(function(data) {
                        self.buying = false;
                        if (data.code === 0) {
                            ElementPlus.ElMessage.success(data.msg);
                            // 更新余额
                            self.agentInfo.balance = data.balance;
                            // 刷新统计数据
                            self.loadStats();
                            // 刷新商品列表（更新库存）
                            self.loadProducts();
                            // 重置购买数量
                            self.buyForm.quantity = 1;
                            // 刷新代理信息
                            self.refreshAgentInfo();
                        } else {
                            ElementPlus.ElMessage.error(data.msg);
                        }
                    }).catch(function() {
                        self.buying = false;
                        ElementPlus.ElMessage.error('网络错误');
                    });
                },
                loadOrders: function() {
                    var self = this;
                    this.loading = true;
                    fetch('api.php?action=orders&page=' + this.orderPage).then(function(r) { return r.json(); }).then(function(data) {
                        self.loading = false;
                        if (data.code === 0) {
                            self.orderList = data.data;
                            self.orderTotal = data.total;
                        }
                    });
                },
                viewOrderCodes: function(row) {
                    var codes = row.auth_codes ? JSON.parse(row.auth_codes) : [];
                    this.orderCodes = codes.join('\n');
                    this.showCodesDialog = true;
                },
                copyOrderCodes: function() {
                    var self = this;
                    navigator.clipboard.writeText(this.orderCodes).then(function() {
                        ElementPlus.ElMessage.success('已复制');
                    });
                },
                loadCodes: function() {
                    var self = this;
                    this.loading = true;
                    var params = new URLSearchParams({ action: 'codes', page: this.codePage, pageSize: this.codePageSize, ...this.codeSearch });
                    fetch('api.php?' + params).then(function(r) { return r.json(); }).then(function(data) {
                        self.loading = false;
                        if (data.code === 0) {
                            self.codeList = data.data;
                            self.codeTotal = data.total;
                        }
                    });
                },
                loadWithdraws: function() {
                    var self = this;
                    this.loading = true;
                    fetch('api.php?action=withdraws').then(function(r) { return r.json(); }).then(function(data) {
                        self.loading = false;
                        if (data.code === 0) self.withdrawList = data.data;
                    });
                },
                submitWithdraw: function() {
                    var self = this;
                    if (this.withdrawForm.amount < 10) {
                        ElementPlus.ElMessage.error('最低提现10元');
                        return;
                    }
                    if (!this.withdrawForm.account || !this.withdrawForm.real_name) {
                        ElementPlus.ElMessage.error('请填写完整信息');
                        return;
                    }
                    fetch('api.php?action=withdraw', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(this.withdrawForm)
                    }).then(function(r) { return r.json(); }).then(function(data) {
                        if (data.code === 0) {
                            ElementPlus.ElMessage.success(data.msg);
                            self.showWithdrawDialog = false;
                            self.agentInfo.balance = data.balance;
                            self.loadWithdraws();
                        } else {
                            ElementPlus.ElMessage.error(data.msg);
                        }
                    });
                },
                saveProfile: function() {
                    var self = this;
                    fetch('api.php?action=profile', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(this.profileForm)
                    }).then(function(r) { return r.json(); }).then(function(data) {
                        if (data.code === 0) {
                            ElementPlus.ElMessage.success(data.msg);
                            self.agentInfo.nickname = self.profileForm.nickname;
                        } else {
                            ElementPlus.ElMessage.error(data.msg);
                        }
                    });
                },
                handleCodeSelectionChange: function(selection) {
                    this.selectedCodes = selection;
                },
                copyCode: function(code) {
                    navigator.clipboard.writeText(code).then(function() {
                        ElementPlus.ElMessage.success('已复制');
                    });
                },
                handleBatchCopy: function() {
                    var self = this;
                    if (this.selectedCodes.length === 0) {
                        ElementPlus.ElMessage.warning('请选择要复制的卡密');
                        return;
                    }
                    var content = this.selectedCodes.map(function(c) { return c.code; }).join('\n');
                    navigator.clipboard.writeText(content).then(function() {
                        ElementPlus.ElMessage.success('已复制 ' + self.selectedCodes.length + ' 个卡密');
                    });
                },
                handleBatchExport: function() {
                    var self = this;
                    if (this.selectedCodes.length === 0) {
                        ElementPlus.ElMessage.warning('请选择要导出的卡密');
                        return;
                    }
                    var ids = this.selectedCodes.map(function(c) { return c.id; });
                    fetch('api.php?action=batchExport', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ ids: ids })
                    }).then(function(r) { return r.json(); }).then(function(data) {
                        if (data.code === 0) {
                            // 生成CSV格式
                            var csv = '\uFEFF授权码,软件,有效期,状态,机器码,生效时间,到期时间\n';
                            data.data.forEach(function(c) {
                                var status = c.status == 0 ? '未使用' : (c.status == 1 ? '已激活' : (c.status == 2 ? '已禁用' : '已过期'));
                                csv += c.code + ',' + (c.software_name || '') + ',' + (c.days || 0) + '天,' + status + ',' + (c.machine_code || '') + ',' + (c.activate_time || '') + ',' + (c.expire_time || '') + '\n';
                            });
                            var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
                            var url = URL.createObjectURL(blob);
                            var a = document.createElement('a');
                            a.href = url;
                            a.download = 'codes_' + new Date().toISOString().slice(0,10) + '.csv';
                            a.click();
                            URL.revokeObjectURL(url);
                            ElementPlus.ElMessage.success('已导出 ' + data.data.length + ' 个卡密');
                        } else {
                            ElementPlus.ElMessage.error(data.msg);
                        }
                    });
                },
                handleBatchToggle: function() {
                    var self = this;
                    if (this.selectedCodes.length === 0) {
                        ElementPlus.ElMessage.warning('请选择卡密');
                        return;
                    }
                    var hasDisabled = this.selectedCodes.some(function(c) { return c.status == 2; });
                    var action = hasDisabled ? 'batchEnable' : 'batchDisable';
                    var actionText = hasDisabled ? '启用' : '禁用';
                    
                    ElementPlus.ElMessageBox.confirm('确定要' + actionText + '选中的 ' + this.selectedCodes.length + ' 个卡密吗？', '确认' + actionText, {
                        type: 'warning'
                    }).then(function() {
                        var ids = self.selectedCodes.map(function(c) { return c.id; });
                        fetch('api.php?action=' + action, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ ids: ids })
                        }).then(function(r) { return r.json(); }).then(function(data) {
                            if (data.code === 0) {
                                ElementPlus.ElMessage.success(data.msg);
                                self.loadCodes();
                            } else {
                                ElementPlus.ElMessage.error(data.msg);
                            }
                        });
                    }).catch(function() {});
                },
                handleToggleStatus: function(row) {
                    var self = this;
                    var action = row.status == 2 ? 'enableCode' : 'disableCode';
                    var actionText = row.status == 2 ? '启用' : '禁用';
                    
                    ElementPlus.ElMessageBox.confirm('确定要' + actionText + '该卡密吗？', '确认' + actionText, {
                        type: 'warning'
                    }).then(function() {
                        fetch('api.php?action=' + action, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id: row.id })
                        }).then(function(r) { return r.json(); }).then(function(data) {
                            if (data.code === 0) {
                                ElementPlus.ElMessage.success(data.msg);
                                self.loadCodes();
                            } else {
                                ElementPlus.ElMessage.error(data.msg);
                            }
                        });
                    }).catch(function() {});
                },
                handleDeleteCode: function(row) {
                    var self = this;
                    ElementPlus.ElMessageBox.confirm('确定要删除该卡密吗？此操作不可恢复！', '确认删除', {
                        type: 'error'
                    }).then(function() {
                        fetch('api.php?action=deleteCode', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ id: row.id })
                        }).then(function(r) { return r.json(); }).then(function(data) {
                            if (data.code === 0) {
                                ElementPlus.ElMessage.success(data.msg);
                                self.loadCodes();
                            } else {
                                ElementPlus.ElMessage.error(data.msg);
                            }
                        });
                    }).catch(function() {});
                },
                getStatusType: function(status) {
                    var types = { 0: 'success', 1: 'primary', 2: 'danger', 3: 'info' };
                    return types[status] || 'info';
                },
                getStatusText: function(status) {
                    var texts = { 0: '未使用', 1: '已激活', 2: '已禁用', 3: '已过期' };
                    return texts[status] || '未知';
                },
                getCardTypeColor: function(type) {
                    var colors = { minute: 'info', hour: 'info', day: '', week: 'success', month: 'success', quarter: 'warning', year: 'warning', permanent: 'danger' };
                    return colors[type] || '';
                },
                formatDuration: function(row) {
                    var type = row.card_type;
                    var days = parseInt(row.days) || 0;
                    var minutes = parseInt(row.minutes) || 0;
                    if (type === 'permanent') return '永久';
                    switch (type) {
                        case 'minute': return (minutes > 0 ? minutes : days * 1440) + '分钟';
                        case 'hour': return (minutes > 0 ? Math.round(minutes / 60) : days * 24) + '小时';
                        case 'day': return days + '天';
                        case 'week': return Math.max(1, Math.round(days / 7)) + '周';
                        case 'month': return Math.max(1, Math.round(days / 30)) + '月';
                        case 'quarter': return Math.max(1, Math.round(days / 90)) + '季';
                        case 'year': return Math.max(1, Math.round(days / 365)) + '年';
                        default: return days + '天';
                    }
                },
                handleBatchDelete: function() {
                    var self = this;
                    if (this.selectedCodes.length === 0) {
                        ElementPlus.ElMessage.warning('请选择要删除的卡密');
                        return;
                    }
                    ElementPlus.ElMessageBox.confirm('确定要删除选中的 ' + this.selectedCodes.length + ' 个卡密吗？此操作不可恢复！', '确认删除', {
                        type: 'error'
                    }).then(function() {
                        var ids = self.selectedCodes.map(function(c) { return c.id; });
                        fetch('api.php?action=batchDelete', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ ids: ids })
                        }).then(function(r) { return r.json(); }).then(function(data) {
                            if (data.code === 0) {
                                ElementPlus.ElMessage.success(data.msg);
                                self.loadCodes();
                            } else {
                                ElementPlus.ElMessage.error(data.msg);
                            }
                        });
                    }).catch(function() {});
                }
            }
        });
        app.use(ElementPlus);
        for (var key in ElementPlusIconsVue) {
            app.component(key, ElementPlusIconsVue[key]);
        }
        app.mount('#app');
    </script>
</body>
</html>
