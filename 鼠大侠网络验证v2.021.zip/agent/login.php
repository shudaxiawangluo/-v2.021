<?php
session_start();
require_once '../api/config.php';

// 检测是否已安装
try {
    $db = getDB();
    $stmt = $db->query("SELECT COUNT(*) FROM admins");
    if ($stmt->fetchColumn() == 0) {
        header('Location: ../install.php');
        exit;
    }
} catch (Exception $e) {
    header('Location: ../install.php');
    exit;
}

// 登录失败限制
$maxAttempts = 5;
$lockoutTime = 900;

function getLoginAttempts($ip) {
    $file = sys_get_temp_dir() . '/agent_login_' . md5($ip) . '.json';
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        if (isset($data['lockout_until']) && time() > $data['lockout_until']) {
            unlink($file);
            return ['attempts' => 0, 'lockout_until' => 0];
        }
        return $data;
    }
    return ['attempts' => 0, 'lockout_until' => 0];
}

function recordLoginAttempt($ip, $success, $maxAttempts, $lockoutTime) {
    $file = sys_get_temp_dir() . '/agent_login_' . md5($ip) . '.json';
    if ($success) {
        if (file_exists($file)) unlink($file);
        return;
    }
    $data = getLoginAttempts($ip);
    $data['attempts']++;
    if ($data['attempts'] >= $maxAttempts) {
        $data['lockout_until'] = time() + $lockoutTime;
    }
    file_put_contents($file, json_encode($data));
}

$clientIP = $_SERVER['REMOTE_ADDR'];
$loginData = getLoginAttempts($clientIP);

if ($loginData['lockout_until'] > time()) {
    $remainingTime = ceil(($loginData['lockout_until'] - time()) / 60);
    $error = "登录尝试次数过多，请 {$remainingTime} 分钟后再试";
    $locked = true;
}

// 自动登录（从管理后台跳转）- 需要验证token
if (isset($_GET['auto_login']) && isset($_GET['token'])) {
    $username = $_GET['auto_login'];
    $token = $_GET['token'];
    
    // 验证token（token = md5(username + 当天日期 + 密钥)）
    $expectedToken = md5($username . date('Y-m-d') . 'shudaxia_agent_auto_login_secret');
    
    if ($token === $expectedToken) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM agents WHERE username = ? AND status = 1");
        $stmt->execute([$username]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($agent) {
            $_SESSION['agent_id'] = $agent['id'];
            $_SESSION['agent_name'] = $agent['username'];
            $_SESSION['agent_nickname'] = $agent['nickname'];
            header('Location: index.php');
            exit;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($locked)) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM agents WHERE username = ?");
    $stmt->execute([$username]);
    $agent = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($agent && password_verify($password, $agent['password'])) {
        if ($agent['status'] != 1) {
            $error = '账号已被禁用，请联系管理员';
        } else {
            recordLoginAttempt($clientIP, true, $maxAttempts, $lockoutTime);
            $_SESSION['agent_id'] = $agent['id'];
            $_SESSION['agent_name'] = $agent['username'];
            $_SESSION['agent_nickname'] = $agent['nickname'];
            
            // 更新登录信息
            $stmt = $db->prepare("UPDATE agents SET last_ip = ?, last_login = NOW() WHERE id = ?");
            $stmt->execute([$_SERVER['REMOTE_ADDR'], $agent['id']]);
            
            header('Location: index.php');
            exit;
        }
    } else {
        recordLoginAttempt($clientIP, false, $maxAttempts, $lockoutTime);
        $remainingAttempts = $maxAttempts - getLoginAttempts($clientIP)['attempts'];
        if ($remainingAttempts > 0) {
            $error = "用户名或密码错误，还剩 {$remainingAttempts} 次尝试机会";
        } else {
            $error = "登录尝试次数过多，账号已被锁定15分钟";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>代理商登录 - 鼠大侠网络验证</title>
    <link rel="stylesheet" href="https://unpkg.com/element-plus/dist/index.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://unpkg.com/element-plus"></script>
    <script src="https://unpkg.com/@element-plus/icons-vue"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; }
        body { font-family: 'Microsoft YaHei', Arial, sans-serif; }
        .login-container { display: flex; height: 100vh; }
        .login-left {
            flex: 1;
            background-color: #f5f7fa;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px;
            position: relative;
        }
        .page-logo {
            position: absolute;
            top: 30px;
            left: 40px;
            font-size: 20px;
            font-weight: 500;
            color: #303133;
            letter-spacing: 1px;
        }
        .login-left-content { text-align: center; }
        .login-left img {
            max-width: 500px;
            max-height: 500px;
            object-fit: contain;
        }
        .login-right {
            flex: 1;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 60px;
            position: relative;
        }
        .login-right::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
            border-radius: 50%;
            opacity: 0.3;
            z-index: 0;
        }
        .login-right::after {
            content: '';
            position: absolute;
            bottom: -80px;
            left: -80px;
            width: 250px;
            height: 250px;
            background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
            border-radius: 50%;
            opacity: 0.3;
            z-index: 0;
        }
        .login-form-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 380px;
        }
        .login-form-card {
            background: white;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.08);
        }
        .login-title {
            font-size: 26px;
            font-weight: 500;
            color: #303133;
            margin-bottom: 8px;
            text-align: center;
        }
        .login-subtitle {
            color: #909399;
            text-align: center;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .login-btn {
            width: 220px !important;
            margin: 0 auto;
            display: block;
        }
        .login-footer {
            text-align: center;
            margin-top: 24px;
            color: #909399;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div id="app">
        <div class="login-container">
            <div class="login-left">
                <div class="page-logo">鼠大侠网络验证 - 代理商系统</div>
                <div class="login-left-content">
                    <img src="../img/登录背景.png" alt="登录插画">
                </div>
            </div>
            
            <div class="login-right">
                <div class="login-form-wrapper">
                    <div class="login-form-card">
                        <h2 class="login-title">代理商登录</h2>
                        <p class="login-subtitle">请登录您的代理商账号</p>
                        
                        <el-form method="POST" @submit.prevent="handleSubmit">
                            <transition name="el-fade-in">
                                <el-alert 
                                    v-if="showError" 
                                    :title="errorMsg" 
                                    type="error" 
                                    show-icon
                                    :closable="true"
                                    @close="showError = false"
                                    style="margin-bottom: 20px;"
                                />
                            </transition>
                            
                            <el-form-item>
                                <el-input name="username" v-model="username" placeholder="请输入账号" size="default" clearable>
                                    <template #prefix><el-icon><User /></el-icon></template>
                                </el-input>
                            </el-form-item>
                            
                            <el-form-item>
                                <el-input name="password" v-model="password" type="password" placeholder="请输入密码" size="default" show-password>
                                    <template #prefix><el-icon><Lock /></el-icon></template>
                                </el-input>
                            </el-form-item>
                            
                            <el-form-item style="margin-bottom: 10px;">
                                <el-checkbox v-model="remember">记住密码</el-checkbox>
                            </el-form-item>
                            
                            <el-form-item style="margin-top: 24px;">
                                <el-button type="primary" native-type="submit" size="default" class="login-btn">登 录</el-button>
                            </el-form-item>
                        </el-form>
                        
                        <div class="login-footer">© 2026 鼠大侠网络验证 · 代理商系统</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var app = Vue.createApp({
            data: function() {
                return {
                    username: '',
                    password: '',
                    remember: false,
                    showError: <?php echo isset($error) ? 'true' : 'false'; ?>,
                    errorMsg: '<?php echo $error ?? ''; ?>'
                }
            },
            mounted: function() {
                var savedUsername = localStorage.getItem('agent_username');
                var savedPassword = localStorage.getItem('agent_password');
                var rememberMe = localStorage.getItem('agent_remember');
                
                if (rememberMe === 'true' && savedUsername && savedPassword) {
                    this.username = savedUsername;
                    this.password = savedPassword;
                    this.remember = true;
                }
                
                if (this.showError) {
                    var self = this;
                    setTimeout(function() { self.showError = false; }, 3000);
                }
            },
            methods: {
                handleSubmit: function(e) {
                    if (!this.username || !this.password) {
                        this.errorMsg = '请输入账号和密码';
                        this.showError = true;
                        var self = this;
                        setTimeout(function() { self.showError = false; }, 3000);
                        e.preventDefault();
                        return false;
                    }
                    
                    if (this.remember) {
                        localStorage.setItem('agent_username', this.username);
                        localStorage.setItem('agent_password', this.password);
                        localStorage.setItem('agent_remember', 'true');
                    } else {
                        localStorage.removeItem('agent_username');
                        localStorage.removeItem('agent_password');
                        localStorage.removeItem('agent_remember');
                    }
                    
                    e.target.submit();
                }
            }
        });
        app.use(ElementPlus);
        for (var key in ElementPlusIconsVue) {
            app.component(key, ElementPlusIconsVue[key]);
        }
        app.mount('#app');
    </script>
</body>
</html>
