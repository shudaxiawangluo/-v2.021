<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

switch ($action) {
    // 远程变量
    case 'list':
        $where = "1=1";
        $params = [];
        if (!empty($_GET['software_id'])) {
            $where .= " AND v.software_id = ?";
            $params[] = $_GET['software_id'];
        }
        if (!empty($_GET['keyword'])) {
            $where .= " AND v.var_name LIKE ?";
            $params[] = '%' . $_GET['keyword'] . '%';
        }
        $sql = "SELECT v.*, s.name as software_name FROM remote_vars v LEFT JOIN software s ON v.software_id = s.id WHERE $where ORDER BY v.id DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;
        
    case 'add_var':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("INSERT INTO remote_vars (software_id, var_name, var_value, var_type, description, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$input['software_id'], $input['var_name'] ?? $input['var_key'], $input['var_value'], $input['var_type'] ?? 'string', $input['description'] ?? '', $input['status'] ?? 1]);
        echo json_encode(['code' => 0, 'msg' => '添加成功']);
        break;
        
    case 'update_var':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("UPDATE remote_vars SET var_value = ?, var_type = ?, description = ?, status = ? WHERE id = ?");
        $stmt->execute([$input['var_value'], $input['var_type'] ?? 'string', $input['description'] ?? '', $input['status'] ?? 1, $input['id']]);
        echo json_encode(['code' => 0, 'msg' => '修改成功']);
        break;
        
    case 'delete_var':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("DELETE FROM remote_vars WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    // 公告管理
    case 'announcement_list':
        $where = "1=1";
        $params = [];
        if (!empty($_GET['software_id'])) {
            $where .= " AND (a.software_id = ? OR a.software_id = 0)";
            $params[] = $_GET['software_id'];
        }
        $sql = "SELECT a.*, a.is_popup as popup, s.name as software_name FROM announcements a LEFT JOIN software s ON a.software_id = s.id WHERE $where ORDER BY a.sort_order DESC, a.id DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;
        
    case 'add_announcement':
        $input = json_decode(file_get_contents('php://input'), true);
        $status = isset($input['status']) ? intval($input['status']) : 1;
        $showOnce = isset($input['show_once']) ? intval($input['show_once']) : 1;
        
        // 确保show_once字段存在
        try {
            $db->exec("ALTER TABLE announcements ADD COLUMN show_once TINYINT(1) DEFAULT 1 COMMENT '1=只显示一次,0=每次启动显示'");
        } catch (Exception $e) {}
        
        $stmt = $db->prepare("INSERT INTO announcements (software_id, title, content, type, is_popup, show_once, start_time, end_time, status, sort_order, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            intval($input['software_id'] ?? 0),
            $input['title'],
            $input['content'] ?? '',
            $input['type'] ?? 'notice',
            ($input['popup'] || $input['is_popup']) ? 1 : 0,
            $showOnce,
            !empty($input['start_time']) ? $input['start_time'] : null,
            !empty($input['end_time']) ? $input['end_time'] : null,
            $status,
            intval($input['sort_order'] ?? 0)
        ]);
        echo json_encode(['code' => 0, 'msg' => '添加成功']);
        break;
        
    case 'update_announcement':
        $input = json_decode(file_get_contents('php://input'), true);
        $status = isset($input['status']) ? intval($input['status']) : 1;
        $showOnce = isset($input['show_once']) ? intval($input['show_once']) : 1;
        
        // 确保show_once字段存在
        try {
            $db->exec("ALTER TABLE announcements ADD COLUMN show_once TINYINT(1) DEFAULT 1 COMMENT '1=只显示一次,0=每次启动显示'");
        } catch (Exception $e) {}
        
        $stmt = $db->prepare("UPDATE announcements SET software_id = ?, title = ?, content = ?, type = ?, is_popup = ?, show_once = ?, start_time = ?, end_time = ?, status = ?, sort_order = ? WHERE id = ?");
        $stmt->execute([
            intval($input['software_id'] ?? 0),
            $input['title'],
            $input['content'] ?? '',
            $input['type'] ?? 'notice',
            ($input['popup'] || $input['is_popup']) ? 1 : 0,
            $showOnce,
            !empty($input['start_time']) ? $input['start_time'] : null,
            !empty($input['end_time']) ? $input['end_time'] : null,
            $status,
            intval($input['sort_order'] ?? 0),
            $input['id']
        ]);
        echo json_encode(['code' => 0, 'msg' => '修改成功']);
        break;
        
    case 'toggle_announcement':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("UPDATE announcements SET status = ? WHERE id = ?");
        $stmt->execute([intval($input['status']), $input['id']]);
        echo json_encode(['code' => 0, 'msg' => '操作成功']);
        break;
        
    case 'delete_announcement':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("DELETE FROM announcements WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    // 版本管理
    case 'version_list':
        $where = "1=1";
        $params = [];
        if (!empty($_GET['software_id'])) {
            $where .= " AND v.software_id = ?";
            $params[] = $_GET['software_id'];
        }
        $sql = "SELECT v.*, s.name as software_name FROM versions v LEFT JOIN software s ON v.software_id = s.id WHERE $where ORDER BY v.version_code DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;
        
    case 'add_version':
        $input = json_decode(file_get_contents('php://input'), true);
        $status = isset($input['status']) ? intval($input['status']) : 1;
        $stmt = $db->prepare("INSERT INTO versions (software_id, version, version_code, title, changelog, download_url, file_size, file_md5, force_update, min_version, status, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            intval($input['software_id']),
            $input['version'],
            intval($input['version_code'] ?? 0),
            $input['title'] ?? '',
            $input['changelog'] ?? '',
            $input['download_url'] ?? '',
            $input['file_size'] ?? '',
            $input['file_md5'] ?? '',
            $input['force_update'] ? 1 : 0,
            $input['min_version'] ?? '',
            $status
        ]);
        echo json_encode(['code' => 0, 'msg' => '添加成功']);
        break;
        
    case 'update_version':
        $input = json_decode(file_get_contents('php://input'), true);
        $status = isset($input['status']) ? intval($input['status']) : 1;
        $stmt = $db->prepare("UPDATE versions SET version = ?, version_code = ?, title = ?, changelog = ?, download_url = ?, file_size = ?, file_md5 = ?, force_update = ?, min_version = ?, status = ? WHERE id = ?");
        $stmt->execute([
            $input['version'],
            intval($input['version_code'] ?? 0),
            $input['title'] ?? '',
            $input['changelog'] ?? '',
            $input['download_url'] ?? '',
            $input['file_size'] ?? '',
            $input['file_md5'] ?? '',
            $input['force_update'] ? 1 : 0,
            $input['min_version'] ?? '',
            $status,
            $input['id']
        ]);
        echo json_encode(['code' => 0, 'msg' => '修改成功']);
        break;
        
    case 'toggle_version':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("UPDATE versions SET status = ? WHERE id = ?");
        $stmt->execute([intval($input['status']), $input['id']]);
        echo json_encode(['code' => 0, 'msg' => '操作成功']);
        break;
        
    case 'delete_version':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("DELETE FROM versions WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    // 远程开关
    case 'switch_list':
        $where = "1=1";
        $params = [];
        if (!empty($_GET['software_id'])) {
            $where .= " AND sw.software_id = ?";
            $params[] = $_GET['software_id'];
        }
        $sql = "SELECT sw.*, s.name as software_name FROM remote_switches sw LEFT JOIN software s ON sw.software_id = s.id WHERE $where ORDER BY sw.id DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;
        
    case 'add_switch':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("INSERT INTO remote_switches (software_id, switch_key, switch_name, switch_value, description) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$input['software_id'], $input['switch_key'], $input['switch_name'] ?? '', $input['switch_value'] ?? ($input['is_enabled'] ? 1 : 0), $input['description'] ?? '']);
        echo json_encode(['code' => 0, 'msg' => '添加成功']);
        break;
        
    case 'update_switch':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("UPDATE remote_switches SET switch_name = ?, switch_value = ?, description = ? WHERE id = ?");
        $stmt->execute([$input['switch_name'] ?? '', $input['switch_value'] ?? ($input['is_enabled'] ? 1 : 0), $input['description'] ?? '', $input['id']]);
        echo json_encode(['code' => 0, 'msg' => '修改成功']);
        break;
        
    case 'toggle_switch':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("UPDATE remote_switches SET switch_value = ? WHERE id = ?");
        $stmt->execute([$input['switch_value'] ?? ($input['is_enabled'] ? 1 : 0), $input['id']]);
        echo json_encode(['code' => 0, 'msg' => '操作成功']);
        break;
        
    case 'delete_switch':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("DELETE FROM remote_switches WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
