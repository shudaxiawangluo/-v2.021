<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json; charset=utf-8');
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$db = getDB();

// 确保日志表存在
try {
    $db->exec("CREATE TABLE IF NOT EXISTS operation_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        admin_id INT DEFAULT 0,
        admin_name VARCHAR(50) DEFAULT '',
        action VARCHAR(255) NOT NULL,
        detail TEXT,
        ip VARCHAR(50) DEFAULT '',
        create_time DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
    $db->exec("CREATE TABLE IF NOT EXISTS runtime_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type VARCHAR(50) DEFAULT 'info',
        module VARCHAR(50) DEFAULT '',
        content TEXT,
        ip VARCHAR(50) DEFAULT '',
        user_id INT DEFAULT 0,
        software_id INT DEFAULT 0,
        create_time DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

// 获取POST数据
function getPostData() {
    $raw = file_get_contents('php://input');
    if (!empty($raw)) {
        $data = json_decode($raw, true);
        if (is_array($data)) return $data;
    }
    return $_POST;
}

switch ($action) {
    case 'operation_list':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, intval($_GET['pageSize'] ?? 20));
        $keyword = trim($_GET['keyword'] ?? '');
        $dateRange = trim($_GET['dateRange'] ?? '');
        
        $where = "1=1";
        $params = [];
        
        if ($keyword !== '') {
            $where .= " AND (action LIKE ? OR ip LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        if ($dateRange !== '') {
            $dates = explode(',', $dateRange);
            if (count($dates) == 2) {
                $where .= " AND create_time BETWEEN ? AND ?";
                $params[] = $dates[0] . ' 00:00:00';
                $params[] = $dates[1] . ' 23:59:59';
            }
        }
        
        try {
            $countStmt = $db->prepare("SELECT COUNT(*) FROM operation_logs WHERE $where");
            $countStmt->execute($params);
            $total = intval($countStmt->fetchColumn());
            
            $offset = ($page - 1) * $pageSize;
            $stmt = $db->prepare("SELECT * FROM operation_logs WHERE $where ORDER BY id DESC LIMIT $offset, $pageSize");
            $stmt->execute($params);
            $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '查询失败']);
        }
        break;
        
    case 'operation_clear':
        $input = getPostData();
        $mode = $input['mode'] ?? 'all';
        
        try {
            if ($mode === 'days') {
                $days = max(0, intval($input['days'] ?? 30));
                $stmt = $db->prepare("DELETE FROM operation_logs WHERE create_time < DATE_SUB(NOW(), INTERVAL ? DAY)");
                $stmt->execute([$days]);
                $deleted = $stmt->rowCount();
            } elseif ($mode === 'range') {
                $startDate = $input['startDate'] ?? '';
                $endDate = $input['endDate'] ?? '';
                if ($startDate && $endDate) {
                    $stmt = $db->prepare("DELETE FROM operation_logs WHERE create_time BETWEEN ? AND ?");
                    $stmt->execute([$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
                    $deleted = $stmt->rowCount();
                } else {
                    echo json_encode(['code' => 1, 'msg' => '请选择日期范围']);
                    exit;
                }
            } else {
                // 全部清理
                $stmt = $db->prepare("DELETE FROM operation_logs WHERE create_time <= NOW()");
                $stmt->execute();
                $deleted = $stmt->rowCount();
            }
            
            echo json_encode(['code' => 0, 'msg' => "成功清理 {$deleted} 条操作日志"]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '清理失败: ' . $e->getMessage()]);
        }
        break;

    case 'runtime_list':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, intval($_GET['pageSize'] ?? 20));
        $type = trim($_GET['type'] ?? '');
        $keyword = trim($_GET['keyword'] ?? '');
        $dateRange = trim($_GET['dateRange'] ?? '');
        
        $where = "1=1";
        $params = [];
        
        if ($type !== '') {
            $where .= " AND type = ?";
            $params[] = $type;
        }
        
        if ($keyword !== '') {
            $where .= " AND (content LIKE ? OR ip LIKE ? OR module LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        if ($dateRange !== '') {
            $dates = explode(',', $dateRange);
            if (count($dates) == 2) {
                $where .= " AND create_time BETWEEN ? AND ?";
                $params[] = $dates[0] . ' 00:00:00';
                $params[] = $dates[1] . ' 23:59:59';
            }
        }
        
        try {
            $countStmt = $db->prepare("SELECT COUNT(*) FROM runtime_logs WHERE $where");
            $countStmt->execute($params);
            $total = intval($countStmt->fetchColumn());
            
            $offset = ($page - 1) * $pageSize;
            $stmt = $db->prepare("SELECT * FROM runtime_logs WHERE $where ORDER BY id DESC LIMIT $offset, $pageSize");
            $stmt->execute($params);
            $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '查询失败']);
        }
        break;
        
    case 'runtime_clear':
        $input = getPostData();
        $mode = $input['mode'] ?? 'all';
        
        try {
            if ($mode === 'days') {
                $days = max(0, intval($input['days'] ?? 7));
                $stmt = $db->prepare("DELETE FROM runtime_logs WHERE create_time < DATE_SUB(NOW(), INTERVAL ? DAY)");
                $stmt->execute([$days]);
                $deleted = $stmt->rowCount();
            } elseif ($mode === 'range') {
                $startDate = $input['startDate'] ?? '';
                $endDate = $input['endDate'] ?? '';
                if ($startDate && $endDate) {
                    $stmt = $db->prepare("DELETE FROM runtime_logs WHERE create_time BETWEEN ? AND ?");
                    $stmt->execute([$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
                    $deleted = $stmt->rowCount();
                } else {
                    echo json_encode(['code' => 1, 'msg' => '请选择日期范围']);
                    exit;
                }
            } else {
                // 全部清理
                $stmt = $db->prepare("DELETE FROM runtime_logs WHERE create_time <= NOW()");
                $stmt->execute();
                $deleted = $stmt->rowCount();
            }
            
            echo json_encode(['code' => 0, 'msg' => "成功清理 {$deleted} 条运行日志"]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '清理失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'runtime_stats':
        try {
            $stats = [];
            $stmt = $db->query("SELECT type, COUNT(*) as count FROM runtime_logs GROUP BY type");
            $stats['byType'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt = $db->query("SELECT COUNT(*) FROM runtime_logs WHERE DATE(create_time) = CURDATE()");
            $stats['today'] = intval($stmt->fetchColumn());
            $stmt = $db->query("SELECT COUNT(*) FROM runtime_logs");
            $stats['total'] = intval($stmt->fetchColumn());
            echo json_encode(['code' => 0, 'data' => $stats]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '统计失败']);
        }
        break;

    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
