<?php
$pageTitle = '卡密管理';
$breadcrumbs = ['授权管理', '卡密管理'];

$pageStyles = "
.custom-pagination {
    display: flex;
    align-items: center;
    gap: 8px;
}
.custom-pagination .page-btn {
    min-width: 32px;
    height: 32px;
    padding: 0 10px;
    border: none;
    border-radius: 3px;
    background-color: #f4f4f5;
    color: #606266;
    font-size: 13px;
    font-weight: 400;
    cursor: pointer;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}
.custom-pagination .page-btn:hover:not(:disabled):not(.active) {
    color: #409eff;
}
.custom-pagination .page-btn.active {
    background-color: #409eff;
    color: #fff;
}
.custom-pagination .page-btn:disabled {
    cursor: not-allowed;
    color: #c0c4cc;
    background-color: #f4f4f5;
}
.custom-pagination .prev-btn,
.custom-pagination .next-btn {
    font-weight: bold;
}
";

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; flex-shrink: 0;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 140px;" @change="loadData">
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-select v-model="searchForm.card_type" placeholder="卡类型" clearable style="width: 110px;" @change="loadData">
            <el-option label="分钟卡" value="minute"></el-option>
            <el-option label="小时卡" value="hour"></el-option>
            <el-option label="天卡" value="day"></el-option>
            <el-option label="周卡" value="week"></el-option>
            <el-option label="月卡" value="month"></el-option>
            <el-option label="季卡" value="quarter"></el-option>
            <el-option label="年卡" value="year"></el-option>
            <el-option label="永久卡" value="permanent"></el-option>
        </el-select>
        <el-select v-model="searchForm.status" placeholder="状态" clearable style="width: 100px;" @change="loadData">
            <el-option label="未使用" :value="0"></el-option>
            <el-option label="已激活" :value="1"></el-option>
            <el-option label="已禁用" :value="2"></el-option>
            <el-option label="已过期" :value="3"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索卡密/机器码/用户" clearable style="width: 200px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <div style="display: flex; gap: 10px; align-items: center;">
        <el-button type="danger" :disabled="selectedRows.length === 0" @click="handleBatchDelete">删除选中</el-button>
        <el-button :type="batchToggleBtnType" :disabled="selectedRows.length === 0" @click="handleBatchToggle">{{ batchToggleBtnText }}</el-button>
        <el-button @click="handleExport">导出</el-button>
        <el-button type="primary" @click="showAddDialog = true"><el-icon><Plus /></el-icon>生成授权码</el-button>
    </div>
</div>

<el-card shadow="hover">
    <el-table :data="codeList" v-loading="loading" @selection-change="handleSelectionChange" stripe table-layout="auto">
        <el-table-column type="selection" width="40" align="center"></el-table-column>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="code" label="授权码" min-width="160" align="center">
            <template #default="scope">
                <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                    <el-tooltip :content="scope.row.code" placement="top">
                        <span class="code-text">{{ scope.row.code.substring(0, 12) }}...</span>
                    </el-tooltip>
                    <el-button link type="primary" size="small" @click="copyCode(scope.row.code)">
                        <el-icon><CopyDocument /></el-icon>
                    </el-button>
                </div>
            </template>
        </el-table-column>
        <el-table-column prop="software_name" label="软件" min-width="70" align="center">
            <template #default="scope">
                <el-tooltip :content="scope.row.software_name" placement="top" v-if="scope.row.software_name && scope.row.software_name.length > 5">
                    <span>{{ scope.row.software_name.substring(0, 5) }}...</span>
                </el-tooltip>
                <span v-else>{{ scope.row.software_name || '-' }}</span>
            </template>
        </el-table-column>
        <el-table-column label="有效期/点数" min-width="90" align="center">
            <template #default="scope">
                <el-tag v-if="scope.row.is_point_card == 1" size="small" type="warning">
                    {{ scope.row.remaining_points }}/{{ scope.row.total_points }}点
                </el-tag>
                <el-tag v-else size="small" :type="getCardTypeColor(scope.row.card_type)">
                    {{ formatDuration(scope.row) }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="机器码" min-width="90" align="center">
            <template #default="scope">
                <template v-if="scope.row.machine_code">
                    <el-tooltip :content="scope.row.machine_code" placement="top">
                        <span style="font-family: monospace; font-size: 12px; color: #67c23a;">{{ scope.row.machine_code.substring(0, 8) }}...</span>
                    </el-tooltip>
                </template>
                <span v-else style="color:#c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column label="设备" min-width="50" align="center">
            <template #default="scope">
                <span>{{ scope.row.max_devices || 1 }}台</span>
            </template>
        </el-table-column>
        <el-table-column label="换绑" min-width="50" align="center">
            <template #default="scope">
                <template v-if="scope.row.allow_unbind">
                    <span>{{ scope.row.unbind_count || 0 }}/{{ scope.row.max_unbind || 0 }}</span>
                </template>
                <span v-else style="color:#c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" min-width="70" align="center">
            <template #default="scope">
                <el-tag :type="getStatusType(scope.row.status)" size="small">{{ getStatusText(scope.row.status) }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column label="生效时间" min-width="140" align="center">
            <template #default="scope">
                <span v-if="scope.row.activate_time">{{ scope.row.activate_time }}</span>
                <span v-else style="color: #c0c4cc;">未激活</span>
            </template>
        </el-table-column>
        <el-table-column label="到期时间" min-width="140" align="center">
            <template #default="scope">
                <span v-if="scope.row.expire_time">{{ scope.row.expire_time }}</span>
                <span v-else style="color: #c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column label="操作" width="230" fixed="right" align="center">
            <template #default="scope">
                <div style="display: flex; gap: 4px; justify-content: center; flex-wrap: nowrap;">
                    <el-button type="primary" size="small" @click="copyCode(scope.row.code)">复制</el-button>
                    <el-button type="success" size="small" @click="handleRenew(scope.row)">续费</el-button>
                    <el-button type="warning" size="small" @click="handleUnbind(scope.row)" v-if="scope.row.machine_code && scope.row.allow_unbind && (scope.row.unbind_count || 0) < (scope.row.max_unbind || 0)">解绑</el-button>
                    <el-button :type="scope.row.status == 2 ? 'success' : 'warning'" size="small" @click="handleToggleStatus(scope.row)">{{ scope.row.status == 2 ? '启用' : '禁用' }}</el-button>
                    <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
                </div>
            </template>
        </el-table-column>
    </el-table>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
        <div style="display: flex; align-items: center; gap: 16px;">
            <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ pagination.total }}</b> 条</span>
            <el-select v-model="pagination.pageSize" style="width: 110px;" @change="pagination.page = 1; loadData()">
                <el-option :value="20" label="20条/页"></el-option>
                <el-option :value="50" label="50条/页"></el-option>
                <el-option :value="100" label="100条/页"></el-option>
            </el-select>
        </div>
        <div class="custom-pagination">
            <button @click="goPage(pagination.page - 1)" :disabled="pagination.page <= 1" class="page-btn prev-btn">&lt;</button>
            <button v-for="p in getPageList()" :key="p" @click="goPage(p)" :class="['page-btn', 'num-btn', p === pagination.page ? 'active' : '']">{{ p }}</button>
            <button @click="goPage(pagination.page + 1)" :disabled="pagination.page >= Math.ceil(pagination.total / pagination.pageSize)" class="page-btn next-btn">&gt;</button>
        </div>
    </div>
</el-card>

<!-- 生成授权码对话框 -->
<el-dialog v-model="showAddDialog" title="生成授权码" width="720px" :close-on-click-modal="false" class="gen-dialog">
    <el-form :model="addForm" label-width="100px" class="gen-form">
        <div class="section-title">基础设置</div>
        
        <el-form-item label="选择软件" required>
            <el-select v-model="addForm.software_id" placeholder="请选择软件" style="width: 100%;" @change="onSoftwareChange">
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        
        <el-form-item label="关联商品" v-if="productList.length > 0">
            <el-select v-model="addForm.product_id" placeholder="选择商品（可选）" clearable style="width: 100%;">
                <el-option v-for="p in productList" :key="p.id" :label="p.name + ' - ' + getCardTypeName(p.card_type)" :value="p.id"></el-option>
            </el-select>
            <div style="font-size: 12px; color: #909399; margin-top: 4px;">关联商品后，卡密将自动计入商品库存</div>
        </el-form-item>
        
        <el-form-item label="卡密类型" required>
            <el-radio-group v-model="addForm.is_point_card" @change="handleCardModeChange">
                <el-radio :label="0">时长卡</el-radio>
                <el-radio :label="1">点卡</el-radio>
            </el-radio-group>
        </el-form-item>
        
        <!-- 时长卡配置 -->
        <template v-if="addForm.is_point_card === 0">
            <el-form-item label="有效期类型" required>
                <el-select v-model="addForm.card_type" placeholder="请选择有效期" style="width: 200px;">
                    <el-option label="分钟卡" value="minute"></el-option>
                    <el-option label="小时卡" value="hour"></el-option>
                    <el-option label="天卡" value="day"></el-option>
                    <el-option label="周卡（7天）" value="week"></el-option>
                    <el-option label="月卡（30天）" value="month"></el-option>
                    <el-option label="季卡（90天）" value="quarter"></el-option>
                    <el-option label="年卡（365天）" value="year"></el-option>
                    <el-option label="永久卡" value="permanent"></el-option>
                </el-select>
                <template v-if="['minute','hour','day'].includes(addForm.card_type)">
                    <el-input-number v-model="addForm.duration" :min="1" :max="9999" class="num-input" style="margin-left: 16px;"></el-input-number>
                    <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">{{ {minute:'分钟',hour:'小时',day:'天'}[addForm.card_type] }}</span>
                </template>
            </el-form-item>
        </template>
        
        <!-- 点卡配置 -->
        <template v-if="addForm.is_point_card === 1">
            <el-form-item label="点数" required>
                <el-input-number v-model="addForm.points" :min="1" :max="999999" class="num-input"></el-input-number>
                <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">点</span>
            </el-form-item>
            
            <el-form-item label="扣点方式" required>
                <el-select v-model="addForm.deduct_type" style="width: 200px;">
                    <el-option label="按次扣点" value="per_use"></el-option>
                    <el-option label="按小时扣点" value="per_hour"></el-option>
                </el-select>
                <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">每次扣除</span>
                <el-input-number v-model="addForm.deduct_amount" :min="1" :max="999" class="num-input" style="margin-left: 10px; width: 100px;"></el-input-number>
                <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">点</span>
            </el-form-item>
        </template>
        
        <el-form-item label="激活方式">
            <el-radio-group v-model="addForm.activate_mode">
                <el-radio label="immediate">立即生效</el-radio>
                <el-radio label="first_use">首次使用生效</el-radio>
                <el-radio label="scheduled">定时生效</el-radio>
            </el-radio-group>
        </el-form-item>
        
        <el-form-item label="生效时间" v-if="addForm.activate_mode === 'scheduled'">
            <el-date-picker v-model="addForm.start_time" type="datetime" placeholder="选择生效时间" style="width: 220px;"></el-date-picker>
            <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">卡密在此时间后才能使用</span>
        </el-form-item>
        
        <el-form-item label="生成数量" required>
            <el-input-number v-model="addForm.count" :min="1" :max="10000" class="num-input"></el-input-number>
            <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">个</span>
        </el-form-item>
        
        <div class="section-title">设备绑定</div>
        
        <el-form-item label="设备数量">
            <el-input-number v-model="addForm.max_devices" :min="1" :max="99" class="num-input"></el-input-number>
            <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">允许绑定的最大设备数</span>
        </el-form-item>
        
        <el-form-item label="允许多开">
            <el-switch v-model="addForm.allow_multi"></el-switch>
        </el-form-item>
        
        <el-form-item label="允许换绑">
            <div class="switch-row">
                <el-switch v-model="addForm.allow_unbind"></el-switch>
                <template v-if="addForm.allow_unbind">
                    <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">最多</span>
                    <el-input-number v-model="addForm.max_unbind" :min="1" :max="99" size="small" style="width: 90px; margin: 0 10px;"></el-input-number>
                    <span style="color: #b0b0b0; font-size: 12px;">次</span>
                </template>
            </div>
        </el-form-item>
        
        <el-form-item label="单设备在线">
            <el-switch v-model="addForm.single_online"></el-switch>
        </el-form-item>
        
        <el-form-item label="预绑机器码">
            <el-switch v-model="addForm.pre_bind"></el-switch>
        </el-form-item>
        
        <el-form-item label="机器码列表" v-if="addForm.pre_bind">
            <el-input v-model="addForm.machine_codes" type="textarea" :rows="3" placeholder="每行一个机器码，数量需与生成数量一致"></el-input>
        </el-form-item>
        
        <div class="section-title">使用限制</div>
        
        <el-form-item label="IP限制">
            <div class="switch-row">
                <el-switch v-model="addForm.ip_limit"></el-switch>
                <template v-if="addForm.ip_limit">
                    <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">最多</span>
                    <el-input-number v-model="addForm.max_ip" :min="1" :max="99" size="small" style="width: 90px; margin: 0 10px;"></el-input-number>
                    <span style="color: #b0b0b0; font-size: 12px;">个IP</span>
                </template>
            </div>
        </el-form-item>
        
        <el-form-item label="使用次数">
            <div class="switch-row">
                <el-switch v-model="addForm.use_limit"></el-switch>
                <template v-if="addForm.use_limit">
                    <span style="margin-left: 10px; color: #b0b0b0; font-size: 12px;">最多</span>
                    <el-input-number v-model="addForm.max_use" :min="1" :max="9999" size="small" style="width: 100px; margin: 0 10px;"></el-input-number>
                    <span style="color: #b0b0b0; font-size: 12px;">次</span>
                </template>
            </div>
        </el-form-item>
        
        <el-form-item label="区域限制">
            <div class="switch-row">
                <el-switch v-model="addForm.region_limit"></el-switch>
                <template v-if="addForm.region_limit">
                    <el-select v-model="addForm.allowed_regions" multiple placeholder="选择允许的地区" style="width: 280px; margin-left: 10px;">
                        <el-option label="中国大陆" value="CN"></el-option>
                        <el-option label="香港" value="HK"></el-option>
                        <el-option label="台湾" value="TW"></el-option>
                        <el-option label="美国" value="US"></el-option>
                        <el-option label="日本" value="JP"></el-option>
                        <el-option label="韩国" value="KR"></el-option>
                        <el-option label="其他" value="OTHER"></el-option>
                    </el-select>
                </template>
            </div>
        </el-form-item>
        
        <div class="section-title">其他</div>
        
        <el-form-item label="备注">
            <el-input v-model="addForm.remark" placeholder="可选，标记用途如：双十一活动" maxlength="100"></el-input>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="handleGenerate" :loading="generating">
            <el-icon><Check /></el-icon>生成
        </el-button>
    </template>
</el-dialog>

<!-- 编辑授权码对话框 -->
<el-dialog v-model="showEditDialog" title="编辑授权码" width="550px">
    <el-form :model="editForm" label-width="100px">
        <el-form-item label="授权码">
            <el-input v-model="editForm.code" disabled>
                <template #append>
                    <el-button @click="copyCode(editForm.code)"><el-icon><CopyDocument /></el-icon></el-button>
                </template>
            </el-input>
        </el-form-item>
        <el-form-item label="绑定机器码">
            <el-input v-model="editForm.machine_code" placeholder="留空为未绑定状态">
                <template #append>
                    <el-button @click="editForm.machine_code = ''" v-if="editForm.machine_code">清空</el-button>
                </template>
            </el-input>
        </el-form-item>
        <el-form-item label="设备数量">
            <el-input-number v-model="editForm.max_devices" :min="1" :max="99" style="width: 150px;"></el-input-number>
            <span class="form-tip">台</span>
        </el-form-item>
        <el-form-item label="允许多开">
            <el-switch v-model="editForm.allow_multi"></el-switch>
        </el-form-item>
        <el-form-item label="允许换绑">
            <el-switch v-model="editForm.allow_unbind"></el-switch>
            <template v-if="editForm.allow_unbind">
                <span class="form-tip" style="margin-right: 8px;">最多</span>
                <el-input-number v-model="editForm.max_unbind" :min="1" :max="99" size="small" style="width: 80px;"></el-input-number>
                <span class="form-tip">次</span>
            </template>
        </el-form-item>
        <el-form-item label="已换绑次数" v-if="editForm.allow_unbind">
            <el-input-number v-model="editForm.unbind_count" :min="0" :max="editForm.max_unbind" style="width: 150px;"></el-input-number>
            <span class="form-tip">次</span>
        </el-form-item>
        <el-form-item label="备注">
            <el-input v-model="editForm.remark" type="textarea" :rows="2"></el-input>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showEditDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSaveEdit">保存</el-button>
    </template>
</el-dialog>

<!-- 生成结果对话框 -->
<el-dialog v-model="showResultDialog" title="生成成功" width="550px">
    <el-alert type="success" :closable="false" style="margin-bottom: 16px;">
        成功生成 {{ generatedCodes.length }} 个授权码
    </el-alert>
    <el-input type="textarea" :model-value="generatedCodes.join('\n')" :rows="12" readonly style="font-family: 'Courier New', monospace;"></el-input>
    <template #footer>
        <el-button @click="copyAllCodes">
            <el-icon><CopyDocument /></el-icon>复制全部
        </el-button>
        <el-button type="primary" @click="showResultDialog = false">关闭</el-button>
    </template>
</el-dialog>

<!-- 续费对话框 -->
<el-dialog v-model="showRenewDialog" :title="renewForm.is_point_card ? '充值点数' : '续费'" width="450px">
    <el-form :model="renewForm" label-width="100px">
        <el-form-item label="授权码">
            <el-input v-model="renewForm.code" disabled></el-input>
        </el-form-item>
        
        <!-- 点卡显示剩余点数 -->
        <el-form-item v-if="renewForm.is_point_card" label="当前点数">
            <el-input :value="renewForm.remaining_points + ' / ' + renewForm.total_points + ' 点'" disabled></el-input>
        </el-form-item>
        
        <!-- 时长卡显示到期时间 -->
        <el-form-item v-else label="当前到期">
            <el-input v-model="renewForm.current_expire" disabled></el-input>
        </el-form-item>
        
        <!-- 点卡充值 -->
        <template v-if="renewForm.is_point_card">
            <el-form-item label="充值点数" required>
                <el-input-number v-model="renewForm.renew_amount" :min="1" :max="999999" style="width: 140px;"></el-input-number>
                <span style="margin-left: 10px; color: #909399;">点</span>
            </el-form-item>
        </template>
        
        <!-- 时长卡续费 -->
        <template v-else>
            <el-form-item label="续费类型" required>
                <el-select v-model="renewForm.renew_type" style="width: 140px;">
                    <el-option label="分钟" value="minute"></el-option>
                    <el-option label="小时" value="hour"></el-option>
                    <el-option label="天" value="day"></el-option>
                    <el-option label="周" value="week"></el-option>
                    <el-option label="月" value="month"></el-option>
                    <el-option label="季度" value="quarter"></el-option>
                    <el-option label="年" value="year"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="续费数量" required>
                <el-input-number v-model="renewForm.renew_amount" :min="1" :max="9999" style="width: 140px;"></el-input-number>
                <span style="margin-left: 10px; color: #909399;">{{ getRenewUnit() }}</span>
            </el-form-item>
        </template>
    </el-form>
    <template #footer>
        <el-button @click="showRenewDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSaveRenew" :loading="renewLoading">
            {{ renewForm.is_point_card ? '确定充值' : '确定续费' }}
        </el-button>
    </template>
</el-dialog>

<style>
.code-text {
    font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
    font-size: 13px;
    letter-spacing: 0.5px;
    color: #409eff;
}
.gen-dialog .el-dialog__body {
    padding: 20px 28px;
    max-height: 65vh;
    overflow-y: auto;
}
.gen-form .el-form-item {
    margin-bottom: 22px;
}
.section-title {
    font-size: 14px;
    font-weight: 500;
    color: #606266;
    margin: 24px 0 16px 0;
    padding-bottom: 10px;
    border-bottom: 1px solid #ebeef5;
}
.section-title:first-child {
    margin-top: 0;
}
.form-tip {
    margin-left: 10px;
    color: #b0b0b0;
    font-size: 12px;
}
.switch-row {
    display: flex;
    align-items: center;
    min-height: 32px;
}
.switch-tip {
    margin-left: 10px;
    color: #b0b0b0;
    font-size: 12px;
}
.gen-form .num-input {
    width: 140px;
}
</style>

<?php
$pageContent = ob_get_clean();

$vueData = "
codeList: [],
softwareList: [],
productList: [],
loading: false,
generating: false,
renewLoading: false,
showAddDialog: false,
showEditDialog: false,
showResultDialog: false,
showRenewDialog: false,
generatedCodes: [],
selectedRows: [],
searchForm: {
    software_id: '',
    card_type: '',
    status: '',
    keyword: ''
},
pagination: { page: 1, pageSize: 20, total: 0 },
jumpPage: 1,
addForm: {
    software_id: '',
    product_id: '',
    is_point_card: 0,
    card_type: 'month',
    duration: 30,
    points: 100,
    deduct_type: 'per_use',
    deduct_amount: 1,
    activate_mode: 'first_use',
    start_time: null,
    max_devices: 1,
    allow_multi: false,
    allow_unbind: true,
    max_unbind: 3,
    single_online: true,
    pre_bind: false,
    machine_codes: '',
    ip_limit: false,
    max_ip: 5,
    use_limit: false,
    max_use: 100,
    region_limit: false,
    allowed_regions: [],
    count: 10,
    remark: ''
},
editForm: {
    id: '',
    code: '',
    machine_code: '',
    max_devices: 1,
    allow_multi: false,
    allow_unbind: false,
    max_unbind: 3,
    unbind_count: 0,
    remark: ''
},
renewForm: {
    id: '',
    code: '',
    is_point_card: 0,
    current_expire: '',
    remaining_points: 0,
    total_points: 0,
    renew_type: 'day',
    renew_amount: 30
}
";

$vueMounted = "
this.loadData();
this.loadSoftware();
";

$vueComputed = "
batchToggleBtnType() {
    if (this.selectedRows.length === 0) return 'warning';
    const hasDisabled = this.selectedRows.some(r => r.status == 2);
    return hasDisabled ? 'success' : 'warning';
},
batchToggleBtnText() {
    if (this.selectedRows.length === 0) return '批量禁用';
    const hasDisabled = this.selectedRows.some(r => r.status == 2);
    return hasDisabled ? '批量启用' : '批量禁用';
}
";

$vueMethods = "
getPageList() {
    const total = Math.ceil(this.pagination.total / this.pagination.pageSize) || 1;
    const current = this.pagination.page;
    const pages = [];
    let start = Math.max(1, current - 2);
    let end = Math.min(total, current + 2);
    if (end - start < 4) {
        if (start === 1) end = Math.min(total, start + 4);
        else start = Math.max(1, end - 4);
    }
    for (let i = start; i <= end; i++) pages.push(i);
    return pages;
},
goPage(p) {
    const total = Math.ceil(this.pagination.total / this.pagination.pageSize) || 1;
    if (p < 1) p = 1;
    if (p > total) p = total;
    this.pagination.page = p;
    this.jumpPage = p;
    this.loadData();
},
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            ...this.searchForm
        });
        const res = await fetch('api_authcode.php?' + params);
        const data = await res.json();
        if (data.code === 0) {
            this.codeList = data.data;
            this.pagination.total = data.total || 0;
            this.jumpPage = this.pagination.page;
        }
    } catch (e) {
        console.error(e);
    }
    this.loading = false;
},
async loadSoftware() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
async onSoftwareChange(softwareId) {
    // 清空已选商品
    this.addForm.product_id = '';
    this.productList = [];
    
    if (!softwareId) return;
    
    // 加载该软件下的商品
    try {
        const res = await fetch('api_product.php?action=list&software_id=' + softwareId);
        const data = await res.json();
        if (data.code === 0) {
            this.productList = data.data || [];
        }
    } catch (e) {}
},
handleCardModeChange(val) {
    // 切换卡密类型时重置相关字段
    if (val === 0) {
        // 时长卡
        this.addForm.card_type = 'month';
        this.addForm.duration = 30;
    } else {
        // 点卡
        this.addForm.points = 100;
        this.addForm.deduct_type = 'per_use';
        this.addForm.deduct_amount = 1;
    }
},
getCardTypeName(type) {
    const names = { minute: '分钟', hour: '小时', day: '天', week: '周', month: '月', quarter: '季', year: '年', permanent: '永久' };
    return names[type] || type;
},
formatDuration(row) {
    const type = row.card_type;
    const minutes = parseInt(row.minutes) || 0;
    const days = parseInt(row.days) || 0;
    
    // 永久卡
    if (type === 'permanent') return '永久';
    
    // 根据card_type决定显示单位
    // 注意：days字段存储的是总天数，需要根据类型转换
    switch (type) {
        case 'minute':
            if (minutes > 0) return minutes + '分钟';
            return (days * 1440) + '分钟';
        case 'hour':
            if (minutes > 0) return Math.round(minutes / 60) + '小时';
            return (days * 24) + '小时';
        case 'day':
            if (minutes > 0) return Math.round(minutes / 1440) + '天';
            return days + '天';
        case 'week':
            // 周卡：7天为1周
            var weeks = minutes > 0 ? Math.round(minutes / 1440 / 7) : Math.round(days / 7);
            return (weeks || 1) + '周';
        case 'month':
            // 月卡：30天为1月
            var months = minutes > 0 ? Math.round(minutes / 1440 / 30) : Math.round(days / 30);
            return (months || 1) + '个月';
        case 'quarter':
            // 季卡：90天为1季度
            var quarters = minutes > 0 ? Math.round(minutes / 1440 / 90) : Math.round(days / 90);
            return (quarters || 1) + '季度';
        case 'year':
            // 年卡：365天为1年
            var years = minutes > 0 ? Math.round(minutes / 1440 / 365) : Math.round(days / 365);
            return (years || 1) + '年';
        default:
            if (minutes > 0) return Math.round(minutes / 1440) + '天';
            return days + '天';
    }
},
getCardTypeColor(type) {
    const colors = { minute: 'info', hour: 'info', day: '', week: '', month: 'success', quarter: 'success', year: 'warning', permanent: 'danger' };
    return colors[type] || '';
},
getStatusType(s) {
    return { 0: 'info', 1: 'success', 2: 'danger', 3: 'warning' }[s] || 'info';
},
getStatusText(s) {
    return { 0: '未使用', 1: '已激活', 2: '已禁用', 3: '已过期' }[s] || '未知';
},
async handleGenerate() {
    if (!this.addForm.software_id) {
        ElementPlus.ElMessage.error('请选择软件');
        return;
    }
    this.generating = true;
    try {
        const res = await fetch('api_authcode.php?action=generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.addForm)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('生成成功');
            this.showAddDialog = false;
            this.generatedCodes = data.data.codes || [];
            if (this.generatedCodes.length > 0) {
                this.showResultDialog = true;
            }
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {
        ElementPlus.ElMessage.error('请求失败');
    }
    this.generating = false;
},
handleEdit(row) {
    this.editForm = {
        id: row.id,
        code: row.code,
        machine_code: row.machine_code || '',
        max_devices: row.max_devices || 1,
        allow_multi: row.allow_multi == 1,
        allow_unbind: row.allow_unbind == 1,
        max_unbind: row.max_unbind || 3,
        unbind_count: row.unbind_count || 0,
        remark: row.remark || ''
    };
    this.showEditDialog = true;
},
async handleSaveEdit() {
    try {
        const res = await fetch('api_authcode.php?action=update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.editForm)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('保存成功');
            this.showEditDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {
        ElementPlus.ElMessage.error('请求失败');
    }
},
async handleUnbind(row) {
    try {
        await ElementPlus.ElMessageBox.confirm(
            '解绑后用户需要重新激活绑定新设备，确定解绑吗？',
            '解绑确认',
            { type: 'warning' }
        );
        const res = await fetch('api_authcode.php?action=unbind', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('解绑成功，剩余换绑次数：' + data.data.remaining);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleToggleStatus(row) {
    const action = row.status == 2 ? 'enable' : 'disable';
    const actionText = row.status == 2 ? '启用' : '禁用';
    try {
        const res = await fetch('api_authcode.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(actionText + '成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除此授权码？删除后无法恢复！', '删除确认', { type: 'error' });
        const res = await fetch('api_authcode.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('删除成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
handleSelectionChange(rows) {
    this.selectedRows = rows;
},
async handleBatchDelete() {
    if (this.selectedRows.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除选中的 ' + this.selectedRows.length + ' 个授权码？', '批量删除', { type: 'error' });
        const ids = this.selectedRows.map(r => r.id);
        const res = await fetch('api_authcode.php?action=batchDelete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('批量删除成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleBatchToggle() {
    if (this.selectedRows.length === 0) return;
    const hasDisabled = this.selectedRows.some(r => r.status == 2);
    const action = hasDisabled ? 'batchEnable' : 'batchDisable';
    const actionText = hasDisabled ? '启用' : '禁用';
    try {
        await ElementPlus.ElMessageBox.confirm('确定' + actionText + '选中的 ' + this.selectedRows.length + ' 个授权码？', '批量' + actionText, { type: 'warning' });
        const ids = this.selectedRows.map(r => r.id);
        const res = await fetch('api_authcode.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('批量' + actionText + '成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
handleBatchExport() {
    if (this.selectedRows.length === 0) return;
    const codes = this.selectedRows.map(r => r.code).join('\\n');
    navigator.clipboard.writeText(codes).then(() => {
        ElementPlus.ElMessage.success('已复制 ' + this.selectedRows.length + ' 个授权码');
    });
},
copyCode(code) {
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(code).then(() => {
            ElementPlus.ElMessage.success('已复制');
        });
    } else {
        const textarea = document.createElement('textarea');
        textarea.value = code;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        ElementPlus.ElMessage.success('已复制');
    }
},
copyAllCodes() {
    const text = this.generatedCodes.join('\\n');
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(() => {
            ElementPlus.ElMessage.success('已复制全部授权码');
        });
    } else {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        ElementPlus.ElMessage.success('已复制全部授权码');
    }
},
handleExport() {
    const params = new URLSearchParams({ action: 'export', ...this.searchForm });
    window.open('api_authcode.php?' + params);
},
handleRenew(row) {
    this.renewForm = {
        id: row.id,
        code: row.code,
        is_point_card: parseInt(row.is_point_card) === 1 ? 1 : 0,
        current_expire: row.expire_time || '未激活',
        remaining_points: row.remaining_points || 0,
        total_points: row.total_points || 0,
        renew_type: 'day',
        renew_amount: parseInt(row.is_point_card) === 1 ? 100 : 30
    };
    this.showRenewDialog = true;
},
getRenewUnit() {
    const units = { minute: '分钟', hour: '小时', day: '天', week: '周', month: '月', quarter: '季度', year: '年' };
    return units[this.renewForm.renew_type] || '';
},
async handleSaveRenew() {
    this.renewLoading = true;
    try {
        const res = await fetch('api_authcode.php?action=renew', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.renewForm)
        });
        const data = await res.json();
        if (data.code === 0) {
            if (this.renewForm.is_point_card) {
                ElementPlus.ElMessage.success('充值成功，当前点数：' + data.data.new_points);
            } else {
                ElementPlus.ElMessage.success('续费成功，新到期时间：' + data.data.new_expire);
            }
            this.showRenewDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {
        ElementPlus.ElMessage.error('请求失败');
    }
    this.renewLoading = false;
},
async handleDeleteAll() {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除当前筛选条件下的所有授权码？此操作不可恢复！', '删除全部', { type: 'error', confirmButtonText: '确定删除', cancelButtonText: '取消' });
        const res = await fetch('api_authcode.php?action=deleteAll', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.searchForm)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('删除成功，共删除 ' + data.data.count + ' 条');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
