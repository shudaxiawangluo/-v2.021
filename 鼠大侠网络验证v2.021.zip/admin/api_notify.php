<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'get_config':
        $configs = [];
        $stmt = $db->query("SELECT * FROM notify_configs");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $configs[$row['type']] = array_merge(
                json_decode($row['config'] ?: '{}', true),
                ['enabled' => $row['status'] == 1]
            );
        }
        
        // 获取事件设置
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'notify_events'");
        $stmt->execute();
        $eventsJson = $stmt->fetchColumn();
        if ($eventsJson) {
            $configs['events'] = json_decode($eventsJson, true);
        }
        
        // 获取发卡页面设置
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'shop_enabled'");
        $stmt->execute();
        $shopEnabled = $stmt->fetchColumn();
        $configs['shop_enabled'] = $shopEnabled !== '0';
        
        echo json_encode(['code' => 0, 'data' => $configs]);
        break;
        
    case 'save_config':
        $input = json_decode(file_get_contents('php://input'), true);
        $type = $input['type'] ?? '';
        $config = $input['config'] ?? [];
        
        if (!in_array($type, ['email', 'telegram', 'wechat', 'dingtalk', 'sms', 'webhook'])) {
            echo json_encode(['code' => 1, 'msg' => '无效的通知类型']);
            break;
        }
        
        $enabled = $config['enabled'] ?? false;
        unset($config['enabled']);
        
        // 检查是否存在
        $stmt = $db->prepare("SELECT id FROM notify_configs WHERE type = ?");
        $stmt->execute([$type]);
        $exists = $stmt->fetch();
        
        if ($exists) {
            $stmt = $db->prepare("UPDATE notify_configs SET config = ?, status = ? WHERE type = ?");
            $stmt->execute([json_encode($config), $enabled ? 1 : 0, $type]);
        } else {
            $names = ['email' => '邮件通知', 'telegram' => 'Telegram通知', 'wechat' => '微信通知', 'dingtalk' => '钉钉通知', 'sms' => '短信通知', 'webhook' => 'Webhook通知'];
            $stmt = $db->prepare("INSERT INTO notify_configs (type, name, config, status) VALUES (?, ?, ?, ?)");
            $stmt->execute([$type, $names[$type] ?? $type, json_encode($config), $enabled ? 1 : 0]);
        }
        
        // 同时保存到system_settings表供notifier使用
        $settingKey = "notify_{$type}";
        $config['enabled'] = $enabled;
        $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $configJson = json_encode($config);
        $stmt->execute([$settingKey, $configJson, $configJson]);
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
        
    case 'test_email':
        $input = json_decode(file_get_contents('php://input'), true);
        $email = $input['email'] ?? '';
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['code' => 1, 'msg' => '邮箱格式不正确']);
            break;
        }
        
        require_once '../api/notifier.php';
        $notifier = new Notifier($db);
        $result = $notifier->sendEmail(
            $email, 
            '测试邮件', 
            "类型: 测试邮件\n状态: 配置正确\n时间: " . date('Y-m-d H:i:s') . "\n说明: 如果您收到此邮件，说明邮件配置正确"
        );
        
        if ($result['success']) {
            echo json_encode(['code' => 0, 'msg' => '测试邮件已发送']);
        } else {
            echo json_encode(['code' => 1, 'msg' => $result['error'] ?? '发送失败']);
        }
        break;
        
    case 'save_events':
        $input = json_decode(file_get_contents('php://input'), true);
        $events = $input['events'] ?? [];
        
        // 保存事件设置
        $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES ('notify_events', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $eventsJson = json_encode($events);
        $stmt->execute([$eventsJson, $eventsJson]);
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
        
    case 'test_telegram':
        require_once '../api/notifier.php';
        $notifier = new Notifier($db);
        $result = $notifier->sendTelegram("测试消息\n\n这是一条来自授权系统的测试通知\n\n时间: " . date('Y-m-d H:i:s'));
        if ($result['success']) {
            echo json_encode(['code' => 0, 'msg' => '测试消息已发送']);
        } else {
            echo json_encode(['code' => 1, 'msg' => $result['error'] ?? '发送失败']);
        }
        break;
        
    case 'test_wechat':
        require_once '../api/notifier.php';
        $notifier = new Notifier($db);
        $result = $notifier->sendWechat('测试消息', "> 这是一条来自授权系统的测试通知\n> 时间: " . date('Y-m-d H:i:s'));
        if ($result['success']) {
            echo json_encode(['code' => 0, 'msg' => '测试消息已发送']);
        } else {
            echo json_encode(['code' => 1, 'msg' => $result['error'] ?? '发送失败']);
        }
        break;
    
    case 'test_dingtalk':
        require_once '../api/notifier.php';
        $notifier = new Notifier($db);
        $result = $notifier->sendDingtalk('测试消息', "> 这是一条来自授权系统的测试通知\n> 时间: " . date('Y-m-d H:i:s'));
        if ($result['success']) {
            echo json_encode(['code' => 0, 'msg' => '测试消息已发送']);
        } else {
            echo json_encode(['code' => 1, 'msg' => $result['error'] ?? '发送失败']);
        }
        break;
        
    case 'template_list':
        // 检查是否有模板，没有则初始化默认模板
        $stmt = $db->query("SELECT COUNT(*) FROM notify_templates");
        if ($stmt->fetchColumn() == 0) {
            $defaultTemplates = [
                ['order_paid', '订单支付成功', '订单支付成功通知', "订单号: {order_no}\n金额: ¥{amount}\n商品: {product_name}\n数量: {quantity}\n授权码: {auth_code}\n时间: {time}"],
                ['withdraw_apply', '提现申请', '代理商提现申请', "代理商ID: {agent_id}\n提现金额: ¥{amount}\n手续费: ¥{fee}\n实际到账: ¥{actual_amount}\n收款方式: {account_type}\n收款账号: {account_no}\n收款人: {account_name}\n时间: {time}"],
                ['auth_activated', '授权激活', '授权码激活通知', "软件: {software_name}\n授权码: {auth_code}\n设备指纹: {fingerprint}\nIP地址: {ip}\n到期时间: {expire_time}\n时间: {time}"],
                ['auth_expire', '授权到期提醒', '授权即将到期', "软件: {software_name}\n授权码: {auth_code}\n到期时间: {expire_time}\n剩余天数: {remain_days}天\n请及时续费"],
                ['ip_blocked', 'IP封禁通知', 'IP已被封禁', "封禁IP: {ip}\n原因: {reason}\n操作人: {operator}\n时间: {time}"]
            ];
            $stmt = $db->prepare("INSERT INTO notify_templates (event, name, title, content, status) VALUES (?, ?, ?, ?, 1)");
            foreach ($defaultTemplates as $t) {
                $stmt->execute($t);
            }
        }
        $stmt = $db->query("SELECT * FROM notify_templates ORDER BY id");
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;
        
    case 'update_template':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("UPDATE notify_templates SET title = ?, content = ?, status = ? WHERE id = ?");
        $stmt->execute([$input['title'], $input['content'], $input['status'] ?? 1, $input['id']]);
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
        
    case 'log_list':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, intval($_GET['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;
        
        $where = "1=1";
        $params = [];
        if (!empty($_GET['type'])) {
            $where .= " AND type = ?";
            $params[] = $_GET['type'];
        }
        if (isset($_GET['status']) && $_GET['status'] !== '') {
            $where .= " AND status = ?";
            $params[] = $_GET['status'];
        }
        
        $countSql = "SELECT COUNT(*) FROM notify_logs WHERE $where";
        $stmt = $db->prepare($countSql);
        $stmt->execute($params);
        $total = $stmt->fetchColumn();
        
        $sql = "SELECT * FROM notify_logs WHERE $where ORDER BY id DESC LIMIT $offset, $pageSize";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC), 'total' => $total]);
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
