<?php
$pageTitle = '充值记录';
$breadcrumbs = ['代理商', '充值记录'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="YYYY-MM-DD" style="width: 260px;" @change="loadData"></el-date-picker>
        <el-input v-model="searchForm.keyword" placeholder="搜索代理账号" clearable style="width: 180px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <el-card shadow="never" style="padding: 0;">
        <div style="display: flex; align-items: center; gap: 8px;">
            <el-icon :size="20" style="color: #67c23a;"><money /></el-icon>
            <span style="color: #909399; font-size: 13px;">充值总额</span>
            <span style="color: #67c23a; font-size: 20px; font-weight: 600;">¥{{ totalAmount.toFixed(2) }}</span>
        </div>
    </el-card>
</div>

<el-card shadow="hover">
    <el-table :data="rechargeList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="70" align="center"></el-table-column>
        <el-table-column prop="agent_name" label="代理账号" min-width="120"></el-table-column>
        <el-table-column label="充值金额" width="120" align="right">
            <template #default="scope">
                <span style="color: #67c23a; font-weight: 500;">+¥{{ scope.row.amount }}</span>
            </template>
        </el-table-column>
        <el-table-column label="充值前余额" width="120" align="right">
            <template #default="scope">¥{{ scope.row.before_balance }}</template>
        </el-table-column>
        <el-table-column label="充值后余额" width="120" align="right">
            <template #default="scope">¥{{ scope.row.after_balance }}</template>
        </el-table-column>
        <el-table-column prop="admin_name" label="操作员" width="100"></el-table-column>
        <el-table-column prop="remark" label="备注" min-width="150">
            <template #default="scope">{{ scope.row.remark || '-' }}</template>
        </el-table-column>
        <el-table-column prop="create_time" label="充值时间" width="170"></el-table-column>
    </el-table>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
        <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ pagination.total }}</b> 条</span>
        <el-pagination background layout="prev, pager, next" :total="pagination.total" :page-size="pagination.pageSize" v-model:current-page="pagination.page" @current-change="loadData"></el-pagination>
    </div>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
rechargeList: [],
loading: false,
totalAmount: 0,
dateRange: [],
searchForm: { keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 }
";

$vueMounted = "this.loadData();";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'recharge_list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            keyword: this.searchForm.keyword,
            start_date: this.dateRange?.[0] || '',
            end_date: this.dateRange?.[1] || ''
        });
        const res = await fetch('api_agent.php?' + params);
        const data = await res.json();
        if (data.code === 0) {
            this.rechargeList = data.data;
            this.pagination.total = data.total || 0;
            this.totalAmount = data.totalAmount || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
}
";

include 'layout.php';
?>
