<?php
$pageTitle = '提现审核';
$breadcrumbs = ['代理商', '提现审核'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-tag v-if="pendingCount > 0" type="warning" size="large" effect="dark" style="font-size: 14px; padding: 8px 16px;">
            待审核 {{ pendingCount }} 笔 · ¥{{ pendingAmount.toFixed(2) }}
        </el-tag>
        <el-select v-model="searchForm.status" placeholder="状态" clearable style="width: 120px;" @change="loadData">
            <el-option label="待审核" :value="0"></el-option>
            <el-option label="处理中" :value="3"></el-option>
            <el-option label="已完成" :value="1"></el-option>
            <el-option label="已拒绝" :value="2"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索代理账号" clearable style="width: 180px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
</div>

<el-card shadow="hover">
    <el-table :data="withdrawList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" min-width="60" align="center"></el-table-column>
        <el-table-column prop="agent_name" label="代理账号" min-width="100"></el-table-column>
        <el-table-column label="提现金额" min-width="100" align="right">
            <template #default="scope"><span style="color: #f56c6c; font-weight: 500;">¥{{ scope.row.amount }}</span></template>
        </el-table-column>
        <el-table-column label="手续费" min-width="80" align="right">
            <template #default="scope">¥{{ scope.row.fee }}</template>
        </el-table-column>
        <el-table-column label="实际到账" min-width="100" align="right">
            <template #default="scope"><span style="color: #67c23a; font-weight: 500;">¥{{ scope.row.actual_amount }}</span></template>
        </el-table-column>
        <el-table-column label="提现方式" min-width="90" align="center">
            <template #default="scope">
                <el-tag size="small" :type="scope.row.withdraw_type === 'alipay' ? 'primary' : (scope.row.withdraw_type === 'wechat' ? 'success' : 'info')">
                    {{ {alipay:'支付宝',wechat:'微信',bank:'银行卡'}[scope.row.withdraw_type] || scope.row.withdraw_type }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="account_name" label="账户名" min-width="90"></el-table-column>
        <el-table-column prop="account_no" label="账号" min-width="140"></el-table-column>
        <el-table-column label="状态" min-width="80" align="center">
            <template #default="scope">
                <el-tag :type="{0:'warning',1:'success',2:'danger',3:'primary'}[scope.row.status]" size="small">
                    {{ {0:'待审核',1:'已完成',2:'已拒绝',3:'处理中'}[scope.row.status] }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="申请时间" min-width="150"></el-table-column>
        <el-table-column label="审核时间" min-width="150">
            <template #default="scope">{{ scope.row.audit_time || '-' }}</template>
        </el-table-column>
        <el-table-column label="备注" min-width="120">
            <template #default="scope">
                <span v-if="scope.row.audit_remark" style="color: #909399;">{{ scope.row.audit_remark }}</span>
                <span v-else>-</span>
            </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
            <template #default="scope">
                <el-select :model-value="scope.row.status" size="small" style="width: 120px;" @change="handleStatusChange(scope.row, $event)">
                    <el-option :value="0" label="待审核"></el-option>
                    <el-option :value="3" label="处理中"></el-option>
                    <el-option :value="1" label="已完成"></el-option>
                    <el-option :value="2" label="拒绝"></el-option>
                </el-select>
            </template>
        </el-table-column>
    </el-table>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
        <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ pagination.total }}</b> 条</span>
        <el-pagination background layout="prev, pager, next" :total="pagination.total" :page-size="pagination.pageSize" v-model:current-page="pagination.page" @current-change="loadData"></el-pagination>
    </div>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
withdrawList: [],
loading: false,
pendingCount: 0,
pendingAmount: 0,
searchForm: { status: '', keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 }
";

$vueMounted = "this.loadData();";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        var params = new URLSearchParams({
            action: 'withdraw_list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            status: this.searchForm.status !== '' ? this.searchForm.status : '',
            keyword: this.searchForm.keyword || ''
        });
        var res = await fetch('api_agent.php?' + params);
        var data = await res.json();
        if (data.code === 0) {
            this.withdrawList = data.data;
            this.pagination.total = data.total || 0;
            this.pendingCount = data.pendingCount || 0;
            this.pendingAmount = data.pendingAmount || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
async handleStatusChange(row, newStatus) {
    var self = this;
    var oldStatus = row.status;
    
    // 如果选择拒绝，需要输入理由
    if (newStatus === 2) {
        try {
            var result = await ElementPlus.ElMessageBox.prompt('请输入拒绝理由', '拒绝提现', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                inputPlaceholder: '请输入拒绝理由',
                inputValidator: function(v) { return v && v.trim() ? true : '请输入拒绝理由'; }
            });
            await self.updateStatus(row, newStatus, result.value);
        } catch (e) {
            // 取消了，不做任何操作
        }
    } else {
        await self.updateStatus(row, newStatus, '');
    }
},
async updateStatus(row, status, remark) {
    var self = this;
    try {
        var res = await fetch('api_agent.php?action=audit_withdraw', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id, status: status, remark: remark })
        });
        var data = await res.json();
        if (data.code === 0) {
            // 直接更新当前行的状态，不重新加载列表
            row.status = status;
            if (remark) row.audit_remark = remark;
            row.audit_time = new Date().toLocaleString('zh-CN', {year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}).replace(/\\//g, '-');
            // 更新统计数据
            self.updatePendingStats();
            ElementPlus.ElMessage.success('状态已更新');
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { 
        ElementPlus.ElMessage.error('请求失败'); 
    }
},
updatePendingStats() {
    var pending = this.withdrawList.filter(function(item) { return item.status === 0; });
    this.pendingCount = pending.length;
    this.pendingAmount = pending.reduce(function(sum, item) { return sum + parseFloat(item.actual_amount || 0); }, 0);
}
";

include 'layout.php';
?>
