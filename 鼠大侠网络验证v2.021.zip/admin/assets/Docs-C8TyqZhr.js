import{_ as p}from"./_plugin-vue_export-helper-DlAUqK2U.js";import{i as c,o as u,w as a,b as l,a as o,d as e}from"./index-CEeXY0r4.js";const _={};function d(i,n){const t=l("el-tab-pane"),r=l("el-tabs"),s=l("el-card");return u(),c(s,{header:"开发文档"},{default:a(()=>[o(r,null,{default:a(()=>[o(t,{label:"网络验证API"},{default:a(()=>[...n[0]||(n[0]=[e("h3",null,"1. 登录验证",-1),e("pre",null,`POST /api/auth/login
参数: { appKey, username, password, machineCode }`,-1),e("h3",null,"2. 心跳检测",-1),e("pre",null,`POST /api/auth/heartbeat
参数: { token }`,-1)])]),_:1}),o(t,{label:"离线验证API"},{default:a(()=>[...n[1]||(n[1]=[e("h3",null,"1. 生成离线授权",-1),e("pre",null,`POST /api/offline/generate
参数: { machineCode, days }`,-1),e("h3",null,"2. 验证离线授权",-1),e("pre",null,`POST /api/offline/verify
参数: { machineCode, license }`,-1)])]),_:1})]),_:1})]),_:1})}const h=p(_,[["render",d]]);export{h as default};
