<?php
$pageTitle = '代理列表';
$breadcrumbs = ['代理商', '代理列表'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.status" placeholder="状态" clearable style="width: 100px;" @change="loadData">
            <el-option label="正常" :value="1"></el-option>
            <el-option label="禁用" :value="0"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索账号/昵称/QQ" clearable style="width: 200px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <div style="display: flex; gap: 10px;">
        <el-button @click="copyAgentUrl">复制代理后台地址</el-button>
        <el-button type="primary" @click="handleAdd">添加代理</el-button>
    </div>
</div>

<el-card shadow="hover">
    <el-table :data="agentList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" min-width="50" align="center"></el-table-column>
        <el-table-column prop="username" label="账号" min-width="100"></el-table-column>
        <el-table-column prop="nickname" label="昵称" min-width="100">
            <template #default="scope">{{ scope.row.nickname || '-' }}</template>
        </el-table-column>
        <el-table-column label="余额" min-width="90" align="right">
            <template #default="scope">
                <span style="color: #e6a23c; font-weight: 500;">¥{{ scope.row.balance }}</span>
            </template>
        </el-table-column>
        <el-table-column label="折扣" min-width="70" align="center">
            <template #default="scope">{{ (scope.row.discount * 100).toFixed(0) }}%</template>
        </el-table-column>
        <el-table-column prop="qq" label="QQ" min-width="100"></el-table-column>
        <el-table-column label="状态" min-width="70" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.status == 1 ? 'success' : 'danger'" size="small">
                    {{ scope.row.status == 1 ? '正常' : '禁用' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="注册时间" min-width="150"></el-table-column>
        <el-table-column label="操作" width="380" fixed="right" align="center">
            <template #default="scope">
                <div style="display: flex; gap: 4px; justify-content: center; flex-wrap: nowrap; white-space: nowrap;">
                    <el-button type="primary" size="small" @click="handleLoginAs(scope.row)">登录后台</el-button>
                    <el-button type="success" size="small" @click="handleRecharge(scope.row)">充值</el-button>
                    <el-button :type="scope.row.status == 1 ? 'info' : 'success'" size="small" @click="handleToggleStatus(scope.row)">{{ scope.row.status == 1 ? '禁用' : '启用' }}</el-button>
                    <el-button type="warning" size="small" @click="handleEdit(scope.row)">编辑</el-button>
                    <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
                </div>
            </template>
        </el-table-column>
    </el-table>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
        <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ pagination.total }}</b> 条</span>
        <el-pagination background layout="prev, pager, next" :total="pagination.total" :page-size="pagination.pageSize" v-model:current-page="pagination.page" @current-change="loadData"></el-pagination>
    </div>
</el-card>

<!-- 添加/编辑代理对话框 -->
<el-dialog v-model="showAddDialog" :title="editForm.id ? '编辑代理' : '添加代理'" width="550px">
    <el-form :model="editForm" label-width="100px">
        <el-form-item label="登录账号" required>
            <el-input v-model="editForm.username" :disabled="!!editForm.id" placeholder="用于登录代理后台"></el-input>
        </el-form-item>
        <el-form-item label="登录密码" :required="!editForm.id">
            <el-input v-model="editForm.password" type="password" show-password :placeholder="editForm.id ? '留空不修改' : '请输入密码'"></el-input>
        </el-form-item>
        <el-form-item label="昵称">
            <el-input v-model="editForm.nickname" placeholder="代理商昵称"></el-input>
        </el-form-item>
        <el-form-item label="折扣率">
            <el-slider v-model="editForm.discountPercent" :min="50" :max="100" :step="5" show-input :format-tooltip="v => v + '%'"></el-slider>
            <div style="font-size: 12px; color: #909399;">代理购买价格 = 原价 × {{ editForm.discountPercent }}%</div>
        </el-form-item>
        <el-form-item label="联系QQ">
            <el-input v-model="editForm.qq" placeholder="QQ号码"></el-input>
        </el-form-item>
        <el-form-item label="联系邮箱">
            <el-input v-model="editForm.email" placeholder="邮箱地址"></el-input>
        </el-form-item>
        <el-form-item label="允许软件">
            <el-select v-model="editForm.allowed_software" multiple placeholder="留空为全部软件" style="width: 100%;">
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="状态">
            <el-switch v-model="editForm.statusBool" active-text="正常" inactive-text="禁用"></el-switch>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSave" :loading="saving">保存</el-button>
    </template>
</el-dialog>

<!-- 充值对话框 -->
<el-dialog v-model="showRechargeDialog" title="代理充值" width="450px">
    <el-form :model="rechargeForm" label-width="100px">
        <el-form-item label="代理账号">
            <el-input v-model="rechargeForm.username" disabled></el-input>
        </el-form-item>
        <el-form-item label="当前余额">
            <el-input v-model="rechargeForm.balance" disabled>
                <template #prepend>¥</template>
            </el-input>
        </el-form-item>
        <el-form-item label="充值金额" required>
            <el-input-number v-model="rechargeForm.amount" :min="1" :max="100000" :precision="2" style="width: 200px;"></el-input-number>
            <span style="margin-left: 10px; color: #909399;">元</span>
        </el-form-item>
        <el-form-item label="备注">
            <el-input v-model="rechargeForm.remark" placeholder="充值备注"></el-input>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showRechargeDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSaveRecharge" :loading="recharging">确认充值</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
agentList: [],
parentAgents: [],
softwareList: [],
loading: false,
saving: false,
recharging: false,
showAddDialog: false,
showRechargeDialog: false,
agentUrl: '',
searchForm: { status: '', keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 },
editForm: {
    id: '',
    username: '',
    password: '',
    nickname: '',
    discountPercent: 100,
    qq: '',
    email: '',
    allowed_software: [],
    statusBool: true
},
rechargeForm: { id: '', username: '', balance: 0, amount: 100, remark: '' }
";

$vueMounted = "
var baseUrl = window.location.origin + window.location.pathname.replace('/admin/agent_list.php', '');
this.agentUrl = baseUrl + '/agent/';
this.loadData();
this.loadSoftware();
this.loadParentAgents();
";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        var params = new URLSearchParams({
            action: 'list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            ...this.searchForm
        });
        var res = await fetch('api_agent.php?' + params);
        var data = await res.json();
        if (data.code === 0) {
            this.agentList = data.data;
            this.pagination.total = data.total || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        var res = await fetch('api_software.php?action=list');
        var data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
async loadParentAgents() {
    try {
        var res = await fetch('api_agent.php?action=parents');
        var data = await res.json();
        if (data.code === 0) this.parentAgents = data.data;
    } catch (e) {}
},
handleEdit(row) {
    this.editForm = {
        id: row.id,
        username: row.username,
        password: '',
        nickname: row.nickname || '',
        discountPercent: Math.round(row.discount * 100),
        qq: row.qq || '',
        email: row.email || '',
        allowed_software: row.allowed_software ? JSON.parse(row.allowed_software) : [],
        statusBool: row.status == 1
    };
    this.showAddDialog = true;
},
async handleSave() {
    if (!this.editForm.username) {
        ElementPlus.ElMessage.error('请输入登录账号');
        return;
    }
    if (!this.editForm.id && !this.editForm.password) {
        ElementPlus.ElMessage.error('请输入登录密码');
        return;
    }
    this.saving = true;
    try {
        var postData = {
            id: this.editForm.id,
            username: this.editForm.username,
            password: this.editForm.password,
            nickname: this.editForm.nickname,
            level: 1,
            parent_id: 0,
            discount: this.editForm.discountPercent / 100,
            qq: this.editForm.qq,
            email: this.editForm.email,
            allowed_software: this.editForm.allowed_software,
            status: this.editForm.statusBool ? 1 : 0
        };
        var res = await fetch('api_agent.php?action=' + (this.editForm.id ? 'update' : 'add'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(postData)
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showAddDialog = false;
            this.resetForm();
            this.loadData();
            this.loadParentAgents();
        } else {
            ElementPlus.ElMessage.error(data.msg || '操作失败');
        }
    } catch (e) { 
        console.error(e);
        ElementPlus.ElMessage.error('请求失败: ' + e.message); 
    }
    this.saving = false;
},
resetForm() {
    this.editForm = { id: '', username: '', password: '', nickname: '', discountPercent: 100, qq: '', email: '', allowed_software: [], statusBool: true };
},
handleAdd() {
    this.resetForm();
    this.showAddDialog = true;
},
handleRecharge(row) {
    this.rechargeForm = { id: row.id, username: row.username, balance: row.balance, amount: 100, remark: '' };
    this.showRechargeDialog = true;
},
async handleSaveRecharge() {
    if (this.rechargeForm.amount <= 0) {
        ElementPlus.ElMessage.error('充值金额必须大于0');
        return;
    }
    this.recharging = true;
    try {
        var res = await fetch('api_agent.php?action=recharge', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.rechargeForm)
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showRechargeDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('请求失败'); }
    this.recharging = false;
},
async handleToggleStatus(row) {
    var newStatus = row.status == 1 ? 0 : 1;
    try {
        var res = await fetch('api_agent.php?action=toggle_status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id, status: newStatus })
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('操作失败'); }
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除代理\"' + row.username + '\"吗？', '删除确认', { type: 'error' });
        var res = await fetch('api_agent.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
copyAgentUrl() {
    var self = this;
    navigator.clipboard.writeText(self.agentUrl).then(function() {
        ElementPlus.ElMessage.success('代理后台地址已复制');
    });
},
openAgentUrl() {
    window.open(this.agentUrl, '_blank');
},
handleLoginAs(row) {
    // 生成安全token
    var today = new Date();
    var dateStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
    // 注意：这里的token生成需要和后端一致
    var token = this.md5(row.username + dateStr + 'shudaxia_agent_auto_login_secret');
    window.open(this.agentUrl + '?auto_login=' + row.username + '&token=' + token, '_blank');
},
md5(string) {
    // 简单的MD5实现（生产环境建议使用后端生成token）
    function md5cycle(x, k) {
        var a = x[0], b = x[1], c = x[2], d = x[3];
        a = ff(a, b, c, d, k[0], 7, -680876936); d = ff(d, a, b, c, k[1], 12, -389564586); c = ff(c, d, a, b, k[2], 17, 606105819); b = ff(b, c, d, a, k[3], 22, -1044525330);
        a = ff(a, b, c, d, k[4], 7, -176418897); d = ff(d, a, b, c, k[5], 12, 1200080426); c = ff(c, d, a, b, k[6], 17, -1473231341); b = ff(b, c, d, a, k[7], 22, -45705983);
        a = ff(a, b, c, d, k[8], 7, 1770035416); d = ff(d, a, b, c, k[9], 12, -1958414417); c = ff(c, d, a, b, k[10], 17, -42063); b = ff(b, c, d, a, k[11], 22, -1990404162);
        a = ff(a, b, c, d, k[12], 7, 1804603682); d = ff(d, a, b, c, k[13], 12, -40341101); c = ff(c, d, a, b, k[14], 17, -1502002290); b = ff(b, c, d, a, k[15], 22, 1236535329);
        a = gg(a, b, c, d, k[1], 5, -165796510); d = gg(d, a, b, c, k[6], 9, -1069501632); c = gg(c, d, a, b, k[11], 14, 643717713); b = gg(b, c, d, a, k[0], 20, -373897302);
        a = gg(a, b, c, d, k[5], 5, -701558691); d = gg(d, a, b, c, k[10], 9, 38016083); c = gg(c, d, a, b, k[15], 14, -660478335); b = gg(b, c, d, a, k[4], 20, -405537848);
        a = gg(a, b, c, d, k[9], 5, 568446438); d = gg(d, a, b, c, k[14], 9, -1019803690); c = gg(c, d, a, b, k[3], 14, -187363961); b = gg(b, c, d, a, k[8], 20, 1163531501);
        a = gg(a, b, c, d, k[13], 5, -1444681467); d = gg(d, a, b, c, k[2], 9, -51403784); c = gg(c, d, a, b, k[7], 14, 1735328473); b = gg(b, c, d, a, k[12], 20, -1926607734);
        a = hh(a, b, c, d, k[5], 4, -378558); d = hh(d, a, b, c, k[8], 11, -2022574463); c = hh(c, d, a, b, k[11], 16, 1839030562); b = hh(b, c, d, a, k[14], 23, -35309556);
        a = hh(a, b, c, d, k[1], 4, -1530992060); d = hh(d, a, b, c, k[4], 11, 1272893353); c = hh(c, d, a, b, k[7], 16, -155497632); b = hh(b, c, d, a, k[10], 23, -1094730640);
        a = hh(a, b, c, d, k[13], 4, 681279174); d = hh(d, a, b, c, k[0], 11, -358537222); c = hh(c, d, a, b, k[3], 16, -722521979); b = hh(b, c, d, a, k[6], 23, 76029189);
        a = hh(a, b, c, d, k[9], 4, -640364487); d = hh(d, a, b, c, k[12], 11, -421815835); c = hh(c, d, a, b, k[15], 16, 530742520); b = hh(b, c, d, a, k[2], 23, -995338651);
        a = ii(a, b, c, d, k[0], 6, -198630844); d = ii(d, a, b, c, k[7], 10, 1126891415); c = ii(c, d, a, b, k[14], 15, -1416354905); b = ii(b, c, d, a, k[5], 21, -57434055);
        a = ii(a, b, c, d, k[12], 6, 1700485571); d = ii(d, a, b, c, k[3], 10, -1894986606); c = ii(c, d, a, b, k[10], 15, -1051523); b = ii(b, c, d, a, k[1], 21, -2054922799);
        a = ii(a, b, c, d, k[8], 6, 1873313359); d = ii(d, a, b, c, k[15], 10, -30611744); c = ii(c, d, a, b, k[6], 15, -1560198380); b = ii(b, c, d, a, k[13], 21, 1309151649);
        a = ii(a, b, c, d, k[4], 6, -145523070); d = ii(d, a, b, c, k[11], 10, -1120210379); c = ii(c, d, a, b, k[2], 15, 718787259); b = ii(b, c, d, a, k[9], 21, -343485551);
        x[0] = add32(a, x[0]); x[1] = add32(b, x[1]); x[2] = add32(c, x[2]); x[3] = add32(d, x[3]);
    }
    function cmn(q, a, b, x, s, t) { a = add32(add32(a, q), add32(x, t)); return add32((a << s) | (a >>> (32 - s)), b); }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
    function md51(s) {
        var n = s.length, state = [1732584193, -271733879, -1732584194, 271733878], i;
        for (i = 64; i <= s.length; i += 64) { md5cycle(state, md5blk(s.substring(i - 64, i))); }
        s = s.substring(i - 64); var tail = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
        for (i = 0; i < s.length; i++) tail[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
        tail[i >> 2] |= 0x80 << ((i % 4) << 3);
        if (i > 55) { md5cycle(state, tail); for (i = 0; i < 16; i++) tail[i] = 0; }
        tail[14] = n * 8; md5cycle(state, tail); return state;
    }
    function md5blk(s) { var md5blks = [], i; for (i = 0; i < 64; i += 4) { md5blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i + 1) << 8) + (s.charCodeAt(i + 2) << 16) + (s.charCodeAt(i + 3) << 24); } return md5blks; }
    var hex_chr = '0123456789abcdef'.split('');
    function rhex(n) { var s = '', j = 0; for (; j < 4; j++) s += hex_chr[(n >> (j * 8 + 4)) & 0x0F] + hex_chr[(n >> (j * 8)) & 0x0F]; return s; }
    function hex(x) { for (var i = 0; i < x.length; i++) x[i] = rhex(x[i]); return x.join(''); }
    function add32(a, b) { return (a + b) & 0xFFFFFFFF; }
    return hex(md51(string));
},
handleCommand(cmd, row) {
    if (cmd === 'recharge') this.handleRecharge(row);
    else if (cmd === 'edit') this.handleEdit(row);
    else if (cmd === 'disable' || cmd === 'enable') this.handleToggleStatus(row);
    else if (cmd === 'delete') this.handleDelete(row);
}
";

include 'layout.php';
?>
