<?php
$pageTitle = '操作日志';
$breadcrumbs = ['日志管理', '操作日志'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; margin-bottom: 16px; flex-shrink: 0;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="YYYY-MM-DD" style="width: 260px;" @change="loadData"></el-date-picker>
        <el-input v-model="searchForm.keyword" placeholder="搜索操作/管理员/IP" clearable style="width: 200px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon>搜索</el-button>
    </div>
    <div>
        <el-button type="danger" @click="showClearDialog = true"><el-icon><Delete /></el-icon>清理日志</el-button>
    </div>
</div>

<el-card shadow="hover">
    <el-table :data="dataList" v-loading="loading" stripe table-layout="auto">
        <el-table-column prop="id" label="ID" width="70" align="center"></el-table-column>
        <el-table-column prop="admin_name" label="管理员" width="100" align="center">
            <template #default="scope">
                <span>{{ scope.row.admin_name || 'admin' }}</span>
            </template>
        </el-table-column>
        <el-table-column prop="action" label="操作内容" min-width="250">
            <template #default="scope">
                <span>{{ scope.row.action }}</span>
                <el-tooltip v-if="scope.row.detail" :content="scope.row.detail" placement="top">
                    <el-icon style="margin-left: 5px; color: #909399; cursor: pointer;"><InfoFilled /></el-icon>
                </el-tooltip>
            </template>
        </el-table-column>
        <el-table-column prop="ip" label="IP地址" width="140" align="center">
            <template #default="scope">
                <span style="font-family: monospace;">{{ scope.row.ip || '-' }}</span>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="操作时间" width="170" align="center"></el-table-column>
    </el-table>
    
    <div class="pagination-container" style="justify-content: flex-end;">
        <el-pagination
            v-model:current-page="pagination.page"
            v-model:page-size="pagination.pageSize"
            :page-sizes="[20, 50, 100]"
            :total="pagination.total"
            layout="total, sizes, prev, pager, next"
            @size-change="loadData"
            @current-change="loadData"
        />
    </div>
</el-card>

<!-- 清理对话框 -->
<el-dialog v-model="showClearDialog" title="清理日志" width="450px">
    <el-form label-width="100px">
        <el-form-item label="清理方式">
            <el-radio-group v-model="clearMode">
                <el-radio label="days">按天数</el-radio>
                <el-radio label="range">按日期范围</el-radio>
                <el-radio label="all">全部清理</el-radio>
            </el-radio-group>
        </el-form-item>
        <el-form-item v-if="clearMode === 'days'" label="保留天数">
            <el-input-number v-model="clearDays" :min="0" :max="365" style="width: 100%;"></el-input-number>
            <div style="color: #909399; font-size: 12px; margin-top: 5px;">将删除 {{ clearDays }} 天前的所有操作日志（0表示删除今天之前的）</div>
        </el-form-item>
        <el-form-item v-if="clearMode === 'range'" label="日期范围">
            <el-date-picker v-model="clearDateRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="YYYY-MM-DD" style="width: 100%;"></el-date-picker>
            <div style="color: #909399; font-size: 12px; margin-top: 5px;">将删除选定日期范围内的日志</div>
        </el-form-item>
        <el-form-item v-if="clearMode === 'all'">
            <div style="color: #F56C6C; font-size: 13px;">将删除所有操作日志，此操作不可恢复！</div>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showClearDialog = false">取消</el-button>
        <el-button type="danger" @click="handleClear" :loading="clearing">确认清理</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
dataList: [],
loading: false,
clearing: false,
showClearDialog: false,
clearMode: 'days',
clearDays: 30,
clearDateRange: null,
dateRange: null,
searchForm: { keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 }
";

$vueMounted = "
this.loadData();
";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'operation_list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            keyword: this.searchForm.keyword,
            dateRange: this.dateRange ? this.dateRange.join(',') : ''
        });
        const res = await fetch('api_logs.php?' + params);
        const data = await res.json();
        if (data.code === 0) {
            this.dataList = data.data;
            this.pagination.total = data.total || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
async handleClear() {
    this.clearing = true;
    try {
        const body = { mode: this.clearMode };
        if (this.clearMode === 'days') {
            body.days = this.clearDays;
        } else if (this.clearMode === 'range') {
            if (!this.clearDateRange || this.clearDateRange.length !== 2) {
                ElementPlus.ElMessage.warning('请选择日期范围');
                this.clearing = false;
                return;
            }
            body.startDate = this.clearDateRange[0];
            body.endDate = this.clearDateRange[1];
        }
        const res = await fetch('api_logs.php?action=operation_clear', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showClearDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg || '操作失败');
        }
    } catch (e) { 
        console.error(e);
        ElementPlus.ElMessage.error('请求失败'); 
    }
    this.clearing = false;
}
";

include 'layout.php';
?>
