<?php
$pageTitle = '用户管理';
$breadcrumbs = ['用户管理'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 140px;" @change="loadData">
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-select v-model="searchForm.status" placeholder="状态" clearable style="width: 100px;" @change="loadData">
            <el-option label="正常" :value="1"></el-option>
            <el-option label="禁用" :value="0"></el-option>
        </el-select>
        <el-select v-model="searchForm.online" placeholder="在线状态" clearable style="width: 110px;" @change="loadData">
            <el-option label="在线" :value="1"></el-option>
            <el-option label="离线" :value="0"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索机器码/IP" clearable style="width: 200px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <div style="display: flex; gap: 10px;">
        <el-button type="warning" :disabled="selectedRows.length === 0" @click="handleBatchKickOffline">批量下线</el-button>
        <el-button type="danger" :disabled="selectedRows.length === 0" @click="handleBatchBan">批量禁用</el-button>
        <el-button type="danger" :disabled="selectedRows.length === 0" @click="handleBatchDelete">批量删除</el-button>
        <el-button @click="handleRefresh"><el-icon><Refresh /></el-icon>刷新</el-button>
    </div>
</div>

<el-card shadow="hover">
    <el-table :data="userList" v-loading="loading" @selection-change="handleSelectionChange" stripe table-layout="auto">
        <el-table-column type="selection" width="40" align="center"></el-table-column>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="software_name" label="软件" min-width="80" align="center">
            <template #default="scope">
                <el-tooltip :content="scope.row.software_name" placement="top" v-if="scope.row.software_name && scope.row.software_name.length > 5">
                    <span>{{ scope.row.software_name.substring(0, 5) }}...</span>
                </el-tooltip>
                <span v-else>{{ scope.row.software_name || '-' }}</span>
            </template>
        </el-table-column>
        <el-table-column label="状态" width="70" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.is_online ? 'success' : 'info'" size="small">
                    {{ scope.row.is_online ? '在线' : '离线' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="登录方式" width="80" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.username && scope.row.username.startsWith('trial_') ? 'warning' : 'success'" size="small">
                    {{ scope.row.username && scope.row.username.startsWith('trial_') ? '试用' : '授权码' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="machine_code" label="机器码" min-width="180" align="center">
            <template #default="scope">
                <template v-if="scope.row.machine_code">
                    <el-tooltip :content="scope.row.machine_code" placement="top">
                        <span style="font-family: monospace; font-size: 12px;">{{ scope.row.machine_code.substring(0, 16) }}...</span>
                    </el-tooltip>
                    <el-button link type="primary" size="small" @click="copyText(scope.row.machine_code)">
                        <el-icon><CopyDocument /></el-icon>
                    </el-button>
                </template>
                <span v-else style="color:#c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column label="IP/归属地" min-width="160" align="center">
            <template #default="scope">
                <template v-if="scope.row.last_login_ip">
                    <div>{{ scope.row.last_login_ip }}</div>
                    <div style="font-size: 12px; color: #909399;">{{ scope.row.ip_location || '未知' }}</div>
                </template>
                <span v-else style="color:#c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="注册时间" min-width="140" align="center"></el-table-column>
        <el-table-column prop="expire_time" label="到期时间" min-width="140" align="center">
            <template #default="scope">
                <span v-if="scope.row.expire_time" :style="{color: isExpired(scope.row.expire_time) ? '#f56c6c' : ''}">{{ scope.row.expire_time }}</span>
                <span v-else style="color:#c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column prop="status" label="账号" width="70" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.status == 1 ? 'success' : 'danger'" size="small">
                    {{ scope.row.status == 1 ? '正常' : '禁用' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right" align="center">
            <template #default="scope">
                <div style="display: flex; gap: 4px; justify-content: center; flex-wrap: nowrap;">
                    <el-button type="warning" size="small" @click="handleKickOffline(scope.row)" v-if="scope.row.is_online">下线</el-button>
                    <el-button :type="scope.row.status == 1 ? 'danger' : 'success'" size="small" @click="handleToggleStatus(scope.row)">
                        {{ scope.row.status == 1 ? '禁用' : '启用' }}
                    </el-button>
                    <el-button type="danger" size="small" @click="handleBanMachine(scope.row)" v-if="scope.row.machine_code && !scope.row.machine_banned">封机器</el-button>
                    <el-button type="success" size="small" @click="handleUnbanMachine(scope.row)" v-if="scope.row.machine_banned">解封</el-button>
                    <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
                </div>
            </template>
        </el-table-column>
    </el-table>
    
    <div class="pagination-container" style="justify-content: flex-end;">
        <el-pagination
            v-model:current-page="pagination.page"
            v-model:page-size="pagination.pageSize"
            :page-sizes="[20, 50, 100, 200]"
            :total="pagination.total"
            layout="total, sizes, prev, pager, next, jumper"
            @size-change="loadData"
            @current-change="loadData"
        />
    </div>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
userList: [],
softwareList: [],
loading: false,
selectedRows: [],
searchForm: {
    software_id: '',
    status: '',
    online: '',
    keyword: ''
},
pagination: { page: 1, pageSize: 20, total: 0 }
";

$vueMounted = "
this.loadData();
this.loadSoftware();
";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            ...this.searchForm
        });
        const res = await fetch('api_users.php?' + params);
        const data = await res.json();
        if (data.code === 0) {
            this.userList = data.data;
            this.pagination.total = data.total || 0;
        }
    } catch (e) {
        console.error(e);
    }
    this.loading = false;
},
async loadSoftware() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
handleRefresh() {
    this.loadData();
},
handleSelectionChange(rows) {
    this.selectedRows = rows;
},
isExpired(expireTime) {
    if (!expireTime) return false;
    return new Date(expireTime) < new Date();
},
copyText(text) {
    navigator.clipboard.writeText(text).then(() => {
        ElementPlus.ElMessage.success('已复制');
    });
},
async handleKickOffline(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定将该用户强制下线吗？', '下线确认', { type: 'warning' });
        const res = await fetch('api_users.php?action=kickOffline', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('已强制下线');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleToggleStatus(row) {
    const action = row.status == 1 ? 'disable' : 'enable';
    const actionText = row.status == 1 ? '禁用' : '启用';
    try {
        const res = await fetch('api_users.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(actionText + '成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleBanMachine(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('封禁后该机器码将无法登录任何账号，确定封禁吗？', '封禁机器', { type: 'error' });
        const res = await fetch('api_users.php?action=banMachine', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id, machine_code: row.machine_code })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('机器已封禁');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleUnbanMachine(row) {
    try {
        const res = await fetch('api_users.php?action=unbanMachine', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id, machine_code: row.machine_code })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('机器已解封');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除该用户？删除后无法恢复！', '删除确认', { type: 'error' });
        const res = await fetch('api_users.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('删除成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleBatchKickOffline() {
    if (this.selectedRows.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm('确定将选中的 ' + this.selectedRows.length + ' 个用户强制下线吗？', '批量下线', { type: 'warning' });
        const ids = this.selectedRows.map(r => r.id);
        const res = await fetch('api_users.php?action=batchKickOffline', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('批量下线成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleBatchBan() {
    if (this.selectedRows.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm('确定禁用选中的 ' + this.selectedRows.length + ' 个用户吗？', '批量禁用', { type: 'warning' });
        const ids = this.selectedRows.map(r => r.id);
        const res = await fetch('api_users.php?action=batchDisable', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('批量禁用成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleBatchDelete() {
    if (this.selectedRows.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除选中的 ' + this.selectedRows.length + ' 个用户吗？此操作不可恢复！', '批量删除', { type: 'error' });
        const ids = this.selectedRows.map(r => r.id);
        const res = await fetch('api_users.php?action=batchDelete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('批量删除成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
