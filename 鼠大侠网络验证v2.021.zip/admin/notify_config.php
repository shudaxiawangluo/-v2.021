<?php
$pageTitle = '通知配置';
$breadcrumbs = ['消息通知', '通知配置'];

ob_start();
?>

<el-alert type="info" :closable="false" style="margin-bottom: 16px;">
    配置通知渠道后，系统可自动发送订单支付成功、授权到期提醒等通知消息。
</el-alert>

<div style="display: flex; gap: 16px; margin-bottom: 16px;">
    <div style="flex: 1; background: #fff; border-radius: 4px; box-shadow: 0 2px 12px 0 rgba(0,0,0,.1); height: 340px; display: flex; flex-direction: column;">
        <div style="padding: 14px 20px; border-bottom: 1px solid #ebeef5; display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 500;">邮件通知</span>
            <el-switch v-model="emailConfig.enabled" @change="saveConfig('email')"></el-switch>
        </div>
        <div style="padding: 20px; flex: 1; display: flex; flex-direction: column;">
            <div style="flex: 1;">
                <el-form label-width="70px" size="small">
                    <el-form-item label="SMTP服务"><el-input v-model="emailConfig.smtp_host" placeholder="smtp.qq.com"></el-input></el-form-item>
                    <el-form-item label="端口"><el-input v-model="emailConfig.smtp_port" placeholder="465"></el-input></el-form-item>
                    <el-form-item label="发件邮箱"><el-input v-model="emailConfig.smtp_user" placeholder="your@qq.com"></el-input></el-form-item>
                    <el-form-item label="授权码"><el-input v-model="emailConfig.smtp_pass" type="password" show-password></el-input></el-form-item>
                    <el-form-item label="发件人名"><el-input v-model="emailConfig.from_name" placeholder="系统通知"></el-input></el-form-item>
                </el-form>
            </div>
            <div style="text-align: right; padding-top: 12px; border-top: 1px solid #ebeef5;">
                <el-button size="small" @click="testEmail">测试</el-button>
                <el-button type="primary" size="small" @click="saveConfig('email')">保存</el-button>
            </div>
        </div>
    </div>
    
    <div style="flex: 1; background: #fff; border-radius: 4px; box-shadow: 0 2px 12px 0 rgba(0,0,0,.1); height: 340px; display: flex; flex-direction: column;">
        <div style="padding: 14px 20px; border-bottom: 1px solid #ebeef5; display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 500;">微信通知</span>
            <el-switch v-model="wechatConfig.enabled" @change="saveConfig('wechat')"></el-switch>
        </div>
        <div style="padding: 20px; flex: 1; display: flex; flex-direction: column;">
            <div style="flex: 1;">
                <el-form label-width="70px" size="small">
                    <el-form-item label="Webhook"><el-input v-model="wechatConfig.webhook_url" placeholder="企业微信机器人Webhook"></el-input></el-form-item>
                </el-form>
                <div style="font-size: 12px; color: #909399; line-height: 1.8; padding: 12px; background: #f5f7fa; border-radius: 4px; margin-top: 12px;">
                    1. 打开企业微信群聊<br>
                    2. 右上角 → 群机器人 → 添加<br>
                    3. 复制Webhook地址
                </div>
            </div>
            <div style="text-align: right; padding-top: 12px; border-top: 1px solid #ebeef5;">
                <el-button size="small" @click="testWechat">测试</el-button>
                <el-button type="primary" size="small" @click="saveConfig('wechat')">保存</el-button>
            </div>
        </div>
    </div>
    
    <div style="flex: 1; background: #fff; border-radius: 4px; box-shadow: 0 2px 12px 0 rgba(0,0,0,.1); height: 340px; display: flex; flex-direction: column;">
        <div style="padding: 14px 20px; border-bottom: 1px solid #ebeef5; display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 500;">钉钉通知</span>
            <el-switch v-model="dingtalkConfig.enabled" @change="saveConfig('dingtalk')"></el-switch>
        </div>
        <div style="padding: 20px; flex: 1; display: flex; flex-direction: column;">
            <div style="flex: 1;">
                <el-form label-width="70px" size="small">
                    <el-form-item label="Webhook"><el-input v-model="dingtalkConfig.webhook_url" placeholder="钉钉机器人Webhook"></el-input></el-form-item>
                    <el-form-item label="加签密钥"><el-input v-model="dingtalkConfig.secret" placeholder="可选"></el-input></el-form-item>
                </el-form>
                <div style="font-size: 12px; color: #909399; line-height: 1.8; padding: 12px; background: #f5f7fa; border-radius: 4px; margin-top: 12px;">
                    1. 打开钉钉群 → 群设置<br>
                    2. 智能群助手 → 添加机器人<br>
                    3. 选择自定义 → 复制Webhook
                </div>
            </div>
            <div style="text-align: right; padding-top: 12px; border-top: 1px solid #ebeef5;">
                <el-button size="small" @click="testDingtalk">测试</el-button>
                <el-button type="primary" size="small" @click="saveConfig('dingtalk')">保存</el-button>
            </div>
        </div>
    </div>
    
    <div style="flex: 1; background: #fff; border-radius: 4px; box-shadow: 0 2px 12px 0 rgba(0,0,0,.1); height: 340px; display: flex; flex-direction: column;">
        <div style="padding: 14px 20px; border-bottom: 1px solid #ebeef5; display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 500;">Telegram通知</span>
            <el-switch v-model="telegramConfig.enabled" @change="saveConfig('telegram')"></el-switch>
        </div>
        <div style="padding: 20px; flex: 1; display: flex; flex-direction: column;">
            <div style="flex: 1;">
                <el-form label-width="70px" size="small">
                    <el-form-item label="Bot Token"><el-input v-model="telegramConfig.bot_token" placeholder="机器人Token"></el-input></el-form-item>
                    <el-form-item label="Chat ID"><el-input v-model="telegramConfig.chat_id" placeholder="接收消息的ID"></el-input></el-form-item>
                    <el-form-item label="代理地址"><el-input v-model="telegramConfig.proxy" placeholder="http://127.0.0.1:7890"></el-input></el-form-item>
                </el-form>
                <div style="font-size: 12px; color: #e6a23c; margin-top: 12px;">国内服务器需配置代理才能使用</div>
            </div>
            <div style="text-align: right; padding-top: 12px; border-top: 1px solid #ebeef5;">
                <el-button size="small" @click="testTelegram">测试</el-button>
                <el-button type="primary" size="small" @click="saveConfig('telegram')">保存</el-button>
            </div>
        </div>
    </div>
</div>

<el-card shadow="hover">
    <template #header><span style="font-weight: 500;">通知事件设置</span></template>
    <el-row :gutter="12">
        <el-col :span="6" v-for="item in eventSettings" :key="item.key" style="margin-bottom: 12px;">
            <div style="border: 1px solid #ebeef5; border-radius: 4px; padding: 16px; height: 100px;">
                <div style="font-weight: 500; margin-bottom: 6px;">{{ item.name }}</div>
                <div style="font-size: 12px; color: #909399; margin-bottom: 12px;">{{ item.description }}</div>
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <span style="font-size: 12px; display: flex; align-items: center; gap: 4px;"><el-switch v-model="item.email" size="small" @change="saveEventSettings"></el-switch>邮件</span>
                    <span style="font-size: 12px; display: flex; align-items: center; gap: 4px;"><el-switch v-model="item.wechat" size="small" @change="saveEventSettings"></el-switch>微信</span>
                    <span style="font-size: 12px; display: flex; align-items: center; gap: 4px;"><el-switch v-model="item.dingtalk" size="small" @change="saveEventSettings"></el-switch>钉钉</span>
                    <span style="font-size: 12px; display: flex; align-items: center; gap: 4px;"><el-switch v-model="item.telegram" size="small" @change="saveEventSettings"></el-switch>TG</span>
                </div>
            </div>
        </el-col>
    </el-row>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
emailConfig: { enabled: false, smtp_host: '', smtp_port: '465', smtp_user: '', smtp_pass: '', from_name: '' },
wechatConfig: { enabled: false, webhook_url: '' },
dingtalkConfig: { enabled: false, webhook_url: '', secret: '' },
telegramConfig: { enabled: false, bot_token: '', chat_id: '', proxy: '' },
eventSettings: [
    { key: 'order_paid', name: '订单支付成功', description: '用户支付订单后通知', email: true, wechat: true, dingtalk: true, telegram: true },
    { key: 'withdraw_apply', name: '提现申请', description: '代理商申请提现时通知', email: false, wechat: true, dingtalk: true, telegram: true },
    { key: 'auth_activated', name: '授权激活', description: '用户激活授权码时通知', email: true, wechat: false, dingtalk: false, telegram: false },
    { key: 'auth_expiring', name: '授权到期', description: '授权码即将到期时通知', email: true, wechat: false, dingtalk: false, telegram: false },
    { key: 'abnormal_login', name: '异常登录', description: '检测到异地登录时通知', email: true, wechat: false, dingtalk: false, telegram: false },
    { key: 'new_user', name: '新用户注册', description: '有新用户注册时通知', email: false, wechat: true, dingtalk: true, telegram: true },
    { key: 'ip_blocked', name: 'IP封禁', description: 'IP被自动封禁时通知', email: false, wechat: true, dingtalk: true, telegram: true },
    { key: 'system_error', name: '系统异常', description: '系统发生异常时通知', email: false, wechat: true, dingtalk: true, telegram: true }
]
";

$vueMounted = "this.loadConfig();";

$vueMethods = "
async loadConfig() {
    try {
        const res = await fetch('api_notify.php?action=get_config');
        const data = await res.json();
        if (data.code === 0) {
            if (data.data.email) this.emailConfig = { ...this.emailConfig, ...data.data.email };
            if (data.data.wechat) this.wechatConfig = { ...this.wechatConfig, ...data.data.wechat };
            if (data.data.dingtalk) this.dingtalkConfig = { ...this.dingtalkConfig, ...data.data.dingtalk };
            if (data.data.telegram) this.telegramConfig = { ...this.telegramConfig, ...data.data.telegram };
            if (data.data.events) {
                data.data.events.forEach(e => {
                    const item = this.eventSettings.find(i => i.key === e.key);
                    if (item) Object.assign(item, e);
                });
            }
        }
    } catch (e) {}
},
async saveConfig(type) {
    let cfg = type === 'email' ? this.emailConfig : type === 'wechat' ? this.wechatConfig : type === 'dingtalk' ? this.dingtalkConfig : this.telegramConfig;
    const res = await fetch('api_notify.php?action=save_config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type, config: cfg }) });
    const data = await res.json();
    ElementPlus.ElMessage[data.code === 0 ? 'success' : 'error'](data.code === 0 ? '保存成功' : data.msg);
},
async saveEventSettings() {
    await fetch('api_notify.php?action=save_events', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ events: this.eventSettings }) });
},
async testEmail() {
    const { value } = await ElementPlus.ElMessageBox.prompt('输入测试邮箱', '测试').catch(() => ({}));
    if (!value) return;
    const res = await fetch('api_notify.php?action=test_email', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: value }) });
    const data = await res.json();
    ElementPlus.ElMessage[data.code === 0 ? 'success' : 'error'](data.code === 0 ? '发送成功' : data.msg);
},
async testWechat() {
    const res = await fetch('api_notify.php?action=test_wechat', { method: 'POST' });
    const data = await res.json();
    ElementPlus.ElMessage[data.code === 0 ? 'success' : 'error'](data.code === 0 ? '发送成功' : data.msg);
},
async testDingtalk() {
    const res = await fetch('api_notify.php?action=test_dingtalk', { method: 'POST' });
    const data = await res.json();
    ElementPlus.ElMessage[data.code === 0 ? 'success' : 'error'](data.code === 0 ? '发送成功' : data.msg);
},
async testTelegram() {
    const res = await fetch('api_notify.php?action=test_telegram', { method: 'POST' });
    const data = await res.json();
    ElementPlus.ElMessage[data.code === 0 ? 'success' : 'error'](data.code === 0 ? '发送成功' : data.msg);
}
";

include 'layout.php';
?>
