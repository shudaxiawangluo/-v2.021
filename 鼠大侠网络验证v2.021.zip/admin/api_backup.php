<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';

$action = $_GET['action'] ?? '';
$backupDir = __DIR__ . '/../backups';

// 确保备份目录存在
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0755, true);
    file_put_contents($backupDir . '/.htaccess', 'Deny from all');
}

switch ($action) {
    case 'list':
        header('Content-Type: application/json; charset=utf-8');
        $files = glob($backupDir . '/*.sql');
        $list = [];
        foreach ($files as $file) {
            $list[] = [
                'filename' => basename($file),
                'size' => filesize($file),
                'time' => date('Y-m-d H:i:s', filemtime($file))
            ];
        }
        // 按时间倒序
        usort($list, function($a, $b) {
            return strtotime($b['time']) - strtotime($a['time']);
        });
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
        
    case 'backup':
        header('Content-Type: application/json; charset=utf-8');
        try {
            $db = getDB();
            $filename = 'backup_' . date('Ymd_His') . '.sql';
            $filepath = $backupDir . '/' . $filename;
            
            // 获取所有表
            $tables = [];
            $result = $db->query("SHOW TABLES");
            while ($row = $result->fetch(PDO::FETCH_NUM)) {
                $tables[] = $row[0];
            }
            
            $sql = "-- 数据库备份\n";
            $sql .= "-- 备份时间: " . date('Y-m-d H:i:s') . "\n";
            $sql .= "-- ----------------------------------------\n\n";
            $sql .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
            
            foreach ($tables as $table) {
                // 表结构
                $createResult = $db->query("SHOW CREATE TABLE `$table`");
                $createRow = $createResult->fetch(PDO::FETCH_NUM);
                $sql .= "DROP TABLE IF EXISTS `$table`;\n";
                $sql .= $createRow[1] . ";\n\n";
                
                // 表数据
                $dataResult = $db->query("SELECT * FROM `$table`");
                $rows = $dataResult->fetchAll(PDO::FETCH_ASSOC);
                
                if (count($rows) > 0) {
                    $columns = array_keys($rows[0]);
                    $columnList = '`' . implode('`, `', $columns) . '`';
                    
                    foreach ($rows as $row) {
                        $values = array_map(function($v) use ($db) {
                            if ($v === null) return 'NULL';
                            return $db->quote($v);
                        }, array_values($row));
                        $sql .= "INSERT INTO `$table` ($columnList) VALUES (" . implode(', ', $values) . ");\n";
                    }
                    $sql .= "\n";
                }
            }
            
            $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
            
            file_put_contents($filepath, $sql);
            
            echo json_encode(['code' => 0, 'msg' => '备份成功', 'data' => ['filename' => $filename, 'size' => filesize($filepath)]]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '备份失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'download':
        $file = $_GET['file'] ?? '';
        $file = basename($file); // 防止目录遍历
        $filepath = $backupDir . '/' . $file;
        
        if (!file_exists($filepath) || !preg_match('/^backup_\d{8}_\d{6}\.sql$/', $file)) {
            die('文件不存在');
        }
        
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
        
    case 'delete':
        header('Content-Type: application/json; charset=utf-8');
        $input = json_decode(file_get_contents('php://input'), true);
        $file = basename($input['filename'] ?? '');
        $filepath = $backupDir . '/' . $file;
        
        if (!file_exists($filepath) || !preg_match('/^backup_\d{8}_\d{6}\.sql$/', $file)) {
            echo json_encode(['code' => 1, 'msg' => '文件不存在']);
            break;
        }
        
        unlink($filepath);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
        
    case 'clear':
        header('Content-Type: application/json; charset=utf-8');
        $files = glob($backupDir . '/*.sql');
        $count = 0;
        foreach ($files as $file) {
            if (unlink($file)) $count++;
        }
        echo json_encode(['code' => 0, 'msg' => "已清理 $count 个备份文件"]);
        break;
        
    default:
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
