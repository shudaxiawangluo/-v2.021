<?php
$pageTitle = '支付配置';
$breadcrumbs = ['订单管理', '支付配置'];

ob_start();
?>

<el-alert type="info" :closable="false" style="margin-bottom: 16px;">
    配置支付接口后，用户可通过发卡页面自助购买授权码。支持支付宝当面付、微信支付、易支付、USDT等多种支付方式。
</el-alert>

<style>
.pay-card { margin-bottom: 16px; }
.pay-card .el-card__header { padding: 12px 16px; }
.pay-card .el-card__body { padding: 16px; min-height: 220px; }
.pay-card .el-form-item { margin-bottom: 12px; }
.pay-card .el-form-item:last-child { margin-bottom: 0; }
.pay-card .card-footer { text-align: right; margin-top: 16px; padding-top: 12px; border-top: 1px solid #ebeef5; }
</style>

<el-row :gutter="16">
    <!-- 微信支付 -->
    <el-col :span="12">
        <el-card shadow="hover" class="pay-card">
            <template #header>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: 500;"><img src="../img/微信支付.png" style="width:20px;height:20px;vertical-align:middle;margin-right:6px;">微信支付（Native）</span>
                    <el-switch v-model="wechatConfig.enabled" @change="saveConfig('wechat')"></el-switch>
                </div>
            </template>
            <el-form label-width="80px" size="small">
                <el-form-item label="AppID"><el-input v-model="wechatConfig.app_id" placeholder="微信公众号/小程序AppID"></el-input></el-form-item>
                <el-form-item label="商户号"><el-input v-model="wechatConfig.mch_id" placeholder="微信支付商户号"></el-input></el-form-item>
                <el-form-item label="API密钥"><el-input v-model="wechatConfig.api_key" type="password" show-password placeholder="商户API密钥（V2）"></el-input></el-form-item>
                <el-form-item label="回调地址"><el-input v-model="wechatConfig.notify_url" readonly><template #append><el-button @click="copyText(wechatConfig.notify_url)" size="small">复制</el-button></template></el-input></el-form-item>
            </el-form>
            <div class="card-footer"><el-button type="primary" size="small" @click="saveConfig('wechat')" :loading="saving">保存配置</el-button></div>
        </el-card>
    </el-col>
    
    <!-- 支付宝当面付 -->
    <el-col :span="12">
        <el-card shadow="hover" class="pay-card">
            <template #header>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: 500;"><img src="../img/支付宝支付.png" style="width:20px;height:20px;vertical-align:middle;margin-right:6px;">支付宝当面付</span>
                    <el-switch v-model="alipayConfig.enabled" @change="saveConfig('alipay')"></el-switch>
                </div>
            </template>
            <el-form label-width="80px" size="small">
                <el-form-item label="AppID"><el-input v-model="alipayConfig.app_id" placeholder="支付宝应用AppID"></el-input></el-form-item>
                <el-form-item label="应用私钥"><el-input v-model="alipayConfig.private_key" type="password" show-password placeholder="应用私钥（RSA2）"></el-input></el-form-item>
                <el-form-item label="支付宝公钥"><el-input v-model="alipayConfig.alipay_public_key" type="password" show-password placeholder="支付宝公钥"></el-input></el-form-item>
                <el-form-item label="回调地址"><el-input v-model="alipayConfig.notify_url" readonly><template #append><el-button @click="copyText(alipayConfig.notify_url)" size="small">复制</el-button></template></el-input></el-form-item>
            </el-form>
            <div class="card-footer"><el-button type="primary" size="small" @click="saveConfig('alipay')" :loading="saving">保存配置</el-button></div>
        </el-card>
    </el-col>
</el-row>

<el-row :gutter="16">
    <!-- 易支付 -->
    <el-col :span="12">
        <el-card shadow="hover" class="pay-card">
            <template #header>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: 500;"><img src="../img/网易支付.png" style="width:20px;height:20px;vertical-align:middle;margin-right:6px;">易支付（彩虹）</span>
                    <el-switch v-model="epayConfig.enabled" @change="saveConfig('epay')"></el-switch>
                </div>
            </template>
            <el-form label-width="80px" size="small">
                <el-form-item label="网关地址"><el-input v-model="epayConfig.api_url" placeholder="如：https://pay.example.com"></el-input></el-form-item>
                <el-form-item label="商户ID"><el-input v-model="epayConfig.pid" placeholder="易支付商户ID"></el-input></el-form-item>
                <el-form-item label="商户密钥"><el-input v-model="epayConfig.key" type="password" show-password placeholder="易支付商户密钥"></el-input></el-form-item>
                <el-form-item label="回调地址"><el-input v-model="epayConfig.notify_url" readonly><template #append><el-button @click="copyText(epayConfig.notify_url)" size="small">复制</el-button></template></el-input></el-form-item>
            </el-form>
            <div class="card-footer"><el-button type="primary" size="small" @click="saveConfig('epay')" :loading="saving">保存配置</el-button></div>
        </el-card>
    </el-col>
    
    <!-- USDT支付 -->
    <el-col :span="12">
        <el-card shadow="hover" class="pay-card">
            <template #header>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-weight: 500;"><img src="../img/USDT.png" style="width:20px;height:20px;vertical-align:middle;margin-right:6px;">USDT支付</span>
                    <el-switch v-model="usdtConfig.enabled" @change="saveConfig('usdt')"></el-switch>
                </div>
            </template>
            <el-form label-width="80px" size="small">
                <el-form-item label="收款模式">
                    <el-radio-group v-model="usdtConfig.mode" size="small">
                        <el-radio-button label="gateway">网关</el-radio-button>
                        <el-radio-button label="manual">手动</el-radio-button>
                    </el-radio-group>
                </el-form-item>
                <template v-if="usdtConfig.mode === 'gateway'">
                    <el-form-item label="网关地址"><el-input v-model="usdtConfig.api_url" placeholder="如：https://usdt.example.com"></el-input></el-form-item>
                    <el-form-item label="API Token"><el-input v-model="usdtConfig.api_token" type="password" show-password placeholder="USDT支付API Token"></el-input></el-form-item>
                </template>
                <template v-else>
                    <el-form-item label="TRC20"><el-input v-model="usdtConfig.trc20_address" placeholder="TRC20收款地址"></el-input></el-form-item>
                    <el-form-item label="ERC20"><el-input v-model="usdtConfig.erc20_address" placeholder="ERC20收款地址（可选）"></el-input></el-form-item>
                </template>
                <el-form-item label="汇率">
                    <el-input-number v-model="usdtConfig.usdt_rate" :min="1" :max="20" :precision="2" size="small" style="width: 100px;"></el-input-number>
                    <span style="margin-left: 6px; color: #909399; font-size: 12px;">1 USDT = ? CNY</span>
                </el-form-item>
            </el-form>
            <div class="card-footer"><el-button type="primary" size="small" @click="saveConfig('usdt')" :loading="saving">保存配置</el-button></div>
        </el-card>
    </el-col>
</el-row>

<el-card shadow="hover">
    <template #header><span style="font-weight: 500;">发卡页面设置</span></template>
    <el-form label-width="120px">
        <el-form-item label="发卡页面地址">
            <div style="display: flex; gap: 10px; align-items: center;">
                <el-input :model-value="shopUrl" readonly style="max-width: 400px;"></el-input>
                <el-button type="primary" @click="copyText(shopUrl)">复制地址</el-button>
                <el-button @click="openShop">打开页面</el-button>
            </div>
        </el-form-item>
        <el-form-item label="启用发卡页面">
            <el-switch v-model="shopEnabled" @change="saveShopSetting"></el-switch>
            <span style="margin-left: 12px; color: #909399;">关闭后用户无法访问发卡页面</span>
        </el-form-item>
    </el-form>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
saving: false,
shopUrl: '',
shopEnabled: true,
alipayConfig: { enabled: false, app_id: '', private_key: '', alipay_public_key: '', notify_url: '' },
wechatConfig: { enabled: false, app_id: '', mch_id: '', api_key: '', notify_url: '' },
epayConfig: { enabled: false, api_url: '', pid: '', key: '', notify_url: '' },
usdtConfig: { enabled: false, mode: 'gateway', api_url: '', api_token: '', trc20_address: '', erc20_address: '', usdt_rate: 7.2, notify_url: '' }
";

$vueMounted = "
var baseUrl = window.location.origin + window.location.pathname.replace('/admin/payment_config.php', '');
this.shopUrl = baseUrl + '/shop/';
this.alipayConfig.notify_url = baseUrl + '/api/pay/notify_alipay.php';
this.wechatConfig.notify_url = baseUrl + '/api/pay/notify_wechat.php';
this.epayConfig.notify_url = baseUrl + '/api/pay/notify_epay.php';
this.usdtConfig.notify_url = baseUrl + '/api/pay/notify_usdt.php';
this.loadConfig();
";

$vueMethods = "
async loadConfig() {
    try {
        var res = await fetch('api_payment.php?action=get_config');
        var data = await res.json();
        if (data.code === 0 && data.data) {
            if (data.data.alipay) this.alipayConfig = { ...this.alipayConfig, ...data.data.alipay, enabled: data.data.alipay.status == 1 };
            if (data.data.wechat) this.wechatConfig = { ...this.wechatConfig, ...data.data.wechat, enabled: data.data.wechat.status == 1 };
            if (data.data.epay) this.epayConfig = { ...this.epayConfig, ...data.data.epay, enabled: data.data.epay.status == 1 };
            if (data.data.usdt) this.usdtConfig = { ...this.usdtConfig, ...data.data.usdt, enabled: data.data.usdt.status == 1 };
            this.shopEnabled = data.data.shop_enabled !== false;
        }
    } catch (e) { console.error(e); }
},
async saveConfig(type) {
    this.saving = true;
    try {
        var configData = {};
        if (type === 'alipay') configData = this.alipayConfig;
        else if (type === 'wechat') configData = this.wechatConfig;
        else if (type === 'epay') configData = this.epayConfig;
        else if (type === 'usdt') configData = this.usdtConfig;
        
        var res = await fetch('api_payment.php?action=save_config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: type, config: configData })
        });
        var data = await res.json();
        if (data.code === 0) ElementPlus.ElMessage.success('保存成功');
        else ElementPlus.ElMessage.error(data.msg);
    } catch (e) { ElementPlus.ElMessage.error('保存失败'); }
    this.saving = false;
},
copyText(text) {
    navigator.clipboard.writeText(text).then(function() { ElementPlus.ElMessage.success('已复制到剪贴板'); }).catch(function() { ElementPlus.ElMessage.error('复制失败'); });
},
openShop() { window.open(this.shopUrl, '_blank'); },
async saveShopSetting() {
    try {
        var res = await fetch('api_payment.php?action=save_shop_setting', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled: this.shopEnabled })
        });
        var data = await res.json();
        if (data.code === 0) ElementPlus.ElMessage.success(this.shopEnabled ? '发卡页面已启用' : '发卡页面已禁用');
    } catch (e) {}
}
";

include 'layout.php';
?>
