<?php
$pageTitle = '消息模板';
$breadcrumbs = ['消息通知', '消息模板'];

ob_start();
?>

<el-card shadow="hover">
    <el-table :data="templateList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="name" label="模板名称" min-width="120"></el-table-column>
        <el-table-column prop="event" label="事件类型" min-width="120">
            <template #default="scope">
                <el-tag size="small" type="info">{{ scope.row.event }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="title" label="标题" min-width="150"></el-table-column>
        <el-table-column label="状态" width="80" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.status == 1 ? 'success' : 'info'" size="small">{{ scope.row.status == 1 ? '启用' : '禁用' }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column label="操作" width="160" fixed="right" align="center">
            <template #default="scope">
                <el-button type="primary" size="small" @click="handlePreview(scope.row)">预览</el-button>
                <el-button type="warning" size="small" @click="handleEdit(scope.row)">编辑</el-button>
            </template>
        </el-table-column>
    </el-table>
</el-card>

<!-- 编辑模板对话框 -->
<el-dialog v-model="showDialog" title="编辑模板" width="650px">
    <el-form :model="editForm" label-width="100px">
        <el-form-item label="模板名称">
            <el-input v-model="editForm.name" disabled></el-input>
        </el-form-item>
        <el-form-item label="事件类型">
            <el-input v-model="editForm.event" disabled></el-input>
        </el-form-item>
        <el-form-item label="标题">
            <el-input v-model="editForm.title" placeholder="消息标题"></el-input>
        </el-form-item>
        <el-form-item label="内容模板">
            <el-input v-model="editForm.content" type="textarea" :rows="8" placeholder="消息内容，支持变量：{order_no}、{amount}、{product_name}等"></el-input>
        </el-form-item>
        <el-form-item label="可用变量">
            <div style="font-size: 12px; color: #909399; line-height: 1.8;">
                {order_no} 订单号 | {amount} 金额 | {product_name} 商品名 | {auth_code} 授权码 | {expire_time} 到期时间 | {time} 当前时间
            </div>
        </el-form-item>
        <el-form-item label="状态">
            <el-switch v-model="editForm.statusBool" active-text="启用" inactive-text="禁用"></el-switch>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSave" :loading="saving">保存</el-button>
    </template>
</el-dialog>

<!-- 预览对话框 -->
<el-dialog v-model="showPreview" title="邮件预览" width="700px">
    <div style="background:#f5f7fa;padding:20px;border-radius:4px;">
        <iframe :srcdoc="previewHtml" style="width:100%;height:500px;border:none;background:#fff;border-radius:4px;"></iframe>
    </div>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
templateList: [],
loading: false,
saving: false,
showDialog: false,
showPreview: false,
previewHtml: '',
editForm: { id: '', name: '', event: '', title: '', content: '', statusBool: true }
";

$vueMounted = "this.loadData();";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const res = await fetch('api_notify.php?action=template_list');
        const data = await res.json();
        if (data.code === 0) this.templateList = data.data;
    } catch (e) { console.error(e); }
    this.loading = false;
},
handleEdit(row) {
    this.editForm = { ...row, statusBool: row.status == 1 };
    this.showDialog = true;
},
handlePreview(row) {
    const title = row.title || '通知';
    const content = row.content || '';
    const lines = content.split('\\n');
    let contentHtml = '';
    lines.forEach(line => {
        line = line.trim();
        if (!line) return;
        if (line.includes(':')) {
            const [label, value] = line.split(':');
            contentHtml += '<tr><td style=\"padding:12px 16px;color:#606266;border-bottom:1px solid #ebeef5;width:120px;background:#fafafa;\">' + label.trim() + '</td><td style=\"padding:12px 16px;color:#303133;border-bottom:1px solid #ebeef5;\">' + (value || '').trim() + '</td></tr>';
        } else {
            contentHtml += '<tr><td colspan=\"2\" style=\"padding:12px 16px;color:#303133;border-bottom:1px solid #ebeef5;\">' + line + '</td></tr>';
        }
    });
    this.previewHtml = '<!DOCTYPE html><html><head><meta charset=\"UTF-8\"></head><body style=\"margin:0;padding:0;background:#f5f7fa;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif;\"><div style=\"max-width:560px;margin:20px auto;background:#fff;border-radius:4px;box-shadow:0 2px 12px 0 rgba(0,0,0,0.1);\"><div style=\"padding:20px;border-bottom:1px solid #ebeef5;\"><h1 style=\"margin:0;color:#303133;font-size:18px;font-weight:500;\">' + title + '</h1></div><div style=\"padding:20px;\"><table style=\"width:100%;border-collapse:collapse;border:1px solid #ebeef5;border-radius:4px;\">' + contentHtml + '</table></div><div style=\"padding:16px 20px;background:#fafafa;color:#909399;font-size:12px;text-align:center;border-top:1px solid #ebeef5;\">此邮件由系统自动发送</div></div></body></html>';
    this.showPreview = true;
},
async handleSave() {
    this.saving = true;
    try {
        const res = await fetch('api_notify.php?action=update_template', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...this.editForm, status: this.editForm.statusBool ? 1 : 0 })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('保存失败'); }
    this.saving = false;
}
";

include 'layout.php';
?>
