<?php
/**
 * 风险设备审核页面
 */

require_once __DIR__ . '/layout.php';
requireLogin();

$pageTitle = '风险设备';
include __DIR__ . '/layout.php';
?>

<div class="container-fluid">
    <div class="row mb-3">
        <div class="col">
            <h4><i class="bi bi-shield-exclamation"></i> 风险设备审核</h4>
            <p class="text-muted">审核检测到虚拟机/模拟器的设备</p>
        </div>
    </div>

    <!-- 筛选 -->
    <div class="card mb-3">
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">软件</label>
                    <select class="form-select" name="software_id" id="softwareSelect">
                        <option value="">全部软件</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">风险等级</label>
                    <select class="form-select" name="risk_level" id="riskLevelSelect">
                        <option value="">全部</option>
                        <option value="1">待审核</option>
                        <option value="2">已拒绝</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">
                        <i class="bi bi-search"></i> 查询
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="bi bi-arrow-clockwise"></i> 重置
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- 列表 -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>软件</th>
                            <th>机器指纹</th>
                            <th>平台</th>
                            <th>系统版本</th>
                            <th>虚拟机类型</th>
                            <th>IP</th>
                            <th>风险等级</th>
                            <th>创建时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody id="deviceList">
                        <tr>
                            <td colspan="10" class="text-center">加载中...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- 分页 -->
            <nav id="pagination" class="mt-3"></nav>
        </div>
    </div>
</div>

<script>
let currentPage = 1;
const pageSize = 20;

// 加载软件列表
function loadSoftwareList() {
    fetch('api_software.php?action=list')
        .then(r => r.json())
        .then(data => {
            if (data.code === 200) {
                const select = document.getElementById('softwareSelect');
                data.data.list.forEach(item => {
                    select.innerHTML += `<option value="${item.id}">${item.name}</option>`;
                });
            }
        });
}

// 加载设备列表
function loadDeviceList(page = 1) {
    currentPage = page;
    const softwareId = document.getElementById('softwareSelect').value;
    const riskLevel = document.getElementById('riskLevelSelect').value;
    
    let url = `api_risk.php?action=list&page=${page}&page_size=${pageSize}`;
    if (softwareId) url += `&software_id=${softwareId}`;
    if (riskLevel) url += `&risk_level=${riskLevel}`;
    
    fetch(url)
        .then(r => r.json())
        .then(data => {
            if (data.code === 200) {
                renderList(data.data.list);
                renderPagination(data.data.total, page);
            }
        });
}

// 渲染列表
function renderList(list) {
    const tbody = document.getElementById('deviceList');
    
    if (list.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">暂无风险设备</td></tr>';
        return;
    }
    
    tbody.innerHTML = list.map(item => {
        const riskBadge = {
            1: '<span class="badge bg-warning">待审核</span>',
            2: '<span class="badge bg-danger">已拒绝</span>'
        }[item.risk_level] || '<span class="badge bg-secondary">未知</span>';
        
        return `
            <tr>
                <td>${item.id}</td>
                <td>${item.software_name || '-'}</td>
                <td><code title="${item.fingerprint}">${item.fingerprint_masked || '-'}</code></td>
                <td>${item.platform || '-'}</td>
                <td>${item.os_version || '-'}</td>
                <td><span class="text-danger">${item.virtual_type || '-'}</span></td>
                <td>${item.last_ip || '-'}</td>
                <td>${riskBadge}</td>
                <td>${item.create_time}</td>
                <td>
                    ${item.risk_level == 1 ? `
                        <button class="btn btn-sm btn-success" onclick="approveDevice(${item.id})">
                            <i class="bi bi-check"></i> 允许
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="rejectDevice(${item.id})">
                            <i class="bi bi-x"></i> 拒绝
                        </button>
                    ` : '-'}
                </td>
            </tr>
        `;
    }).join('');
}

// 渲染分页
function renderPagination(total, page) {
    const totalPages = Math.ceil(total / pageSize);
    const nav = document.getElementById('pagination');
    
    if (totalPages <= 1) {
        nav.innerHTML = '';
        return;
    }
    
    let html = '<ul class="pagination justify-content-center">';
    
    html += `<li class="page-item ${page <= 1 ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="loadDeviceList(${page - 1})">上一页</a>
    </li>`;
    
    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= page - 2 && i <= page + 2)) {
            html += `<li class="page-item ${i === page ? 'active' : ''}">
                <a class="page-link" href="#" onclick="loadDeviceList(${i})">${i}</a>
            </li>`;
        } else if (i === page - 3 || i === page + 3) {
            html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
    }
    
    html += `<li class="page-item ${page >= totalPages ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="loadDeviceList(${page + 1})">下一页</a>
    </li>`;
    
    html += '</ul>';
    nav.innerHTML = html;
}

// 允许设备
function approveDevice(id) {
    if (!confirm('确定允许此设备？虚拟机/模拟器将可以正常使用授权。')) return;
    
    fetch('api_risk.php?action=approve', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id=${id}`
    })
    .then(r => r.json())
    .then(data => {
        alert(data.message);
        if (data.code === 200) loadDeviceList(currentPage);
    });
}

// 拒绝设备
function rejectDevice(id) {
    if (!confirm('确定拒绝此设备？设备将被禁用且无法使用授权。')) return;
    
    fetch('api_risk.php?action=reject', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id=${id}`
    })
    .then(r => r.json())
    .then(data => {
        alert(data.message);
        if (data.code === 200) loadDeviceList(currentPage);
    });
}

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    loadSoftwareList();
    loadDeviceList();
    
    document.getElementById('filterForm').addEventListener('submit', function(e) {
        e.preventDefault();
        loadDeviceList(1);
    });
    
    document.getElementById('filterForm').addEventListener('reset', function() {
        setTimeout(() => loadDeviceList(1), 0);
    });
});
</script>

<?php include __DIR__ . '/layout.php'; ?>
