<?php
$pageTitle = 'API调用统计';
$breadcrumbs = ['API管理', '调用统计'];

$pageStyles = "
.stat-item { 
    padding: 16px 20px; 
    background: var(--el-bg-color-overlay); 
    border-radius: 8px; 
    border: 1px solid var(--el-border-color-lighter);
    transition: all 0.3s;
}
.stat-item:hover { box-shadow: 0 2px 12px rgba(0,0,0,0.08); transform: translateY(-2px); }
.stat-item-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.stat-title { font-size: 13px; color: var(--el-text-color-secondary); }
.stat-icon { width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
.stat-value { font-size: 28px; font-weight: 600; margin-bottom: 10px; line-height: 1; }
.color-blue { color: #409eff; } .bg-blue { background-color: rgba(64, 158, 255, 0.1); }
.color-green { color: #67c23a; } .bg-green { background-color: rgba(103, 194, 58, 0.1); }
.color-red { color: #f56c6c; } .bg-red { background-color: rgba(245, 108, 108, 0.1); }
.color-orange { color: #e6a23c; } .bg-orange { background-color: rgba(230, 162, 60, 0.1); }
.card-header-title { font-size: 14px; font-weight: 500; }
";

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 150px;" @change="loadData">
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-date-picker v-model="searchForm.dateRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="YYYY-MM-DD" style="width: 260px;" @change="loadData"></el-date-picker>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon>查询</el-button>
    </div>
</div>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :xs="24" :sm="12" :md="6">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">总调用次数</span>
                <div class="stat-icon bg-blue color-blue"><el-icon><connection /></el-icon></div>
            </div>
            <div class="stat-value">{{ stats.totalCalls }}</div>
        </div>
    </el-col>
    <el-col :xs="24" :sm="12" :md="6">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">成功次数</span>
                <div class="stat-icon bg-green color-green"><el-icon><circle-check /></el-icon></div>
            </div>
            <div class="stat-value" style="color: #67c23a;">{{ stats.successCalls }}</div>
        </div>
    </el-col>
    <el-col :xs="24" :sm="12" :md="6">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">失败次数</span>
                <div class="stat-icon bg-red color-red"><el-icon><circle-close /></el-icon></div>
            </div>
            <div class="stat-value" style="color: #f56c6c;">{{ stats.failCalls }}</div>
        </div>
    </el-col>
    <el-col :xs="24" :sm="12" :md="6">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">平均响应时间</span>
                <div class="stat-icon bg-orange color-orange"><el-icon><timer /></el-icon></div>
            </div>
            <div class="stat-value">{{ stats.avgTime }}ms</div>
        </div>
    </el-col>
</el-row>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :span="16">
        <el-card shadow="hover">
            <template #header><span class="card-header-title">调用趋势</span></template>
            <div ref="trendChartRef" style="height: 300px;"></div>
        </el-card>
    </el-col>
    <el-col :span="8">
        <el-card shadow="hover">
            <template #header><span class="card-header-title">API调用排行</span></template>
            <div ref="barChartRef" style="height: 300px;"></div>
        </el-card>
    </el-col>
</el-row>

<el-card shadow="hover">
    <template #header><span class="card-header-title">API调用明细</span></template>
    <el-table :data="tableData" size="small">
        <el-table-column prop="stat_date" label="日期" width="120"></el-table-column>
        <el-table-column prop="api_name" label="API名称" min-width="150" show-overflow-tooltip></el-table-column>
        <el-table-column prop="software_name" label="所属软件" width="120"></el-table-column>
        <el-table-column prop="call_count" label="调用次数" width="100" align="center"></el-table-column>
        <el-table-column prop="success_count" label="成功" width="80" align="center">
            <template #default="scope"><span style="color: #67c23a;">{{ scope.row.success_count }}</span></template>
        </el-table-column>
        <el-table-column prop="fail_count" label="失败" width="80" align="center">
            <template #default="scope"><span style="color: #f56c6c;">{{ scope.row.fail_count }}</span></template>
        </el-table-column>
        <el-table-column label="成功率" width="100" align="center">
            <template #default="scope"><span :style="{ color: getSuccessRateColor(scope.row) }">{{ getSuccessRate(scope.row) }}%</span></template>
        </el-table-column>
        <el-table-column prop="avg_response_time" label="平均响应" width="100" align="center">
            <template #default="scope">{{ scope.row.avg_response_time || 0 }}ms</template>
        </el-table-column>
    </el-table>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
searchForm: {
    software_id: '',
    dateRange: [new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], new Date().toISOString().split('T')[0]]
},
softwareList: [],
stats: { totalCalls: 0, successCalls: 0, failCalls: 0, avgTime: 0 },
tableData: [],
trendData: [],
trendChart: null,
barChart: null
";

$vueMounted = "
this.loadSoftwareList();
this.loadData();
";

$vueMethods = "
loadSoftwareList() {
    var self = this;
    fetch('api_software.php?action=list')
        .then(function(res) { return res.json(); })
        .then(function(data) { if (data.code === 0) self.softwareList = data.data || []; })
        .catch(function(e) { console.error(e); });
},
loadData() {
    var self = this;
    var params = new URLSearchParams({
        action: 'list',
        software_id: this.searchForm.software_id || '',
        start_date: this.searchForm.dateRange ? this.searchForm.dateRange[0] : '',
        end_date: this.searchForm.dateRange ? this.searchForm.dateRange[1] : ''
    });
    fetch('api_custom.php?' + params)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.code === 0) {
                self.tableData = data.data.list || [];
                self.stats = data.data.stats || { totalCalls: 0, successCalls: 0, failCalls: 0, avgTime: 0 };
                self.trendData = data.data.trend || [];
                self.\$nextTick(function() {
                    self.renderTrendChart();
                    self.renderBarChart();
                });
            }
        })
        .catch(function(e) { console.error(e); });
},
getSuccessRate(row) {
    if (!row.call_count) return 0;
    return ((row.success_count / row.call_count) * 100).toFixed(1);
},
getSuccessRateColor(row) {
    var rate = this.getSuccessRate(row);
    if (rate >= 95) return '#67c23a';
    if (rate >= 80) return '#e6a23c';
    return '#f56c6c';
},
renderTrendChart() {
    if (typeof echarts === 'undefined' || !this.\$refs.trendChartRef) return;
    if (!this.trendChart) this.trendChart = echarts.init(this.\$refs.trendChartRef);
    var trend = this.trendData || [];
    var dateSet = {};
    trend.forEach(function(i) { dateSet[i.stat_date] = true; });
    var dates = Object.keys(dateSet).sort();
    var successData = dates.map(function(d) {
        var items = trend.filter(function(i) { return i.stat_date === d; });
        return items.reduce(function(sum, i) { return sum + parseInt(i.success_count || 0); }, 0);
    });
    var failData = dates.map(function(d) {
        var items = trend.filter(function(i) { return i.stat_date === d; });
        return items.reduce(function(sum, i) { return sum + parseInt(i.fail_count || 0); }, 0);
    });
    this.trendChart.setOption({
        tooltip: { trigger: 'axis' },
        legend: { data: ['成功', '失败'], bottom: 0 },
        grid: { left: '3%', right: '4%', bottom: '12%', top: '10%', containLabel: true },
        xAxis: { type: 'category', data: dates.map(function(d) { return d.substring(5); }), boundaryGap: false, axisLine: { lineStyle: { color: '#e4e7ed' } }, axisTick: { show: false } },
        yAxis: { type: 'value', axisLine: { show: false }, axisTick: { show: false }, splitLine: { show: false } },
        series: [
            { name: '成功', type: 'line', smooth: true, data: successData, itemStyle: { color: '#67c23a' }, lineStyle: { width: 2 }, symbol: 'circle', symbolSize: 4, areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: 'rgba(103, 194, 58, 0.25)' }, { offset: 1, color: 'rgba(103, 194, 58, 0.05)' }] } } },
            { name: '失败', type: 'line', smooth: true, data: failData, itemStyle: { color: '#f56c6c' }, lineStyle: { width: 2 }, symbol: 'circle', symbolSize: 4, areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: 'rgba(245, 108, 108, 0.25)' }, { offset: 1, color: 'rgba(245, 108, 108, 0.05)' }] } } }
        ]
    });
},
renderBarChart() {
    if (typeof echarts === 'undefined' || !this.\$refs.barChartRef) return;
    if (!this.barChart) this.barChart = echarts.init(this.\$refs.barChartRef);
    var trend = this.trendData || [];
    var apiStats = {};
    trend.forEach(function(i) {
        if (!apiStats[i.api_name]) apiStats[i.api_name] = 0;
        apiStats[i.api_name] += parseInt(i.call_count || 0);
    });
    var pieData = [];
    for (var name in apiStats) { pieData.push({ name: name, value: apiStats[name] }); }
    pieData.sort(function(a, b) { return b.value - a.value; });
    pieData = pieData.slice(0, 10);
    var names = pieData.map(function(i) { return i.name; }).reverse();
    var values = pieData.map(function(i) { return i.value; }).reverse();
    var colors = ['#409eff', '#67c23a', '#e6a23c', '#f56c6c', '#9c27b0'];
    if (names.length === 0) { names = ['暂无数据']; values = [0]; }
    this.barChart.setOption({
        tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: '25%', right: '10%', top: '5%', bottom: '5%', containLabel: true },
        xAxis: { type: 'value', axisLine: { show: false }, axisTick: { show: false }, axisLabel: { show: false }, splitLine: { show: false } },
        yAxis: { type: 'category', data: names, axisLine: { show: false }, axisTick: { show: false } },
        series: [{ type: 'bar', data: values.map(function(v, i) { return { value: v, itemStyle: { color: colors[i % colors.length], borderRadius: [0, 3, 3, 0] } }; }), barWidth: 8, label: { show: true, position: 'right', formatter: '{c}' }, showBackground: true, backgroundStyle: { color: 'rgba(220, 223, 230, 0.2)', borderRadius: [0, 3, 3, 0] } }]
    });
}
";

include 'layout.php';
?>
