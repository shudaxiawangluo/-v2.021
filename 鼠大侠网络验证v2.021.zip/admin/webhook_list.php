<?php
$pageTitle = 'Webhook';
$breadcrumbs = ['API管理', 'Webhook'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 160px;" @change="loadData">
            <el-option label="全局" :value="0"></el-option>
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
    </div>
    <el-button type="primary" @click="handleAdd"><el-icon><Plus /></el-icon>添加Webhook</el-button>
</div>

<el-alert type="info" :closable="false" style="margin-bottom: 16px;">
    Webhook可在特定事件发生时（如用户激活、订单支付等）自动向您的服务器发送HTTP请求。
</el-alert>

<el-card shadow="hover">
    <el-table :data="webhookList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column label="软件" width="100">
            <template #default="scope">{{ scope.row.software_id === 0 ? '全局' : scope.row.software_name }}</template>
        </el-table-column>
        <el-table-column prop="webhook_name" label="名称" width="150"></el-table-column>
        <el-table-column prop="webhook_url" label="URL" min-width="250">
            <template #default="scope">
                <el-tooltip :content="scope.row.webhook_url" placement="top">
                    <span style="font-size: 12px;">{{ scope.row.webhook_url.substring(0, 50) }}...</span>
                </el-tooltip>
            </template>
        </el-table-column>
        <el-table-column label="触发事件" min-width="200">
            <template #default="scope">
                <el-tag v-for="e in (scope.row.events || '').split(',')" :key="e" size="small" style="margin: 2px;" v-if="e">{{ eventNames[e] || e }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column label="状态" width="80" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.status === 1 ? 'success' : 'info'" size="small">{{ scope.row.status === 1 ? '启用' : '禁用' }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right" align="center">
            <template #default="scope">
                <el-button type="success" size="small" @click="handleTest(scope.row)">测试</el-button>
                <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
                <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
</el-card>

<!-- 添加/编辑Webhook对话框 -->
<el-dialog v-model="showDialog" :title="editForm.id ? '编辑Webhook' : '添加Webhook'" width="600px">
    <el-form :model="editForm" label-width="100px">
        <el-form-item label="所属软件">
            <el-select v-model="editForm.software_id" style="width: 100%;">
                <el-option label="全局（所有软件）" :value="0"></el-option>
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="名称" required>
            <el-input v-model="editForm.webhook_name" placeholder="如：订单通知"></el-input>
        </el-form-item>
        <el-form-item label="URL" required>
            <el-input v-model="editForm.webhook_url" placeholder="https://your-server.com/webhook"></el-input>
        </el-form-item>
        <el-form-item label="触发事件">
            <el-checkbox-group v-model="editForm.eventList">
                <el-checkbox value="user_register">用户注册</el-checkbox>
                <el-checkbox value="auth_activated">授权激活</el-checkbox>
                <el-checkbox value="auth_expired">授权到期</el-checkbox>
                <el-checkbox value="order_created">订单创建</el-checkbox>
                <el-checkbox value="order_paid">订单支付</el-checkbox>
                <el-checkbox value="user_login">用户登录</el-checkbox>
            </el-checkbox-group>
        </el-form-item>
        <el-form-item label="签名密钥">
            <el-input v-model="editForm.secret_key" placeholder="用于验证请求来源（可选）"></el-input>
        </el-form-item>
        <el-form-item label="状态">
            <el-switch v-model="editForm.statusBool" active-text="启用" inactive-text="禁用"></el-switch>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSave" :loading="saving">保存</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
webhookList: [],
softwareList: [],
loading: false,
saving: false,
showDialog: false,
searchForm: { software_id: '' },
editForm: { id: '', software_id: 0, webhook_name: '', webhook_url: '', eventList: [], secret_key: '', statusBool: true },
eventNames: { user_register: '用户注册', auth_activated: '授权激活', auth_expired: '授权到期', order_created: '订单创建', order_paid: '订单支付', user_login: '用户登录' }
";

$vueMounted = "this.loadData(); this.loadSoftware();";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({ action: 'webhook_list', ...this.searchForm });
        const res = await fetch('api_custom.php?' + params);
        const data = await res.json();
        if (data.code === 0) this.webhookList = data.data;
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
handleAdd() {
    this.editForm = { id: '', software_id: 0, webhook_name: '', webhook_url: '', eventList: [], secret_key: '', statusBool: true };
    this.showDialog = true;
},
handleEdit(row) {
    this.editForm = { ...row, eventList: (row.events || '').split(',').filter(e => e), statusBool: row.status == 1 };
    this.showDialog = true;
},
async handleSave() {
    if (!this.editForm.webhook_name || !this.editForm.webhook_url) {
        ElementPlus.ElMessage.error('请填写必填项');
        return;
    }
    this.saving = true;
    try {
        const postData = { ...this.editForm, events: this.editForm.eventList.join(','), status: this.editForm.statusBool ? 1 : 0 };
        const res = await fetch('api_custom.php?action=' + (this.editForm.id ? 'webhook_update' : 'webhook_add'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(postData)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('请求失败'); }
    this.saving = false;
},
async handleTest(row) {
    ElementPlus.ElMessage.info('正在发送测试请求...');
    // 这里应该实际发送测试请求
    setTimeout(() => ElementPlus.ElMessage.success('测试请求已发送'), 1000);
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除该Webhook吗？', '删除确认', { type: 'warning' });
        const res = await fetch('api_custom.php?action=webhook_delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
