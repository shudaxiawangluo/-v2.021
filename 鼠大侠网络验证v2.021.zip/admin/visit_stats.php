<?php
$pageTitle = '访问统计';
$breadcrumbs = ['安全中心', '访问统计'];

ob_start();
?>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :span="6">
        <el-card shadow="hover">
            <el-statistic title="今日访问" :value="stats.today">
                <template #suffix><span style="font-size: 14px; color: #909399;">次</span></template>
            </el-statistic>
        </el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover">
            <el-statistic title="今日独立IP" :value="stats.unique_ip_today">
                <template #suffix><span style="font-size: 14px; color: #909399;">个</span></template>
            </el-statistic>
        </el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover">
            <el-statistic title="总访问量" :value="stats.total">
                <template #suffix><span style="font-size: 14px; color: #909399;">次</span></template>
            </el-statistic>
        </el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover">
            <el-statistic title="已拦截IP" :value="stats.blocked_count" value-style="color: #f56c6c;">
                <template #suffix><span style="font-size: 14px; color: #909399;">个</span></template>
            </el-statistic>
        </el-card>
    </el-col>
</el-row>

<el-card shadow="hover" style="margin-bottom: 16px;">
    <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span>访问趋势</span>
            <el-radio-group v-model="chartDays" size="small" @change="loadChart">
                <el-radio-button :label="7">近7天</el-radio-button>
                <el-radio-button :label="30">近30天</el-radio-button>
            </el-radio-group>
        </div>
    </template>
    <div id="visitChart" style="height: 300px;"></div>
</el-card>

<el-card shadow="hover">
    <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span>实时访问记录</span>
            <div style="display: flex; gap: 12px; align-items: center;">
                <el-input v-model="searchIP" placeholder="搜索IP" clearable style="width: 150px;" @keyup.enter="loadLogs">
                    <template #prefix><el-icon><Search /></el-icon></template>
                </el-input>
                <el-select v-model="filterType" placeholder="筛选" style="width: 120px;" @change="loadLogs">
                    <el-option label="全部" value=""></el-option>
                    <el-option label="高频访问" value="high"></el-option>
                    <el-option label="可疑IP" value="suspicious"></el-option>
                </el-select>
                <el-button type="primary" @click="loadLogs"><el-icon><Refresh /></el-icon>刷新</el-button>
                <el-button type="danger" @click="cleanOldLogs"><el-icon><Delete /></el-icon>清理旧日志</el-button>
            </div>
        </div>
    </template>
    
    <el-table :data="logs" v-loading="loading" stripe max-height="500">
        <el-table-column prop="ip" label="IP地址" min-width="130">
            <template #default="scope">
                <el-tooltip :content="'点击复制'" placement="top">
                    <span style="cursor: pointer; color: #409eff;" @click="copyIP(scope.row.ip)">{{ scope.row.ip }}</span>
                </el-tooltip>
            </template>
        </el-table-column>
        <el-table-column prop="location" label="地理位置" min-width="140"></el-table-column>
        <el-table-column prop="visit_count" label="访问次数" min-width="90" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.visit_count > 100 ? 'danger' : (scope.row.visit_count > 50 ? 'warning' : 'info')" size="small">
                    {{ scope.row.visit_count }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="path" label="最近访问路径" min-width="200" show-overflow-tooltip></el-table-column>
        <el-table-column prop="method" label="方法" min-width="70" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.method === 'POST' ? 'warning' : 'info'" size="small">{{ scope.row.method }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="user_agent" label="User-Agent" min-width="200" show-overflow-tooltip></el-table-column>
        <el-table-column prop="last_visit" label="最后访问" min-width="160"></el-table-column>
        <el-table-column label="操作" width="180" fixed="right" align="center">
            <template #default="scope">
                <el-button type="primary" size="small" @click="viewDetail(scope.row)">详情</el-button>
                <el-button type="danger" size="small" @click="blockIP(scope.row)">拉黑</el-button>
            </template>
        </el-table-column>
    </el-table>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
        <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ pagination.total }}</b> 个IP</span>
        <el-pagination background layout="prev, pager, next" :total="pagination.total" :page-size="pagination.pageSize" v-model:current-page="pagination.page" @current-change="loadLogs"></el-pagination>
    </div>
</el-card>

<!-- IP详情对话框 -->
<el-dialog v-model="detailVisible" title="IP访问详情" width="800px">
    <el-descriptions :column="2" border>
        <el-descriptions-item label="IP地址">{{ currentIP.ip }}</el-descriptions-item>
        <el-descriptions-item label="地理位置">{{ currentIP.location }}</el-descriptions-item>
        <el-descriptions-item label="总访问次数">{{ currentIP.visit_count }}</el-descriptions-item>
        <el-descriptions-item label="首次访问">{{ currentIP.first_visit }}</el-descriptions-item>
        <el-descriptions-item label="最后访问">{{ currentIP.last_visit }}</el-descriptions-item>
        <el-descriptions-item label="状态">
            <el-tag :type="currentIP.is_blocked ? 'danger' : 'success'">{{ currentIP.is_blocked ? '已拉黑' : '正常' }}</el-tag>
        </el-descriptions-item>
    </el-descriptions>
    
    <div style="margin-top: 16px;">
        <h4 style="margin-bottom: 12px;">最近访问记录</h4>
        <el-table :data="currentIP.recent_logs" max-height="300" stripe>
            <el-table-column prop="path" label="访问路径" min-width="200" show-overflow-tooltip></el-table-column>
            <el-table-column prop="method" label="方法" width="80"></el-table-column>
            <el-table-column prop="create_time" label="时间" width="160"></el-table-column>
        </el-table>
    </div>
    
    <template #footer>
        <el-button @click="detailVisible = false">关闭</el-button>
        <el-button type="warning" @click="addToWhitelist(currentIP.ip)" v-if="!currentIP.is_blocked">加入白名单</el-button>
        <el-button type="danger" @click="blockIP(currentIP)" v-if="!currentIP.is_blocked">拉黑此IP</el-button>
        <el-button type="success" @click="unblockIP(currentIP.ip)" v-if="currentIP.is_blocked">解除拉黑</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = <<<JS
stats: { today: 0, unique_ip_today: 0, total: 0, blocked_count: 0 },
logs: [],
loading: false,
searchIP: '',
filterType: '',
chartDays: 7,
pagination: { page: 1, pageSize: 20, total: 0 },
detailVisible: false,
currentIP: {},
visitChart: null
JS;

$vueMounted = <<<JS
this.loadStats();
this.loadLogs();
this.loadChart();
JS;

$vueMethods = <<<JS
loadStats: function() {
    var self = this;
    fetch('api_visit.php?action=stats').then(function(r) { return r.json(); }).then(function(data) {
        if (data.code === 0) self.stats = data.data;
    });
},
loadLogs: function() {
    var self = this;
    self.loading = true;
    var params = new URLSearchParams({
        action: 'logs',
        page: self.pagination.page,
        pageSize: self.pagination.pageSize,
        ip: self.searchIP,
        filter: self.filterType
    });
    fetch('api_visit.php?' + params).then(function(r) { return r.json(); }).then(function(data) {
        self.loading = false;
        if (data.code === 0) {
            self.logs = data.data;
            self.pagination.total = data.total;
        }
    });
},
loadChart: function() {
    var self = this;
    fetch('api_visit.php?action=chart&days=' + self.chartDays).then(function(r) { return r.json(); }).then(function(data) {
        if (data.code === 0) {
            self.renderChart(data.data);
        }
    });
},
renderChart: function(data) {
    var chart = echarts.init(document.getElementById('visitChart'));
    var option = {
        tooltip: { trigger: 'axis' },
        legend: { data: ['访问量', '独立IP'] },
        grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
        xAxis: { type: 'category', boundaryGap: false, data: data.dates },
        yAxis: { type: 'value' },
        series: [
            { name: '访问量', type: 'line', smooth: true, data: data.visits, areaStyle: { opacity: 0.3 } },
            { name: '独立IP', type: 'line', smooth: true, data: data.ips }
        ]
    };
    chart.setOption(option);
    this.visitChart = chart;
},
viewDetail: function(row) {
    var self = this;
    fetch('api_visit.php?action=detail&ip=' + encodeURIComponent(row.ip)).then(function(r) { return r.json(); }).then(function(data) {
        if (data.code === 0) {
            self.currentIP = data.data;
            self.detailVisible = true;
        }
    });
},
blockIP: function(row) {
    var self = this;
    ElementPlus.ElMessageBox.prompt('请输入拉黑原因', '拉黑IP: ' + row.ip, {
        confirmButtonText: '确定拉黑',
        cancelButtonText: '取消',
        inputPlaceholder: '如：恶意访问、攻击行为等',
        type: 'warning'
    }).then(function(result) {
        fetch('api_visit.php?action=block', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ip: row.ip, reason: result.value || '手动拉黑' })
        }).then(function(r) { return r.json(); }).then(function(data) {
            if (data.code === 0) {
                ElementPlus.ElMessage.success('已拉黑');
                self.loadLogs();
                self.loadStats();
                self.detailVisible = false;
            } else {
                ElementPlus.ElMessage.error(data.msg);
            }
        });
    }).catch(function() {});
},
unblockIP: function(ip) {
    var self = this;
    fetch('api_visit.php?action=unblock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip: ip })
    }).then(function(r) { return r.json(); }).then(function(data) {
        if (data.code === 0) {
            ElementPlus.ElMessage.success('已解除拉黑');
            self.detailVisible = false;
            self.loadLogs();
            self.loadStats();
        }
    });
},
addToWhitelist: function(ip) {
    var self = this;
    fetch('api_visit.php?action=whitelist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip: ip })
    }).then(function(r) { return r.json(); }).then(function(data) {
        if (data.code === 0) {
            ElementPlus.ElMessage.success('已加入白名单');
            self.detailVisible = false;
        }
    });
},
cleanOldLogs: function() {
    var self = this;
    ElementPlus.ElMessageBox.confirm('确定要清理30天前的访问日志吗？', '清理日志', { type: 'warning' }).then(function() {
        fetch('api_visit.php?action=clean', { method: 'POST' }).then(function(r) { return r.json(); }).then(function(data) {
            if (data.code === 0) {
                ElementPlus.ElMessage.success('已清理 ' + data.deleted + ' 条记录');
                self.loadLogs();
                self.loadStats();
            }
        });
    }).catch(function() {});
},
copyIP: function(ip) {
    navigator.clipboard.writeText(ip).then(function() {
        ElementPlus.ElMessage.success('已复制');
    });
}
JS;

include 'layout.php';
?>
