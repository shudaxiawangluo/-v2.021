<?php
require_once '../api/config.php';

$pageTitle = '代码加密';
$breadcrumbs = ['工具箱', '代码加密'];

ob_start();
?>

<el-row :gutter="20">
    <el-col :span="12">
        <el-card shadow="hover">
            <template #header>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span>源代码</span>
                    <el-upload
                        ref="uploadRef"
                        :auto-upload="false"
                        :show-file-list="false"
                        :on-change="handleFileChange"
                        accept=".js,.php,.py,.java,.cs,.html,.css,.jsx,.ts,.tsx,.vue"
                    >
                        <el-button size="small" type="primary"><el-icon><Upload /></el-icon>上传文件</el-button>
                    </el-upload>
                </div>
            </template>
            <el-form label-width="80px">
                <el-form-item label="语言类型">
                    <el-select v-model="language" style="width: 100%;">
                        <el-option label="自动识别" value="auto"></el-option>
                        <el-option label="JavaScript / TypeScript" value="javascript"></el-option>
                        <el-option label="PHP" value="php"></el-option>
                        <el-option label="Python" value="python"></el-option>
                        <el-option label="Java" value="java"></el-option>
                        <el-option label="C#" value="csharp"></el-option>
                        <el-option label="HTML / CSS" value="html"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <el-input
                v-model="sourceCode"
                type="textarea"
                :rows="20"
                placeholder="请粘贴需要加密的代码，或点击上方按钮上传文件..."
                style="font-family: Consolas, Monaco, monospace; font-size: 13px;"
            ></el-input>
            <div style="margin-top: 16px; display: flex; gap: 10px;">
                <el-button type="primary" @click="encryptCode" :loading="encrypting" :disabled="!sourceCode">
                    <el-icon><Lock /></el-icon>加密代码
                </el-button>
                <el-button @click="decryptCode" :loading="decrypting" :disabled="!sourceCode">
                    <el-icon><Unlock /></el-icon>解密代码
                </el-button>
                <el-button @click="clearCode"><el-icon><Delete /></el-icon>清空</el-button>
            </div>
        </el-card>
    </el-col>
    
    <el-col :span="12">
        <el-card shadow="hover">
            <template #header>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span>加密结果 <el-tag v-if="detectedLang" size="small" type="info" style="margin-left: 8px;">{{ detectedLang }}</el-tag></span>
                    <div style="display: flex; gap: 8px;">
                        <el-button size="small" type="success" @click="copyResult" :disabled="!resultCode"><el-icon><CopyDocument /></el-icon>复制</el-button>
                        <el-button size="small" type="primary" @click="downloadResult" :disabled="!resultCode"><el-icon><Download /></el-icon>下载</el-button>
                    </div>
                </div>
            </template>
            <el-input
                v-model="resultCode"
                type="textarea"
                :rows="24"
                placeholder="加密后的代码将显示在这里..."
                readonly
                style="font-family: Consolas, Monaco, monospace; font-size: 13px;"
            ></el-input>
        </el-card>
    </el-col>
</el-row>

<el-card shadow="hover" style="margin-top: 20px;">
    <div style="display: flex; gap: 40px; padding: 10px 0;">
        <div style="flex: 1; text-align: center; border-right: 1px solid #eee;">
            <div style="font-size: 24px; color: #409eff; margin-bottom: 8px;">6+</div>
            <div style="color: #666; font-size: 13px;">支持语言</div>
            <div style="color: #999; font-size: 12px; margin-top: 4px;">JS/PHP/Python/Java/C#/HTML</div>
        </div>
        <div style="flex: 1; text-align: center; border-right: 1px solid #eee;">
            <div style="font-size: 24px; color: #67c23a; margin-bottom: 8px;">智能</div>
            <div style="color: #666; font-size: 13px;">加密方式</div>
            <div style="color: #999; font-size: 12px; margin-top: 4px;">纯代码用eval，模板用压缩</div>
        </div>
        <div style="flex: 1; text-align: center; border-right: 1px solid #eee;">
            <div style="font-size: 24px; color: #e6a23c; margin-bottom: 8px;">自动</div>
            <div style="color: #666; font-size: 13px;">语言识别</div>
            <div style="color: #999; font-size: 12px; margin-top: 4px;">智能检测代码语言类型</div>
        </div>
        <div style="flex: 1; text-align: center;">
            <div style="font-size: 24px; color: #f56c6c; margin-bottom: 8px;">100%</div>
            <div style="color: #666; font-size: 13px;">功能保证</div>
            <div style="color: #999; font-size: 12px; margin-top: 4px;">加密后代码完全可用</div>
        </div>
    </div>
    <el-alert type="info" :closable="false" style="margin-top: 10px;">
        <template #title>
            <span style="font-size: 13px;">提示：PHP模板文件（包含HTML的）只会进行压缩混淆，纯PHP逻辑文件会使用eval+base64加密</span>
        </template>
    </el-alert>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
sourceCode: '',
resultCode: '',
language: 'auto',
detectedLang: '',
encrypting: false,
decrypting: false
";

$vueMounted = "";

$vueMethods = "
handleFileChange(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
        this.sourceCode = e.target.result;
        // 根据文件扩展名预设语言
        const ext = file.name.split('.').pop().toLowerCase();
        const langMap = {
            'js': 'javascript', 'jsx': 'javascript', 'ts': 'javascript', 'tsx': 'javascript', 'vue': 'javascript',
            'php': 'php',
            'py': 'python',
            'java': 'java',
            'cs': 'csharp',
            'html': 'html', 'htm': 'html', 'css': 'html'
        };
        if (langMap[ext]) this.language = langMap[ext];
    };
    reader.readAsText(file.raw);
},
async encryptCode() {
    if (!this.sourceCode.trim()) {
        ElementPlus.ElMessage.error('请输入需要加密的代码');
        return;
    }
    this.encrypting = true;
    this.detectedLang = '';
    try {
        const res = await fetch('api_code.php?action=encrypt', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                code: this.sourceCode,
                language: this.language
            })
        });
        const data = await res.json();
        if (data.code === 0) {
            this.resultCode = data.data;
            this.detectedLang = data.detected || '';
            ElementPlus.ElMessage.success('加密成功');
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {
        ElementPlus.ElMessage.error('加密失败：' + e.message);
    }
    this.encrypting = false;
},
async decryptCode() {
    if (!this.sourceCode.trim()) {
        ElementPlus.ElMessage.error('请输入需要解密的代码');
        return;
    }
    this.decrypting = true;
    try {
        const res = await fetch('api_code.php?action=decrypt', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                code: this.sourceCode,
                language: this.language
            })
        });
        const data = await res.json();
        if (data.code === 0) {
            this.resultCode = data.data;
            ElementPlus.ElMessage.success('解密成功');
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {
        ElementPlus.ElMessage.error('解密失败：' + e.message);
    }
    this.decrypting = false;
},
clearCode() {
    this.sourceCode = '';
    this.resultCode = '';
    this.detectedLang = '';
},
copyResult() {
    if (!this.resultCode) return;
    navigator.clipboard.writeText(this.resultCode).then(() => {
        ElementPlus.ElMessage.success('已复制到剪贴板');
    }).catch(() => {
        // 降级方案
        const textarea = document.createElement('textarea');
        textarea.value = this.resultCode;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        ElementPlus.ElMessage.success('已复制到剪贴板');
    });
},
downloadResult() {
    if (!this.resultCode) return;
    const langExt = {
        'javascript': 'js', 'JavaScript': 'js',
        'php': 'php', 'PHP': 'php',
        'python': 'py', 'Python': 'py',
        'java': 'java', 'Java': 'java',
        'csharp': 'cs', 'C#': 'cs',
        'html': 'html', 'HTML': 'html'
    };
    const ext = langExt[this.detectedLang] || langExt[this.language] || 'txt';
    const blob = new Blob([this.resultCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'encrypted_code.' + ext;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    ElementPlus.ElMessage.success('下载成功');
}
";

include 'layout.php';
?>
