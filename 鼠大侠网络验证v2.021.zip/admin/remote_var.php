<?php
$pageTitle = '远程变量';
$breadcrumbs = ['云控制', '远程变量'];

ob_start();
?>

<el-alert type="info" :closable="false" style="margin-bottom: 16px;">
    远程变量用于动态配置客户端参数，客户端通过心跳接口获取。变量名建议使用英文下划线格式，如：download_url、max_retry
</el-alert>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 160px;" @change="loadData">
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索变量名" clearable style="width: 180px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <el-button type="primary" @click="handleAdd"><el-icon><Plus /></el-icon>添加变量</el-button>
</div>

<el-card shadow="hover">
    <el-table :data="varList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="software_name" label="所属软件" width="120"></el-table-column>
        <el-table-column prop="var_name" label="变量名" min-width="150">
            <template #default="scope">
                <code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;">{{ scope.row.var_name }}</code>
            </template>
        </el-table-column>
        <el-table-column prop="var_value" label="变量值" min-width="200">
            <template #default="scope">
                <el-tooltip :content="scope.row.var_value" placement="top" v-if="scope.row.var_value && scope.row.var_value.length > 50">
                    <span>{{ scope.row.var_value.substring(0, 50) }}...</span>
                </el-tooltip>
                <span v-else>{{ scope.row.var_value || '-' }}</span>
            </template>
        </el-table-column>
        <el-table-column label="类型" width="90" align="center">
            <template #default="scope">
                <el-tag size="small" :type="{string:'',number:'success',json:'warning',boolean:'info'}[scope.row.var_type]">
                    {{ scope.row.var_type || 'string' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="状态" width="70" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.status == 1 ? 'success' : 'info'" size="small">
                    {{ scope.row.status == 1 ? '启用' : '禁用' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="description" label="描述" min-width="150">
            <template #default="scope">{{ scope.row.description || '-' }}</template>
        </el-table-column>
        <el-table-column prop="update_time" label="更新时间" width="160"></el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
            <template #default="scope">
                <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
                <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
</el-card>

<!-- 添加/编辑变量对话框 -->
<el-dialog v-model="showDialog" :title="editForm.id ? '编辑变量' : '添加变量'" width="550px">
    <el-form :model="editForm" label-width="100px">
        <el-form-item label="所属软件" required>
            <el-select v-model="editForm.software_id" placeholder="选择软件" style="width: 100%;">
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="变量名" required>
            <el-autocomplete v-model="editForm.var_name" :fetch-suggestions="queryVarSuggestions" placeholder="输入或选择常用变量名" style="width: 100%;" :disabled="!!editForm.id"></el-autocomplete>
            <div style="font-size: 12px; color: #909399; margin-top: 4px;">常用：download_url、notice_text、max_retry、debug_mode</div>
        </el-form-item>
        <el-form-item label="变量类型">
            <el-select v-model="editForm.var_type" style="width: 150px;">
                <el-option label="字符串" value="string"></el-option>
                <el-option label="数字" value="number"></el-option>
                <el-option label="布尔值" value="boolean"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="变量值" required>
            <el-input v-model="editForm.var_value" placeholder="变量值" v-if="editForm.var_type !== 'boolean'"></el-input>
            <el-switch v-model="editForm.var_bool" v-else></el-switch>
        </el-form-item>
        <el-form-item label="描述">
            <el-input v-model="editForm.description" placeholder="变量用途说明"></el-input>
        </el-form-item>
        <el-form-item label="状态">
            <el-switch v-model="editForm.statusBool" active-text="启用" inactive-text="禁用"></el-switch>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSave" :loading="saving">保存</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
varList: [],
softwareList: [],
loading: false,
saving: false,
showDialog: false,
searchForm: { software_id: '', keyword: '' },
editForm: { id: '', software_id: '', var_name: '', var_value: '', var_type: 'string', description: '', statusBool: true, var_bool: false },
commonVars: [
    { value: 'download_url', label: 'download_url - 下载地址' },
    { value: 'update_url', label: 'update_url - 更新地址' },
    { value: 'notice_text', label: 'notice_text - 公告文本' },
    { value: 'max_retry', label: 'max_retry - 最大重试次数' },
    { value: 'timeout', label: 'timeout - 超时时间(秒)' },
    { value: 'debug_mode', label: 'debug_mode - 调试模式' },
    { value: 'api_url', label: 'api_url - API地址' },
    { value: 'contact_qq', label: 'contact_qq - 联系QQ' },
    { value: 'contact_wx', label: 'contact_wx - 联系微信' },
    { value: 'website_url', label: 'website_url - 官网地址' }
]
";

$vueMounted = "this.loadData(); this.loadSoftware();";

$vueMethods = "
queryVarSuggestions(queryString, cb) {
    const results = queryString ? this.commonVars.filter(v => v.value.toLowerCase().includes(queryString.toLowerCase())) : this.commonVars;
    cb(results);
},
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({ action: 'list', ...this.searchForm });
        const res = await fetch('api_remote.php?' + params);
        const data = await res.json();
        if (data.code === 0) this.varList = data.data;
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
handleAdd() {
    this.editForm = { id: '', software_id: '', var_name: '', var_value: '', var_type: 'string', description: '', statusBool: true, var_bool: false };
    this.showDialog = true;
},
handleEdit(row) {
    this.editForm = { ...row, statusBool: row.status == 1, var_bool: row.var_value === '1' || row.var_value === 'true' };
    this.showDialog = true;
},
async handleSave() {
    if (!this.editForm.software_id || !this.editForm.var_name) {
        ElementPlus.ElMessage.error('请填写必填项');
        return;
    }
    const saveData = { ...this.editForm, status: this.editForm.statusBool ? 1 : 0 };
    if (this.editForm.var_type === 'boolean') {
        saveData.var_value = this.editForm.var_bool ? '1' : '0';
    }
    this.saving = true;
    try {
        const res = await fetch('api_remote.php?action=' + (this.editForm.id ? 'update_var' : 'add_var'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(saveData)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('请求失败'); }
    this.saving = false;
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除该变量吗？', '删除确认', { type: 'warning' });
        const res = await fetch('api_remote.php?action=delete_var', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
