<?php
require_once '../api/config.php';

$pageTitle = '系统设置';
$breadcrumbs = ['系统设置'];

ob_start();
?>

<el-tabs v-model="activeTab" @tab-change="loadSettings">
    <el-tab-pane label="个人中心" name="profile">
        <el-card shadow="hover">
            <el-form label-width="100px" style="max-width: 500px;">
                <el-form-item label="邮箱">
                    <el-input v-model="profileForm.email" placeholder="请输入邮箱"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="saveProfile" :loading="savingProfile">保存修改</el-button>
                </el-form-item>
            </el-form>
            
            <el-divider></el-divider>
            
            <h4 style="margin-bottom: 16px;">修改密码</h4>
            <el-form :model="passwordForm" label-width="100px" style="max-width: 500px;">
                <el-form-item label="原密码">
                    <el-input v-model="passwordForm.old_password" type="password" placeholder="请输入原密码" show-password></el-input>
                </el-form-item>
                <el-form-item label="新密码">
                    <el-input v-model="passwordForm.new_password" type="password" placeholder="请输入新密码（至少6位）" show-password></el-input>
                </el-form-item>
                <el-form-item label="确认密码">
                    <el-input v-model="passwordForm.confirm_password" type="password" placeholder="请再次输入新密码" show-password></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="changePassword" :loading="changingPass">修改密码</el-button>
                </el-form-item>
            </el-form>
        </el-card>
    </el-tab-pane>
    
    <el-tab-pane label="基础设置" name="general">
        <el-card shadow="hover">
            <el-form :model="settings" label-width="140px" style="max-width: 600px;">
                <el-form-item label="网站名称">
                    <el-input v-model="settings.site_name" placeholder="鼠大侠授权系统"></el-input>
                </el-form-item>
                <el-form-item label="网站Logo">
                    <el-input v-model="settings.site_logo" placeholder="Logo图片URL"></el-input>
                </el-form-item>
                <el-form-item label="管理员邮箱">
                    <el-input v-model="settings.admin_email" placeholder="admin@example.com"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="saveSettings" :loading="saving">保存设置</el-button>
                </el-form-item>
            </el-form>
        </el-card>
    </el-tab-pane>
    
    <el-tab-pane label="安全设置" name="security">
        <el-card shadow="hover">
            <el-form :model="settings" label-width="160px" style="max-width: 600px;">
                <el-form-item label="允许用户注册">
                    <el-switch v-model="settings.allow_register" active-value="1" inactive-value="0"></el-switch>
                </el-form-item>
                <el-form-item label="登录验证码">
                    <el-switch v-model="settings.login_captcha" active-value="1" inactive-value="0"></el-switch>
                </el-form-item>
                <el-form-item label="最大登录尝试次数">
                    <el-input-number v-model="settings.max_login_attempts" :min="1" :max="20"></el-input-number>
                    <span style="margin-left: 10px; color: #909399;">次</span>
                </el-form-item>
                <el-form-item label="账号锁定时长">
                    <el-input-number v-model="settings.lockout_duration" :min="1" :max="1440"></el-input-number>
                    <span style="margin-left: 10px; color: #909399;">分钟</span>
                </el-form-item>
                <el-form-item label="Token有效期">
                    <el-input-number v-model="settings.token_expire" :min="3600" :max="604800" :step="3600"></el-input-number>
                    <span style="margin-left: 10px; color: #909399;">秒（{{ Math.floor(settings.token_expire / 3600) }}小时）</span>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="saveSettings" :loading="saving">保存设置</el-button>
                </el-form-item>
            </el-form>
        </el-card>
    </el-tab-pane>
    
    <el-tab-pane label="客户端设置" name="client">
        <el-card shadow="hover">
            <el-form :model="settings" label-width="160px" style="max-width: 600px;">
                <el-form-item label="心跳间隔">
                    <el-input-number v-model="settings.heartbeat_interval" :min="3" :max="60"></el-input-number>
                    <span style="margin-left: 10px; color: #909399;">秒（建议5-10秒）</span>
                </el-form-item>
                <el-form-item label="心跳超时">
                    <el-input-number v-model="settings.heartbeat_timeout" :min="10" :max="120"></el-input-number>
                    <span style="margin-left: 10px; color: #909399;">秒（建议为心跳间隔的3-6倍）</span>
                </el-form-item>
                <el-form-item label="允许多设备登录">
                    <el-switch v-model="settings.allow_multi_device" active-value="1" inactive-value="0"></el-switch>
                </el-form-item>
                <el-form-item label="最大设备数" v-if="settings.allow_multi_device === '1'">
                    <el-input-number v-model="settings.max_devices" :min="1" :max="10"></el-input-number>
                    <span style="margin-left: 10px; color: #909399;">台</span>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="saveSettings" :loading="saving">保存设置</el-button>
                </el-form-item>
            </el-form>
        </el-card>
    </el-tab-pane>
    
    <el-tab-pane label="日志设置" name="logs">
        <el-card shadow="hover">
            <el-form :model="settings" label-width="140px" style="max-width: 600px;">
                <el-form-item label="日志保留天数">
                    <el-input-number v-model="settings.log_retention_days" :min="1" :max="365"></el-input-number>
                    <span style="margin-left: 10px; color: #909399;">天</span>
                </el-form-item>
                <el-form-item label="自动清理日志">
                    <el-switch v-model="settings.auto_clean_logs" active-value="1" inactive-value="0"></el-switch>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="saveSettings" :loading="saving">保存设置</el-button>
                </el-form-item>
            </el-form>
        </el-card>
    </el-tab-pane>
    
    <el-tab-pane label="邮件设置" name="email">
        <el-card shadow="hover">
            <el-form :model="settings" label-width="140px" style="max-width: 600px;">
                <el-form-item label="SMTP服务器">
                    <el-input v-model="settings.smtp_host" placeholder="smtp.example.com"></el-input>
                </el-form-item>
                <el-form-item label="SMTP端口">
                    <el-input-number v-model="settings.smtp_port" :min="1" :max="65535"></el-input-number>
                </el-form-item>
                <el-form-item label="SMTP用户名">
                    <el-input v-model="settings.smtp_user" placeholder="邮箱账号"></el-input>
                </el-form-item>
                <el-form-item label="SMTP密码">
                    <el-input v-model="settings.smtp_pass" type="password" placeholder="邮箱密码或授权码" show-password></el-input>
                </el-form-item>
                <el-form-item label="发件人地址">
                    <el-input v-model="settings.smtp_from" placeholder="noreply@example.com"></el-input>
                </el-form-item>
                <el-form-item label="发件人名称">
                    <el-input v-model="settings.smtp_name" placeholder="鼠大侠授权系统"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="saveSettings" :loading="saving">保存设置</el-button>
                    <el-button @click="showTestEmail = true">发送测试邮件</el-button>
                </el-form-item>
            </el-form>
        </el-card>
    </el-tab-pane>
    
    <el-tab-pane label="系统信息" name="system">
        <el-card shadow="hover">
            <el-descriptions :column="2" border>
                <el-descriptions-item label="系统版本">v1.0.0</el-descriptions-item>
                <el-descriptions-item label="PHP版本"><?= phpversion() ?></el-descriptions-item>
                <el-descriptions-item label="服务器系统"><?= php_uname('s') . ' ' . php_uname('r') ?></el-descriptions-item>
                <el-descriptions-item label="运行模式"><?= isServerMode() ? '服务器模式' : '本地模式' ?></el-descriptions-item>
                <el-descriptions-item label="数据库版本">{{ dbInfo.version || '-' }}</el-descriptions-item>
                <el-descriptions-item label="数据库大小">{{ dbInfo.size || '-' }}</el-descriptions-item>
                <el-descriptions-item label="数据表数量">{{ dbInfo.tables || '-' }} 个</el-descriptions-item>
                <el-descriptions-item label="服务器时间"><?= date('Y-m-d H:i:s') ?></el-descriptions-item>
            </el-descriptions>
            <div style="margin-top: 20px;">
                <el-button type="warning" @click="clearCache" :loading="clearing">清理缓存</el-button>
            </div>
        </el-card>
    </el-tab-pane>
</el-tabs>

<!-- 测试邮件对话框 -->
<el-dialog v-model="showTestEmail" title="发送测试邮件" width="400px">
    <el-form label-width="80px">
        <el-form-item label="收件人">
            <el-input v-model="testEmailTo" placeholder="输入收件人邮箱"></el-input>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showTestEmail = false">取消</el-button>
        <el-button type="primary" @click="sendTestEmail" :loading="sendingTest">发送</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
activeTab: 'profile',
adminInfo: {},
profileForm: { email: '' },
settings: {
    site_name: '',
    site_logo: '',
    admin_email: '',
    allow_register: '1',
    login_captcha: '0',
    max_login_attempts: 5,
    lockout_duration: 30,
    token_expire: 86400,
    heartbeat_interval: 5,
    heartbeat_timeout: 30,
    allow_multi_device: '0',
    max_devices: 1,
    log_retention_days: 30,
    auto_clean_logs: '1',
    smtp_host: '',
    smtp_port: 465,
    smtp_user: '',
    smtp_pass: '',
    smtp_from: '',
    smtp_name: ''
},
passwordForm: {
    old_password: '',
    new_password: '',
    confirm_password: ''
},
dbInfo: {},
saving: false,
savingProfile: false,
clearing: false,
changingPass: false,
showTestEmail: false,
testEmailTo: '',
sendingTest: false
";

$vueMounted = "
this.loadProfile();
this.loadSettings();
this.loadDbInfo();
";

$vueMethods = "
async loadProfile() {
    try {
        const res = await fetch('api_settings.php?action=get_profile');
        const data = await res.json();
        if (data.code === 0) {
            this.adminInfo = data.data;
            this.profileForm.email = data.data.email || '';
        }
    } catch (e) { console.error(e); }
},
async saveProfile() {
    this.savingProfile = true;
    try {
        const res = await fetch('api_settings.php?action=update_profile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.profileForm)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('保存成功');
            this.loadProfile();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('保存失败'); }
    this.savingProfile = false;
},
async loadSettings() {
    try {
        const res = await fetch('api_settings.php?action=get');
        const data = await res.json();
        if (data.code === 0) {
            Object.assign(this.settings, data.data);
        }
    } catch (e) { console.error(e); }
},
async loadDbInfo() {
    try {
        const res = await fetch('api_settings.php?action=get_db_info');
        const data = await res.json();
        if (data.code === 0) {
            this.dbInfo = data.data;
        }
    } catch (e) {}
},
async saveSettings() {
    this.saving = true;
    try {
        const res = await fetch('api_settings.php?action=save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ settings: this.settings })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('保存成功');
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('保存失败'); }
    this.saving = false;
},
async clearCache() {
    this.clearing = true;
    try {
        const res = await fetch('api_settings.php?action=clear_cache', { method: 'POST' });
        const data = await res.json();
        ElementPlus.ElMessage.success(data.msg);
    } catch (e) {}
    this.clearing = false;
},
async sendTestEmail() {
    if (!this.testEmailTo) {
        ElementPlus.ElMessage.error('请输入收件人邮箱');
        return;
    }
    this.sendingTest = true;
    try {
        const res = await fetch('api_settings.php?action=test_email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ to: this.testEmailTo })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showTestEmail = false;
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('发送失败'); }
    this.sendingTest = false;
},
async changePassword() {
    if (!this.passwordForm.old_password || !this.passwordForm.new_password) {
        ElementPlus.ElMessage.error('请输入完整信息');
        return;
    }
    if (this.passwordForm.new_password.length < 6) {
        ElementPlus.ElMessage.error('新密码至少6位');
        return;
    }
    if (this.passwordForm.new_password !== this.passwordForm.confirm_password) {
        ElementPlus.ElMessage.error('两次输入的密码不一致');
        return;
    }
    this.changingPass = true;
    try {
        const res = await fetch('api_settings.php?action=change_password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                old_password: this.passwordForm.old_password,
                new_password: this.passwordForm.new_password
            })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.passwordForm = { old_password: '', new_password: '', confirm_password: '' };
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('操作失败'); }
    this.changingPass = false;
}
";

include 'layout.php';
?>
