<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'list':
        $stmt = $db->query("SELECT * FROM payment_configs ORDER BY sort_order ASC, id ASC");
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
    
    case 'get_config':
        $configs = [];
        $stmt = $db->query("SELECT * FROM payment_configs");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $configData = json_decode($row['extra_config'] ?: '{}', true);
            $configData['status'] = $row['status'];
            $configs[$row['pay_type']] = $configData;
        }
        
        // 获取发卡页面设置
        $stmt = $db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'shop_enabled'");
        $stmt->execute();
        $shopEnabled = $stmt->fetchColumn();
        $configs['shop_enabled'] = $shopEnabled !== '0';
        
        echo json_encode(['code' => 0, 'data' => $configs]);
        break;
        
    case 'save_config':
        $input = json_decode(file_get_contents('php://input'), true);
        $type = $input['type'] ?? '';
        $config = $input['config'] ?? [];
        
        if (!in_array($type, ['alipay', 'wechat', 'epay', 'usdt'])) {
            echo json_encode(['code' => 1, 'msg' => '无效的支付类型']);
            break;
        }
        
        $enabled = $config['enabled'] ?? false;
        unset($config['enabled']);
        
        // 检查是否存在
        $stmt = $db->prepare("SELECT id FROM payment_configs WHERE pay_type = ?");
        $stmt->execute([$type]);
        $exists = $stmt->fetch();
        
        $names = ['alipay' => '支付宝当面付', 'wechat' => '微信支付', 'epay' => '易支付', 'usdt' => 'USDT支付'];
        
        if ($exists) {
            $stmt = $db->prepare("UPDATE payment_configs SET extra_config = ?, status = ? WHERE pay_type = ?");
            $stmt->execute([json_encode($config), $enabled ? 1 : 0, $type]);
        } else {
            $stmt = $db->prepare("INSERT INTO payment_configs (pay_type, pay_name, extra_config, status) VALUES (?, ?, ?, ?)");
            $stmt->execute([$type, $names[$type], json_encode($config), $enabled ? 1 : 0]);
        }
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "修改支付配置: {$names[$type]}", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
        
    case 'toggle':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        $status = $input['status'] ?? 0;
        
        $stmt = $db->prepare("UPDATE payment_configs SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        
        echo json_encode(['code' => 0, 'msg' => '操作成功']);
        break;
        
    case 'save':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $stmt = $db->prepare("UPDATE payment_configs SET merchant_id = ?, merchant_key = ?, api_url = ?, notify_url = ? WHERE id = ?");
        $stmt->execute([
            $input['merchant_id'] ?? '',
            $input['merchant_key'] ?? '',
            $input['api_url'] ?? '',
            $input['notify_url'] ?? '',
            $id
        ]);
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
    
    case 'save_shop_setting':
        $input = json_decode(file_get_contents('php://input'), true);
        $enabled = $input['enabled'] ? '1' : '0';
        
        // 保存到系统设置
        $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES ('shop_enabled', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$enabled, $enabled]);
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
