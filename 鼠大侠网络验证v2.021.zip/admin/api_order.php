<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

// 自动修复数据库
autoFixDatabase();

switch ($action) {
    case 'list':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, intval($_GET['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;
        
        $where = "1=1";
        $params = [];
        
        if (!empty($_GET['software_id'])) {
            $where .= " AND o.software_id = ?";
            $params[] = $_GET['software_id'];
        }
        if (isset($_GET['status']) && $_GET['status'] !== '') {
            $where .= " AND o.status = ?";
            $params[] = $_GET['status'];
        }
        if (!empty($_GET['keyword'])) {
            $where .= " AND (o.order_no LIKE ? OR o.buyer_contact LIKE ?)";
            $keyword = '%' . $_GET['keyword'] . '%';
            $params = array_merge($params, [$keyword, $keyword]);
        }
        if (!empty($_GET['start_date'])) {
            $where .= " AND DATE(o.create_time) >= ?";
            $params[] = $_GET['start_date'];
        }
        if (!empty($_GET['end_date'])) {
            $where .= " AND DATE(o.create_time) <= ?";
            $params[] = $_GET['end_date'];
        }
        
        $countSql = "SELECT COUNT(*) FROM orders o WHERE $where";
        $stmt = $db->prepare($countSql);
        $stmt->execute($params);
        $total = $stmt->fetchColumn();
        
        $sql = "SELECT o.*, s.name as software_name, p.price as product_price
                FROM orders o 
                LEFT JOIN software s ON o.software_id = s.id 
                LEFT JOIN products p ON o.product_id = p.id
                WHERE $where 
                ORDER BY o.id DESC 
                LIMIT $offset, $pageSize";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 修复金额为0的订单
        foreach ($list as &$row) {
            if (empty($row['amount']) || floatval($row['amount']) == 0) {
                $qty = intval($row['quantity'] ?? 1);
                if ($qty < 1) $qty = 1;
                $price = floatval($row['product_price'] ?? 0);
                $row['amount'] = $price * $qty;
            }
            if (empty($row['quantity'])) {
                $row['quantity'] = 1;
            }
            // 如果数据库中没有保存归属地，则实时查询并保存
            if (empty($row['ip_location']) && !empty($row['buyer_ip'])) {
                $row['ip_location'] = getIpLocationSimple($row['buyer_ip']);
                // 保存到数据库
                if (!empty($row['ip_location'])) {
                    try {
                        $updateStmt = $db->prepare("UPDATE orders SET ip_location = ? WHERE id = ?");
                        $updateStmt->execute([$row['ip_location'], $row['id']]);
                    } catch (Exception $e) {}
                }
            }
        }
        unset($row);
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        break;
        
    case 'stats':
        $today = date('Y-m-d');
        $monthStart = date('Y-m-01');
        
        // 今日订单
        $stmt = $db->prepare("SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM orders WHERE DATE(create_time) = ? AND status = 1");
        $stmt->execute([$today]);
        $todayData = $stmt->fetch(PDO::FETCH_NUM);
        
        // 本月订单
        $stmt = $db->prepare("SELECT COUNT(*), COALESCE(SUM(amount), 0) FROM orders WHERE DATE(create_time) >= ? AND status = 1");
        $stmt->execute([$monthStart]);
        $monthData = $stmt->fetch(PDO::FETCH_NUM);
        
        echo json_encode(['code' => 0, 'data' => [
            'todayOrders' => intval($todayData[0]),
            'todayIncome' => floatval($todayData[1]),
            'monthOrders' => intval($monthData[0]),
            'monthIncome' => floatval($monthData[1])
        ]]);
        break;
        
    case 'refund':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $stmt = $db->prepare("SELECT * FROM orders WHERE id = ? AND status = 1");
        $stmt->execute([$id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo json_encode(['code' => 1, 'msg' => '订单不存在或状态不正确']);
            break;
        }
        
        // 更新订单状态
        $stmt = $db->prepare("UPDATE orders SET status = 3 WHERE id = ?");
        $stmt->execute([$id]);
        
        // 禁用相关授权码
        if (!empty($order['auth_codes'])) {
            $codes = json_decode($order['auth_codes'], true);
            if ($codes && is_array($codes)) {
                $placeholders = implode(',', array_fill(0, count($codes), '?'));
                $stmt = $db->prepare("UPDATE auth_codes SET status = 2 WHERE code IN ($placeholders)");
                $stmt->execute($codes);
            }
        }
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$_SESSION['admin_id'], "订单退款: {$order['order_no']}", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => '退款成功']);
        break;
    
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $stmt = $db->prepare("DELETE FROM orders WHERE id = ?");
        $stmt->execute([$id]);
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "删除订单ID: {$id}", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    case 'batchDelete':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (empty($ids)) {
            echo json_encode(['code' => 1, 'msg' => '请选择要删除的订单']);
            break;
        }
        
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $db->prepare("DELETE FROM orders WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        $count = $stmt->rowCount();
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "批量删除订单: {$count}条", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => "成功删除 {$count} 条订单"]);
        break;
    
    case 'clearExpired':
        // 清理30分钟前未支付的订单
        $stmt = $db->prepare("DELETE FROM orders WHERE status = 0 AND expire_time < NOW()");
        $stmt->execute();
        $count = $stmt->rowCount();
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "清理过期订单: {$count}条", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => "成功清理 {$count} 条过期订单"]);
        break;
    
    case 'manualCallback':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $stmt = $db->prepare("SELECT * FROM orders WHERE id = ? AND status = 0");
        $stmt->execute([$id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo json_encode(['code' => 1, 'msg' => '订单不存在或状态不正确']);
            break;
        }
        
        try {
            $db->beginTransaction();
            
            // 获取商品信息
            $days = 30;
            $quantity = intval($order['quantity'] ?? 1);
            if ($quantity < 1) $quantity = 1;
            $productId = $order['product_id'];
            
            // 如果product_id为空，尝试从product_name查找
            if (empty($productId) && !empty($order['product_name'])) {
                $stmt = $db->prepare("SELECT id FROM products WHERE name = ? AND software_id = ? LIMIT 1");
                $stmt->execute([$order['product_name'], $order['software_id']]);
                $foundProduct = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($foundProduct) {
                    $productId = $foundProduct['id'];
                    // 更新订单的product_id
                    $stmt = $db->prepare("UPDATE orders SET product_id = ? WHERE id = ?");
                    $stmt->execute([$productId, $id]);
                }
            }
            
            if ($productId) {
                $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
                $stmt->execute([$productId]);
                $product = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($product) {
                    $days = intval($product['duration'] ?? $product['days'] ?? 30);
                    $cardType = $product['card_type'] ?? 'day';
                    if ($cardType === 'month') $days = $days * 30;
                    elseif ($cardType === 'year') $days = $days * 365;
                    elseif ($cardType === 'week') $days = $days * 7;
                    elseif ($cardType === 'permanent') $days = 36500;
                }
            }
            
            // 生成授权码
            $codes = [];
            for ($i = 0; $i < $quantity; $i++) {
                $code = strtoupper(bin2hex(random_bytes(10)));
                $stmt = $db->prepare("INSERT INTO auth_codes (software_id, code, days, status, create_time) VALUES (?, ?, ?, 0, NOW())");
                $stmt->execute([$order['software_id'], $code, $days]);
                $codes[] = $code;
            }
            
            // 更新订单状态
            $stmt = $db->prepare("UPDATE orders SET status = 1, pay_time = NOW(), auth_codes = ?, is_manual = 1 WHERE id = ?");
            $stmt->execute([json_encode($codes), $id]);
            
            // 更新商品销量
            if ($productId) {
                $stmt = $db->prepare("UPDATE products SET sales = sales + ? WHERE id = ?");
                $stmt->execute([$quantity, $productId]);
            }
            
            $db->commit();
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$_SESSION['admin_id'], "手动回调订单: {$order['order_no']}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '手动回调成功，已生成' . count($codes) . '个授权码']);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '操作失败: ' . $e->getMessage()]);
        }
        break;
    
    case 'cancelCallback':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $stmt = $db->prepare("SELECT * FROM orders WHERE id = ? AND status = 1 AND is_manual = 1");
        $stmt->execute([$id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$order) {
            echo json_encode(['code' => 1, 'msg' => '订单不存在或不是手动回调的订单']);
            break;
        }
        
        try {
            $db->beginTransaction();
            
            // 禁用相关授权码
            if (!empty($order['auth_codes'])) {
                $codes = json_decode($order['auth_codes'], true);
                if ($codes && is_array($codes)) {
                    $placeholders = implode(',', array_fill(0, count($codes), '?'));
                    $stmt = $db->prepare("UPDATE auth_codes SET status = 2 WHERE code IN ($placeholders)");
                    $stmt->execute($codes);
                }
            }
            
            // 恢复订单状态
            $stmt = $db->prepare("UPDATE orders SET status = 0, pay_time = NULL, auth_codes = NULL, is_manual = 0 WHERE id = ?");
            $stmt->execute([$id]);
            
            // 减少商品销量
            $quantity = intval($order['quantity'] ?? 1);
            if ($quantity < 1) $quantity = 1;
            if ($order['product_id']) {
                $stmt = $db->prepare("UPDATE products SET sales = GREATEST(0, sales - ?) WHERE id = ?");
                $stmt->execute([$quantity, $order['product_id']]);
            }
            
            $db->commit();
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$_SESSION['admin_id'], "撤销手动回调: {$order['order_no']}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '已撤销手动回调']);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '操作失败: ' . $e->getMessage()]);
        }
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
