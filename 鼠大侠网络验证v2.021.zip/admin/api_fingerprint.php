<?php
/**
 * 指纹审核API
 */

session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_REQUEST['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'list':
        getReviewList($db);
        break;
    case 'approve':
        approveReview($db);
        break;
    case 'reject':
        rejectReview($db);
        break;
    default:
        echo json_encode(['code' => 400, 'message' => '未知操作']);
}

/**
 * 获取审核列表
 */
function getReviewList($db) {
    
    $page = max(1, intval($_GET['page'] ?? 1));
    $pageSize = max(1, min(100, intval($_GET['page_size'] ?? 20)));
    $status = $_GET['status'] ?? '';
    $softwareId = intval($_GET['software_id'] ?? 0);
    
    $where = "1=1";
    $params = [];
    
    if ($status !== '') {
        $where .= " AND fr.status = ?";
        $params[] = intval($status);
    }
    
    if ($softwareId > 0) {
        $where .= " AND fr.software_id = ?";
        $params[] = $softwareId;
    }
    
    // 获取总数
    $countSql = "SELECT COUNT(*) FROM fingerprint_reviews fr WHERE $where";
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // 获取列表
    $offset = ($page - 1) * $pageSize;
    $sql = "SELECT fr.*, d.fingerprint as device_fingerprint, d.platform, d.last_ip, s.name as software_name
            FROM fingerprint_reviews fr
            LEFT JOIN devices d ON fr.device_id = d.id
            LEFT JOIN software s ON fr.software_id = s.id
            WHERE $where
            ORDER BY fr.create_time DESC
            LIMIT $offset, $pageSize";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 脱敏处理
    foreach ($list as &$item) {
        if ($item['old_fingerprint']) {
            $item['old_fingerprint_masked'] = substr($item['old_fingerprint'], 0, 8) . '...' . substr($item['old_fingerprint'], -8);
        }
        if ($item['new_fingerprint']) {
            $item['new_fingerprint_masked'] = substr($item['new_fingerprint'], 0, 8) . '...' . substr($item['new_fingerprint'], -8);
        }
    }
    
    echo json_encode([
        'code' => 200,
        'data' => [
            'list' => $list,
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize
        ]
    ]);
}

/**
 * 审核通过
 */
function approveReview($db) {
    
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    // 获取审核记录
    $stmt = $db->prepare("SELECT * FROM fingerprint_reviews WHERE id = ? AND status = 0");
    $stmt->execute([$id]);
    $review = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$review) {
        echo json_encode(['code' => 404, 'message' => '审核记录不存在或已处理']);
        return;
    }
    
    $db->beginTransaction();
    
    try {
        // 更新审核状态
        $stmt = $db->prepare("UPDATE fingerprint_reviews SET status = 1, admin_id = ?, review_time = NOW() WHERE id = ?");
        $stmt->execute([$_SESSION['admin_id'], $id]);
        
        // 更新设备指纹
        $stmt = $db->prepare("UPDATE devices SET fingerprint = ?, fingerprint_components = ? WHERE id = ?");
        $stmt->execute([$review['new_fingerprint'], $review['new_components'], $review['device_id']]);
        
        // 更新授权码绑定
        $stmt = $db->prepare("UPDATE auth_codes SET bound_fingerprint = ?, bound_components = ? WHERE bound_fingerprint = ?");
        $stmt->execute([$review['new_fingerprint'], $review['new_components'], $review['old_fingerprint']]);
        
        $db->commit();
        
        echo json_encode(['code' => 200, 'message' => '审核通过']);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['code' => 500, 'message' => '操作失败']);
    }
}

/**
 * 审核拒绝
 */
function rejectReview($db) {
    
    $id = intval($_POST['id'] ?? 0);
    $note = trim($_POST['note'] ?? '');
    
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    $stmt = $db->prepare("UPDATE fingerprint_reviews SET status = 2, admin_id = ?, review_note = ?, review_time = NOW() WHERE id = ? AND status = 0");
    $result = $stmt->execute([$_SESSION['admin_id'], $note, $id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['code' => 200, 'message' => '已拒绝']);
    } else {
        echo json_encode(['code' => 404, 'message' => '审核记录不存在或已处理']);
    }
}
