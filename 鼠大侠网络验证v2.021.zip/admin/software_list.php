<?php
$pageTitle = '软件列表';
$breadcrumbs = ['软件管理', '软件列表'];

$pageStyles = "
/* 简洁软件卡片 */
.software-card {
    background: var(--el-bg-color);
    border-radius: 8px;
    border: 1px solid var(--el-border-color-lighter);
    transition: all 0.2s;
}
.software-card:hover {
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
}
.software-card.selected {
    border-color: #409eff;
}
.software-card .el-card__body {
    padding: 16px;
}
.card-top {
    display: flex;
    align-items: center;
    margin-bottom: 14px;
}
.card-top .el-checkbox {
    margin-right: 12px;
}
.software-logo {
    width: 36px;
    height: 36px;
    border-radius: 8px;
    object-fit: contain;
    margin-right: 12px;
}
.software-meta {
    flex: 1;
    min-width: 0;
}
.software-name {
    font-size: 15px;
    font-weight: 500;
    color: var(--el-text-color-primary);
    margin-bottom: 2px;
}
.software-time {
    font-size: 12px;
    color: var(--el-text-color-secondary);
}
.card-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0;
}
.card-row-label {
    font-size: 13px;
    color: var(--el-text-color-secondary);
    flex-shrink: 0;
}
.card-row-value {
    font-size: 13px;
    color: var(--el-text-color-regular);
    cursor: pointer;
    word-break: break-all;
    line-height: 1.4;
    text-align: right;
}
.card-row-value:hover {
    color: #409eff;
}
.card-stats {
    display: flex;
    justify-content: space-around;
    padding: 10px 0;
    margin-top: 8px;
    background: var(--el-fill-color-lighter);
    border-radius: 6px;
}
.stat-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
}
.stat-num {
    font-size: 16px;
    font-weight: 600;
    color: var(--el-text-color-primary);
}
.stat-label {
    font-size: 11px;
    color: var(--el-text-color-secondary);
}
.card-actions {
    display: flex;
    justify-content: center;
    gap: 12px;
    padding-top: 12px;
    margin-top: 8px;
    border-top: 1px solid var(--el-border-color-lighter);
}
";

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-input v-model="searchKeyword" placeholder="搜索软件名称" clearable style="width: 200px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <div style="display: flex; gap: 10px; align-items: center;">
        <el-button type="primary" @click="handleAdd">
            <el-icon><Plus /></el-icon> 添加软件
        </el-button>
        <el-button type="danger" :disabled="selectedList.length === 0" @click="handleBatchDelete">删除选中</el-button>
    </div>
</div>

<el-row :gutter="16" v-loading="loading">
    <el-col :xs="24" :sm="12" :md="8" :lg="6" v-for="item in filteredList" :key="item.id" style="margin-bottom: 16px;">
        <el-card shadow="never" class="software-card" :class="{ 'selected': selectedList.includes(item.id) }">
            <div class="card-top">
                <el-checkbox v-model="item.selected" @change="toggleSelect(item)"></el-checkbox>
                <img src="../img/鼠大侠logo.png" class="software-logo" />
                <div class="software-meta">
                    <div class="software-name">{{ item.name }}</div>
                    <div class="software-time">{{ item.create_time }}</div>
                </div>
                <el-switch v-model="item.statusBool" size="small" @change="toggleStatus(item)" />
            </div>
            
            <div class="card-row">
                <span class="card-row-label">AppKey</span>
                <span class="card-row-value" @click="copyKey(item.app_key)" title="点击复制">{{ item.app_key || '未生成' }}</span>
            </div>
            
            <div class="card-stats">
                <div class="stat-item">
                    <span class="stat-num">{{ item.user_count || 0 }}</span>
                    <span class="stat-label">用户</span>
                </div>
                <div class="stat-item">
                    <span class="stat-num">{{ item.online_count || 0 }}</span>
                    <span class="stat-label">在线</span>
                </div>
                <div class="stat-item">
                    <span class="stat-num">{{ item.auth_count || 0 }}</span>
                    <span class="stat-label">卡密</span>
                </div>
            </div>
            
            <div class="card-actions">
                <el-button type="primary" size="small" @click="handleEdit(item)">编辑</el-button>
                <el-button type="danger" size="small" plain @click="handleDelete(item)">删除</el-button>
            </div>
        </el-card>
    </el-col>
</el-row>

<el-empty v-if="!loading && softwareList.length === 0" description="暂无软件数据" />

<?php
$pageContent = ob_get_clean();

$vueData = "
softwareList: [],
selectedList: [],
searchKeyword: '',
loading: false
";

$vueComputed = "
filteredList() {
    if (!this.searchKeyword) return this.softwareList;
    const keyword = this.searchKeyword.toLowerCase();
    return this.softwareList.filter(item => item.name && item.name.toLowerCase().includes(keyword));
}
";

$vueMounted = "
this.loadData();
";

$vueMethods = "
handleAdd() {
    window.location.href = 'software_add.php';
},
toggleSelect(item) {
    if (item.selected) {
        if (!this.selectedList.includes(item.id)) this.selectedList.push(item.id);
    } else {
        this.selectedList = this.selectedList.filter(id => id !== item.id);
    }
},
async handleBatchDelete() {
    if (this.selectedList.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm(
            '确定要删除选中的 ' + this.selectedList.length + ' 个软件吗？此操作不可撤销！',
            '批量删除',
            { confirmButtonText: '确定删除', cancelButtonText: '取消', type: 'error' }
        );
        const res = await fetch('api_software.php?action=batchDelete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: this.selectedList })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.selectedList = [];
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg || '删除失败');
        }
    } catch (e) {}
},
async loadData() {
    this.loading = true;
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) {
            // 兼容两种返回格式：data.data.list 或 data.data
            const list = data.data.list || data.data || [];
            this.softwareList = list.map(function(item) {
                return {
                    ...item,
                    statusBool: item.status == 1,
                    selected: false
                };
            });
        } else {
            console.error('加载失败:', data.msg);
        }
    } catch (e) {
        console.error(e);
    }
    this.loading = false;
},
copyKey(key) {
    if (!key) {
        ElementPlus.ElMessage.warning('AppKey不存在');
        return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(key).then(function() {
            ElementPlus.ElMessage.success('已复制');
        }).catch(function() {
            fallbackCopy(key);
        });
    } else {
        fallbackCopy(key);
    }
    function fallbackCopy(text) {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand('copy');
            ElementPlus.ElMessage.success('已复制');
        } catch (e) {
            ElementPlus.ElMessage.error('复制失败');
        }
        document.body.removeChild(textarea);
    }
},
async toggleStatus(item) {
    try {
        const newStatus = item.statusBool ? 1 : 0;
        const res = await fetch('api_software.php?action=toggle_status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: item.id, status: newStatus })
        });
        const data = await res.json();
        if (data.code === 0) {
            item.status = newStatus;
            ElementPlus.ElMessage.success(newStatus == 1 ? '已启用' : '已禁用');
        } else {
            item.statusBool = !item.statusBool;
            ElementPlus.ElMessage.error(data.msg || '操作失败');
        }
    } catch (e) {
        item.statusBool = !item.statusBool;
        ElementPlus.ElMessage.error('网络错误');
    }
},
async handleEdit(item) {
    window.location.href = 'software_edit.php?id=' + item.id;
},
async handleDelete(item) {
    try {
        await ElementPlus.ElMessageBox.confirm(
            '确定要删除软件\"' + item.name + '\"吗？此操作不可撤销！',
            '删除确认',
            {
                confirmButtonText: '确定删除',
                cancelButtonText: '取消',
                type: 'warning'
            }
        );
        
        const res = await fetch('api_software.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: item.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('删除成功');
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg || '删除失败');
        }
    } catch (e) {
        if (e !== 'cancel') {
            ElementPlus.ElMessage.error('网络错误');
        }
    }
},
async handleDeleteAll() {
    try {
        await ElementPlus.ElMessageBox.confirm(
            '确定要删除全部软件吗？此操作不可撤销！',
            '删除全部',
            { confirmButtonText: '确定删除', cancelButtonText: '取消', type: 'error' }
        );
        const res = await fetch('api_software.php?action=deleteAll', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.selectedList = [];
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg || '删除失败');
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
