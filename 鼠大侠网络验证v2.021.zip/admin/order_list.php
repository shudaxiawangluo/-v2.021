<?php
$pageTitle = '订单列表';
$breadcrumbs = ['订单管理', '订单列表'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 120px;" @change="loadData">
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-select v-model="searchForm.status" placeholder="订单状态" clearable style="width: 100px;" @change="loadData">
            <el-option label="待支付" :value="0"></el-option>
            <el-option label="已支付" :value="1"></el-option>
            <el-option label="已取消" :value="2"></el-option>
            <el-option label="已退款" :value="3"></el-option>
        </el-select>
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始" end-placeholder="结束" value-format="YYYY-MM-DD" style="width: 220px;" @change="loadData"></el-date-picker>
        <el-input v-model="searchForm.keyword" placeholder="订单号/邮箱" clearable style="width: 160px;" @keyup.enter="loadData"></el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <div style="display: flex; gap: 10px;">
        <el-button type="danger" :disabled="selectedRows.length === 0" @click="handleBatchDelete">删除选中</el-button>
        <el-button type="warning" @click="handleClearExpired">清理过期订单</el-button>
    </div>
</div>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :span="6">
        <el-card shadow="hover"><el-statistic title="今日订单" :value="stats.todayOrders"></el-statistic></el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover"><el-statistic title="今日收入" :value="stats.todayIncome" prefix="¥" :precision="2"></el-statistic></el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover"><el-statistic title="本月订单" :value="stats.monthOrders"></el-statistic></el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover"><el-statistic title="本月收入" :value="stats.monthIncome" prefix="¥" :precision="2"></el-statistic></el-card>
    </el-col>
</el-row>

<el-card shadow="hover">
    <el-table :data="orderList" v-loading="loading" stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="40" align="center"></el-table-column>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="order_no" label="订单号" min-width="180">
            <template #default="scope">
                <el-tooltip :content="scope.row.order_no" placement="top">
                    <span style="font-family: monospace; font-size: 12px;">{{ scope.row.order_no.substring(0, 18) }}...</span>
                </el-tooltip>
            </template>
        </el-table-column>
        <el-table-column prop="software_name" label="软件" min-width="90"></el-table-column>
        <el-table-column prop="product_name" label="商品" min-width="90"></el-table-column>
        <el-table-column prop="quantity" label="数量" min-width="60" align="center">
            <template #default="scope">{{ scope.row.quantity || 1 }}</template>
        </el-table-column>
        <el-table-column label="金额" min-width="80" align="right">
            <template #default="scope"><span style="color: #e6a23c; font-weight: 500;">¥{{ formatAmount(scope.row) }}</span></template>
        </el-table-column>
        <el-table-column label="支付" min-width="70" align="center">
            <template #default="scope">
                <span v-if="scope.row.pay_type">{{ {alipay:'支付宝',wechat:'微信',epay:'易支付',usdt:'USDT',free:'免费'}[scope.row.pay_type] || scope.row.pay_type }}</span>
                <span v-else style="color: #c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column label="状态" min-width="70" align="center">
            <template #default="scope">
                <el-tag :type="{0:'warning',1:'success',2:'info',3:'danger'}[scope.row.status]" size="small">
                    {{ {0:'待付',1:'已付',2:'取消',3:'退款'}[scope.row.status] }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="购买IP" min-width="130">
            <template #default="scope">
                <div v-if="scope.row.buyer_ip">
                    <div style="font-size: 12px;">{{ scope.row.buyer_ip }}</div>
                    <div v-if="scope.row.ip_location" style="font-size: 11px; color: #909399;">{{ scope.row.ip_location }}</div>
                </div>
                <span v-else style="color: #c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column label="创建时间" min-width="160">
            <template #default="scope">{{ scope.row.create_time }}</template>
        </el-table-column>
        <el-table-column label="来源" min-width="60" align="center">
            <template #default="scope">
                <el-tag v-if="getBuyerInfo(scope.row)" type="warning" size="small">代理</el-tag>
                <span v-else style="color: #c0c4cc;">普通</span>
            </template>
        </el-table-column>
        <el-table-column label="支付时间" min-width="160">
            <template #default="scope">
                <span v-if="scope.row.pay_time">{{ scope.row.pay_time }}</span>
                <span v-else style="color: #c0c4cc;">-</span>
            </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right" align="center">
            <template #default="scope">
                <div style="display: flex; gap: 4px; justify-content: center;">
                    <el-button type="primary" size="small" @click="handleView(scope.row)">详情</el-button>
                    <el-button type="success" size="small" @click="handleManualCallback(scope.row)" v-if="scope.row.status == 0">回调</el-button>
                    <el-button type="info" size="small" @click="handleCancelCallback(scope.row)" v-if="scope.row.status == 1 && scope.row.is_manual == 1">撤销</el-button>
                    <el-button type="warning" size="small" @click="handleRefund(scope.row)" v-if="scope.row.status == 1 && !scope.row.is_manual">退款</el-button>
                    <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
                </div>
            </template>
        </el-table-column>
    </el-table>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
        <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ pagination.total }}</b> 条</span>
        <el-pagination background layout="prev, pager, next" :total="pagination.total" :page-size="pagination.pageSize" v-model:current-page="pagination.page" @current-change="loadData"></el-pagination>
    </div>
</el-card>

<!-- 订单详情对话框 -->
<el-dialog v-model="showDetailDialog" title="订单详情" width="600px">
    <el-descriptions :column="2" border>
        <el-descriptions-item label="订单号">{{ currentOrder.order_no }}</el-descriptions-item>
        <el-descriptions-item label="状态">
            <el-tag :type="{0:'warning',1:'success',2:'info',3:'danger'}[currentOrder.status]" size="small">
                {{ {0:'待支付',1:'已支付',2:'已取消',3:'已退款'}[currentOrder.status] }}
            </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="软件">{{ currentOrder.software_name }}</el-descriptions-item>
        <el-descriptions-item label="商品">{{ currentOrder.product_name }}</el-descriptions-item>
        <el-descriptions-item label="数量">{{ currentOrder.quantity || 1 }}</el-descriptions-item>
        <el-descriptions-item label="单价">¥{{ currentOrder.unit_price || formatAmount(currentOrder) }}</el-descriptions-item>
        <el-descriptions-item label="总金额"><span style="color: #e6a23c; font-weight: 500;">¥{{ formatAmount(currentOrder) }}</span></el-descriptions-item>
        <el-descriptions-item label="支付方式">{{ {alipay:'支付宝',wechat:'微信',epay:'易支付',usdt:'USDT'}[currentOrder.pay_type] || currentOrder.pay_type || '-' }}</el-descriptions-item>
        <el-descriptions-item label="支付时间">{{ currentOrder.pay_time || '-' }}</el-descriptions-item>
        <el-descriptions-item label="购买IP" :span="2">{{ currentOrder.buyer_ip || '-' }}</el-descriptions-item>
        <el-descriptions-item label="来源" :span="2" v-if="getBuyerInfo(currentOrder)">
            <el-tag type="warning" size="small">代理商: {{ getBuyerInfo(currentOrder) }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="创建时间" :span="2">{{ currentOrder.create_time }}</el-descriptions-item>
    </el-descriptions>
    <div v-if="currentOrder.auth_codes" style="margin-top: 16px;">
        <div style="font-weight: 500; margin-bottom: 8px;">授权码：</div>
        <el-input type="textarea" :model-value="formatAuthCodes(currentOrder.auth_codes)" :rows="4" readonly style="font-family: monospace;"></el-input>
    </div>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
orderList: [],
softwareList: [],
selectedRows: [],
loading: false,
showDetailDialog: false,
currentOrder: {},
dateRange: [],
searchForm: { software_id: '', status: '', keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 },
stats: { todayOrders: 0, todayIncome: 0, monthOrders: 0, monthIncome: 0 }
";

$vueMounted = "
this.loadData();
this.loadSoftware();
this.loadStats();
";

$vueMethods = "
handleSelectionChange(rows) { this.selectedRows = rows; },
async loadData() {
    this.loading = true;
    try {
        var params = new URLSearchParams({
            action: 'list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            start_date: this.dateRange && this.dateRange[0] ? this.dateRange[0] : '',
            end_date: this.dateRange && this.dateRange[1] ? this.dateRange[1] : '',
            software_id: this.searchForm.software_id || '',
            status: this.searchForm.status !== '' ? this.searchForm.status : '',
            keyword: this.searchForm.keyword || ''
        });
        var res = await fetch('api_order.php?' + params);
        var data = await res.json();
        if (data.code === 0) {
            this.orderList = data.data;
            this.pagination.total = data.total || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        var res = await fetch('api_software.php?action=list');
        var data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
async loadStats() {
    try {
        var res = await fetch('api_order.php?action=stats');
        var data = await res.json();
        if (data.code === 0) this.stats = data.data;
    } catch (e) {}
},
handleView(row) { this.currentOrder = row; this.showDetailDialog = true; },
formatAmount(row) {
    // 优先使用amount，如果为0则尝试其他字段
    var amount = parseFloat(row.amount) || 0;
    if (amount === 0) {
        amount = parseFloat(row.pay_amount) || parseFloat(row.total_amount) || 0;
    }
    return amount.toFixed(2);
},
formatAuthCodes(codes) {
    try { var arr = JSON.parse(codes); return arr.join('\\n'); } catch(e) { return codes; }
},
getBuyerInfo(row) {
    if (!row.buyer_info) return null;
    try {
        var info = JSON.parse(row.buyer_info);
        if (info.type === 'agent') {
            return info.agent_name || ('ID:' + info.agent_id);
        }
    } catch(e) {}
    return null;
},
async handleRefund(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定要退款该订单吗？退款后授权码将被禁用！', '退款确认', { type: 'warning' });
        var res = await fetch('api_order.php?action=refund', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        var data = await res.json();
        if (data.code === 0) { ElementPlus.ElMessage.success(data.msg); this.loadData(); this.loadStats(); }
        else { ElementPlus.ElMessage.error(data.msg); }
    } catch (e) {}
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除该订单吗？', '删除确认', { type: 'warning' });
        var res = await fetch('api_order.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        var data = await res.json();
        if (data.code === 0) { ElementPlus.ElMessage.success(data.msg); this.loadData(); this.loadStats(); }
        else { ElementPlus.ElMessage.error(data.msg); }
    } catch (e) {}
},
async handleBatchDelete() {
    if (this.selectedRows.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除选中的 ' + this.selectedRows.length + ' 个订单吗？', '批量删除', { type: 'warning' });
        var ids = this.selectedRows.map(function(r) { return r.id; });
        var res = await fetch('api_order.php?action=batchDelete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: ids })
        });
        var data = await res.json();
        if (data.code === 0) { ElementPlus.ElMessage.success(data.msg); this.loadData(); this.loadStats(); }
        else { ElementPlus.ElMessage.error(data.msg); }
    } catch (e) {}
},
async handleClearExpired() {
    try {
        await ElementPlus.ElMessageBox.confirm('确定清理所有过期未支付的订单吗？', '清理确认', { type: 'warning' });
        var res = await fetch('api_order.php?action=clearExpired', { method: 'POST' });
        var data = await res.json();
        if (data.code === 0) { ElementPlus.ElMessage.success(data.msg); this.loadData(); this.loadStats(); }
        else { ElementPlus.ElMessage.error(data.msg); }
    } catch (e) {}
},
async handleManualCallback(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定手动回调该订单吗？将标记为已支付并发放授权码。', '手动回调', { type: 'warning' });
        var res = await fetch('api_order.php?action=manualCallback', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        var data = await res.json();
        if (data.code === 0) { ElementPlus.ElMessage.success(data.msg); this.loadData(); this.loadStats(); }
        else { ElementPlus.ElMessage.error(data.msg); }
    } catch (e) {}
},
async handleCancelCallback(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定撤销该订单的手动回调吗？将恢复为待支付状态并禁用授权码。', '撤销回调', { type: 'warning' });
        var res = await fetch('api_order.php?action=cancelCallback', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        var data = await res.json();
        if (data.code === 0) { ElementPlus.ElMessage.success(data.msg); this.loadData(); this.loadStats(); }
        else { ElementPlus.ElMessage.error(data.msg); }
    } catch (e) {}
}
";

include 'layout.php';
?>
