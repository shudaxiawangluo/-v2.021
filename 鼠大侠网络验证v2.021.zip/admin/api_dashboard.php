<?php
session_start();
require_once '../api/config.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

// 趋势数据接口
if ($action === 'trend') {
    $days = intval($_GET['days'] ?? 7);
    if ($days > 30) $days = 30;
    
    $dates = [];
    $logins = [];
    $devices = [];
    
    for ($i = $days - 1; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-{$i} days"));
        $dates[] = date('m-d', strtotime($date));
        
        // 查询当天登录次数（从auth_logs或runtime_logs）
        try {
            $stmt = $db->prepare("SELECT COUNT(*) FROM auth_logs WHERE action = 'activate' AND response_code = 200 AND DATE(create_time) = ?");
            $stmt->execute([$date]);
            $logins[] = intval($stmt->fetchColumn());
        } catch (Exception $e) {
            $logins[] = 0;
        }
        
        // 查询当天新增设备
        try {
            $stmt = $db->prepare("SELECT COUNT(*) FROM devices WHERE DATE(create_time) = ?");
            $stmt->execute([$date]);
            $devices[] = intval($stmt->fetchColumn());
        } catch (Exception $e) {
            $devices[] = 0;
        }
    }
    
    echo json_encode(['code' => 0, 'data' => ['dates' => $dates, 'logins' => $logins, 'users' => $devices]]);
    exit;
}

// 订单趋势数据接口
if ($action === 'order_trend') {
    $days = intval($_GET['days'] ?? 7);
    if ($days > 30) $days = 30;
    
    $dates = [];
    $orders = [];
    $income = [];
    
    for ($i = $days - 1; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-{$i} days"));
        $dates[] = date('m-d', strtotime($date));
        
        // 查询当天订单数和收入
        try {
            $stmt = $db->prepare("SELECT COUNT(*) as cnt, COALESCE(SUM(amount), 0) as total FROM orders WHERE status = 1 AND DATE(create_time) = ?");
            $stmt->execute([$date]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $orders[] = intval($row['cnt']);
            $income[] = floatval($row['total']);
        } catch (Exception $e) {
            $orders[] = 0;
            $income[] = 0;
        }
    }
    
    echo json_encode(['code' => 0, 'data' => ['dates' => $dates, 'orders' => $orders, 'income' => $income]]);
    exit;
}

try {
    // 安全地查询，如果表不存在则返回0
    $stats = [
        'software' => 0,
        'users' => 0,
        'online' => 0,
        'todayLogin' => 0,
        'authCodes' => 0,
        'blacklist' => 0
    ];
    
    // 软件数量
    try {
        $stats['software'] = intval($db->query("SELECT COUNT(*) FROM software")->fetchColumn());
    } catch (Exception $e) {}
    
    // 设备总数（用户总数改为设备总数）
    try {
        $stats['users'] = intval($db->query("SELECT COUNT(*) FROM devices")->fetchColumn());
    } catch (Exception $e) {}
    
    // 在线设备数（15秒内有心跳）
    try {
        $stats['online'] = intval($db->query("SELECT COUNT(*) FROM devices WHERE last_heartbeat > DATE_SUB(NOW(), INTERVAL 15 SECOND)")->fetchColumn());
    } catch (Exception $e) {}
    
    // 今日登录（今日激活成功的次数）
    try {
        // 先尝试从auth_logs查
        $stmt = $db->query("SELECT COUNT(*) FROM auth_logs WHERE action = 'activate' AND response_code = 200 AND DATE(create_time) = CURDATE()");
        $stats['todayLogin'] = intval($stmt->fetchColumn());
    } catch (Exception $e) {
        // 如果auth_logs不存在，从runtime_logs查
        try {
            $stats['todayLogin'] = intval($db->query("SELECT COUNT(*) FROM runtime_logs WHERE module = 'activate' AND type = 'info' AND DATE(create_time) = CURDATE()")->fetchColumn());
        } catch (Exception $e2) {}
    }
    
    // 卡密总数（所有卡密）
    try {
        $stats['authCodes'] = intval($db->query("SELECT COUNT(*) FROM auth_codes")->fetchColumn());
    } catch (Exception $e) {}
    
    // 黑名单总数（IP黑名单 + 机器码黑名单）
    try {
        $ipBlack = intval($db->query("SELECT COUNT(*) FROM ip_blacklist")->fetchColumn());
        $machineBlack = intval($db->query("SELECT COUNT(*) FROM machine_blacklist")->fetchColumn());
        $stats['blacklist'] = $ipBlack + $machineBlack;
    } catch (Exception $e) {}
    
    // 最近日志
    $logs = [];
    try {
        $logs = $db->query("SELECT id, type, content, ip, create_time as time FROM runtime_logs ORDER BY id DESC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $logs = [];
    }
    
    // 最近订单
    $recentOrders = [];
    try {
        $recentOrders = $db->query("SELECT o.order_no, o.product_name, o.amount, o.create_time FROM orders o WHERE o.status = 1 ORDER BY o.id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {}
    
    // 最近激活的设备（替代最近注册用户）
    $recentUsers = [];
    try {
        $stmt = $db->query("SELECT d.id, d.fingerprint as username, s.name as nickname, d.create_time 
            FROM devices d 
            LEFT JOIN software s ON d.software_id = s.id 
            ORDER BY d.id DESC LIMIT 5");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            $recentUsers[] = [
                'id' => $row['id'],
                'username' => substr($row['username'], 0, 16) . '...',
                'nickname' => $row['nickname'] ?: '未知软件',
                'create_time' => $row['create_time']
            ];
        }
    } catch (Exception $e) {}
    
    echo json_encode(['stats' => $stats, 'logs' => $logs, 'recentOrders' => $recentOrders, 'recentUsers' => $recentUsers]);
} catch (Exception $e) {
    echo json_encode(['stats' => ['software' => 0, 'users' => 0, 'online' => 0, 'todayLogin' => 0, 'authCodes' => 0, 'blacklist' => 0], 'logs' => []]);
}
