<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';

$action = $_GET['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'stats':
        $stats = [
            'total' => 0,
            'today' => 0,
            'unique_ip_today' => 0,
            'blocked_count' => 0
        ];
        
        try {
            // 总访问量
            $stmt = $db->query("SELECT COUNT(*) FROM visit_logs");
            $stats['total'] = intval($stmt->fetchColumn());
            
            // 今日访问
            $stmt = $db->query("SELECT COUNT(*) FROM visit_logs WHERE DATE(create_time) = CURDATE()");
            $stats['today'] = intval($stmt->fetchColumn());
            
            // 今日独立IP
            $stmt = $db->query("SELECT COUNT(DISTINCT ip) FROM visit_logs WHERE DATE(create_time) = CURDATE()");
            $stats['unique_ip_today'] = intval($stmt->fetchColumn());
            
            // 被拦截IP数
            $stmt = $db->query("SELECT COUNT(*) FROM ip_blacklist");
            $stats['blocked_count'] = intval($stmt->fetchColumn());
        } catch (Exception $e) {
            // 表可能不存在，返回默认值
        }
        
        echo json_encode(['code' => 0, 'data' => $stats]);
        break;
    
    case 'logs':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, intval($_GET['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;
        $searchIP = $_GET['ip'] ?? '';
        $filter = $_GET['filter'] ?? '';
        
        try {
            $where = "1=1";
            $params = [];
            
            if ($searchIP) {
                $where .= " AND ip LIKE ?";
                $params[] = "%{$searchIP}%";
            }
            
            // 按IP分组统计
            $havingClause = "";
            if ($filter === 'high') {
                $havingClause = "HAVING visit_count > 50";
            } elseif ($filter === 'suspicious') {
                $havingClause = "HAVING visit_count > 100";
            }
            
            // 统计总数
            $countSql = "SELECT COUNT(DISTINCT ip) FROM visit_logs WHERE {$where}";
            $stmt = $db->prepare($countSql);
            $stmt->execute($params);
            $total = $stmt->fetchColumn();
            
            // 获取分组数据
            $sql = "SELECT ip, 
                           MAX(region) as location,
                           COUNT(*) as visit_count, 
                           MAX(path) as path,
                           'GET' as method,
                           MAX(user_agent) as user_agent,
                           MAX(create_time) as last_visit
                    FROM visit_logs 
                    WHERE {$where}
                    GROUP BY ip
                    {$havingClause}
                    ORDER BY last_visit DESC
                    LIMIT {$offset}, {$pageSize}";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['code' => 0, 'data' => $list, 'total' => intval($total)]);
        } catch (Exception $e) {
            // 表可能不存在
            echo json_encode(['code' => 0, 'data' => [], 'total' => 0]);
        }
        break;
    
    case 'chart':
        $days = intval($_GET['days'] ?? 7);
        $dates = [];
        $visits = [];
        $ips = [];
        
        try {
            for ($i = $days - 1; $i >= 0; $i--) {
                $date = date('Y-m-d', strtotime("-{$i} days"));
                $dates[] = date('m-d', strtotime($date));
                
                $stmt = $db->prepare("SELECT COUNT(*) FROM visit_logs WHERE DATE(create_time) = ?");
                $stmt->execute([$date]);
                $visits[] = intval($stmt->fetchColumn());
                
                $stmt = $db->prepare("SELECT COUNT(DISTINCT ip) FROM visit_logs WHERE DATE(create_time) = ?");
                $stmt->execute([$date]);
                $ips[] = intval($stmt->fetchColumn());
            }
        } catch (Exception $e) {
            // 表可能不存在，返回空数据
            for ($i = $days - 1; $i >= 0; $i--) {
                $date = date('Y-m-d', strtotime("-{$i} days"));
                $dates[] = date('m-d', strtotime($date));
                $visits[] = 0;
                $ips[] = 0;
            }
        }
        
        echo json_encode(['code' => 0, 'data' => ['dates' => $dates, 'visits' => $visits, 'ips' => $ips]]);
        break;
    
    case 'detail':
        $ip = $_GET['ip'] ?? '';
        if (!$ip) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        // 获取IP统计信息
        $stmt = $db->prepare("SELECT ip, 
                                     MAX(region) as location,
                                     COUNT(*) as visit_count,
                                     MIN(create_time) as first_visit,
                                     MAX(create_time) as last_visit
                              FROM visit_logs WHERE ip = ? GROUP BY ip");
        $stmt->execute([$ip]);
        $info = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$info) {
            echo json_encode(['code' => 1, 'msg' => 'IP不存在']);
            break;
        }
        
        // 检查是否被拉黑
        $stmt = $db->prepare("SELECT id FROM ip_blacklist WHERE ip = ?");
        $stmt->execute([$ip]);
        $info['is_blocked'] = $stmt->fetch() !== false;
        
        // 获取最近访问记录
        $stmt = $db->prepare("SELECT path, method, create_time FROM visit_logs WHERE ip = ? ORDER BY create_time DESC LIMIT 50");
        $stmt->execute([$ip]);
        $info['recent_logs'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $info]);
        break;
    
    case 'block':
        $input = json_decode(file_get_contents('php://input'), true);
        $ip = $input['ip'] ?? '';
        $reason = $input['reason'] ?? '手动拉黑';
        
        if (!$ip) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $stmt = $db->prepare("INSERT INTO ip_blacklist (ip, reason, create_time) 
                              VALUES (?, ?, NOW()) 
                              ON DUPLICATE KEY UPDATE reason = ?");
        $stmt->execute([$ip, $reason, $reason]);
        
        echo json_encode(['code' => 0, 'msg' => '已拉黑']);
        break;
    
    case 'unblock':
        $input = json_decode(file_get_contents('php://input'), true);
        $ip = $input['ip'] ?? '';
        
        $stmt = $db->prepare("DELETE FROM ip_blacklist WHERE ip = ?");
        $stmt->execute([$ip]);
        
        echo json_encode(['code' => 0, 'msg' => '已解除']);
        break;
    
    case 'whitelist':
        $input = json_decode(file_get_contents('php://input'), true);
        $ip = $input['ip'] ?? '';
        
        if (!$ip) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $stmt = $db->prepare("INSERT INTO ip_whitelist (ip, remark, create_time) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE remark = ?");
        $stmt->execute([$ip, '手动添加', '手动添加']);
        
        echo json_encode(['code' => 0, 'msg' => '已加入白名单']);
        break;
    
    case 'clean':
        // 默认保留30天
        $days = 30;
        
        $stmt = $db->prepare("DELETE FROM visit_logs WHERE create_time < DATE_SUB(NOW(), INTERVAL ? DAY)");
        $stmt->execute([$days]);
        $deleted = $stmt->rowCount();
        
        echo json_encode(['code' => 0, 'deleted' => $deleted]);
        break;
    
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}

/**
 * 获取IP地理位置
 */
function getIPLocation($ip) {
    if ($ip === '127.0.0.1' || $ip === '::1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0) {
        return '本地网络';
    }
    
    try {
        $ctx = stream_context_create(['http' => ['timeout' => 2]]);
        $response = @file_get_contents("http://ip-api.com/json/{$ip}?lang=zh-CN", false, $ctx);
        if ($response) {
            $data = json_decode($response, true);
            if ($data && $data['status'] === 'success') {
                $location = '';
                if (!empty($data['country'])) $location .= $data['country'];
                if (!empty($data['regionName'])) $location .= ' ' . $data['regionName'];
                if (!empty($data['city'])) $location .= ' ' . $data['city'];
                return trim($location) ?: '未知';
            }
        }
    } catch (Exception $e) {}
    
    return '未知';
}
