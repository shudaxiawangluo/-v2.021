<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$db = getDB();

// 确保设置表存在
function ensureSettingsTable($db) {
    try {
        $db->exec("CREATE TABLE IF NOT EXISTS system_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) NOT NULL UNIQUE,
            setting_value TEXT,
            setting_group VARCHAR(50) DEFAULT 'general',
            description VARCHAR(255) DEFAULT '',
            update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_key (setting_key),
            INDEX idx_group (setting_group)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统设置'");
        
        // 初始化默认设置
        $defaults = [
            ['site_name', '鼠大侠授权系统', 'general', '网站名称'],
            ['site_logo', '', 'general', '网站Logo'],
            ['admin_email', '', 'general', '管理员邮箱'],
            ['allow_register', '1', 'security', '允许注册'],
            ['login_captcha', '0', 'security', '登录验证码'],
            ['max_login_attempts', '5', 'security', '最大登录尝试次数'],
            ['lockout_duration', '30', 'security', '锁定时长(分钟)'],
            ['token_expire', '86400', 'security', 'Token有效期(秒)'],
            ['heartbeat_interval', '5', 'client', '心跳间隔(秒)'],
            ['heartbeat_timeout', '30', 'client', '心跳超时(秒)'],
            ['allow_multi_device', '0', 'client', '允许多设备登录'],
            ['max_devices', '1', 'client', '最大设备数'],
            ['log_retention_days', '30', 'logs', '日志保留天数'],
            ['auto_clean_logs', '1', 'logs', '自动清理日志'],
            ['smtp_host', '', 'email', 'SMTP服务器'],
            ['smtp_port', '465', 'email', 'SMTP端口'],
            ['smtp_user', '', 'email', 'SMTP用户名'],
            ['smtp_pass', '', 'email', 'SMTP密码'],
            ['smtp_from', '', 'email', '发件人地址'],
            ['smtp_name', '', 'email', '发件人名称']
        ];
        
        $stmt = $db->prepare("INSERT IGNORE INTO system_settings (setting_key, setting_value, setting_group, description) VALUES (?, ?, ?, ?)");
        foreach ($defaults as $item) {
            $stmt->execute($item);
        }
    } catch (PDOException $e) {}
}

ensureSettingsTable($db);

switch ($action) {
    case 'get':
        $group = $_GET['group'] ?? '';
        
        if ($group) {
            $stmt = $db->prepare("SELECT * FROM system_settings WHERE setting_group = ? ORDER BY id");
            $stmt->execute([$group]);
        } else {
            $stmt = $db->query("SELECT * FROM system_settings ORDER BY setting_group, id");
        }
        
        $settings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        
        echo json_encode(['code' => 0, 'data' => $settings]);
        break;
        
    case 'get_all':
        $stmt = $db->query("SELECT * FROM system_settings ORDER BY setting_group, id");
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 按组分类
        $grouped = [];
        foreach ($list as $item) {
            $group = $item['setting_group'];
            if (!isset($grouped[$group])) {
                $grouped[$group] = [];
            }
            $grouped[$group][] = $item;
        }
        
        echo json_encode(['code' => 0, 'data' => $grouped]);
        break;
        
    case 'save':
        $input = json_decode(file_get_contents('php://input'), true);
        $settings = $input['settings'] ?? [];
        
        if (empty($settings)) {
            echo json_encode(['code' => 1, 'msg' => '没有要保存的设置']);
            exit;
        }
        
        $stmt = $db->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        
        foreach ($settings as $key => $value) {
            $stmt->execute([$key, $value]);
        }
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
        
    case 'test_email':
        $input = json_decode(file_get_contents('php://input'), true);
        $to = $input['to'] ?? '';
        
        if (empty($to)) {
            echo json_encode(['code' => 1, 'msg' => '请输入收件人邮箱']);
            exit;
        }
        
        // 获取邮件设置
        $stmt = $db->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_group = 'email'");
        $emailSettings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $emailSettings[$row['setting_key']] = $row['setting_value'];
        }
        
        if (empty($emailSettings['smtp_host'])) {
            echo json_encode(['code' => 1, 'msg' => '请先配置SMTP服务器']);
            exit;
        }
        
        // 发送测试邮件
        $result = sendEmail(
            $to,
            '测试邮件 - 鼠大侠授权系统',
            '<h3>这是一封测试邮件</h3><p>如果您收到此邮件，说明邮件配置正确。</p><p>发送时间：' . date('Y-m-d H:i:s') . '</p>',
            $emailSettings
        );
        
        if ($result['success']) {
            echo json_encode(['code' => 0, 'msg' => '测试邮件发送成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '发送失败：' . $result['error']]);
        }
        break;
        
    case 'get_db_info':
        // 获取数据库信息
        $info = [];
        
        // 数据库版本
        $stmt = $db->query("SELECT VERSION()");
        $info['version'] = $stmt->fetchColumn();
        
        // 数据库大小
        $stmt = $db->prepare("SELECT SUM(data_length + index_length) as size FROM information_schema.tables WHERE table_schema = ?");
        $stmt->execute([DB_NAME]);
        $size = $stmt->fetchColumn();
        $info['size'] = round($size / 1024 / 1024, 2) . ' MB';
        
        // 表数量
        $stmt = $db->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ?");
        $stmt->execute([DB_NAME]);
        $info['tables'] = $stmt->fetchColumn();
        
        echo json_encode(['code' => 0, 'data' => $info]);
        break;
        
    case 'clear_cache':
        // 清理缓存（如果有的话）
        echo json_encode(['code' => 0, 'msg' => '缓存已清理']);
        break;
    
    case 'change_password':
        $input = json_decode(file_get_contents('php://input'), true);
        $oldPass = $input['old_password'] ?? '';
        $newPass = $input['new_password'] ?? '';
        
        if (empty($oldPass) || empty($newPass)) {
            echo json_encode(['code' => 1, 'msg' => '请输入完整信息']);
            exit;
        }
        
        if (strlen($newPass) < 6) {
            echo json_encode(['code' => 1, 'msg' => '新密码至少6位']);
            exit;
        }
        
        // 验证旧密码
        $adminId = $_SESSION['admin_id'];
        $stmt = $db->prepare("SELECT password FROM admins WHERE id = ?");
        $stmt->execute([$adminId]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$admin || !password_verify($oldPass, $admin['password'])) {
            echo json_encode(['code' => 1, 'msg' => '原密码错误']);
            exit;
        }
        
        // 更新密码
        $newHash = password_hash($newPass, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE admins SET password = ? WHERE id = ?");
        $stmt->execute([$newHash, $adminId]);
        
        echo json_encode(['code' => 0, 'msg' => '密码修改成功']);
        break;
    
    case 'get_profile':
        $adminId = $_SESSION['admin_id'];
        $stmt = $db->prepare("SELECT id, username, email, create_time, last_login, last_ip, login_count FROM admins WHERE id = ?");
        $stmt->execute([$adminId]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // 如果字段不存在，添加默认值
        if (!isset($admin['last_ip'])) $admin['last_ip'] = '-';
        if (!isset($admin['login_count'])) $admin['login_count'] = 0;
        
        echo json_encode(['code' => 0, 'data' => $admin]);
        break;
    
    case 'update_profile':
        $input = json_decode(file_get_contents('php://input'), true);
        $email = trim($input['email'] ?? '');
        
        $adminId = $_SESSION['admin_id'];
        $stmt = $db->prepare("UPDATE admins SET email = ? WHERE id = ?");
        $stmt->execute([$email, $adminId]);
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;

    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}

/**
 * 发送邮件（使用原生PHP SMTP）
 */
function sendEmail($to, $subject, $body, $settings) {
    $host = $settings['smtp_host'] ?? '';
    $port = intval($settings['smtp_port'] ?? 465);
    $user = $settings['smtp_user'] ?? '';
    $pass = $settings['smtp_pass'] ?? '';
    $from = $settings['smtp_from'] ?? $user;
    $fromName = $settings['smtp_name'] ?? '鼠大侠授权系统';
    
    try {
        // 使用fsockopen连接SMTP服务器
        $ssl = ($port == 465) ? 'ssl://' : '';
        $socket = @fsockopen($ssl . $host, $port, $errno, $errstr, 10);
        
        if (!$socket) {
            return ['success' => false, 'error' => "连接失败: $errstr ($errno)"];
        }
        
        // 设置超时
        stream_set_timeout($socket, 10);
        
        // 读取服务器响应
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '220') {
            fclose($socket);
            return ['success' => false, 'error' => '服务器响应错误: ' . $response];
        }
        
        // EHLO
        fputs($socket, "EHLO localhost\r\n");
        $response = '';
        while ($line = fgets($socket, 512)) {
            $response .= $line;
            if (substr($line, 3, 1) == ' ') break;
        }
        
        // 如果是非SSL的587端口，尝试STARTTLS
        if ($port == 587 && strpos($response, 'STARTTLS') !== false) {
            fputs($socket, "STARTTLS\r\n");
            fgets($socket, 512);
            stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            fputs($socket, "EHLO localhost\r\n");
            while ($line = fgets($socket, 512)) {
                if (substr($line, 3, 1) == ' ') break;
            }
        }
        
        // AUTH LOGIN
        fputs($socket, "AUTH LOGIN\r\n");
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '334') {
            fclose($socket);
            return ['success' => false, 'error' => '认证失败: ' . $response];
        }
        
        // 发送用户名
        fputs($socket, base64_encode($user) . "\r\n");
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '334') {
            fclose($socket);
            return ['success' => false, 'error' => '用户名错误: ' . $response];
        }
        
        // 发送密码
        fputs($socket, base64_encode($pass) . "\r\n");
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '235') {
            fclose($socket);
            return ['success' => false, 'error' => '密码错误: ' . $response];
        }
        
        // MAIL FROM
        fputs($socket, "MAIL FROM:<$from>\r\n");
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '250') {
            fclose($socket);
            return ['success' => false, 'error' => '发件人错误: ' . $response];
        }
        
        // RCPT TO
        fputs($socket, "RCPT TO:<$to>\r\n");
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '250') {
            fclose($socket);
            return ['success' => false, 'error' => '收件人错误: ' . $response];
        }
        
        // DATA
        fputs($socket, "DATA\r\n");
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '354') {
            fclose($socket);
            return ['success' => false, 'error' => 'DATA命令失败: ' . $response];
        }
        
        // 构建邮件内容
        $boundary = md5(uniqid(time()));
        $headers = "From: =?UTF-8?B?" . base64_encode($fromName) . "?= <$from>\r\n";
        $headers .= "To: <$to>\r\n";
        $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "Date: " . date('r') . "\r\n";
        
        $message = $headers . "\r\n" . $body . "\r\n.\r\n";
        fputs($socket, $message);
        
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '250') {
            fclose($socket);
            return ['success' => false, 'error' => '发送失败: ' . $response];
        }
        
        // QUIT
        fputs($socket, "QUIT\r\n");
        fclose($socket);
        
        return ['success' => true, 'error' => ''];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}
