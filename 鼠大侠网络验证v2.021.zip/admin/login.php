<?php
session_start();
require_once '../api/config.php';

// 检测是否已安装
try {
    $db = getDB();
    $stmt = $db->query("SELECT COUNT(*) FROM admins");
    if ($stmt->fetchColumn() == 0) {
        header('Location: ../install.php');
        exit;
    }
} catch (Exception $e) {
    header('Location: ../install.php');
    exit;
}

// 登录失败限制
$maxAttempts = 5; // 最大尝试次数
$lockoutTime = 900; // 锁定时间（秒）= 15分钟

function getLoginAttempts($ip) {
    $file = sys_get_temp_dir() . '/login_attempts_' . md5($ip) . '.json';
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        // 清理过期记录
        if (isset($data['lockout_until']) && time() > $data['lockout_until']) {
            unlink($file);
            return ['attempts' => 0, 'lockout_until' => 0];
        }
        return $data;
    }
    return ['attempts' => 0, 'lockout_until' => 0];
}

function recordLoginAttempt($ip, $success, $maxAttempts, $lockoutTime) {
    $file = sys_get_temp_dir() . '/login_attempts_' . md5($ip) . '.json';
    if ($success) {
        if (file_exists($file)) unlink($file);
        return;
    }
    $data = getLoginAttempts($ip);
    $data['attempts']++;
    $data['last_attempt'] = time();
    if ($data['attempts'] >= $maxAttempts) {
        $data['lockout_until'] = time() + $lockoutTime;
    }
    file_put_contents($file, json_encode($data));
}

$clientIP = $_SERVER['REMOTE_ADDR'];
$loginData = getLoginAttempts($clientIP);

// 检查是否被锁定
if ($loginData['lockout_until'] > time()) {
    $remainingTime = ceil(($loginData['lockout_until'] - time()) / 60);
    $error = "登录尝试次数过多，请 {$remainingTime} 分钟后再试";
    $locked = true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($locked)) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin && password_verify($password, $admin['password'])) {
        recordLoginAttempt($clientIP, true, $maxAttempts, $lockoutTime);
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['username'];
        
        // 记录登录日志
        try {
            $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $logStmt->execute([$admin['id'], '管理员登录', $clientIP]);
        } catch (Exception $e) {}
        
        header('Location: dashboard.php');
        exit;
    } else {
        recordLoginAttempt($clientIP, false, $maxAttempts, $lockoutTime);
        $remainingAttempts = $maxAttempts - getLoginAttempts($clientIP)['attempts'];
        
        // 记录登录失败日志
        try {
            logRuntime('warning', "管理员登录失败，用户名: {$username}", 'login', $clientIP);
        } catch (Exception $e) {}
        
        if ($remainingAttempts > 0) {
            $error = "用户名或密码错误，还剩 {$remainingAttempts} 次尝试机会";
        } else {
            $error = "登录尝试次数过多，账号已被锁定15分钟";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - 鼠大侠网络验证</title>
    <link rel="stylesheet" href="https://unpkg.com/element-plus/dist/index.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://unpkg.com/element-plus"></script>
    <script src="https://unpkg.com/@element-plus/icons-vue"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700&display=swap');
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; }
        body { 
            font-family: 'Noto Sans SC', 'Microsoft YaHei', Arial, sans-serif;
        }
        .login-container {
            display: flex;
            height: 100vh;
        }
        .login-left {
            flex: 1;
            background-color: #f5f7fa;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px;
            position: relative;
        }
        .login-left::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 80px;
            background: linear-gradient(180deg, rgba(245,247,250,0) 0%, #f5f7fa 100%);
        }
        .page-logo {
            position: absolute;
            top: 30px;
            left: 40px;
            font-size: 20px;
            font-weight: 500;
            color: #303133;
            letter-spacing: 1px;
        }
        .login-left-content {
            text-align: center;
        }
        .login-left img {
            max-width: 500px;
            max-height: 500px;
            object-fit: contain;
        }
        .login-right {
            flex: 1;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 60px;
            position: relative;
        }
        .login-right::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
            border-radius: 50%;
            opacity: 0.3;
            z-index: 0;
        }
        .login-right::after {
            content: '';
            position: absolute;
            bottom: -80px;
            left: -80px;
            width: 250px;
            height: 250px;
            background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
            border-radius: 50%;
            opacity: 0.3;
            z-index: 0;
        }
        .login-form-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 380px;
        }
        .login-form-card {
            background: white;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.08);
        }
        .login-title {
            font-size: 26px;
            font-weight: 500;
            color: #303133;
            margin-bottom: 8px;
            text-align: center;
        }
        .login-subtitle {
            color: #909399;
            text-align: center;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .login-btn {
            width: 220px !important;
            margin: 0 auto;
            display: block;
        }
        .login-footer {
            text-align: center;
            margin-top: 24px;
            color: #909399;
            font-size: 12px;
        }
        .login-divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
            color: #dcdfe6;
        }
        .login-divider::before,
        .login-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #dcdfe6;
        }
        .login-divider span {
            padding: 0 15px;
            font-size: 12px;
            color: #909399;
        }
    </style>
</head>
<body>
    <div id="app">
        <div class="login-container">
            <!-- 左侧插画区 -->
            <div class="login-left">
                <div class="page-logo">鼠大侠网络验证 - 软件管理系统</div>
                <div class="login-left-content">
                    <img src="../img/登录背景.png" alt="登录插画">
                </div>
            </div>
            
            <!-- 右侧登录表单 -->
            <div class="login-right">
                <div class="login-form-wrapper">
                    <div class="login-form-card">
                        <h2 class="login-title">欢迎回来</h2>
                        <p class="login-subtitle">请登录您的管理员账号</p>
                        
                        <el-form method="POST" @submit.prevent="handleSubmit">
                            <transition name="el-fade-in">
                                <el-alert 
                                    v-if="showError" 
                                    :title="errorMsg" 
                                    type="error" 
                                    show-icon
                                    :closable="true"
                                    @close="showError = false"
                                    style="margin-bottom: 20px;"
                                />
                            </transition>
                            
                            <el-form-item>
                                <el-input 
                                    name="username" 
                                    v-model="username"
                                    placeholder="请输入用户名" 
                                    size="default"
                                    clearable
                                >
                                    <template #prefix>
                                        <el-icon><user /></el-icon>
                                    </template>
                                </el-input>
                            </el-form-item>
                            
                            <el-form-item>
                                <el-input 
                                    name="password" 
                                    v-model="password"
                                    type="password" 
                                    placeholder="请输入密码" 
                                    size="default"
                                    show-password
                                >
                                    <template #prefix>
                                        <el-icon><lock /></el-icon>
                                    </template>
                                </el-input>
                            </el-form-item>
                            
                            <el-form-item style="margin-bottom: 10px;">
                                <div style="display: flex; justify-content: space-between; width: 100%;">
                                    <el-checkbox v-model="remember">记住密码</el-checkbox>
                                    <el-link type="primary" :underline="false" style="font-size: 13px;" @click="handleForgotPassword">忘记密码？</el-link>
                                </div>
                            </el-form-item>
                            
                            <el-form-item style="margin-top: 24px;">
                                <el-button type="primary" native-type="submit" size="default" class="login-btn">
                                    登录系统
                                </el-button>
                            </el-form-item>
                        </el-form>
                        
                        <div class="login-footer">
                            © 2026 鼠大侠网络验证 · 安全可靠
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const { createApp } = Vue;
        const app = createApp({
            data() {
                return {
                    username: '',
                    password: '',
                    remember: false,
                    showError: <?= isset($error) ? 'true' : 'false' ?>,
                    errorMsg: '<?= $error ?? '' ?>'
                }
            },
            mounted() {
                // 读取记住的账号密码
                const savedUsername = localStorage.getItem('saved_username');
                const savedPassword = localStorage.getItem('saved_password');
                const rememberMe = localStorage.getItem('remember_me');
                
                if (rememberMe === 'true' && savedUsername && savedPassword) {
                    this.username = savedUsername;
                    this.password = savedPassword;
                    this.remember = true;
                }
                
                if (this.showError) {
                    setTimeout(() => {
                        this.showError = false;
                    }, 3000);
                }
            },
            methods: {
                handleSubmit(e) {
                    if (!this.username || !this.password) {
                        this.errorMsg = '请输入用户名和密码';
                        this.showError = true;
                        setTimeout(() => {
                            this.showError = false;
                        }, 3000);
                        e.preventDefault();
                        return false;
                    }
                    
                    // 保存或清除记住的账号密码
                    if (this.remember) {
                        localStorage.setItem('saved_username', this.username);
                        localStorage.setItem('saved_password', this.password);
                        localStorage.setItem('remember_me', 'true');
                    } else {
                        localStorage.removeItem('saved_username');
                        localStorage.removeItem('saved_password');
                        localStorage.removeItem('remember_me');
                    }
                    
                    e.target.submit();
                },
                handleForgotPassword() {
                    ElementPlus.ElMessageBox.alert(
                        '请联系系统管理员重置密码，或使用 reset_password.php 工具重置密码。',
                        '忘记密码',
                        {
                            confirmButtonText: '我知道了',
                            type: 'info'
                        }
                    );
                }
            }
        });
        app.use(ElementPlus);
        for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
            app.component(key, component);
        }
        app.mount('#app');
    </script>
</body>
</html>
