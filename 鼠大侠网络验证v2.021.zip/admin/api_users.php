<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$db = getDB();

// 自动检测并添加缺失的字段
function ensureUserColumns($db) {
    $requiredColumns = [
        'is_online' => 'TINYINT DEFAULT 0',
        'last_login_ip' => 'VARCHAR(50) DEFAULT NULL',
        'ip_location' => 'VARCHAR(100) DEFAULT NULL',
        'last_login_time' => 'DATETIME DEFAULT NULL',
        'login_count' => 'INT DEFAULT 0',
        'device_count' => 'INT DEFAULT 0',
        'max_devices' => 'INT DEFAULT 1',
        'token' => 'VARCHAR(64) DEFAULT NULL',
        'token_expire' => 'DATETIME DEFAULT NULL',
        'machine_banned' => 'TINYINT DEFAULT 0'
    ];
    
    $existingColumns = [];
    $columnsStmt = $db->query("SHOW COLUMNS FROM users");
    while ($col = $columnsStmt->fetch(PDO::FETCH_ASSOC)) {
        $existingColumns[] = $col['Field'];
    }
    
    foreach ($requiredColumns as $colName => $colDef) {
        if (!in_array($colName, $existingColumns)) {
            try {
                $db->exec("ALTER TABLE users ADD COLUMN $colName $colDef");
            } catch (Exception $e) {}
        }
    }
}

// 获取IP归属地
function getIpLocation($ip) {
    if (empty($ip) || $ip == '127.0.0.1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0) {
        return '本地网络';
    }
    
    // 使用太平洋IP库API（免费）
    $url = "https://whois.pconline.com.cn/ipJson.jsp?ip=" . urlencode($ip) . "&json=true";
    $context = stream_context_create([
        'http' => ['timeout' => 3]
    ]);
    
    try {
        $response = @file_get_contents($url, false, $context);
        if ($response) {
            $response = mb_convert_encoding($response, 'UTF-8', 'GBK');
            $data = json_decode($response, true);
            if ($data && isset($data['addr'])) {
                return trim($data['addr']);
            }
            if ($data && isset($data['pro'])) {
                $location = $data['pro'];
                if (!empty($data['city'])) $location .= $data['city'];
                if (!empty($data['region'])) $location .= $data['region'];
                return $location ?: '未知';
            }
        }
    } catch (Exception $e) {}
    
    // 备用：使用ip-api.com
    try {
        $url2 = "http://ip-api.com/json/" . urlencode($ip) . "?lang=zh-CN";
        $response2 = @file_get_contents($url2, false, $context);
        if ($response2) {
            $data2 = json_decode($response2, true);
            if ($data2 && $data2['status'] == 'success') {
                $location = '';
                if (!empty($data2['country'])) $location .= $data2['country'];
                if (!empty($data2['regionName'])) $location .= $data2['regionName'];
                if (!empty($data2['city'])) $location .= $data2['city'];
                return $location ?: '未知';
            }
        }
    } catch (Exception $e) {}
    
    return '未知';
}

switch ($action) {
    case 'list':
        ensureUserColumns($db);
        
        $page = intval($_GET['page'] ?? 1);
        $pageSize = intval($_GET['pageSize'] ?? 20);
        $software_id = $_GET['software_id'] ?? '';
        $status = $_GET['status'] ?? '';
        $online = $_GET['online'] ?? '';
        $keyword = $_GET['keyword'] ?? '';
        
        $where = "1=1";
        $params = [];
        
        if ($software_id !== '') {
            $where .= " AND u.software_id = ?";
            $params[] = $software_id;
        }
        if ($status !== '') {
            $where .= " AND u.status = ?";
            $params[] = $status;
        }
        if ($keyword !== '') {
            $where .= " AND (u.username LIKE ? OR u.machine_code LIKE ? OR u.last_login_ip LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        // 按机器码去重，只取每个机器码最新的一条记录
        // 获取总数（按机器码去重）
        $countStmt = $db->prepare("SELECT COUNT(DISTINCT IFNULL(u.machine_code, u.id)) FROM users u WHERE $where");
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        // 获取用户列表（按机器码去重，取最新的）
        $offset = ($page - 1) * $pageSize;
        $stmt = $db->prepare("SELECT u.*, s.name as software_name
            FROM users u 
            LEFT JOIN software s ON u.software_id = s.id 
            WHERE u.id IN (
                SELECT MAX(id) FROM users WHERE $where GROUP BY IFNULL(machine_code, id)
            )
            ORDER BY u.id DESC LIMIT $offset, $pageSize");
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 处理每个用户的在线状态
        foreach ($list as &$user) {
            // 按机器码查询在线记录（因为同一机器码可能有多个用户记录）
            if ($user['machine_code']) {
                $onlineStmt = $db->prepare("SELECT * FROM online_users WHERE machine_code = ? ORDER BY last_heartbeat DESC LIMIT 1");
                $onlineStmt->execute([$user['machine_code']]);
            } else {
                $onlineStmt = $db->prepare("SELECT * FROM online_users WHERE user_id = ? ORDER BY last_heartbeat DESC LIMIT 1");
                $onlineStmt->execute([$user['id']]);
            }
            $onlineRecord = $onlineStmt->fetch(PDO::FETCH_ASSOC);
            
            // 使用30秒超时判断（与软件列表统计一致）
            $timeout = 30;
            
            if ($onlineRecord && $onlineRecord['last_heartbeat']) {
                $lastHeartbeat = strtotime($onlineRecord['last_heartbeat']);
                $timeDiff = time() - $lastHeartbeat;
                $user['is_online'] = $timeDiff < $timeout ? 1 : 0;
                
                // 使用在线记录的IP
                if ($onlineRecord['ip']) {
                    $user['last_login_ip'] = $onlineRecord['ip'];
                }
                
                // 注意：不要在这里删除online_users记录！
                // 只更新users表的显示状态，不影响客户端心跳
                if ($timeDiff > $timeout) {
                    try {
                        $db->prepare("UPDATE users SET is_online = 0 WHERE id = ?")->execute([$user['id']]);
                    } catch (Exception $e) {}
                }
            } else {
                $user['is_online'] = 0;
            }
            
            // 检查是否在机器黑名单中
            if ($user['machine_code']) {
                $banStmt = $db->prepare("SELECT id FROM machine_blacklist WHERE machine_code = ?");
                $banStmt->execute([$user['machine_code']]);
                $user['machine_banned'] = $banStmt->fetch() ? 1 : 0;
            } else {
                $user['machine_banned'] = 0;
            }
            
            // 如果没有IP归属地，尝试获取
            if (empty($user['ip_location']) && !empty($user['last_login_ip'])) {
                $location = getIpLocation($user['last_login_ip']);
                $user['ip_location'] = $location;
                try {
                    $updateStmt = $db->prepare("UPDATE users SET ip_location = ? WHERE id = ?");
                    $updateStmt->execute([$location, $user['id']]);
                } catch (Exception $e) {}
            }
        }
        
        // 根据在线状态筛选
        if ($online !== '') {
            $list = array_filter($list, function($u) use ($online) {
                return $u['is_online'] == $online;
            });
            $list = array_values($list);
        }
        
        echo json_encode(['code' => 0, 'msg' => 'success', 'data' => $list, 'total' => $total]);
        break;
        
    case 'kickOffline':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            exit;
        }
        
        try {
            // 删除online_users表中的记录
            $stmt = $db->prepare("DELETE FROM online_users WHERE user_id = ?");
            $stmt->execute([$id]);
            
            // 更新users表状态
            $stmt = $db->prepare("UPDATE users SET is_online = 0, token = NULL, token_expire = NULL WHERE id = ?");
            $stmt->execute([$id]);
            
            // 记录日志
            $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $logStmt->execute([$_SESSION['admin_id'], "强制下线用户ID: $id", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '下线成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
        
    case 'disable':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        try {
            // 删除online_users表中的记录
            $db->prepare("DELETE FROM online_users WHERE user_id = ?")->execute([$id]);
            // 更新用户状态
            $db->prepare("UPDATE users SET status = 0, is_online = 0, token = NULL WHERE id = ?")->execute([$id]);
            echo json_encode(['code' => 0, 'msg' => '禁用成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
        
    case 'enable':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        try {
            $db->prepare("UPDATE users SET status = 1 WHERE id = ?")->execute([$id]);
            echo json_encode(['code' => 0, 'msg' => '启用成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
        
    case 'banMachine':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        $machine_code = trim($input['machine_code'] ?? '');
        
        if (empty($machine_code)) {
            echo json_encode(['code' => 1, 'msg' => '机器码不能为空']);
            exit;
        }
        
        try {
            // 创建黑名单表（如果不存在）- 添加software_id字段支持
            $db->exec("CREATE TABLE IF NOT EXISTS machine_blacklist (
                id INT AUTO_INCREMENT PRIMARY KEY,
                machine_code VARCHAR(64) NOT NULL,
                software_id INT DEFAULT NULL,
                reason VARCHAR(255) DEFAULT '',
                admin_id INT DEFAULT 0,
                create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uk_machine_software (machine_code, software_id),
                INDEX idx_machine (machine_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            
            // 添加到黑名单（全局封禁，software_id为NULL）
            $stmt = $db->prepare("INSERT IGNORE INTO machine_blacklist (machine_code, software_id, admin_id, create_time) VALUES (?, NULL, ?, NOW())");
            $stmt->execute([$machine_code, $_SESSION['admin_id']]);
            
            // 删除online_users表中该机器码的所有记录
            $db->prepare("DELETE FROM online_users WHERE machine_code = ?")->execute([$machine_code]);
            
            // 强制该机器码的所有用户下线
            $db->prepare("UPDATE users SET is_online = 0, token = NULL WHERE machine_code = ?")->execute([$machine_code]);
            
            // 记录日志
            $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $logStmt->execute([$_SESSION['admin_id'], "封禁机器码: $machine_code", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '封禁成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'unbanMachine':
        $input = json_decode(file_get_contents('php://input'), true);
        $machine_code = trim($input['machine_code'] ?? '');
        
        if (empty($machine_code)) {
            echo json_encode(['code' => 1, 'msg' => '机器码不能为空']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("DELETE FROM machine_blacklist WHERE machine_code = ?");
            $stmt->execute([$machine_code]);
            
            // 记录日志
            $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $logStmt->execute([$_SESSION['admin_id'], "解封机器码: $machine_code", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '解封成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
        
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        try {
            $db->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
            echo json_encode(['code' => 0, 'msg' => '删除成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        break;
        
    case 'batchKickOffline':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (empty($ids)) {
            echo json_encode(['code' => 1, 'msg' => '请选择用户']);
            exit;
        }
        
        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            // 删除online_users表中的记录
            $db->prepare("DELETE FROM online_users WHERE user_id IN ($placeholders)")->execute($ids);
            // 更新users表状态
            $db->prepare("UPDATE users SET is_online = 0, token = NULL WHERE id IN ($placeholders)")->execute($ids);
            echo json_encode(['code' => 0, 'msg' => '批量下线成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
        
    case 'batchDisable':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (empty($ids)) {
            echo json_encode(['code' => 1, 'msg' => '请选择用户']);
            exit;
        }
        
        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("UPDATE users SET status = 0, is_online = 0, token = NULL WHERE id IN ($placeholders)")->execute($ids);
            echo json_encode(['code' => 0, 'msg' => '批量禁用成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
        
    case 'batchDelete':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (empty($ids)) {
            echo json_encode(['code' => 1, 'msg' => '请选择用户']);
            exit;
        }
        
        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("DELETE FROM users WHERE id IN ($placeholders)")->execute($ids);
            echo json_encode(['code' => 0, 'msg' => '批量删除成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
