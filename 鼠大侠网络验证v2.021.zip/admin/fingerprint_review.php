<?php
/**
 * 指纹审核页面
 */

require_once __DIR__ . '/layout.php';
requireLogin();

$pageTitle = '指纹审核';
include __DIR__ . '/layout.php';
?>

<div class="container-fluid">
    <div class="row mb-3">
        <div class="col">
            <h4><i class="bi bi-fingerprint"></i> 指纹审核</h4>
            <p class="text-muted">审核硬件变更的设备指纹</p>
        </div>
    </div>

    <!-- 筛选 -->
    <div class="card mb-3">
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">软件</label>
                    <select class="form-select" name="software_id" id="softwareSelect">
                        <option value="">全部软件</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">状态</label>
                    <select class="form-select" name="status" id="statusSelect">
                        <option value="">全部状态</option>
                        <option value="0">待审核</option>
                        <option value="1">已通过</option>
                        <option value="2">已拒绝</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">
                        <i class="bi bi-search"></i> 查询
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="bi bi-arrow-clockwise"></i> 重置
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- 列表 -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="reviewTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>软件</th>
                            <th>原指纹</th>
                            <th>新指纹</th>
                            <th>匹配率</th>
                            <th>平台</th>
                            <th>IP</th>
                            <th>状态</th>
                            <th>申请时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody id="reviewList">
                        <tr>
                            <td colspan="10" class="text-center">加载中...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- 分页 -->
            <nav id="pagination" class="mt-3"></nav>
        </div>
    </div>
</div>

<!-- 详情模态框 -->
<div class="modal fade" id="detailModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">指纹详情</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>原指纹组件</h6>
                        <pre id="oldComponents" class="bg-light p-2 rounded"></pre>
                    </div>
                    <div class="col-md-6">
                        <h6>新指纹组件</h6>
                        <pre id="newComponents" class="bg-light p-2 rounded"></pre>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
            </div>
        </div>
    </div>
</div>

<script>
let currentPage = 1;
const pageSize = 20;

// 加载软件列表
function loadSoftwareList() {
    fetch('api_software.php?action=list')
        .then(r => r.json())
        .then(data => {
            if (data.code === 200) {
                const select = document.getElementById('softwareSelect');
                data.data.list.forEach(item => {
                    select.innerHTML += `<option value="${item.id}">${item.name}</option>`;
                });
            }
        });
}

// 加载审核列表
function loadReviewList(page = 1) {
    currentPage = page;
    const softwareId = document.getElementById('softwareSelect').value;
    const status = document.getElementById('statusSelect').value;
    
    let url = `api_fingerprint.php?action=list&page=${page}&page_size=${pageSize}`;
    if (softwareId) url += `&software_id=${softwareId}`;
    if (status !== '') url += `&status=${status}`;
    
    fetch(url)
        .then(r => r.json())
        .then(data => {
            if (data.code === 200) {
                renderList(data.data.list);
                renderPagination(data.data.total, page);
            }
        });
}

// 渲染列表
function renderList(list) {
    const tbody = document.getElementById('reviewList');
    
    if (list.length === 0) {
        tbody.innerHTML = '<tr><td colspan="10" class="text-center text-muted">暂无数据</td></tr>';
        return;
    }
    
    tbody.innerHTML = list.map(item => {
        const statusBadge = {
            0: '<span class="badge bg-warning">待审核</span>',
            1: '<span class="badge bg-success">已通过</span>',
            2: '<span class="badge bg-danger">已拒绝</span>'
        }[item.status] || '';
        
        return `
            <tr>
                <td>${item.id}</td>
                <td>${item.software_name || '-'}</td>
                <td><code title="${item.old_fingerprint}">${item.old_fingerprint_masked || '-'}</code></td>
                <td><code title="${item.new_fingerprint}">${item.new_fingerprint_masked || '-'}</code></td>
                <td>${item.match_rate}%</td>
                <td>${item.platform || '-'}</td>
                <td>${item.last_ip || '-'}</td>
                <td>${statusBadge}</td>
                <td>${item.create_time}</td>
                <td>
                    <button class="btn btn-sm btn-outline-info" onclick="showDetail(${item.id}, '${item.old_components}', '${item.new_components}')">
                        <i class="bi bi-eye"></i>
                    </button>
                    ${item.status == 0 ? `
                        <button class="btn btn-sm btn-success" onclick="approveReview(${item.id})">
                            <i class="bi bi-check"></i> 通过
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="rejectReview(${item.id})">
                            <i class="bi bi-x"></i> 拒绝
                        </button>
                    ` : ''}
                </td>
            </tr>
        `;
    }).join('');
}

// 渲染分页
function renderPagination(total, page) {
    const totalPages = Math.ceil(total / pageSize);
    const nav = document.getElementById('pagination');
    
    if (totalPages <= 1) {
        nav.innerHTML = '';
        return;
    }
    
    let html = '<ul class="pagination justify-content-center">';
    
    // 上一页
    html += `<li class="page-item ${page <= 1 ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="loadReviewList(${page - 1})">上一页</a>
    </li>`;
    
    // 页码
    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= page - 2 && i <= page + 2)) {
            html += `<li class="page-item ${i === page ? 'active' : ''}">
                <a class="page-link" href="#" onclick="loadReviewList(${i})">${i}</a>
            </li>`;
        } else if (i === page - 3 || i === page + 3) {
            html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }
    }
    
    // 下一页
    html += `<li class="page-item ${page >= totalPages ? 'disabled' : ''}">
        <a class="page-link" href="#" onclick="loadReviewList(${page + 1})">下一页</a>
    </li>`;
    
    html += '</ul>';
    nav.innerHTML = html;
}

// 显示详情
function showDetail(id, oldComponents, newComponents) {
    try {
        document.getElementById('oldComponents').textContent = JSON.stringify(JSON.parse(oldComponents || '{}'), null, 2);
        document.getElementById('newComponents').textContent = JSON.stringify(JSON.parse(newComponents || '{}'), null, 2);
    } catch (e) {
        document.getElementById('oldComponents').textContent = oldComponents || '-';
        document.getElementById('newComponents').textContent = newComponents || '-';
    }
    new bootstrap.Modal(document.getElementById('detailModal')).show();
}

// 审核通过
function approveReview(id) {
    if (!confirm('确定通过此审核？设备指纹将被更新。')) return;
    
    fetch('api_fingerprint.php?action=approve', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id=${id}`
    })
    .then(r => r.json())
    .then(data => {
        alert(data.message);
        if (data.code === 200) loadReviewList(currentPage);
    });
}

// 审核拒绝
function rejectReview(id) {
    const note = prompt('请输入拒绝原因（可选）：');
    if (note === null) return;
    
    fetch('api_fingerprint.php?action=reject', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `id=${id}&note=${encodeURIComponent(note)}`
    })
    .then(r => r.json())
    .then(data => {
        alert(data.message);
        if (data.code === 200) loadReviewList(currentPage);
    });
}

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    loadSoftwareList();
    loadReviewList();
    
    document.getElementById('filterForm').addEventListener('submit', function(e) {
        e.preventDefault();
        loadReviewList(1);
    });
    
    document.getElementById('filterForm').addEventListener('reset', function() {
        setTimeout(() => loadReviewList(1), 0);
    });
});
</script>

<?php include __DIR__ . '/layout.php'; ?>
