<?php
$pageTitle = 'IP白名单';
$breadcrumbs = ['安全中心', 'IP白名单'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 140px;" @change="loadData">
            <el-option label="全局" :value="0"></el-option>
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索IP/备注" clearable style="width: 200px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <div style="display: flex; gap: 10px;">
        <el-button type="danger" :disabled="selectedRows.length === 0" @click="handleBatchDelete">批量删除</el-button>
        <el-button type="primary" @click="showAddDialog = true"><el-icon><Plus /></el-icon>添加白名单</el-button>
    </div>
</div>

<el-card shadow="hover">
    <div class="tip-box" style="margin-bottom: 16px; padding: 12px; background: #ecf5ff; border-radius: 4px; color: #409eff; font-size: 13px;">
        <el-icon><InfoFilled /></el-icon>
        IP白名单中的IP将跳过黑名单检测，优先放行。支持通配符（如 192.168.*.*）和CIDR格式（如 192.168.1.0/24）。
    </div>
    
    <el-table :data="dataList" v-loading="loading" @selection-change="handleSelectionChange" stripe table-layout="auto">
        <el-table-column type="selection" width="40" align="center"></el-table-column>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="ip" label="IP地址" min-width="140" align="center">
            <template #default="scope">
                <span style="font-family: monospace;">{{ scope.row.ip }}</span>
                <el-button link type="primary" size="small" @click="copyText(scope.row.ip)">
                    <el-icon><CopyDocument /></el-icon>
                </el-button>
            </template>
        </el-table-column>
        <el-table-column label="适用软件" min-width="100" align="center">
            <template #default="scope">
                <el-tag v-if="scope.row.software_id == 0" type="warning" size="small">全局</el-tag>
                <span v-else>{{ scope.row.software_name || '-' }}</span>
            </template>
        </el-table-column>
        <el-table-column prop="remark" label="备注" min-width="150" align="center">
            <template #default="scope">
                <span>{{ scope.row.remark || '-' }}</span>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="添加时间" min-width="160" align="center"></el-table-column>
        <el-table-column label="操作" width="100" fixed="right" align="center">
            <template #default="scope">
                <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
    
    <div class="pagination-container" style="justify-content: flex-end;">
        <el-pagination
            v-model:current-page="pagination.page"
            v-model:page-size="pagination.pageSize"
            :page-sizes="[20, 50, 100]"
            :total="pagination.total"
            layout="total, sizes, prev, pager, next"
            @size-change="loadData"
            @current-change="loadData"
        />
    </div>
</el-card>

<!-- 添加对话框 -->
<el-dialog v-model="showAddDialog" title="添加IP白名单" width="500px">
    <el-form :model="addForm" label-width="100px">
        <el-form-item label="IP地址" required>
            <el-input v-model="addForm.ip" type="textarea" :rows="4" placeholder="每行一个IP，支持通配符（192.168.*.*）和CIDR（192.168.1.0/24）"></el-input>
        </el-form-item>
        <el-form-item label="适用软件">
            <el-select v-model="addForm.software_id" style="width: 100%;">
                <el-option label="全局（所有软件）" :value="0"></el-option>
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="备注">
            <el-input v-model="addForm.remark" placeholder="可选，如：公司内网IP"></el-input>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="primary" @click="handleAdd" :loading="submitting">添加</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
dataList: [],
softwareList: [],
loading: false,
submitting: false,
showAddDialog: false,
selectedRows: [],
searchForm: { software_id: '', keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 },
addForm: { ip: '', software_id: 0, remark: '' }
";

$vueMounted = "
this.loadData();
this.loadSoftware();
";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'whitelist_list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            ...this.searchForm
        });
        const res = await fetch('api_security.php?' + params);
        const data = await res.json();
        if (data.code === 0) {
            this.dataList = data.data;
            this.pagination.total = data.total || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
handleSelectionChange(rows) { this.selectedRows = rows; },
copyText(text) {
    navigator.clipboard.writeText(text).then(() => {
        ElementPlus.ElMessage.success('已复制');
    });
},
async handleAdd() {
    if (!this.addForm.ip.trim()) {
        ElementPlus.ElMessage.error('请输入IP地址');
        return;
    }
    this.submitting = true;
    try {
        const res = await fetch('api_security.php?action=whitelist_add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.addForm)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showAddDialog = false;
            this.addForm = { ip: '', software_id: 0, remark: '' };
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('请求失败'); }
    this.submitting = false;
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除此IP白名单？', '删除确认', { type: 'warning' });
        const res = await fetch('api_security.php?action=whitelist_delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('删除成功');
            this.loadData();
        }
    } catch (e) {}
},
async handleBatchDelete() {
    if (this.selectedRows.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除选中的 ' + this.selectedRows.length + ' 条记录？', '批量删除', { type: 'warning' });
        const ids = this.selectedRows.map(r => r.id);
        const res = await fetch('api_security.php?action=whitelist_batch_delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('批量删除成功');
            this.loadData();
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
