<?php
$pageTitle = 'IP黑名单';
$breadcrumbs = ['安全中心', 'IP黑名单'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 140px;" @change="loadData">
            <el-option label="全局" :value="0"></el-option>
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索IP/原因" clearable style="width: 200px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <div style="display: flex; gap: 10px;">
        <el-button type="success" :disabled="selectedRows.length === 0" @click="handleBatchDelete">批量解封</el-button>
        <el-button type="danger" @click="showAddDialog = true"><el-icon><Plus /></el-icon>添加黑名单</el-button>
    </div>
</div>

<el-card shadow="hover">
    <div class="tip-box" style="margin-bottom: 16px; padding: 12px; background: #fef0f0; border-radius: 4px; color: #f56c6c; font-size: 13px;">
        <el-icon><WarningFilled /></el-icon>
        IP黑名单中的IP将被禁止登录和激活。支持通配符（如 192.168.*.*）和CIDR格式（如 192.168.1.0/24）。白名单优先级高于黑名单。
    </div>
    
    <el-table :data="dataList" v-loading="loading" @selection-change="handleSelectionChange" stripe table-layout="auto">
        <el-table-column type="selection" width="40" align="center"></el-table-column>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="ip" label="IP地址" min-width="140" align="center">
            <template #default="scope">
                <span style="font-family: monospace; color: #f56c6c;">{{ scope.row.ip }}</span>
                <el-button link type="primary" size="small" @click="copyText(scope.row.ip)">
                    <el-icon><CopyDocument /></el-icon>
                </el-button>
            </template>
        </el-table-column>
        <el-table-column label="适用软件" min-width="100" align="center">
            <template #default="scope">
                <el-tag v-if="scope.row.software_id == 0" type="danger" size="small">全局</el-tag>
                <span v-else>{{ scope.row.software_name || '-' }}</span>
            </template>
        </el-table-column>
        <el-table-column prop="reason" label="封禁原因" min-width="150" align="center">
            <template #default="scope">
                <span>{{ scope.row.reason || '-' }}</span>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="添加时间" min-width="160" align="center"></el-table-column>
        <el-table-column label="操作" width="100" fixed="right" align="center">
            <template #default="scope">
                <el-button type="success" size="small" @click="handleDelete(scope.row)">解封</el-button>
            </template>
        </el-table-column>
    </el-table>
    
    <div class="pagination-container" style="justify-content: flex-end;">
        <el-pagination
            v-model:current-page="pagination.page"
            v-model:page-size="pagination.pageSize"
            :page-sizes="[20, 50, 100]"
            :total="pagination.total"
            layout="total, sizes, prev, pager, next"
            @size-change="loadData"
            @current-change="loadData"
        />
    </div>
</el-card>

<!-- 添加对话框 -->
<el-dialog v-model="showAddDialog" title="添加IP黑名单" width="500px">
    <el-form :model="addForm" label-width="100px">
        <el-form-item label="IP地址" required>
            <el-input v-model="addForm.ip" type="textarea" :rows="4" placeholder="每行一个IP，支持通配符（192.168.*.*）和CIDR（192.168.1.0/24）"></el-input>
        </el-form-item>
        <el-form-item label="适用软件">
            <el-select v-model="addForm.software_id" style="width: 100%;">
                <el-option label="全局（所有软件）" :value="0"></el-option>
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="封禁原因">
            <el-input v-model="addForm.reason" placeholder="可选，如：恶意攻击"></el-input>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showAddDialog = false">取消</el-button>
        <el-button type="danger" @click="handleAdd" :loading="submitting">添加黑名单</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
dataList: [],
softwareList: [],
loading: false,
submitting: false,
showAddDialog: false,
selectedRows: [],
searchForm: { software_id: '', keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 },
addForm: { ip: '', software_id: 0, reason: '' }
";

$vueMounted = "
this.loadData();
this.loadSoftware();
";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'blacklist_list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            ...this.searchForm
        });
        const res = await fetch('api_security.php?' + params);
        const data = await res.json();
        if (data.code === 0) {
            this.dataList = data.data;
            this.pagination.total = data.total || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
handleSelectionChange(rows) { this.selectedRows = rows; },
copyText(text) {
    navigator.clipboard.writeText(text).then(() => {
        ElementPlus.ElMessage.success('已复制');
    });
},
async handleAdd() {
    if (!this.addForm.ip.trim()) {
        ElementPlus.ElMessage.error('请输入IP地址');
        return;
    }
    this.submitting = true;
    try {
        const res = await fetch('api_security.php?action=blacklist_add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.addForm)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showAddDialog = false;
            this.addForm = { ip: '', software_id: 0, reason: '' };
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('请求失败'); }
    this.submitting = false;
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定解封此IP？', '解封确认', { type: 'warning' });
        const res = await fetch('api_security.php?action=blacklist_delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('解封成功');
            this.loadData();
        }
    } catch (e) {}
},
async handleBatchDelete() {
    if (this.selectedRows.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm('确定解封选中的 ' + this.selectedRows.length + ' 个IP？', '批量解封', { type: 'warning' });
        const ids = this.selectedRows.map(r => r.id);
        const res = await fetch('api_security.php?action=blacklist_batch_delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('批量解封成功');
            this.loadData();
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
