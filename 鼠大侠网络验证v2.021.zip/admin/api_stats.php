<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

// 检查表是否存在的辅助函数
function tableExists($db, $table) {
    try {
        $result = $db->query("SELECT 1 FROM {$table} LIMIT 1");
        return true;
    } catch (Exception $e) {
        return false;
    }
}

switch ($action) {
    case 'overview':
        $today = date('Y-m-d');
        
        // 总用户数
        $totalUsers = 0;
        try {
            $totalUsers = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        } catch (Exception $e) {}
        
        // 今日新增用户
        $todayUsers = 0;
        try {
            $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE DATE(create_time) = ?");
            $stmt->execute([$today]);
            $todayUsers = $stmt->fetchColumn();
        } catch (Exception $e) {}
        
        // 总软件数
        $totalSoftware = 0;
        try {
            $totalSoftware = $db->query("SELECT COUNT(*) FROM software")->fetchColumn();
        } catch (Exception $e) {}
        
        // 总卡密数
        $totalAuthCodes = 0;
        try {
            $totalAuthCodes = $db->query("SELECT COUNT(*) FROM auth_codes")->fetchColumn();
        } catch (Exception $e) {}
        
        // 总代理数
        $totalAgents = 0;
        try {
            $totalAgents = $db->query("SELECT COUNT(*) FROM agents")->fetchColumn();
        } catch (Exception $e) {}
        
        // 总订单数
        $totalOrders = 0;
        try {
            $totalOrders = $db->query("SELECT COUNT(*) FROM orders WHERE status = 1")->fetchColumn();
        } catch (Exception $e) {}
        
        // 总收入
        $totalIncome = 0;
        try {
            $totalIncome = $db->query("SELECT COALESCE(SUM(amount), 0) FROM orders WHERE status = 1")->fetchColumn();
        } catch (Exception $e) {}
        
        echo json_encode(['code' => 0, 'data' => [
            'totalUsers' => intval($totalUsers),
            'todayUsers' => intval($todayUsers),
            'totalSoftware' => intval($totalSoftware),
            'totalAuthCodes' => intval($totalAuthCodes),
            'totalAgents' => intval($totalAgents),
            'totalOrders' => intval($totalOrders),
            'totalIncome' => floatval($totalIncome)
        ]]);
        break;
        
    case 'trend':
        $type = $_GET['type'] ?? 'users';
        $days = intval($_GET['days'] ?? 30);
        $dates = [];
        $values = [];
        
        for ($i = $days - 1; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-{$i} days"));
            $dates[] = date('m-d', strtotime($date));
            
            try {
                switch ($type) {
                    case 'users':
                        $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE DATE(create_time) = ?");
                        $stmt->execute([$date]);
                        $values[] = intval($stmt->fetchColumn());
                        break;
                    case 'orders':
                        $stmt = $db->prepare("SELECT COUNT(*) FROM orders WHERE DATE(create_time) = ? AND status = 1");
                        $stmt->execute([$date]);
                        $values[] = intval($stmt->fetchColumn());
                        break;
                    case 'income':
                        $stmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM orders WHERE DATE(create_time) = ? AND status = 1");
                        $stmt->execute([$date]);
                        $values[] = floatval($stmt->fetchColumn());
                        break;
                }
            } catch (Exception $e) {
                $values[] = 0;
            }
        }
        
        echo json_encode(['code' => 0, 'data' => ['dates' => $dates, 'values' => $values]]);
        break;
        
    case 'software_users':
        $data = [];
        try {
            $stmt = $db->query("SELECT s.name, COUNT(u.id) as count FROM software s LEFT JOIN users u ON s.id = u.software_id GROUP BY s.id ORDER BY count DESC LIMIT 10");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {}
        echo json_encode(['code' => 0, 'data' => $data]);
        break;
        
    case 'recent_orders':
        $data = [];
        try {
            $stmt = $db->query("SELECT o.*, p.name as product_name FROM orders o LEFT JOIN products p ON o.product_id = p.id WHERE o.status = 1 ORDER BY o.id DESC LIMIT 10");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {}
        echo json_encode(['code' => 0, 'data' => $data]);
        break;
        
    case 'recent_users':
        $data = [];
        try {
            $stmt = $db->query("SELECT u.*, s.name as software_name FROM users u LEFT JOIN software s ON u.software_id = s.id ORDER BY u.id DESC LIMIT 10");
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {}
        echo json_encode(['code' => 0, 'data' => $data]);
        break;
        
    case 'user_analysis':
        // 用户地区分布 - 优化查询，直接用SQL分组统计
        $regionData = [];
        $mapData = [];
        
        try {
            // 直接用SQL分组统计，避免PHP循环
            $stmt = $db->query("SELECT ip_location, COUNT(*) as cnt FROM orders WHERE ip_location IS NOT NULL AND ip_location != '' GROUP BY ip_location");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $provinceCount = [];
            foreach ($rows as $row) {
                $location = trim($row['ip_location']);
                $cnt = intval($row['cnt']);
                if (empty($location)) continue;
                
                // 提取省份名称
                $province = '';
                if (preg_match('/^(北京|天津|上海|重庆)/u', $location, $m)) {
                    $province = $m[1];
                } elseif (preg_match('/^([^省]+)省/u', $location, $m)) {
                    $province = trim($m[1]);
                } elseif (preg_match('/^(内蒙古|广西|西藏|宁夏|新疆)/u', $location, $m)) {
                    $province = $m[1];
                } elseif (preg_match('/^(香港|澳门|台湾)/u', $location, $m)) {
                    $province = $m[1];
                }
                
                if ($province) {
                    if (!isset($provinceCount[$province])) {
                        $provinceCount[$province] = 0;
                    }
                    $provinceCount[$province] += $cnt;
                }
            }
            
            arsort($provinceCount);
            foreach ($provinceCount as $name => $count) {
                $regionData[] = ['province' => $name, 'count' => $count];
                $mapData[] = ['name' => $name, 'value' => $count];
            }
            $regionData = array_slice($regionData, 0, 10);
        } catch (Exception $e) {}
        
        echo json_encode(['code' => 0, 'data' => ['regions' => $regionData, 'devices' => [], 'map_data' => $mapData]], JSON_UNESCAPED_UNICODE);
        exit;
        
    case 'income_stats':
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-d');
        
        $dailyData = [];
        $softwareData = [];
        $total = ['orders' => 0, 'income' => 0];
        
        try {
            // 按日期统计收入
            $stmt = $db->prepare("SELECT DATE(create_time) as date, COUNT(*) as orders, COALESCE(SUM(amount), 0) as income FROM orders WHERE status = 1 AND DATE(create_time) BETWEEN ? AND ? GROUP BY DATE(create_time) ORDER BY date");
            $stmt->execute([$startDate, $endDate]);
            $dailyData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {}
        
        try {
            // 按软件统计收入
            $stmt = $db->prepare("SELECT COALESCE(s.name, '未分类') as name, COUNT(o.id) as orders, COALESCE(SUM(o.amount), 0) as income FROM orders o LEFT JOIN software s ON o.software_id = s.id WHERE o.status = 1 AND DATE(o.create_time) BETWEEN ? AND ? GROUP BY o.software_id ORDER BY income DESC");
            $stmt->execute([$startDate, $endDate]);
            $softwareData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {}
        
        try {
            // 总计
            $stmt = $db->prepare("SELECT COUNT(*) as orders, COALESCE(SUM(amount), 0) as income FROM orders WHERE status = 1 AND DATE(create_time) BETWEEN ? AND ?");
            $stmt->execute([$startDate, $endDate]);
            $total = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {}
        
        echo json_encode(['code' => 0, 'data' => ['daily' => $dailyData, 'software' => $softwareData, 'total' => $total]]);
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
