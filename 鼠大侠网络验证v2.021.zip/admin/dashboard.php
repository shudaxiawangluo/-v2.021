<?php
$pageTitle = '控制台';
$breadcrumbs = ['控制台'];

$pageStyles = <<<CSS
.stat-item { 
    padding: 16px 20px; 
    background: var(--el-bg-color-overlay); 
    border-radius: 8px; 
    border: 1px solid var(--el-border-color-lighter);
    transition: all 0.3s;
}
.stat-item:hover {
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
    transform: translateY(-2px);
}
.stat-item-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}
.stat-title { font-size: 13px; color: var(--el-text-color-secondary); font-weight: 400; }
.stat-icon {
    width: 36px; height: 36px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center; font-size: 18px;
}
.stat-value { font-size: 28px; font-weight: 600; margin-bottom: 10px; line-height: 1; color: var(--el-text-color-primary); }
.stat-footer { display: flex; align-items: center; gap: 8px; font-size: 12px; color: var(--el-text-color-secondary); }
.stat-trend { display: flex; align-items: center; gap: 4px; font-weight: 500; }
.trend-up { color: #67c23a; }
.trend-down { color: #f56c6c; }
.color-blue { color: #409eff; }
.color-green { color: #67c23a; }
.color-orange { color: #e6a23c; }
.color-red { color: #f56c6c; }
.color-purple { color: #9c27b0; }
.color-cyan { color: #00bcd4; }
.bg-blue { background-color: rgba(64, 158, 255, 0.1); }
.bg-green { background-color: rgba(103, 194, 58, 0.1); }
.bg-orange { background-color: rgba(230, 162, 60, 0.1); }
.bg-red { background-color: rgba(245, 108, 108, 0.1); }
.bg-purple { background-color: rgba(156, 39, 176, 0.1); }
.bg-cyan { background-color: rgba(0, 188, 212, 0.1); }
.card-header-title { font-size: 14px; font-weight: 500; }
.map-container { position: relative; }
.map-stats { position: absolute; right: 20px; top: 20px; background: rgba(255,255,255,0.95); border-radius: 8px; padding: 16px; min-width: 160px; box-shadow: 0 2px 12px rgba(0,0,0,0.1); }
html.dark .map-stats { background: rgba(30,30,30,0.95); }
.map-stats-title { font-size: 13px; color: var(--el-text-color-secondary); margin-bottom: 12px; }
.map-stats-item { display: flex; justify-content: space-between; align-items: center; padding: 6px 0; border-bottom: 1px solid var(--el-border-color-lighter); }
.map-stats-item:last-child { border-bottom: none; }
.map-stats-name { font-size: 13px; color: var(--el-text-color-primary); }
.map-stats-value { font-size: 14px; font-weight: 600; color: #409eff; }
CSS;

ob_start();
?>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :xs="24" :sm="12" :md="8" :lg="4">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">软件总数</span>
                <div class="stat-icon bg-blue color-blue"><el-icon><box /></el-icon></div>
            </div>
            <div class="stat-value">{{ stats.software }}</div>
            <div class="stat-footer"><span>较昨日</span><span class="stat-trend trend-up"><el-icon><top /></el-icon><span>0%</span></span></div>
        </div>
    </el-col>
    <el-col :xs="24" :sm="12" :md="8" :lg="4">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">设备总数</span>
                <div class="stat-icon bg-green color-green"><el-icon><user /></el-icon></div>
            </div>
            <div class="stat-value">{{ stats.users }}</div>
            <div class="stat-footer"><span>较上月</span><span class="stat-trend trend-up"><el-icon><top /></el-icon><span>12%</span></span></div>
        </div>
    </el-col>
    <el-col :xs="24" :sm="12" :md="8" :lg="4">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">在线设备</span>
                <div class="stat-icon bg-orange color-orange"><el-icon><connection /></el-icon></div>
            </div>
            <div class="stat-value">{{ stats.online }}</div>
            <div class="stat-footer"><span>实时数据</span><span class="stat-trend" style="color: var(--el-text-color-secondary);"><el-icon><refresh /></el-icon></span></div>
        </div>
    </el-col>
    <el-col :xs="24" :sm="12" :md="8" :lg="4">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">今日登录</span>
                <div class="stat-icon bg-red color-red"><el-icon><user-filled /></el-icon></div>
            </div>
            <div class="stat-value">{{ stats.todayLogin }}</div>
            <div class="stat-footer"><span>较昨日</span><span class="stat-trend trend-down"><el-icon><bottom /></el-icon><span>5%</span></span></div>
        </div>
    </el-col>
    <el-col :xs="24" :sm="12" :md="8" :lg="4">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">卡密总数</span>
                <div class="stat-icon bg-purple color-purple"><el-icon><key /></el-icon></div>
            </div>
            <div class="stat-value">{{ stats.authCodes }}</div>
            <div class="stat-footer"><span>全部卡密</span></div>
        </div>
    </el-col>
    <el-col :xs="24" :sm="12" :md="8" :lg="4">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">黑名单</span>
                <div class="stat-icon bg-cyan color-cyan"><el-icon><warning /></el-icon></div>
            </div>
            <div class="stat-value">{{ stats.blacklist }}</div>
            <div class="stat-footer"><span>IP封禁</span><span class="stat-trend" style="color: var(--el-text-color-secondary);"><el-icon><lock /></el-icon></span></div>
        </div>
    </el-col>
</el-row>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :span="12">
        <el-card shadow="hover" class="map-container">
            <template #header>
                <span class="card-header-title">用户地区分布</span>
            </template>
            <div ref="mapChart" style="height: 380px;"></div>
            <div class="map-stats" v-if="regionTop.length">
                <div class="map-stats-title">TOP 5 地区</div>
                <div class="map-stats-item" v-for="(item, index) in regionTop" :key="index">
                    <span class="map-stats-name">{{ item.name }}</span>
                    <span class="map-stats-value">{{ item.value }}</span>
                </div>
            </div>
        </el-card>
    </el-col>
    <el-col :span="12">
        <el-card shadow="hover">
            <template #header>
                <div style="display: flex; justify-content: space-between;">
                    <span class="card-header-title">数据趋势</span>
                    <el-radio-group v-model="trendType" size="small" @change="updateTrendChart">
                        <el-radio-button label="week">近7天</el-radio-button>
                        <el-radio-button label="month">近30天</el-radio-button>
                    </el-radio-group>
                </div>
            </template>
            <div ref="trendChart" style="height: 380px;"></div>
        </el-card>
    </el-col>
</el-row>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :span="24">
        <el-card shadow="hover">
            <template #header><span class="card-header-title">快捷操作</span></template>
            <el-space wrap>
                <el-button type="primary" @click="navigate('software_add.php')"><el-icon><circle-plus /></el-icon>添加软件</el-button>
                <el-button type="success" @click="navigate('authcode_list.php')"><el-icon><key /></el-icon>生成卡密</el-button>
                <el-button type="warning" @click="navigate('user_list.php')"><el-icon><user /></el-icon>用户管理</el-button>
                <el-button type="danger" @click="navigate('ip_blacklist.php')"><el-icon><circle-close /></el-icon>IP黑名单</el-button>
                <el-button type="info" @click="navigate('log_runtime.php')"><el-icon><document /></el-icon>运行日志</el-button>
                <el-button @click="navigate('settings.php')"><el-icon><setting /></el-icon>系统设置</el-button>
            </el-space>
        </el-card>
    </el-col>
</el-row>

<el-row :gutter="16">
    <el-col :span="12">
        <el-card shadow="hover">
            <template #header>
                <div style="display: flex; justify-content: space-between;">
                    <span class="card-header-title">最近订单</span>
                    <el-button type="primary" size="small" link @click="navigate('order_list.php')">查看更多</el-button>
                </div>
            </template>
            <el-table :data="recentOrders" size="small">
                <el-table-column prop="order_no" label="订单号" min-width="140" show-overflow-tooltip></el-table-column>
                <el-table-column prop="product_name" label="商品" min-width="80"></el-table-column>
                <el-table-column label="金额" min-width="70">
                    <template #default="scope"><span style="color: #e6a23c;">¥{{ scope.row.amount }}</span></template>
                </el-table-column>
                <el-table-column prop="create_time" label="时间" min-width="140"></el-table-column>
            </el-table>
        </el-card>
    </el-col>
    <el-col :span="12">
        <el-card shadow="hover">
            <template #header>
                <div style="display: flex; justify-content: space-between;">
                    <span class="card-header-title">最近激活设备</span>
                    <el-button type="primary" size="small" link @click="navigate('device_list.php')">查看更多</el-button>
                </div>
            </template>
            <el-table :data="recentUsers" size="small">
                <el-table-column prop="id" label="ID" width="60"></el-table-column>
                <el-table-column prop="username" label="机器码" min-width="120" show-overflow-tooltip></el-table-column>
                <el-table-column prop="nickname" label="软件" min-width="80"></el-table-column>
                <el-table-column prop="create_time" label="激活时间" min-width="140"></el-table-column>
            </el-table>
        </el-card>
    </el-col>
</el-row>

<?php
$pageContent = ob_get_clean();

$vueData = <<<JS
stats: { software: 0, users: 0, online: 0, todayLogin: 0, authCodes: 0, blacklist: 0 },
trendType: 'week',
recentOrders: [],
recentUsers: [],
mapData: [],
regionTop: [],
mapChart: null,
trendChart: null
JS;

$vueMounted = <<<JS
this.loadData();
// 加载地图
var self = this;
fetch('assets/libs/china.json')
    .then(function(res) { return res.json(); })
    .then(function(chinaJson) {
        echarts.registerMap('china', chinaJson);
        self.initCharts();
        self.loadMapData();
    })
    .catch(function(e) {
        console.error('地图加载失败', e);
        self.initCharts();
    });
JS;

$vueMethods = <<<'JS'
loadData: function() {
    var self = this;
    fetch('api_dashboard.php').then(function(res) { return res.json(); }).then(function(data) {
        self.stats = data.stats || { software: 0, users: 0, online: 0, todayLogin: 0, authCodes: 0, blacklist: 0 };
        self.recentOrders = data.recentOrders || [];
        self.recentUsers = data.recentUsers || [];
    }).catch(function(e) {
        console.error('加载数据失败:', e);
    });
},
loadMapData: function() {
    var self = this;
    fetch('api_stats.php?action=user_analysis').then(function(res) { return res.json(); }).then(function(data) {
        console.log('API返回数据:', data); // 调试
        if (data.code === 0) {
            self.mapData = data.data.map_data || [];
            console.log('mapData:', self.mapData); // 调试
            // 处理TOP 5地区显示
            var regions = data.data.regions || [];
            self.regionTop = regions.slice(0, 5).map(function(item) {
                var name = item.province || '';
                return { name: name, value: item.count };
            });
            self.renderMapChart();
        }
    }).catch(function(e) {
        console.error('加载地图数据失败:', e);
    });
},
initCharts: function() {
    this.trendChart = echarts.init(this.$refs.trendChart);
    if (this.$refs.mapChart) {
        this.mapChart = echarts.init(this.$refs.mapChart);
    }
    this.updateTrendChart();
},
renderMapChart: function() {
    if (!this.mapChart) return;
    var mapData = this.mapData || [];
    
    console.log('原始mapData:', JSON.stringify(mapData));
    
    // 省份名称映射 - 转换为ECharts地图需要的格式
    var nameMap = {
        '北京': '北京市', '天津': '天津市', '上海': '上海市', '重庆': '重庆市',
        '河北': '河北省', '山西': '山西省', '辽宁': '辽宁省', '吉林': '吉林省',
        '黑龙江': '黑龙江省', '江苏': '江苏省', '浙江': '浙江省', '安徽': '安徽省',
        '福建': '福建省', '江西': '江西省', '山东': '山东省', '河南': '河南省',
        '湖北': '湖北省', '湖南': '湖南省', '广东': '广东省', '海南': '海南省',
        '四川': '四川省', '贵州': '贵州省', '云南': '云南省', '陕西': '陕西省',
        '甘肃': '甘肃省', '青海': '青海省', '台湾': '台湾省',
        '内蒙古': '内蒙古自治区', '广西': '广西壮族自治区', '西藏': '西藏自治区', 
        '宁夏': '宁夏回族自治区', '新疆': '新疆维吾尔自治区',
        '香港': '香港特别行政区', '澳门': '澳门特别行政区'
    };
    
    // 鲜艳的颜色数组
    var brightColors = [
        '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
        '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
        '#F8B500', '#00CED1', '#FF7F50', '#9370DB', '#20B2AA',
        '#FF69B4', '#00FA9A', '#FFD700', '#1E90FF', '#FF4500'
    ];
    
    var processedData = [];
    var colorIndex = 0;
    
    // 处理数据
    if (mapData && mapData.length > 0) {
        mapData.forEach(function(item) {
            if (item && item.value > 0) {
                var mappedName = nameMap[item.name] || item.name;
                var color = brightColors[colorIndex % brightColors.length];
                colorIndex++;
                processedData.push({
                    name: mappedName,
                    value: item.value,
                    itemStyle: { 
                        areaColor: color,
                        borderColor: '#fff',
                        borderWidth: 1
                    }
                });
            }
        });
    }
    
    console.log('处理后数据:', JSON.stringify(processedData));
    
    this.mapChart.setOption({
        tooltip: { 
            trigger: 'item',
            backgroundColor: 'rgba(255,255,255,0.95)',
            borderColor: '#eee',
            borderWidth: 1,
            textStyle: { color: '#333' },
            formatter: function(params) { 
                if (params.value) {
                    return '<b>' + params.name + '</b><br/>订单数: ' + params.value + ' 单'; 
                }
                return params.name;
            } 
        },
        series: [{
            name: '订单分布',
            type: 'map',
            map: 'china',
            roam: true,
            zoom: 1.1,
            center: [104, 37],
            scaleLimit: { min: 1, max: 5 },
            selectedMode: false,
            label: { show: false },
            emphasis: { 
                disabled: false,
                label: { show: true, fontSize: 12, color: '#333' }, 
                itemStyle: { 
                    areaColor: '#FFE082',
                    borderColor: '#FFA000',
                    borderWidth: 1
                } 
            },
            itemStyle: { 
                areaColor: '#f3f3f3', 
                borderColor: '#ddd', 
                borderWidth: 0.5 
            },
            data: processedData
        }]
    }, true);
},
updateTrendChart: function() {
    var self = this;
    var days = this.trendType === 'week' ? 7 : 30;
    // 改成获取订单数据
    fetch('api_dashboard.php?action=order_trend&days=' + days).then(function(res) { return res.json(); }).then(function(data) {
        if (data.code === 0 && self.trendChart) {
            var dates = data.data.dates || [];
            var orders = data.data.orders || [];
            var income = data.data.income || [];
            
            self.trendChart.setOption({
                tooltip: { trigger: 'axis', axisPointer: { type: 'cross' } },
                legend: { data: ['订单数', '收入(元)'], bottom: 10 },
                grid: { left: 50, right: 50, bottom: 60, top: 30 },
                xAxis: { 
                    type: 'category', 
                    data: dates, 
                    boundaryGap: false, 
                    axisLine: { lineStyle: { color: '#ddd' } }, 
                    axisLabel: { fontSize: 11, color: '#666' }, 
                    axisTick: { show: false } 
                },
                yAxis: [
                    { 
                        type: 'value', 
                        name: '订单',
                        axisLine: { show: false }, 
                        axisTick: { show: false }, 
                        axisLabel: { fontSize: 11, color: '#666' }, 
                        splitLine: { lineStyle: { color: '#f0f0f0', type: 'dashed' } },
                        min: 0
                    },
                    { 
                        type: 'value', 
                        name: '收入',
                        axisLine: { show: false }, 
                        axisTick: { show: false }, 
                        axisLabel: { fontSize: 11, color: '#666' }, 
                        splitLine: { show: false },
                        min: 0
                    }
                ],
                series: [
                    { 
                        name: '订单数', 
                        type: 'line', 
                        smooth: true, 
                        data: orders, 
                        itemStyle: { color: '#409eff' }, 
                        lineStyle: { width: 1, color: '#409eff' }, 
                        symbol: 'circle', 
                        symbolSize: 4,
                        showSymbol: true,
                        areaStyle: { 
                            color: { 
                                type: 'linear', x: 0, y: 0, x2: 0, y2: 1, 
                                colorStops: [
                                    { offset: 0, color: 'rgba(64, 158, 255, 0.2)' }, 
                                    { offset: 1, color: 'rgba(64, 158, 255, 0.02)' }
                                ] 
                            } 
                        } 
                    },
                    { 
                        name: '收入(元)', 
                        type: 'line', 
                        yAxisIndex: 1,
                        smooth: true, 
                        data: income, 
                        itemStyle: { color: '#e6a23c' }, 
                        lineStyle: { width: 1, color: '#e6a23c' }, 
                        symbol: 'circle', 
                        symbolSize: 4,
                        showSymbol: true,
                        areaStyle: { 
                            color: { 
                                type: 'linear', x: 0, y: 0, x2: 0, y2: 1, 
                                colorStops: [
                                    { offset: 0, color: 'rgba(230, 162, 60, 0.2)' }, 
                                    { offset: 1, color: 'rgba(230, 162, 60, 0.02)' }
                                ] 
                            } 
                        } 
                    }
                ]
            });
        }
    }).catch(function(e) { console.error('趋势图加载失败:', e); });
},
navigate: function(page) {
    window.location.href = page;
}
JS;

include 'layout.php';
?>
