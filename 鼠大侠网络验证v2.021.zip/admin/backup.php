<?php
$pageTitle = '数据备份';
$breadcrumbs = ['工具箱', '数据备份'];

ob_start();
?>

<?php
$pageTitle = '数据备份';
$breadcrumbs = ['工具箱', '数据备份'];

ob_start();
?>

<el-card shadow="hover" style="margin-bottom: 16px;">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <div>
            <span style="font-size: 14px; color: #606266;">点击右侧按钮立即备份数据库，备份文件为SQL格式，包含所有数据表结构和数据</span>
        </div>
        <el-button type="primary" @click="handleBackup" :loading="backupLoading">立即备份</el-button>
    </div>
</el-card>

<el-card shadow="hover">
    <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-weight: 500;">备份历史</span>
            <el-button type="danger" size="small" plain @click="handleClearBackups" :disabled="backupList.length === 0">清理全部</el-button>
        </div>
    </template>
    <el-table :data="backupList" v-loading="loading" stripe>
        <el-table-column prop="filename" label="文件名" min-width="280"></el-table-column>
        <el-table-column prop="size" label="大小" width="120" align="center">
            <template #default="scope">{{ formatSize(scope.row.size) }}</template>
        </el-table-column>
        <el-table-column prop="time" label="备份时间" width="180" align="center"></el-table-column>
        <el-table-column label="操作" width="150" align="center">
            <template #default="scope">
                <el-button type="primary" size="small" @click="handleDownload(scope.row)">下载</el-button>
                <el-button type="danger" size="small" plain @click="handleDeleteBackup(scope.row)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
    <el-empty v-if="!loading && backupList.length === 0" description="暂无备份记录"></el-empty>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
backupList: [],
loading: false,
backupLoading: false
";

$vueMounted = "
this.loadBackups();
";

$vueMethods = "
async loadBackups() {
    this.loading = true;
    try {
        const res = await fetch('api_backup.php?action=list');
        const data = await res.json();
        if (data.code === 0) {
            this.backupList = data.data || [];
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
async handleBackup() {
    this.backupLoading = true;
    try {
        const res = await fetch('api_backup.php?action=backup', { method: 'POST' });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('备份成功');
            this.loadBackups();
            // 自动下载
            window.open('api_backup.php?action=download&file=' + encodeURIComponent(data.data.filename));
        } else {
            ElementPlus.ElMessage.error(data.msg || '备份失败');
        }
    } catch (e) { ElementPlus.ElMessage.error('备份失败'); }
    this.backupLoading = false;
},
handleDownload(row) {
    window.open('api_backup.php?action=download&file=' + encodeURIComponent(row.filename));
},
async handleDeleteBackup(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除此备份文件？', '删除确认', { type: 'warning' });
        const res = await fetch('api_backup.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename: row.filename })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('删除成功');
            this.loadBackups();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleClearBackups() {
    try {
        await ElementPlus.ElMessageBox.confirm('确定清理所有备份文件？', '清理确认', { type: 'warning' });
        const res = await fetch('api_backup.php?action=clear', { method: 'POST' });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadBackups();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
}
";

include 'layout.php';
?>
