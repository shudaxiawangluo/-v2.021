<?php
$pageTitle = '远程开关';
$breadcrumbs = ['云控制', '远程开关'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 160px;" @change="loadData">
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
    </div>
    <el-button type="primary" @click="handleAdd"><el-icon><Plus /></el-icon>添加开关</el-button>
</div>

<el-alert type="info" :closable="false" style="margin-bottom: 16px;">
    远程开关可用于控制软件功能的启用/禁用，如：一键禁用某个功能模块、紧急关闭软件等。
</el-alert>

<el-card shadow="hover">
    <el-table :data="switchList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="software_name" label="软件" width="120"></el-table-column>
        <el-table-column prop="switch_key" label="开关标识" width="150">
            <template #default="scope">
                <code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;">{{ scope.row.switch_key }}</code>
            </template>
        </el-table-column>
        <el-table-column prop="switch_name" label="开关名称" min-width="150"></el-table-column>
        <el-table-column label="状态" width="120" align="center">
            <template #default="scope">
                <el-switch v-model="scope.row.switch_value" :active-value="1" :inactive-value="0" @change="handleToggle(scope.row)"></el-switch>
            </template>
        </el-table-column>
        <el-table-column prop="description" label="描述" min-width="200">
            <template #default="scope">{{ scope.row.description || '-' }}</template>
        </el-table-column>
        <el-table-column prop="create_time" label="创建时间" width="160"></el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
            <template #default="scope">
                <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
                <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
</el-card>

<!-- 添加/编辑开关对话框 -->
<el-dialog v-model="showDialog" :title="editForm.id ? '编辑开关' : '添加开关'" width="500px">
    <el-form :model="editForm" label-width="100px">
        <el-form-item label="所属软件" required>
            <el-select v-model="editForm.software_id" placeholder="选择软件" style="width: 100%;">
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="开关标识" required>
            <el-input v-model="editForm.switch_key" placeholder="如：feature_xxx" :disabled="!!editForm.id"></el-input>
            <div style="font-size: 12px; color: #909399; margin-top: 4px;">用于程序中获取开关状态</div>
        </el-form-item>
        <el-form-item label="开关名称">
            <el-input v-model="editForm.switch_name" placeholder="如：XX功能开关"></el-input>
        </el-form-item>
        <el-form-item label="描述">
            <el-input v-model="editForm.description" type="textarea" :rows="2" placeholder="开关用途说明"></el-input>
        </el-form-item>
        <el-form-item label="默认状态">
            <el-switch v-model="editForm.switch_value" active-text="启用" inactive-text="禁用"></el-switch>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSave" :loading="saving">保存</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
switchList: [],
softwareList: [],
loading: false,
saving: false,
showDialog: false,
searchForm: { software_id: '' },
editForm: { id: '', software_id: '', switch_key: '', switch_name: '', description: '', switch_value: true }
";

$vueMounted = "this.loadData(); this.loadSoftware();";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({ action: 'switch_list', ...this.searchForm });
        const res = await fetch('api_remote.php?' + params);
        const data = await res.json();
        if (data.code === 0) this.switchList = data.data;
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
handleAdd() {
    this.editForm = { id: '', software_id: '', switch_key: '', switch_name: '', description: '', switch_value: true };
    this.showDialog = true;
},
handleEdit(row) {
    this.editForm = { ...row, switch_value: row.switch_value == 1 };
    this.showDialog = true;
},
async handleToggle(row) {
    try {
        const res = await fetch('api_remote.php?action=toggle_switch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id, switch_value: row.switch_value })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(row.switch_value ? '已启用' : '已禁用');
        } else {
            row.switch_value = row.switch_value ? 0 : 1;
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {
        row.switch_value = row.switch_value ? 0 : 1;
    }
},
async handleSave() {
    if (!this.editForm.software_id || !this.editForm.switch_key) {
        ElementPlus.ElMessage.error('请填写必填项');
        return;
    }
    this.saving = true;
    try {
        const postData = { ...this.editForm, switch_value: this.editForm.switch_value ? 1 : 0 };
        const res = await fetch('api_remote.php?action=' + (this.editForm.id ? 'update_switch' : 'add_switch'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(postData)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('请求失败'); }
    this.saving = false;
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除该开关吗？', '删除确认', { type: 'warning' });
        const res = await fetch('api_remote.php?action=delete_switch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
