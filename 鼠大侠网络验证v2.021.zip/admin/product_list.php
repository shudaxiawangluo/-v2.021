<?php
$pageTitle = '商品管理';
$breadcrumbs = ['订单管理', '商品管理'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 140px;" @change="loadData">
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-select v-model="searchForm.status" placeholder="状态" clearable style="width: 100px;" @change="loadData">
            <el-option label="上架" :value="1"></el-option>
            <el-option label="下架" :value="0"></el-option>
        </el-select>
    </div>
    <div style="display: flex; gap: 10px; align-items: center;">
        <el-button type="danger" :disabled="selectedRows.length === 0" @click="handleBatchDelete">删除选中</el-button>
        <el-button type="danger" plain @click="handleDeleteAll">删除全部</el-button>
        <el-button type="primary" @click="handleAdd"><el-icon><Plus /></el-icon>添加商品</el-button>
    </div>
</div>

<el-card shadow="hover">
    <el-table :data="productList" v-loading="loading" stripe @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="40" align="center"></el-table-column>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="software_name" label="所属软件" min-width="100"></el-table-column>
        <el-table-column prop="name" label="商品名称" min-width="120"></el-table-column>
        <el-table-column label="类型" min-width="70" align="center">
            <template #default="scope">
                <el-tag size="small" :type="scope.row.is_point_card == 1 ? 'warning' : 'primary'">
                    {{ scope.row.is_point_card == 1 ? '点卡' : getCardTypeName(scope.row.card_type) }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="库存" min-width="70" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.stock > 0 ? 'success' : 'danger'" size="small">
                    {{ scope.row.stock || 0 }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="售价" min-width="80" align="right">
            <template #default="scope">
                <span style="color: #e6a23c; font-weight: 500;">¥{{ scope.row.price }}</span>
            </template>
        </el-table-column>
        <el-table-column label="原价" min-width="80" align="right">
            <template #default="scope">
                <span style="color: #909399; text-decoration: line-through;" v-if="scope.row.original_price > 0">¥{{ scope.row.original_price }}</span>
                <span v-else>-</span>
            </template>
        </el-table-column>
        <el-table-column label="代理价" min-width="80" align="right">
            <template #default="scope">
                <span style="color: #67c23a;">¥{{ scope.row.agent_price }}</span>
            </template>
        </el-table-column>
        <el-table-column prop="sales" label="销量" min-width="60" align="center"></el-table-column>
        <el-table-column label="状态" min-width="70" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.status == 1 ? 'success' : 'info'" size="small">
                    {{ scope.row.status == 1 ? '上架' : '下架' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="sort_order" label="排序" min-width="60" align="center"></el-table-column>
        <el-table-column label="操作" width="200" fixed="right" align="center">
            <template #default="scope">
                <div style="display: flex; gap: 4px; justify-content: center;">
                    <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
                    <el-button :type="scope.row.status == 1 ? 'warning' : 'success'" size="small" @click="handleToggle(scope.row)">
                        {{ scope.row.status == 1 ? '下架' : '上架' }}
                    </el-button>
                    <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
                </div>
            </template>
        </el-table-column>
    </el-table>
</el-card>

<!-- 添加/编辑商品对话框 -->
<el-dialog v-model="showDialog" :title="editForm.id ? '编辑商品' : '添加商品'" width="650px" :close-on-click-modal="false">
    <el-form :model="editForm" label-width="100px">
        <el-form-item label="所属软件" required>
            <el-select v-model="editForm.software_id" placeholder="选择软件" style="width: 100%;" @change="onSoftwareChange">
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="商品名称" required>
            <el-input v-model="editForm.name" placeholder="如：月卡套餐"></el-input>
        </el-form-item>
        
        <!-- 选择卡密 -->
        <el-form-item label="关联卡密" required>
            <div style="width: 100%;">
                <div style="display: flex; gap: 10px; margin-bottom: 10px; align-items: center;">
                    <el-button type="primary" size="small" @click="showSelectCodeDialog" :disabled="!editForm.software_id">
                        <el-icon><Plus /></el-icon>选择卡密
                    </el-button>
                    <span style="color: #909399; font-size: 13px;">
                        已选择 <b style="color: #409eff;">{{ editForm.selectedCodes.length }}</b> 张卡密（即库存数量）
                    </span>
                </div>
                <el-alert v-if="!editForm.software_id" type="info" :closable="false" show-icon>
                    <template #title>请先选择所属软件</template>
                </el-alert>
                <el-alert v-else-if="editForm.selectedCodes.length === 0" type="warning" :closable="false" show-icon>
                    <template #title>请选择要关联的卡密，卡密数量即为商品库存</template>
                </el-alert>
                <el-alert v-else type="success" :closable="false" show-icon>
                    <template #title>已选择 {{ editForm.selectedCodes.length }} 张卡密</template>
                </el-alert>
            </div>
        </el-form-item>
        
        <el-form-item label="售价" required>
            <el-input-number v-model="editForm.price" :min="0" :precision="2" style="width: 150px;"></el-input-number>
            <span style="margin-left: 8px; color: #909399;">元（0元为免费商品）</span>
        </el-form-item>
        <el-form-item label="原价">
            <el-input-number v-model="editForm.original_price" :min="0" :precision="2" style="width: 150px;"></el-input-number>
            <span style="margin-left: 8px; color: #909399;">用于显示划线价</span>
        </el-form-item>
        <el-form-item label="代理价">
            <el-input-number v-model="editForm.agent_price" :min="0" :precision="2" style="width: 150px;"></el-input-number>
            <span style="margin-left: 8px; color: #909399;">代理商进货价</span>
        </el-form-item>
        <el-form-item label="商品描述">
            <el-input v-model="editForm.description" type="textarea" :rows="2" placeholder="商品描述信息"></el-input>
        </el-form-item>
        <el-form-item label="排序">
            <el-input-number v-model="editForm.sort_order" :min="0" style="width: 150px;"></el-input-number>
            <span style="margin-left: 8px; color: #909399;">数字越大越靠前</span>
        </el-form-item>
        <el-form-item label="状态">
            <el-switch v-model="editForm.statusBool" active-text="上架" inactive-text="下架"></el-switch>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSave" :loading="saving">保存</el-button>
    </template>
</el-dialog>

<!-- 选择卡密对话框 -->
<el-dialog v-model="showCodeDialog" title="选择卡密" width="850px" :close-on-click-modal="false">
    <div style="margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center;">
        <div style="display: flex; gap: 10px; align-items: center;">
            <el-button type="primary" size="small" @click="selectAllCodes">全选当前页</el-button>
            <el-button type="success" size="small" @click="selectAllAvailableCodes">全选所有</el-button>
            <el-button size="small" @click="clearSelectedCodes">清空选择</el-button>
            <span style="color: #606266; font-size: 13px;">
                可用: <b style="color: #409eff;">{{ availableCodes.length }}</b> 张，
                已选: <b style="color: #67c23a;">{{ tempSelectedCodes.length }}</b> 张
            </span>
        </div>
        <el-input v-model="codeSearchKeyword" placeholder="搜索卡密" clearable style="width: 200px;" size="small" @input="codePagination.page = 1">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
    </div>
    
    <el-table :data="filteredAvailableCodes" height="350" @selection-change="onCodeSelectionChange" ref="codeTable" v-loading="loadingCodes">
        <el-table-column type="selection" width="45" align="center"></el-table-column>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="code" label="卡密" min-width="220">
            <template #default="scope">
                <span style="font-family: monospace; font-size: 12px; color: #409eff;">{{ scope.row.code }}</span>
            </template>
        </el-table-column>
        <el-table-column label="类型" min-width="80" align="center">
            <template #default="scope">
                <el-tag size="small" :type="scope.row.is_point_card == 1 ? 'warning' : 'primary'">
                    {{ scope.row.is_point_card == 1 ? '点卡' : getCardTypeName(scope.row.card_type) }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="有效期/点数" min-width="100" align="center">
            <template #default="scope">
                <span v-if="scope.row.is_point_card == 1">{{ scope.row.total_points }}点</span>
                <span v-else>{{ formatDuration(scope.row) }}</span>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="创建时间" min-width="150" align="center"></el-table-column>
    </el-table>
    
    <div style="margin-top: 12px; display: flex; justify-content: center;">
        <el-pagination
            v-model:current-page="codePagination.page"
            :page-size="codePagination.pageSize"
            :total="codePagination.total"
            layout="prev, pager, next, jumper"
            @current-change="onCodePageChange"
        />
    </div>
    
    <template #footer>
        <el-button @click="showCodeDialog = false">取消</el-button>
        <el-button type="primary" @click="confirmSelectCodes">确定选择 ({{ tempSelectedCodes.length }}张)</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = <<<'VUEDATA'
productList: [],
softwareList: [],
selectedRows: [],
loading: false,
saving: false,
showDialog: false,
showCodeDialog: false,
loadingCodes: false,
availableCodes: [],
tempSelectedCodes: [],
codeSearchKeyword: '',
codePagination: { page: 1, pageSize: 10, total: 0 },
searchForm: { software_id: '', status: '' },
editForm: {
    id: '',
    software_id: '',
    name: '',
    selectedCodes: [],
    price: 0,
    original_price: 0,
    agent_price: 0,
    description: '',
    sort_order: 0,
    statusBool: true
}
VUEDATA;

$vueComputed = <<<'VUECOMPUTED'
filteredAvailableCodes() {
    var self = this;
    var list = this.availableCodes;
    if (this.codeSearchKeyword) {
        var kw = this.codeSearchKeyword.toLowerCase();
        list = list.filter(function(c) { 
            return c.code.toLowerCase().indexOf(kw) >= 0; 
        });
    }
    // 更新总数
    this.codePagination.total = list.length;
    // 分页
    var start = (this.codePagination.page - 1) * this.codePagination.pageSize;
    var end = start + this.codePagination.pageSize;
    return list.slice(start, end);
}
VUECOMPUTED;

$vueMounted = <<<'VUEMOUNTED'
this.loadData();
this.loadSoftware();
VUEMOUNTED;

$vueMethods = <<<'VUEMETHODS'
handleSelectionChange(rows) {
    this.selectedRows = rows;
},
async handleBatchDelete() {
    if (this.selectedRows.length === 0) return;
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除选中的 ' + this.selectedRows.length + ' 个商品吗？关联的卡密将被释放。', '批量删除', { type: 'warning' });
        var ids = [];
        for (var i = 0; i < this.selectedRows.length; i++) {
            ids.push(this.selectedRows[i].id);
        }
        var res = await fetch('api_product.php?action=batchDelete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ids: ids })
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.selectedRows = [];
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleDeleteAll() {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除全部商品吗？关联的卡密将被释放，此操作不可撤销！', '删除全部', { confirmButtonText: '确定删除', cancelButtonText: '取消', type: 'error' });
        var res = await fetch('api_product.php?action=deleteAll', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.selectedRows = [];
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async loadData() {
    this.loading = true;
    try {
        var params = new URLSearchParams();
        params.append('action', 'list');
        if (this.searchForm.software_id) params.append('software_id', this.searchForm.software_id);
        if (this.searchForm.status !== '') params.append('status', this.searchForm.status);
        var res = await fetch('api_product.php?' + params.toString());
        var data = await res.json();
        if (data.code === 0) this.productList = data.data;
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        var res = await fetch('api_software.php?action=list');
        var data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
getCardTypeName(type) {
    var names = { minute: '分钟卡', hour: '小时卡', day: '天卡', week: '周卡', month: '月卡', quarter: '季卡', year: '年卡', permanent: '永久' };
    return names[type] || type;
},
formatDuration(row) {
    var type = row.card_type;
    var minutes = parseInt(row.minutes) || 0;
    var days = parseInt(row.days) || 0;
    if (type === 'permanent') return '永久';
    
    // 根据card_type决定显示单位
    switch (type) {
        case 'minute':
            if (minutes > 0) return minutes + '分钟';
            return (days * 1440) + '分钟';
        case 'hour':
            if (minutes > 0) return Math.round(minutes / 60) + '小时';
            return (days * 24) + '小时';
        case 'day':
            if (minutes > 0) return Math.round(minutes / 1440) + '天';
            return days + '天';
        case 'week':
            var weeks = minutes > 0 ? Math.round(minutes / 1440 / 7) : Math.round(days / 7);
            return (weeks || 1) + '周';
        case 'month':
            var months = minutes > 0 ? Math.round(minutes / 1440 / 30) : Math.round(days / 30);
            return (months || 1) + '个月';
        case 'quarter':
            var quarters = minutes > 0 ? Math.round(minutes / 1440 / 90) : Math.round(days / 90);
            return (quarters || 1) + '季度';
        case 'year':
            var years = minutes > 0 ? Math.round(minutes / 1440 / 365) : Math.round(days / 365);
            return (years || 1) + '年';
        default:
            if (minutes > 0) return Math.round(minutes / 1440) + '天';
            return days + '天';
    }
},
handleAdd() {
    this.editForm = { 
        id: '', 
        software_id: '', 
        name: '', 
        selectedCodes: [], 
        price: 0, 
        original_price: 0, 
        agent_price: 0, 
        description: '', 
        sort_order: 0, 
        statusBool: true 
    };
    this.showDialog = true;
},
async handleEdit(row) {
    var selectedCodes = [];
    try {
        var res = await fetch('api_product.php?action=getProductCodes&product_id=' + row.id);
        var data = await res.json();
        if (data.code === 0) {
            for (var i = 0; i < data.data.length; i++) {
                selectedCodes.push(data.data[i].id);
            }
        }
    } catch (e) {}
    this.editForm = { 
        id: row.id, 
        software_id: row.software_id, 
        name: row.name, 
        selectedCodes: selectedCodes, 
        price: parseFloat(row.price) || 0, 
        original_price: parseFloat(row.original_price) || 0, 
        agent_price: parseFloat(row.agent_price) || 0, 
        description: row.description || '', 
        sort_order: parseInt(row.sort_order) || 0, 
        statusBool: row.status == 1 
    };
    this.showDialog = true;
},
onSoftwareChange() {
    this.editForm.selectedCodes = [];
},
async showSelectCodeDialog() {
    var self = this;
    if (!this.editForm.software_id) {
        ElementPlus.ElMessage.warning('请先选择软件');
        return;
    }
    this.loadingCodes = true;
    this.showCodeDialog = true;
    this.codeSearchKeyword = '';
    this.codePagination.page = 1;
    
    try {
        var res = await fetch('api_product.php?action=getAvailableCodes&software_id=' + this.editForm.software_id + '&product_id=' + (this.editForm.id || 0));
        var data = await res.json();
        if (data.code === 0) {
            self.availableCodes = data.data;
            self.tempSelectedCodes = self.editForm.selectedCodes.slice();
            self.codePagination.total = data.data.length;
            // 延迟设置选中状态
            self.$nextTick(function() {
                self.restoreCodeSelection();
            });
        }
    } catch (e) { console.error(e); }
    this.loadingCodes = false;
},
restoreCodeSelection() {
    var self = this;
    if (self.$refs.codeTable && self.tempSelectedCodes.length > 0) {
        self.filteredAvailableCodes.forEach(function(row) {
            if (self.tempSelectedCodes.indexOf(row.id) >= 0) {
                self.$refs.codeTable.toggleRowSelection(row, true);
            }
        });
    }
},
onCodePageChange() {
    var self = this;
    self.$nextTick(function() {
        self.restoreCodeSelection();
    });
},
onCodeSelectionChange(rows) {
    var self = this;
    // 获取当前页选中的ID
    var currentPageIds = [];
    for (var i = 0; i < rows.length; i++) {
        currentPageIds.push(rows[i].id);
    }
    // 获取当前页所有ID
    var currentPageAllIds = [];
    for (var i = 0; i < self.filteredAvailableCodes.length; i++) {
        currentPageAllIds.push(self.filteredAvailableCodes[i].id);
    }
    // 移除当前页的所有ID，然后添加当前页选中的ID
    var newSelected = self.tempSelectedCodes.filter(function(id) {
        return currentPageAllIds.indexOf(id) < 0;
    });
    for (var i = 0; i < currentPageIds.length; i++) {
        if (newSelected.indexOf(currentPageIds[i]) < 0) {
            newSelected.push(currentPageIds[i]);
        }
    }
    self.tempSelectedCodes = newSelected;
},
selectAllCodes() {
    var self = this;
    // 全选当前页
    if (this.$refs.codeTable) {
        this.filteredAvailableCodes.forEach(function(row) {
            self.$refs.codeTable.toggleRowSelection(row, true);
            if (self.tempSelectedCodes.indexOf(row.id) < 0) {
                self.tempSelectedCodes.push(row.id);
            }
        });
    }
},
selectAllAvailableCodes() {
    var self = this;
    // 全选所有可用卡密
    self.tempSelectedCodes = [];
    for (var i = 0; i < self.availableCodes.length; i++) {
        self.tempSelectedCodes.push(self.availableCodes[i].id);
    }
    self.$nextTick(function() {
        self.restoreCodeSelection();
    });
    ElementPlus.ElMessage.success('已全选 ' + self.tempSelectedCodes.length + ' 张卡密');
},
clearSelectedCodes() {
    if (this.$refs.codeTable) {
        this.$refs.codeTable.clearSelection();
    }
    this.tempSelectedCodes = [];
},
confirmSelectCodes() {
    this.editForm.selectedCodes = this.tempSelectedCodes.slice();
    this.showCodeDialog = false;
},
async handleSave() {
    if (!this.editForm.software_id || !this.editForm.name) {
        ElementPlus.ElMessage.error('请填写必填项');
        return;
    }
    if (this.editForm.selectedCodes.length === 0) {
        ElementPlus.ElMessage.error('请选择要关联的卡密');
        return;
    }
    this.saving = true;
    try {
        var postData = { 
            id: this.editForm.id, 
            software_id: this.editForm.software_id, 
            name: this.editForm.name, 
            price: this.editForm.price, 
            original_price: this.editForm.original_price, 
            agent_price: this.editForm.agent_price, 
            description: this.editForm.description, 
            sort_order: this.editForm.sort_order, 
            status: this.editForm.statusBool ? 1 : 0, 
            code_ids: this.editForm.selectedCodes 
        };
        var action = this.editForm.id ? 'update' : 'add';
        var res = await fetch('api_product.php?action=' + action, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(postData)
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { 
        console.error(e);
        ElementPlus.ElMessage.error('请求失败'); 
    }
    this.saving = false;
},
async handleToggle(row) {
    try {
        var res = await fetch('api_product.php?action=toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id, status: row.status == 1 ? 0 : 1 })
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除该商品吗？关联的卡密将被释放。', '删除确认', { type: 'warning' });
        var res = await fetch('api_product.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
}
VUEMETHODS;

include 'layout.php';
?>
