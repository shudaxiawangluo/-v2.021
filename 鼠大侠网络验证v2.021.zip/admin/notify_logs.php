<?php
$pageTitle = '发送记录';
$breadcrumbs = ['消息通知', '发送记录'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.type" placeholder="通知类型" clearable style="width: 120px;" @change="loadData">
            <el-option label="邮件" value="email"></el-option>
            <el-option label="Telegram" value="telegram"></el-option>
            <el-option label="微信" value="wechat"></el-option>
            <el-option label="钉钉" value="dingtalk"></el-option>
        </el-select>
        <el-select v-model="searchForm.status" placeholder="状态" clearable style="width: 100px;" @change="loadData">
            <el-option label="成功" :value="1"></el-option>
            <el-option label="失败" :value="0"></el-option>
        </el-select>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
</div>

<el-card shadow="hover">
    <el-table :data="logList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="70" align="center"></el-table-column>
        <el-table-column label="类型" width="90" align="center">
            <template #default="scope">
                <el-tag size="small" :type="{email:'',telegram:'success',wechat:'warning',dingtalk:'info'}[scope.row.type]">
                    {{ {email:'邮件',telegram:'TG',wechat:'微信',dingtalk:'钉钉'}[scope.row.type] || scope.row.type }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="event" label="事件" width="120">
            <template #default="scope">
                {{ {order_paid:'订单支付',withdraw_apply:'提现申请',auth_activated:'授权激活',auth_expire:'授权到期',ip_blocked:'IP封禁'}[scope.row.event] || scope.row.event || '-' }}
            </template>
        </el-table-column>
        <el-table-column prop="title" label="主题" min-width="200"></el-table-column>
        <el-table-column label="状态" width="90" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.status == 1 ? 'success' : 'danger'" size="small">
                    {{ scope.row.status == 1 ? '成功' : '失败' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="error_msg" label="错误信息" min-width="150">
            <template #default="scope">{{ scope.row.error_msg || '-' }}</template>
        </el-table-column>
        <el-table-column prop="create_time" label="创建时间" width="160"></el-table-column>
        <el-table-column label="操作" width="100" fixed="right" align="center">
            <template #default="scope">
                <el-button type="primary" size="small" @click="handleView(scope.row)">详情</el-button>
            </template>
        </el-table-column>
    </el-table>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
        <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ pagination.total }}</b> 条</span>
        <el-pagination background layout="prev, pager, next" :total="pagination.total" :page-size="pagination.pageSize" v-model:current-page="pagination.page" @current-change="loadData"></el-pagination>
    </div>
</el-card>

<!-- 详情对话框 -->
<el-dialog v-model="showDialog" title="消息详情" width="600px">
    <el-descriptions :column="2" border>
        <el-descriptions-item label="通知类型">{{ {email:'邮件',telegram:'Telegram',wechat:'微信',dingtalk:'钉钉'}[currentLog.type] || currentLog.type }}</el-descriptions-item>
        <el-descriptions-item label="状态">
            <el-tag :type="currentLog.status == 1 ? 'success' : 'danger'" size="small">
                {{ currentLog.status == 1 ? '成功' : '失败' }}
            </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="事件">{{ {order_paid:'订单支付',withdraw_apply:'提现申请',auth_activated:'授权激活',auth_expire:'授权到期',ip_blocked:'IP封禁'}[currentLog.event] || currentLog.event || '-' }}</el-descriptions-item>
        <el-descriptions-item label="主题">{{ currentLog.title }}</el-descriptions-item>
        <el-descriptions-item label="创建时间" :span="2">{{ currentLog.create_time }}</el-descriptions-item>
    </el-descriptions>
    <div style="margin-top: 16px;">
        <div style="font-weight: 500; margin-bottom: 8px;">消息内容：</div>
        <el-input type="textarea" :model-value="currentLog.content" :rows="6" readonly></el-input>
    </div>
    <div v-if="currentLog.error_msg" style="margin-top: 16px;">
        <div style="font-weight: 500; margin-bottom: 8px; color: #f56c6c;">错误信息：</div>
        <el-input type="textarea" :model-value="currentLog.error_msg" :rows="2" readonly></el-input>
    </div>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
logList: [],
loading: false,
showDialog: false,
currentLog: {},
searchForm: { type: '', status: '' },
pagination: { page: 1, pageSize: 20, total: 0 }
";

$vueMounted = "this.loadData();";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'log_list',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            type: this.searchForm.type || '',
            status: this.searchForm.status !== '' ? this.searchForm.status : ''
        });
        const res = await fetch('api_notify.php?' + params);
        const data = await res.json();
        if (data.code === 0) {
            this.logList = data.data;
            this.pagination.total = data.total || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
handleView(row) {
    this.currentLog = row;
    this.showDialog = true;
}
";

include 'layout.php';
?>
