<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
require_once '../api/v2/lib/RSAHelper.php';
require_once '../api/v2/lib/AESHelper.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'list':
        // V2版本：尝试统计devices表，如果不存在则回退到users表
        try {
            // 检查devices表是否存在
            $tableCheck = $db->query("SHOW TABLES LIKE 'devices'");
            $devicesExists = $tableCheck->rowCount() > 0;
            
            if ($devicesExists) {
                $stmt = $db->query("SELECT s.*, 
                    (SELECT COUNT(*) FROM devices WHERE software_id = s.id) as user_count,
                    (SELECT COUNT(*) FROM devices WHERE software_id = s.id AND last_heartbeat > DATE_SUB(NOW(), INTERVAL 15 SECOND)) as online_count,
                    (SELECT COUNT(*) FROM auth_codes WHERE software_id = s.id AND status = 0) as auth_count
                    FROM software s ORDER BY s.id ASC");
            } else {
                // 回退到users表
                $stmt = $db->query("SELECT s.*, 
                    (SELECT COUNT(*) FROM users WHERE software_id = s.id) as user_count,
                    0 as online_count,
                    (SELECT COUNT(*) FROM auth_codes WHERE software_id = s.id AND status = 0) as auth_count
                    FROM software s ORDER BY s.id ASC");
            }
            $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['code' => 0, 'msg' => 'success', 'data' => $list]);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '查询失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'generate_keys':
        // 生成RSA密钥对
        try {
            $keyPair = RSAHelper::generateKeyPair();
            echo json_encode([
                'code' => 0, 
                'msg' => 'success', 
                'data' => [
                    'public_key' => $keyPair['public_key'],
                    'private_key' => $keyPair['private_key']
                ]
            ]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '密钥生成失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'add':
        $input = json_decode(file_get_contents('php://input'), true);
        
        $name = trim($input['name'] ?? '');
        
        if (empty($name)) {
            echo json_encode(['code' => 1, 'msg' => '软件名称不能为空']);
            exit;
        }
        
        $publicKey = $input['public_key'] ?? '';
        $privateKey = $input['private_key'] ?? '';
        
        if (empty($publicKey) || empty($privateKey)) {
            echo json_encode(['code' => 1, 'msg' => '请先生成RSA密钥对']);
            exit;
        }
        
        // 自动生成AppKey
        $appKey = 'SK_' . bin2hex(random_bytes(16));
        
        // AES加密私钥存储
        $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
        $aes = new AESHelper($aesKey);
        $encryptedPrivateKey = $aes->encrypt($privateKey);
        
        try {
            $stmt = $db->prepare("INSERT INTO software (
                name, app_key, status, notice,
                public_key, private_key,
                enable_trial, trial_duration, trial_unit,
                create_time
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            
            $stmt->execute([
                $name,
                $appKey,
                $input['status'] ?? 1,
                $input['notice'] ?? '',
                $publicKey,
                $encryptedPrivateKey,
                $input['enable_trial'] ? 1 : 0,
                $input['trial_duration'] ?? 30,
                $input['trial_unit'] ?? 'minute'
            ]);
            
            // 记录操作日志
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "添加软件: {$name}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '添加成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '添加失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'toggle_status':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        $status = $input['status'] ?? 0;
        
        if ($id > 0) {
            $stmt = $db->prepare("UPDATE software SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "切换软件状态ID: {$id} -> " . ($status ? '启用' : '禁用'), $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '操作成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
        }
        break;
        
    case 'get':
        $id = $_GET['id'] ?? 0;
        if ($id > 0) {
            $stmt = $db->prepare("SELECT * FROM software WHERE id = ?");
            $stmt->execute([$id]);
            $software = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($software) {
                // 不返回私钥
                unset($software['private_key']);
                echo json_encode(['code' => 0, 'msg' => 'success', 'data' => $software]);
            } else {
                echo json_encode(['code' => 1, 'msg' => '软件不存在']);
            }
        } else {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
        }
        break;
        
    case 'update':
    case 'update_settings':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        $name = trim($input['name'] ?? '');
        
        if ($id <= 0 || empty($name)) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("UPDATE software SET 
                name = ?,
                status = ?, 
                notice = ?,
                enable_trial = ?, 
                trial_duration = ?, 
                trial_unit = ?
                WHERE id = ?");
            
            $stmt->execute([
                $name,
                $input['status'] ?? 1,
                $input['notice'] ?? '',
                $input['enable_trial'] ? 1 : 0,
                $input['trial_duration'] ?? 30,
                $input['trial_unit'] ?? 'minute',
                $id
            ]);
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "修改软件ID: {$id} -> {$name}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '保存成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '保存失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'regenerate_keys':
        // 重新生成密钥
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            exit;
        }
        
        try {
            $keyPair = RSAHelper::generateKeyPair();
            
            $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
            $aes = new AESHelper($aesKey);
            $encryptedPrivateKey = $aes->encrypt($keyPair['private_key']);
            
            $stmt = $db->prepare("UPDATE software SET public_key = ?, private_key = ? WHERE id = ?");
            $stmt->execute([$keyPair['public_key'], $encryptedPrivateKey, $id]);
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "重新生成软件密钥ID: {$id}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode([
                'code' => 0, 
                'msg' => '密钥已重新生成',
                'data' => ['public_key' => $keyPair['public_key']]
            ]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '生成失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id > 0) {
            // 检查devices表是否存在
            $tableCheck = $db->query("SHOW TABLES LIKE 'devices'");
            $devicesExists = $tableCheck->rowCount() > 0;
            
            if ($devicesExists) {
                $stmt = $db->prepare("SELECT COUNT(*) FROM devices WHERE software_id = ?");
                $stmt->execute([$id]);
                $deviceCount = $stmt->fetchColumn();
                
                if ($deviceCount > 0) {
                    echo json_encode(['code' => 1, 'msg' => "该软件下还有 {$deviceCount} 个设备，无法删除"]);
                    break;
                }
            }
            
            $stmt = $db->prepare("DELETE FROM software WHERE id = ?");
            $stmt->execute([$id]);
            
            $stmt = $db->prepare("DELETE FROM auth_codes WHERE software_id = ?");
            $stmt->execute([$id]);
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "删除软件ID: {$id}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '删除成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
        }
        break;
        
    case 'batchDelete':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (empty($ids)) {
            echo json_encode(['code' => 1, 'msg' => '请选择要删除的软件']);
            break;
        }
        
        // 检查devices表是否存在
        $tableCheck = $db->query("SHOW TABLES LIKE 'devices'");
        $devicesExists = $tableCheck->rowCount() > 0;
        
        $deleted = 0;
        $skipped = 0;
        foreach ($ids as $id) {
            if ($devicesExists) {
                $stmt = $db->prepare("SELECT COUNT(*) FROM devices WHERE software_id = ?");
                $stmt->execute([$id]);
                $deviceCount = $stmt->fetchColumn();
                
                if ($deviceCount > 0) {
                    $skipped++;
                    continue;
                }
            }
            
            $stmt = $db->prepare("DELETE FROM software WHERE id = ?");
            $stmt->execute([$id]);
            
            $stmt = $db->prepare("DELETE FROM auth_codes WHERE software_id = ?");
            $stmt->execute([$id]);
            
            $deleted++;
        }
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "批量删除软件 {$deleted} 个", $_SERVER['REMOTE_ADDR']]);
        
        $msg = "成功删除 {$deleted} 个软件";
        if ($skipped > 0) {
            $msg .= "，{$skipped} 个软件因有关联设备被跳过";
        }
        echo json_encode(['code' => 0, 'msg' => $msg]);
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
