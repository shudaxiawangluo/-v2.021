<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$db = getDB();
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'stats':
        $stmt = $db->query("SELECT COUNT(*) as channels, 
                                   COALESCE(SUM(visits), 0) as total_visits,
                                   COALESCE(SUM(orders), 0) as total_orders,
                                   COALESCE(SUM(amount), 0) as total_amount
                            FROM promotion_stats");
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(['code' => 0, 'data' => $stats]);
        break;
    
    case 'list':
        $stmt = $db->query("SELECT * FROM promotion_stats ORDER BY id DESC");
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
    
    case 'save':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        $channel = trim($input['channel'] ?? '');
        $code = trim($input['code'] ?? '');
        
        if (!$channel || !$code) {
            echo json_encode(['code' => 1, 'msg' => '参数不完整']);
            break;
        }
        
        // 检查推广码是否重复
        $stmt = $db->prepare("SELECT id FROM promotion_stats WHERE code = ? AND id != ?");
        $stmt->execute([$code, $id]);
        if ($stmt->fetch()) {
            echo json_encode(['code' => 1, 'msg' => '推广码已存在']);
            break;
        }
        
        if ($id > 0) {
            $stmt = $db->prepare("UPDATE promotion_stats SET channel = ?, update_time = NOW() WHERE id = ?");
            $stmt->execute([$channel, $id]);
        } else {
            $stmt = $db->prepare("INSERT INTO promotion_stats (channel, code, visits, registers, orders, amount, create_time) VALUES (?, ?, 0, 0, 0, 0, NOW())");
            $stmt->execute([$channel, $code]);
        }
        
        echo json_encode(['code' => 0, 'msg' => '保存成功']);
        break;
    
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        $stmt = $db->prepare("DELETE FROM promotion_stats WHERE id = ?");
        $stmt->execute([$id]);
        
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
