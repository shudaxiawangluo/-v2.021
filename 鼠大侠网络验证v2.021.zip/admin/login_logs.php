<?php
$pageTitle = '登录日志';
$breadcrumbs = ['安全中心', '登录日志'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.account_type" placeholder="操作类型" clearable style="width: 120px;" @change="loadData">
            <el-option label="初始化" value="init"></el-option>
            <el-option label="激活" value="activate"></el-option>
            <el-option label="试用" value="trial"></el-option>
            <el-option label="心跳" value="heartbeat"></el-option>
            <el-option label="刷新" value="refresh"></el-option>
        </el-select>
        <el-select v-model="searchForm.success" placeholder="登录结果" clearable style="width: 120px;" @change="loadData">
            <el-option label="成功" :value="1"></el-option>
            <el-option label="失败" :value="0"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索账号/IP" clearable style="width: 180px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <el-button type="danger" @click="handleClear">清空日志</el-button>
</div>

<el-card shadow="hover">
    <el-table :data="logList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="70" align="center"></el-table-column>
        <el-table-column label="类型" width="90" align="center">
            <template #default="scope">
                <el-tag size="small" :type="{init:'info',activate:'success',trial:'warning',heartbeat:'',refresh:'primary'}[scope.row.account_type]">
                    {{ {init:'初始化',activate:'激活',trial:'试用',heartbeat:'心跳',refresh:'刷新'}[scope.row.account_type] || scope.row.account_type }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="account" label="设备指纹" min-width="150">
            <template #default="scope">
                <code v-if="scope.row.account && scope.row.account !== '-'" style="cursor: pointer;" @click="copyText(scope.row.account)">
                    {{ scope.row.account.substring(0, 16) }}...
                </code>
                <span v-else>-</span>
            </template>
        </el-table-column>
        <el-table-column prop="ip" label="IP地址" width="140"></el-table-column>
        <el-table-column label="结果" width="80" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.success ? 'success' : 'danger'" size="small">
                    {{ scope.row.success ? '成功' : '失败' }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="user_agent" label="响应信息" min-width="200">
            <template #default="scope">
                <el-tooltip :content="scope.row.user_agent" placement="top">
                    <span style="cursor: pointer;" @click="copyText(scope.row.user_agent)">{{ (scope.row.user_agent || '').substring(0, 50) }}...</span>
                </el-tooltip>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="时间" width="170"></el-table-column>
    </el-table>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #ebeef5;">
        <span style="font-size: 14px; color: #606266;">共 <b style="color: #409eff;">{{ pagination.total }}</b> 条</span>
        <el-pagination background layout="prev, pager, next" :total="pagination.total" :page-size="pagination.pageSize" v-model:current-page="pagination.page" @current-change="loadData"></el-pagination>
    </div>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
logList: [],
loading: false,
searchForm: { account_type: '', success: '', keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 }
";

$vueMounted = "this.loadData();";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'login_logs',
            page: this.pagination.page,
            pageSize: this.pagination.pageSize,
            ...this.searchForm
        });
        const res = await fetch('api_security.php?' + params);
        const data = await res.json();
        if (data.code === 0) {
            this.logList = data.data;
            this.pagination.total = data.total || 0;
        }
    } catch (e) { console.error(e); }
    this.loading = false;
},
async handleClear() {
    try {
        await ElementPlus.ElMessageBox.confirm('确定要清空所有认证日志吗？', '清空确认', { type: 'warning' });
        const res = await fetch('api_security.php?action=clear_login_logs', { method: 'POST' });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
},
copyText(text) {
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
        ElementPlus.ElMessage.success('已复制');
    });
}
";

include 'layout.php';
?>
