<?php
/**
 * V2 设备管理API
 */

session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_REQUEST['action'] ?? '';
$db = getDB();

// 自动修复数据库结构
autoFixDevicesTables($db);

switch ($action) {
    case 'list':
        getDeviceList($db);
        break;
    case 'detail':
        getDeviceDetail($db);
        break;
    case 'disable':
        disableDevice($db);
        break;
    case 'enable':
        enableDevice($db);
        break;
    case 'kick':
        kickDevice($db);
        break;
    case 'delete':
        deleteDevice($db);
        break;
    case 'online_count':
        getDeviceOnlineCount($db);
        break;
    default:
        echo json_encode(['code' => 400, 'message' => '未知操作']);
}

/**
 * 获取设备列表
 */
function getDeviceList($db) {
    try {
        // 确保devices表存在
        $db->exec("CREATE TABLE IF NOT EXISTS devices (
            id INT AUTO_INCREMENT PRIMARY KEY,
            software_id INT NOT NULL,
            machine_code VARCHAR(128) DEFAULT '',
            fingerprint VARCHAR(128) DEFAULT '',
            fingerprint_components TEXT,
            platform VARCHAR(50) DEFAULT '',
            os_version VARCHAR(100) DEFAULT '',
            is_virtual TINYINT DEFAULT 0,
            virtual_type VARCHAR(50) DEFAULT '',
            risk_level TINYINT DEFAULT 0,
            status TINYINT DEFAULT 1,
            expire_time DATETIME,
            last_ip VARCHAR(50) DEFAULT '',
            last_heartbeat DATETIME,
            create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_software (software_id),
            INDEX idx_fingerprint (fingerprint),
            INDEX idx_machine (machine_code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, intval($_GET['page_size'] ?? 20)));
        $softwareId = intval($_GET['software_id'] ?? 0);
        $status = $_GET['status'] ?? '';
        $keyword = trim($_GET['keyword'] ?? '');
        $onlineOnly = intval($_GET['online_only'] ?? 0);
        
        $where = "1=1";
        $params = [];
        
        if ($softwareId > 0) {
            $where .= " AND d.software_id = ?";
            $params[] = $softwareId;
        }
        
        if ($status !== '') {
            $where .= " AND d.status = ?";
            $params[] = intval($status);
        }
        
        if ($keyword) {
            $where .= " AND (d.machine_code LIKE ? OR d.fingerprint LIKE ? OR d.last_ip LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        // 在线判断：15秒内有心跳
        if ($onlineOnly) {
            $where .= " AND d.last_heartbeat > DATE_SUB(NOW(), INTERVAL 15 SECOND)";
        }
        
        // 获取总数
        $countSql = "SELECT COUNT(*) FROM devices d WHERE $where";
        $stmt = $db->prepare($countSql);
        $stmt->execute($params);
        $total = $stmt->fetchColumn();
        
        // 获取列表
        $offset = ($page - 1) * $pageSize;
        $sql = "SELECT d.*, s.name as software_name,
                CASE WHEN d.last_heartbeat > DATE_SUB(NOW(), INTERVAL 15 SECOND) THEN 1 ELSE 0 END as is_online
                FROM devices d
                LEFT JOIN software s ON d.software_id = s.id
                WHERE $where
                ORDER BY d.id DESC
                LIMIT $offset, $pageSize";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 脱敏处理
        foreach ($list as &$item) {
            if (!empty($item['machine_code'])) {
                $item['machine_code_masked'] = substr($item['machine_code'], 0, 8) . '...' . substr($item['machine_code'], -8);
            }
            if (!empty($item['fingerprint'])) {
                $item['fingerprint_masked'] = substr($item['fingerprint'], 0, 8) . '...' . substr($item['fingerprint'], -8);
            }
            
            // 查询关联的授权码信息（获取点卡信息）
            $fingerprint = $item['fingerprint'] ?: $item['machine_code'];
            if ($fingerprint) {
                $stmt2 = $db->prepare("SELECT is_point_card, total_points, remaining_points FROM auth_codes WHERE bound_fingerprint = ? AND software_id = ? ORDER BY id DESC LIMIT 1");
                $stmt2->execute([$fingerprint, $item['software_id']]);
                $codeInfo = $stmt2->fetch(PDO::FETCH_ASSOC);
                
                if ($codeInfo && intval($codeInfo['is_point_card']) == 1) {
                    $item['is_point_card'] = 1;
                    $item['total_points'] = intval($codeInfo['total_points']);
                    $item['remaining_points'] = intval($codeInfo['remaining_points']);
                } else {
                    $item['is_point_card'] = 0;
                }
            } else {
                $item['is_point_card'] = 0;
            }
            
            // 计算剩余天数（仅对时长卡有效）
            if (!empty($item['expire_time'])) {
                $remainSeconds = strtotime($item['expire_time']) - time();
                $item['remain_days'] = max(0, floor($remainSeconds / 86400));
                // 点卡模式下，到期时间是100年后，不算过期
                if ($item['is_point_card'] == 1) {
                    $item['is_expired'] = ($item['remaining_points'] ?? 0) <= 0 ? 1 : 0;
                } else {
                    $item['is_expired'] = $remainSeconds < 0 ? 1 : 0;
                }
            } else {
                $item['remain_days'] = 0;
                $item['is_expired'] = 1;
            }
            // 获取IP归属地
            if (!empty($item['last_ip'])) {
                $item['ip_location'] = getIpLocationSimple($item['last_ip']);
            } else {
                $item['ip_location'] = '';
            }
        }
        
        echo json_encode([
            'code' => 200,
            'data' => [
                'list' => $list,
                'total' => intval($total),
                'page' => $page,
                'page_size' => $pageSize
            ]
        ]);
    } catch (Exception $e) {
        echo json_encode(['code' => 500, 'message' => '查询失败: ' . $e->getMessage()]);
    }
}

/**
 * 获取设备详情
 */
function getDeviceDetail($db) {
    
    $id = intval($_GET['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    $stmt = $db->prepare("SELECT d.*, s.name as software_name FROM devices d LEFT JOIN software s ON d.software_id = s.id WHERE d.id = ?");
    $stmt->execute([$id]);
    $device = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$device) {
        echo json_encode(['code' => 404, 'message' => '设备不存在']);
        return;
    }
    
    // 获取会话信息
    $stmt = $db->prepare("SELECT * FROM online_sessions WHERE device_id = ? ORDER BY login_time DESC LIMIT 10");
    $stmt->execute([$id]);
    $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $device['sessions'] = $sessions;
    
    echo json_encode(['code' => 200, 'data' => $device]);
}

/**
 * 禁用设备
 */
function disableDevice($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? $_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    $db->beginTransaction();
    
    try {
        // 确保online_sessions表有force_offline字段
        try {
            $db->exec("ALTER TABLE online_sessions ADD COLUMN force_offline TINYINT(1) DEFAULT 0");
        } catch (Exception $e) {
            // 字段已存在，忽略
        }
        
        // 获取设备信息
        $stmt = $db->prepare("SELECT machine_code, fingerprint, software_id FROM devices WHERE id = ?");
        $stmt->execute([$id]);
        $device = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$device) {
            $db->rollBack();
            echo json_encode(['code' => 404, 'message' => '设备不存在']);
            return;
        }
        
        // 禁用设备
        $stmt = $db->prepare("UPDATE devices SET status = 0 WHERE id = ?");
        $stmt->execute([$id]);
        
        // 使所有会话失效并标记强制下线
        $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0, force_offline = 1 WHERE device_id = ?");
        $stmt->execute([$id]);
        
        // 将机器码加入黑名单
        $machineCode = $device['fingerprint'] ?: $device['machine_code'];
        if ($machineCode) {
            try {
                $stmt = $db->prepare("INSERT INTO machine_blacklist (machine_code, software_id, reason, admin_id, create_time) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$machineCode, $device['software_id'], '设备禁用自动加入', $_SESSION['admin_id'] ?? 0]);
            } catch (Exception $e) {
                // 可能已存在，忽略
            }
        }
        
        $db->commit();
        
        echo json_encode(['code' => 200, 'message' => '设备已禁用并加入黑名单']);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['code' => 500, 'message' => '操作失败: ' . $e->getMessage()]);
    }
}

/**
 * 启用设备
 */
function enableDevice($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? $_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    // 获取设备信息
    $stmt = $db->prepare("SELECT machine_code, fingerprint, software_id FROM devices WHERE id = ?");
    $stmt->execute([$id]);
    $device = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // 启用设备
    $stmt = $db->prepare("UPDATE devices SET status = 1 WHERE id = ?");
    $stmt->execute([$id]);
    
    // 从黑名单移除
    if ($device) {
        $machineCode = $device['fingerprint'] ?: $device['machine_code'];
        if ($machineCode) {
            $stmt = $db->prepare("DELETE FROM machine_blacklist WHERE machine_code = ? AND software_id = ?");
            $stmt->execute([$machineCode, $device['software_id']]);
        }
    }
    
    echo json_encode(['code' => 200, 'message' => '设备已启用并从黑名单移除']);
}

/**
 * 强制下线
 */
function kickDevice($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['id'] ?? $_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    // 确保online_sessions表有force_offline字段
    try {
        $db->exec("ALTER TABLE online_sessions ADD COLUMN force_offline TINYINT(1) DEFAULT 0");
    } catch (Exception $e) {
        // 字段已存在，忽略
    }
    
    // 获取设备信息
    $stmt = $db->prepare("SELECT id, fingerprint, machine_code, software_id FROM devices WHERE id = ?");
    $stmt->execute([$id]);
    $device = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$device) {
        echo json_encode(['code' => 404, 'message' => '设备不存在']);
        return;
    }
    
    $affected = 0;
    
    // 方法1: 通过device_id更新
    $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0, force_offline = 1 WHERE device_id = ? AND is_valid = 1");
    $stmt->execute([$id]);
    $affected += $stmt->rowCount();
    
    // 方法2: 如果有software_id，也通过software_id+fingerprint更新（兼容旧数据）
    if ($device['software_id'] && ($device['fingerprint'] || $device['machine_code'])) {
        $fingerprint = $device['fingerprint'] ?: $device['machine_code'];
        // 查找所有匹配的设备ID
        $stmt = $db->prepare("SELECT id FROM devices WHERE software_id = ? AND (fingerprint = ? OR machine_code = ?)");
        $stmt->execute([$device['software_id'], $fingerprint, $fingerprint]);
        $deviceIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (!empty($deviceIds)) {
            $placeholders = implode(',', array_fill(0, count($deviceIds), '?'));
            $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0, force_offline = 1 WHERE device_id IN ($placeholders) AND is_valid = 1");
            $stmt->execute($deviceIds);
            $affected += $stmt->rowCount();
        }
    }
    
    // 更新设备心跳时间为很久以前，让管理界面立即显示"离线"
    $stmt = $db->prepare("UPDATE devices SET last_heartbeat = DATE_SUB(NOW(), INTERVAL 1 HOUR) WHERE id = ?");
    $stmt->execute([$id]);
    
    // 记录日志
    try {
        $stmt = $db->prepare("INSERT INTO runtime_logs (type, module, content, ip, create_time) VALUES ('info', 'admin', ?, ?, NOW())");
        $stmt->execute(["强制下线设备ID={$id}, 更新会话数={$affected}", $_SERVER['REMOTE_ADDR'] ?? '']);
    } catch (Exception $e) {}
    
    if ($affected > 0) {
        echo json_encode(['code' => 200, 'message' => "已强制下线，客户端将在下次心跳时断开（取决于客户端心跳间隔）"]);
    } else {
        echo json_encode(['code' => 200, 'message' => "设备无活跃会话，已标记为离线"]);
    }
}

/**
 * 删除设备
 */
function deleteDevice($db) {
    
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    $db->beginTransaction();
    
    try {
        // 删除会话
        $stmt = $db->prepare("DELETE FROM online_sessions WHERE device_id = ?");
        $stmt->execute([$id]);
        
        // 删除审核记录
        $stmt = $db->prepare("DELETE FROM fingerprint_reviews WHERE device_id = ?");
        $stmt->execute([$id]);
        
        // 删除设备
        $stmt = $db->prepare("DELETE FROM devices WHERE id = ?");
        $stmt->execute([$id]);
        
        $db->commit();
        
        echo json_encode(['code' => 200, 'message' => '设备已删除']);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['code' => 500, 'message' => '删除失败']);
    }
}

/**
 * 获取在线统计
 */
function getDeviceOnlineCount($db) {
    try {
        $softwareId = intval($_GET['software_id'] ?? 0);
        
        $where = "last_heartbeat > DATE_SUB(NOW(), INTERVAL 15 SECOND)";
        $params = [];
        
        if ($softwareId > 0) {
            $where .= " AND software_id = ?";
            $params[] = $softwareId;
        }
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM devices WHERE $where");
        $stmt->execute($params);
        $onlineCount = $stmt->fetchColumn();
        
        // 总设备数
        $where2 = "1=1";
        if ($softwareId > 0) {
            $where2 .= " AND software_id = ?";
        }
        $stmt = $db->prepare("SELECT COUNT(*) FROM devices WHERE $where2");
        $stmt->execute($softwareId > 0 ? [$softwareId] : []);
        $totalCount = $stmt->fetchColumn();
        
        echo json_encode([
            'code' => 200,
            'data' => [
                'online' => intval($onlineCount),
                'total' => intval($totalCount)
            ]
        ]);
    } catch (Exception $e) {
        echo json_encode(['code' => 200, 'data' => ['online' => 0, 'total' => 0]]);
    }
}

/**
 * 自动修复数据库表结构
 */
function autoFixDevicesTables($db) {
    static $fixed = false;
    if ($fixed) return;
    $fixed = true;
    
    try {
        // 确保online_sessions表有force_offline字段
        try {
            $db->exec("ALTER TABLE online_sessions ADD COLUMN force_offline TINYINT(1) DEFAULT 0");
        } catch (Exception $e) {}
        
        // 确保machine_blacklist表有admin_id字段
        try {
            $db->exec("ALTER TABLE machine_blacklist ADD COLUMN admin_id INT(11) DEFAULT NULL");
        } catch (Exception $e) {}
        
        // 确保runtime_logs表有software_id和user_id字段
        try {
            $db->exec("ALTER TABLE runtime_logs ADD COLUMN software_id INT(11) DEFAULT 0");
        } catch (Exception $e) {}
        try {
            $db->exec("ALTER TABLE runtime_logs ADD COLUMN user_id INT(11) DEFAULT 0");
        } catch (Exception $e) {}
        
        // 确保auth_codes表有machine_code字段
        try {
            $db->exec("ALTER TABLE auth_codes ADD COLUMN machine_code VARCHAR(128) DEFAULT NULL");
        } catch (Exception $e) {}
        
        // 同步已有的bound_fingerprint到machine_code
        try {
            $db->exec("UPDATE auth_codes SET machine_code = bound_fingerprint WHERE bound_fingerprint IS NOT NULL AND bound_fingerprint != '' AND (machine_code IS NULL OR machine_code = '')");
        } catch (Exception $e) {}
        
    } catch (Exception $e) {
        // 忽略错误
    }
}
