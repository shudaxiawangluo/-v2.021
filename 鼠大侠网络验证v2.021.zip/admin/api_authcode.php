<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$db = getDB();

// 自动修复数据库
autoFixDatabase();

switch ($action) {
    case 'list':
        $page = intval($_GET['page'] ?? 1);
        $pageSize = intval($_GET['pageSize'] ?? 20);
        $software_id = $_GET['software_id'] ?? '';
        $card_type = $_GET['card_type'] ?? '';
        $status = $_GET['status'] ?? '';
        $keyword = $_GET['keyword'] ?? '';
        
        $where = "1=1";
        $params = [];
        
        if ($software_id !== '') {
            $where .= " AND ac.software_id = ?";
            $params[] = $software_id;
        }
        if ($card_type !== '') {
            $where .= " AND ac.card_type = ?";
            $params[] = $card_type;
        }
        if ($status !== '') {
            $where .= " AND ac.status = ?";
            $params[] = $status;
        }
        if ($keyword !== '') {
            $where .= " AND (ac.code LIKE ? OR ac.machine_code LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        // 获取总数
        $countStmt = $db->prepare("SELECT COUNT(*) FROM auth_codes ac WHERE $where");
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        // 获取列表
        $offset = ($page - 1) * $pageSize;
        $stmt = $db->prepare("SELECT ac.*, s.name as software_name FROM auth_codes ac 
            LEFT JOIN software s ON ac.software_id = s.id 
            WHERE $where ORDER BY ac.id DESC LIMIT $offset, $pageSize");
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 处理状态：根据实际情况更新状态显示
        $now = time();
        foreach ($list as &$item) {
            $originalStatus = intval($item['status']);
            
            // 如果状态是禁用(2)，保持不变
            if ($originalStatus == 2) {
                continue;
            }
            
            // 如果有到期时间
            if (!empty($item['expire_time'])) {
                $expireTime = strtotime($item['expire_time']);
                if ($expireTime < $now) {
                    // 已过期
                    $item['status'] = 3;
                } else {
                    // 有到期时间但未过期，说明已激活
                    $item['status'] = 1;
                }
            }
            // 如果有机器码绑定，说明已激活
            elseif (!empty($item['machine_code'])) {
                $item['status'] = 1;
            }
            // 否则保持原状态（未使用）
        }
        unset($item);
        
        echo json_encode(['code' => 0, 'msg' => 'success', 'data' => $list, 'total' => $total]);
        break;
        
    case 'generate':
        $input = json_decode(file_get_contents('php://input'), true);
        
        $software_id = intval($input['software_id'] ?? 0);
        $product_id = intval($input['product_id'] ?? 0); // 关联商品ID
        $card_type = $input['card_type'] ?? 'month';
        $duration = intval($input['duration'] ?? 30);
        $activate_mode = $input['activate_mode'] ?? 'first_use';
        $start_time = $input['start_time'] ?? null;
        $max_devices = intval($input['max_devices'] ?? 1);
        $allow_multi = $input['allow_multi'] ? 1 : 0;
        $allow_unbind = $input['allow_unbind'] ? 1 : 0;
        $max_unbind = intval($input['max_unbind'] ?? 3);
        $single_online = $input['single_online'] ? 1 : 0;
        $pre_bind = $input['pre_bind'] ?? false;
        $machine_codes_str = trim($input['machine_codes'] ?? '');
        $ip_limit = $input['ip_limit'] ? 1 : 0;
        $max_ip = intval($input['max_ip'] ?? 5);
        $use_limit = $input['use_limit'] ? 1 : 0;
        $max_use = intval($input['max_use'] ?? 100);
        $region_limit = $input['region_limit'] ? 1 : 0;
        $allowed_regions = $input['allowed_regions'] ?? [];
        $count = intval($input['count'] ?? 1);
        $remark = trim($input['remark'] ?? '');
        
        // 点卡相关参数
        $is_point_card = intval($input['is_point_card'] ?? 0);
        $points = intval($input['points'] ?? 0);
        $deduct_type = $input['deduct_type'] ?? null;
        $deduct_amount = intval($input['deduct_amount'] ?? 1);
        
        if ($software_id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '请选择软件']);
            exit;
        }
        if ($count <= 0 || $count > 10000) {
            echo json_encode(['code' => 1, 'msg' => '生成数量必须在1-10000之间']);
            exit;
        }
        
        // 验证商品是否属于该软件
        if ($product_id > 0) {
            $stmt = $db->prepare("SELECT id FROM products WHERE id = ? AND software_id = ?");
            $stmt->execute([$product_id, $software_id]);
            if (!$stmt->fetch()) {
                $product_id = 0; // 商品不存在或不属于该软件，不关联
            }
        }
        
        // 处理预绑定机器码
        $preBoundMachines = [];
        if ($pre_bind && $machine_codes_str) {
            $preBoundMachines = array_filter(array_map('trim', explode("\n", $machine_codes_str)));
            if (count($preBoundMachines) !== $count) {
                echo json_encode(['code' => 1, 'msg' => '机器码数量(' . count($preBoundMachines) . ')与生成数量(' . $count . ')不一致']);
                exit;
            }
        }
        
        // 计算有效天数
        $days = 30;
        switch ($card_type) {
            case 'minute': $days = max(1, ceil($duration / 1440)); break;
            case 'hour': $days = max(1, ceil($duration / 24)); break;
            case 'day': $days = $duration; break;
            case 'week': $days = 7; break;
            case 'month': $days = 30; break;
            case 'quarter': $days = 90; break;
            case 'year': $days = 365; break;
            case 'permanent': $days = 36500; break;
        }
        
        // 计算有效分钟数（精确计算）
        $minutes = 0;
        switch ($card_type) {
            case 'minute': $minutes = $duration; break;
            case 'hour': $minutes = $duration * 60; break;
            case 'day': $minutes = $duration * 1440; break;
            case 'week': $minutes = 7 * 1440; break;
            case 'month': $minutes = 30 * 1440; break;
            case 'quarter': $minutes = 90 * 1440; break;
            case 'year': $minutes = 365 * 1440; break;
            case 'permanent': $minutes = 36500 * 1440; break;
        }
        
        // 处理生效时间
        $startTimeValue = null;
        if ($activate_mode === 'scheduled' && $start_time) {
            $startTimeValue = date('Y-m-d H:i:s', strtotime($start_time));
        }
        
        // 处理区域限制
        $regionsJson = $region_limit && !empty($allowed_regions) ? json_encode($allowed_regions) : null;
        
        try {
            // 记录调试日志到运行日志表
            $logStmt = $db->prepare("INSERT INTO runtime_logs (type, module, content, ip, create_time) VALUES ('debug', 'authcode', ?, ?, NOW())");
            $logStmt->execute(["生成卡密: card_type={$card_type}, duration={$duration}, days={$days}, minutes={$minutes}, is_point_card={$is_point_card}, deduct_amount={$deduct_amount}, product_id={$product_id}", $_SERVER['REMOTE_ADDR']]);
        } catch (Exception $e) {}
        
        try {
            $stmt = $db->prepare("INSERT INTO auth_codes (software_id, product_id, code, days, minutes, card_type, activate_mode, start_time, max_devices, allow_multi, allow_unbind, max_unbind, single_online, ip_limit, max_ip, use_limit, max_use, use_count, region_limit, allowed_regions, machine_code, is_point_card, total_points, remaining_points, deduct_type, deduct_amount, remark, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            
            $generatedCodes = [];
            $existingCodes = [];
            
            // 预先获取已存在的卡密
            $checkStmt = $db->query("SELECT code FROM auth_codes");
            while ($row = $checkStmt->fetch()) {
                $existingCodes[$row['code']] = true;
            }
            
            for ($i = 0; $i < $count; $i++) {
                // 生成20位随机卡密
                $attempts = 0;
                do {
                    $code = strtoupper(bin2hex(random_bytes(10))); // 20位
                    $attempts++;
                } while (isset($existingCodes[$code]) && $attempts < 10);
                
                // 预绑定机器码
                $machineCode = $pre_bind && isset($preBoundMachines[$i]) ? $preBoundMachines[$i] : null;
                
                $stmt->execute([
                    $software_id, $product_id > 0 ? $product_id : null, $code, $days, $minutes, $card_type,
                    $activate_mode, $startTimeValue,
                    $max_devices, $allow_multi, $allow_unbind, $max_unbind,
                    $single_online, $ip_limit, $max_ip,
                    $use_limit, $max_use, $region_limit, $regionsJson,
                    $machineCode,
                    $is_point_card, $points, $points, $deduct_type, $deduct_amount,
                    $remark
                ]);
                
                $generatedCodes[] = $code;
                $existingCodes[$code] = true;
            }
            
            // 记录操作日志
            $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $logStmt->execute([$_SESSION['admin_id'], "生成授权码 {$count} 个，类型: {$card_type}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '生成成功', 'data' => ['codes' => $generatedCodes, 'count' => count($generatedCodes)]]);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '生成失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'update':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            exit;
        }
        
        try {
            $stmt = $db->prepare("UPDATE auth_codes SET 
                machine_code = ?, 
                max_devices = ?, 
                allow_multi = ?, 
                allow_unbind = ?, 
                max_unbind = ?,
                unbind_count = ?,
                remark = ? 
                WHERE id = ?");
            $stmt->execute([
                trim($input['machine_code'] ?? '') ?: null,
                intval($input['max_devices'] ?? 1),
                $input['allow_multi'] ? 1 : 0,
                $input['allow_unbind'] ? 1 : 0,
                intval($input['max_unbind'] ?? 3),
                intval($input['unbind_count'] ?? 0),
                trim($input['remark'] ?? ''),
                $id
            ]);
            echo json_encode(['code' => 0, 'msg' => '更新成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '更新失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'unbind':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            exit;
        }
        
        try {
            // 获取当前授权码信息
            $stmt = $db->prepare("SELECT * FROM auth_codes WHERE id = ?");
            $stmt->execute([$id]);
            $code = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$code) {
                echo json_encode(['code' => 1, 'msg' => '授权码不存在']);
                exit;
            }
            
            if (!$code['allow_unbind']) {
                echo json_encode(['code' => 1, 'msg' => '此授权码不允许换绑']);
                exit;
            }
            
            $unbindCount = intval($code['unbind_count'] ?? 0);
            $maxUnbind = intval($code['max_unbind'] ?? 0);
            
            if ($unbindCount >= $maxUnbind) {
                echo json_encode(['code' => 1, 'msg' => '已达到最大换绑次数']);
                exit;
            }
            
            // 通过机器码查找设备并踢下线
            if ($code['machine_code']) {
                // 查找设备
                $deviceStmt = $db->prepare("SELECT id FROM devices WHERE fingerprint = ? AND software_id = ?");
                $deviceStmt->execute([$code['machine_code'], $code['software_id']]);
                $device = $deviceStmt->fetch(PDO::FETCH_ASSOC);
                
                if ($device) {
                    // 使会话失效
                    $db->prepare("UPDATE online_sessions SET is_valid = 0, force_offline = 1 WHERE device_id = ?")->execute([$device['id']]);
                }
            }
            
            // 执行解绑
            $stmt = $db->prepare("UPDATE auth_codes SET machine_code = NULL, bound_fingerprint = NULL, unbind_count = unbind_count + 1, status = 0 WHERE id = ?");
            $stmt->execute([$id]);
            
            // 记录日志
            $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $logStmt->execute([$_SESSION['admin_id'], "解绑授权码: {$code['code']}", $_SERVER['REMOTE_ADDR']]);
            
            $remaining = $maxUnbind - $unbindCount - 1;
            echo json_encode(['code' => 0, 'msg' => '解绑成功', 'data' => ['remaining' => $remaining]]);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '解绑失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'disable':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        if ($id <= 0) { echo json_encode(['code' => 1, 'msg' => '参数错误']); exit; }
        
        try {
            $db->prepare("UPDATE auth_codes SET status = 2 WHERE id = ?")->execute([$id]);
            echo json_encode(['code' => 0, 'msg' => '禁用成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
        
    case 'enable':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        if ($id <= 0) { echo json_encode(['code' => 1, 'msg' => '参数错误']); exit; }
        
        try {
            // 恢复为未使用或已激活状态
            $stmt = $db->prepare("SELECT machine_code FROM auth_codes WHERE id = ?");
            $stmt->execute([$id]);
            $code = $stmt->fetch();
            $newStatus = $code && $code['machine_code'] ? 1 : 0;
            
            $db->prepare("UPDATE auth_codes SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
            echo json_encode(['code' => 0, 'msg' => '启用成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
        
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        if ($id <= 0) { echo json_encode(['code' => 1, 'msg' => '参数错误']); exit; }
        
        try {
            // 先获取卡密关联的商品ID
            $stmt = $db->prepare("SELECT product_id FROM auth_codes WHERE id = ?");
            $stmt->execute([$id]);
            $code = $stmt->fetch(PDO::FETCH_ASSOC);
            $productId = $code ? intval($code['product_id']) : 0;
            
            // 删除卡密
            $db->prepare("DELETE FROM auth_codes WHERE id = ?")->execute([$id]);
            
            // 更新商品库存
            if ($productId > 0) {
                $db->prepare("UPDATE products SET stock = (SELECT COUNT(*) FROM auth_codes WHERE product_id = ? AND status = 0) WHERE id = ?")->execute([$productId, $productId]);
            }
            
            echo json_encode(['code' => 0, 'msg' => '删除成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        break;
        
    case 'batchDelete':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        if (empty($ids)) { echo json_encode(['code' => 1, 'msg' => '请选择要删除的授权码']); exit; }
        
        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            
            // 先获取这些卡密关联的商品ID
            $stmt = $db->prepare("SELECT DISTINCT product_id FROM auth_codes WHERE id IN ($placeholders) AND product_id IS NOT NULL AND product_id > 0");
            $stmt->execute($ids);
            $productIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            // 删除卡密
            $db->prepare("DELETE FROM auth_codes WHERE id IN ($placeholders)")->execute($ids);
            
            // 更新所有关联商品的库存
            foreach ($productIds as $productId) {
                $db->prepare("UPDATE products SET stock = (SELECT COUNT(*) FROM auth_codes WHERE product_id = ? AND status = 0) WHERE id = ?")->execute([$productId, $productId]);
            }
            
            $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $logStmt->execute([$_SESSION['admin_id'], "批量删除授权码 " . count($ids) . " 个", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '批量删除成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        break;
        
    case 'batchDisable':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        if (empty($ids)) { echo json_encode(['code' => 1, 'msg' => '请选择要禁用的授权码']); exit; }
        
        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("UPDATE auth_codes SET status = 2 WHERE id IN ($placeholders)")->execute($ids);
            echo json_encode(['code' => 0, 'msg' => '批量禁用成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
    
    case 'batchEnable':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        if (empty($ids)) { echo json_encode(['code' => 1, 'msg' => '请选择要启用的授权码']); exit; }
        
        try {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            // 将已禁用的卡密恢复为未使用状态
            $db->prepare("UPDATE auth_codes SET status = 0 WHERE id IN ($placeholders) AND status = 2")->execute($ids);
            echo json_encode(['code' => 0, 'msg' => '批量启用成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败']);
        }
        break;
    
    case 'renew':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        $is_point_card = intval($input['is_point_card'] ?? 0);
        $renew_type = $input['renew_type'] ?? 'day';
        $renew_amount = intval($input['renew_amount'] ?? 0);
        
        if ($id <= 0 || $renew_amount <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            exit;
        }
        
        try {
            // 获取当前授权码
            $stmt = $db->prepare("SELECT * FROM auth_codes WHERE id = ?");
            $stmt->execute([$id]);
            $code = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$code) {
                echo json_encode(['code' => 1, 'msg' => '授权码不存在']);
                exit;
            }
            
            // 判断是点卡还是时长卡
            if ($is_point_card == 1) {
                // 点卡充值 - 增加点数
                $currentPoints = intval($code['remaining_points'] ?? 0);
                $totalPoints = intval($code['total_points'] ?? 0);
                $newPoints = $currentPoints + $renew_amount;
                $newTotalPoints = $totalPoints + $renew_amount;
                
                $stmt = $db->prepare("UPDATE auth_codes SET remaining_points = ?, total_points = ? WHERE id = ?");
                $stmt->execute([$newPoints, $newTotalPoints, $id]);
                
                // 记录充值日志
                try {
                    $stmt = $db->prepare("INSERT INTO point_recharge_logs (auth_code_id, auth_code, recharge_points, before_points, after_points, ip, create_time) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                    $stmt->execute([$id, $code['code'], $renew_amount, $currentPoints, $newPoints, $_SERVER['REMOTE_ADDR']]);
                } catch (Exception $e) {}
                
                // 记录操作日志
                $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
                $logStmt->execute([$_SESSION['admin_id'], "充值点卡: {$code['code']}，增加 {$renew_amount} 点", $_SERVER['REMOTE_ADDR']]);
                
                echo json_encode(['code' => 0, 'msg' => '充值成功', 'data' => ['new_points' => $newPoints]]);
            } else {
                // 时长卡续费 - 延长到期时间
                // 计算续费分钟数
                $addMinutes = 0;
                switch ($renew_type) {
                    case 'minute': $addMinutes = $renew_amount; break;
                    case 'hour': $addMinutes = $renew_amount * 60; break;
                    case 'day': $addMinutes = $renew_amount * 1440; break;
                    case 'week': $addMinutes = $renew_amount * 7 * 1440; break;
                    case 'month': $addMinutes = $renew_amount * 30 * 1440; break;
                    case 'quarter': $addMinutes = $renew_amount * 90 * 1440; break;
                    case 'year': $addMinutes = $renew_amount * 365 * 1440; break;
                }
                
                // 计算新的到期时间
                $currentExpire = $code['expire_time'] ? strtotime($code['expire_time']) : time();
                if ($currentExpire < time()) {
                    $currentExpire = time(); // 如果已过期，从现在开始算
                }
                $newExpire = date('Y-m-d H:i:s', $currentExpire + $addMinutes * 60);
                
                // 更新到期时间和分钟数
                $newMinutes = intval($code['minutes'] ?? 0) + $addMinutes;
                $newDays = ceil($newMinutes / 1440);
                
                $stmt = $db->prepare("UPDATE auth_codes SET expire_time = ?, minutes = ?, days = ?, status = CASE WHEN status = 3 THEN 1 ELSE status END WHERE id = ?");
                $stmt->execute([$newExpire, $newMinutes, $newDays, $id]);
                
                // 同步更新设备的到期时间
                if (!empty($code['machine_code'])) {
                    $stmt = $db->prepare("UPDATE devices SET expire_time = ? WHERE fingerprint = ? AND software_id = ?");
                    $stmt->execute([$newExpire, $code['machine_code'], $code['software_id']]);
                }
                
                // 记录日志
                $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
                $logStmt->execute([$_SESSION['admin_id'], "续费授权码: {$code['code']}，增加 {$renew_amount} {$renew_type}", $_SERVER['REMOTE_ADDR']]);
                
                echo json_encode(['code' => 0, 'msg' => '续费成功', 'data' => ['new_expire' => $newExpire]]);
            }
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '操作失败: ' . $e->getMessage()]);
        }
        break;
    
    case 'deleteAll':
        $input = json_decode(file_get_contents('php://input'), true);
        $software_id = $input['software_id'] ?? '';
        $card_type = $input['card_type'] ?? '';
        $status = $input['status'] ?? '';
        $keyword = $input['keyword'] ?? '';
        
        $where = "1=1";
        $params = [];
        
        if ($software_id !== '') { $where .= " AND software_id = ?"; $params[] = $software_id; }
        if ($card_type !== '') { $where .= " AND card_type = ?"; $params[] = $card_type; }
        if ($status !== '') { $where .= " AND status = ?"; $params[] = $status; }
        if ($keyword !== '') { $where .= " AND code LIKE ?"; $params[] = "%$keyword%"; }
        
        try {
            // 先获取要删除的卡密关联的商品ID
            $productStmt = $db->prepare("SELECT DISTINCT product_id FROM auth_codes WHERE $where AND product_id IS NOT NULL AND product_id > 0");
            $productStmt->execute($params);
            $productIds = $productStmt->fetchAll(PDO::FETCH_COLUMN);
            
            // 统计数量
            $countStmt = $db->prepare("SELECT COUNT(*) FROM auth_codes WHERE $where");
            $countStmt->execute($params);
            $count = $countStmt->fetchColumn();
            
            // 删除
            $stmt = $db->prepare("DELETE FROM auth_codes WHERE $where");
            $stmt->execute($params);
            
            // 更新所有关联商品的库存
            foreach ($productIds as $productId) {
                $db->prepare("UPDATE products SET stock = (SELECT COUNT(*) FROM auth_codes WHERE product_id = ? AND status = 0) WHERE id = ?")->execute([$productId, $productId]);
            }
            
            // 记录日志
            $logStmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
            $logStmt->execute([$_SESSION['admin_id'], "删除全部授权码 {$count} 个", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '删除成功', 'data' => ['count' => $count]]);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        break;
        
    case 'export':
        $software_id = $_GET['software_id'] ?? '';
        $card_type = $_GET['card_type'] ?? '';
        $status = $_GET['status'] ?? '';
        $keyword = $_GET['keyword'] ?? '';
        
        $where = "1=1";
        $params = [];
        
        if ($software_id !== '') { $where .= " AND ac.software_id = ?"; $params[] = $software_id; }
        if ($card_type !== '') { $where .= " AND ac.card_type = ?"; $params[] = $card_type; }
        if ($status !== '') { $where .= " AND ac.status = ?"; $params[] = $status; }
        if ($keyword !== '') { $where .= " AND ac.code LIKE ?"; $params[] = "%$keyword%"; }
        
        $stmt = $db->prepare("SELECT ac.code, s.name as software_name, ac.days, ac.card_type, ac.machine_code, ac.max_devices, ac.allow_multi, ac.allow_unbind, ac.status, ac.create_time, ac.expire_time FROM auth_codes ac LEFT JOIN software s ON ac.software_id = s.id WHERE $where ORDER BY ac.id DESC");
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="authcodes_' . date('Ymd_His') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM
        fputcsv($output, ['授权码', '软件', '天数', '类型', '机器码', '设备数', '多开', '换绑', '状态', '创建时间', '到期时间']);
        
        $statusTexts = ['未使用', '已激活', '已禁用', '已过期'];
        $cardTypes = ['minute'=>'分钟', 'hour'=>'小时', 'day'=>'天', 'week'=>'周', 'month'=>'月', 'quarter'=>'季', 'year'=>'年', 'permanent'=>'永久'];
        
        foreach ($list as $row) {
            fputcsv($output, [
                $row['code'],
                $row['software_name'],
                $row['days'],
                $cardTypes[$row['card_type']] ?? $row['card_type'],
                $row['machine_code'] ?: '未绑定',
                $row['max_devices'],
                $row['allow_multi'] ? '是' : '否',
                $row['allow_unbind'] ? '是' : '否',
                $statusTexts[$row['status']] ?? '未知',
                $row['create_time'],
                $row['expire_time'] ?: '-'
            ]);
        }
        
        fclose($output);
        exit;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
