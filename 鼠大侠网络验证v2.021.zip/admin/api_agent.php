<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'list':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, intval($_GET['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;
        
        $where = "1=1";
        $params = [];
        
        // 检查表结构
        $columns = [];
        $colStmt = $db->query("SHOW COLUMNS FROM agents");
        while ($col = $colStmt->fetch(PDO::FETCH_ASSOC)) {
            $columns[] = $col['Field'];
        }
        
        if (in_array('level', $columns) && !empty($_GET['level'])) {
            $where .= " AND a.level = ?";
            $params[] = $_GET['level'];
        }
        if (isset($_GET['status']) && $_GET['status'] !== '') {
            $where .= " AND a.status = ?";
            $params[] = $_GET['status'];
        }
        if (!empty($_GET['keyword'])) {
            $where .= " AND (a.username LIKE ? OR a.nickname LIKE ? OR a.qq LIKE ?)";
            $keyword = '%' . $_GET['keyword'] . '%';
            $params = array_merge($params, [$keyword, $keyword, $keyword]);
        }
        
        // 获取总数
        $countSql = "SELECT COUNT(*) FROM agents a WHERE $where";
        $stmt = $db->prepare($countSql);
        $stmt->execute($params);
        $total = $stmt->fetchColumn();
        
        // 获取列表 - 根据表结构动态构建查询
        if (in_array('parent_id', $columns)) {
            $sql = "SELECT a.*, p.username as parent_name 
                    FROM agents a 
                    LEFT JOIN agents p ON a.parent_id = p.id 
                    WHERE $where 
                    ORDER BY a.id DESC 
                    LIMIT $offset, $pageSize";
        } else {
            $sql = "SELECT a.* 
                    FROM agents a 
                    WHERE $where 
                    ORDER BY a.id DESC 
                    LIMIT $offset, $pageSize";
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        break;
        
    case 'parents':
        // 获取一级代理列表（用于选择上级）
        try {
            // 检查是否有level字段
            $columns = [];
            $colStmt = $db->query("SHOW COLUMNS FROM agents");
            while ($col = $colStmt->fetch(PDO::FETCH_ASSOC)) {
                $columns[] = $col['Field'];
            }
            
            if (in_array('level', $columns)) {
                $stmt = $db->query("SELECT id, username, nickname FROM agents WHERE level = 1 AND status = 1 ORDER BY id");
            } else {
                $stmt = $db->query("SELECT id, username, nickname FROM agents WHERE status = 1 ORDER BY id");
            }
            $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['code' => 0, 'data' => $list]);
        } catch (PDOException $e) {
            echo json_encode(['code' => 0, 'data' => []]);
        }
        break;
        
    case 'add':
        $input = json_decode(file_get_contents('php://input'), true);
        
        $username = trim($input['username'] ?? '');
        $password = $input['password'] ?? '';
        
        if (empty($username) || empty($password)) {
            echo json_encode(['code' => 1, 'msg' => '账号和密码不能为空']);
            break;
        }
        
        try {
            // 检查账号是否存在
            $stmt = $db->prepare("SELECT id FROM agents WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                echo json_encode(['code' => 1, 'msg' => '账号已存在']);
                break;
            }
            
            // 检查表结构，获取现有字段
            $columns = [];
            $colStmt = $db->query("SHOW COLUMNS FROM agents");
            while ($col = $colStmt->fetch(PDO::FETCH_ASSOC)) {
                $columns[] = $col['Field'];
            }
            
            // 构建插入语句
            $fields = ['username', 'password'];
            $values = [$username, password_hash($password, PASSWORD_DEFAULT)];
            $placeholders = ['?', '?'];
            
            // 可选字段
            $optionalFields = [
                'nickname' => $input['nickname'] ?? '',
                'level' => intval($input['level'] ?? 1),
                'parent_id' => intval($input['parent_id'] ?? 0),
                'discount' => floatval($input['discount'] ?? 1),
                'qq' => $input['qq'] ?? '',
                'email' => $input['email'] ?? '',
                'contact' => $input['contact'] ?? '',
                'allowed_software' => !empty($input['allowed_software']) ? json_encode($input['allowed_software']) : null,
                'status' => intval($input['status'] ?? 1)
            ];
            
            foreach ($optionalFields as $field => $value) {
                if (in_array($field, $columns)) {
                    $fields[] = $field;
                    $values[] = $value;
                    $placeholders[] = '?';
                }
            }
            
            $sql = "INSERT INTO agents (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";
            $stmt = $db->prepare($sql);
            $stmt->execute($values);
            
            // 记录日志
            if (in_array('operation_logs', getTableList($db))) {
                $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
                $stmt->execute([$_SESSION['admin_id'], "添加代理: {$username}", $_SERVER['REMOTE_ADDR']]);
            }
            
            echo json_encode(['code' => 0, 'msg' => '添加成功']);
        } catch (PDOException $e) {
            echo json_encode(['code' => 1, 'msg' => '数据库错误: ' . $e->getMessage()]);
        }
        break;
        
    case 'update':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        $sql = "UPDATE agents SET nickname = ?, level = ?, parent_id = ?, discount = ?, qq = ?, email = ?, allowed_software = ?, status = ?";
        $params = [
            $input['nickname'] ?? '',
            $input['level'] ?? 1,
            $input['parent_id'] ?? 0,
            $input['discount'] ?? 1,
            $input['qq'] ?? '',
            $input['email'] ?? '',
            !empty($input['allowed_software']) ? json_encode($input['allowed_software']) : null,
            $input['status'] ?? 1
        ];
        
        // 如果有密码则更新密码
        if (!empty($input['password'])) {
            $sql .= ", password = ?";
            $params[] = password_hash($input['password'], PASSWORD_DEFAULT);
        }
        
        $sql .= " WHERE id = ?";
        $params[] = $id;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "修改代理ID: {$id}", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => '修改成功']);
        break;
        
    case 'recharge':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        $amount = floatval($input['amount'] ?? 0);
        
        if ($id <= 0 || $amount <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        // 获取当前余额
        $stmt = $db->prepare("SELECT balance FROM agents WHERE id = ?");
        $stmt->execute([$id]);
        $agent = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$agent) {
            echo json_encode(['code' => 1, 'msg' => '代理不存在']);
            break;
        }
        
        $beforeBalance = $agent['balance'];
        $afterBalance = $beforeBalance + $amount;
        
        // 更新余额
        $stmt = $db->prepare("UPDATE agents SET balance = balance + ?, total_income = total_income + ? WHERE id = ?");
        $stmt->execute([$amount, $amount, $id]);
        
        // 记录充值
        $stmt = $db->prepare("INSERT INTO agent_recharges (agent_id, amount, before_balance, after_balance, admin_id, remark) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$id, $amount, $beforeBalance, $afterBalance, $_SESSION['admin_id'], $input['remark'] ?? '']);
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "代理充值ID: {$id}, 金额: {$amount}", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => "充值成功，当前余额: ¥{$afterBalance}"]);
        break;
        
    case 'toggle_status':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        $status = $input['status'] ?? 0;
        
        $stmt = $db->prepare("UPDATE agents SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "切换代理状态ID: {$id} -> " . ($status ? '启用' : '禁用'), $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => '操作成功']);
        break;
        
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        // 检查是否有下级代理
        $stmt = $db->prepare("SELECT COUNT(*) FROM agents WHERE parent_id = ?");
        $stmt->execute([$id]);
        if ($stmt->fetchColumn() > 0) {
            echo json_encode(['code' => 1, 'msg' => '该代理有下级代理，无法删除']);
            break;
        }
        
        $stmt = $db->prepare("DELETE FROM agents WHERE id = ?");
        $stmt->execute([$id]);
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['admin_id'], "删除代理ID: {$id}", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    case 'recharge_list':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, intval($_GET['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;
        
        $where = "1=1";
        $params = [];
        
        if (!empty($_GET['keyword'])) {
            $where .= " AND a.username LIKE ?";
            $params[] = '%' . $_GET['keyword'] . '%';
        }
        if (!empty($_GET['start_date'])) {
            $where .= " AND DATE(r.create_time) >= ?";
            $params[] = $_GET['start_date'];
        }
        if (!empty($_GET['end_date'])) {
            $where .= " AND DATE(r.create_time) <= ?";
            $params[] = $_GET['end_date'];
        }
        
        $countSql = "SELECT COUNT(*) FROM agent_recharges r LEFT JOIN agents a ON r.agent_id = a.id WHERE $where";
        $stmt = $db->prepare($countSql);
        $stmt->execute($params);
        $total = $stmt->fetchColumn();
        
        // 统计总金额
        $sumSql = "SELECT COALESCE(SUM(r.amount), 0) FROM agent_recharges r LEFT JOIN agents a ON r.agent_id = a.id WHERE $where";
        $stmt = $db->prepare($sumSql);
        $stmt->execute($params);
        $totalAmount = $stmt->fetchColumn();
        
        $sql = "SELECT r.*, a.username as agent_name, adm.username as admin_name 
                FROM agent_recharges r 
                LEFT JOIN agents a ON r.agent_id = a.id 
                LEFT JOIN admins adm ON r.admin_id = adm.id
                WHERE $where 
                ORDER BY r.id DESC 
                LIMIT $offset, $pageSize";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total, 'totalAmount' => floatval($totalAmount)]);
        break;
    
    case 'withdraw_list':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, intval($_GET['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;
        
        $where = "1=1";
        $params = [];
        
        if (isset($_GET['status']) && $_GET['status'] !== '') {
            $where .= " AND w.status = ?";
            $params[] = $_GET['status'];
        }
        if (!empty($_GET['keyword'])) {
            $where .= " AND a.username LIKE ?";
            $params[] = '%' . $_GET['keyword'] . '%';
        }
        
        $countSql = "SELECT COUNT(*) FROM agent_withdraws w LEFT JOIN agents a ON w.agent_id = a.id WHERE $where";
        $stmt = $db->prepare($countSql);
        $stmt->execute($params);
        $total = $stmt->fetchColumn();
        
        // 待审核统计
        $stmt = $db->query("SELECT COUNT(*), COALESCE(SUM(actual_amount), 0) FROM agent_withdraws WHERE status = 0");
        $pending = $stmt->fetch(PDO::FETCH_NUM);
        
        $sql = "SELECT w.*, a.username as agent_name 
                FROM agent_withdraws w 
                LEFT JOIN agents a ON w.agent_id = a.id 
                WHERE $where 
                ORDER BY w.id ASC 
                LIMIT $offset, $pageSize";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 确保status是整数类型
        foreach ($list as &$item) {
            $item['status'] = intval($item['status']);
        }
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total, 'pendingCount' => intval($pending[0]), 'pendingAmount' => floatval($pending[1])]);
        break;
    
    case 'audit_withdraw':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        $newStatus = intval($input['status'] ?? -1);
        $remark = $input['remark'] ?? '';
        
        if ($id <= 0 || !in_array($newStatus, [0, 1, 2, 3])) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        // 获取提现记录
        $stmt = $db->prepare("SELECT * FROM agent_withdraws WHERE id = ?");
        $stmt->execute([$id]);
        $withdraw = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$withdraw) {
            echo json_encode(['code' => 1, 'msg' => '提现记录不存在']);
            break;
        }
        
        $oldStatus = intval($withdraw['status']);
        
        // 如果状态没变，不处理
        if ($oldStatus === $newStatus) {
            echo json_encode(['code' => 0, 'msg' => '状态未变化']);
            break;
        }
        
        try {
            $db->beginTransaction();
            
            // 处理余额变化
            // 如果之前是拒绝状态（已退款），现在改成其他状态，需要重新扣款
            if ($oldStatus == 2 && $newStatus != 2) {
                $stmt = $db->prepare("UPDATE agents SET balance = balance - ? WHERE id = ?");
                $stmt->execute([$withdraw['amount'], $withdraw['agent_id']]);
            }
            // 如果之前是已完成状态，现在改成其他状态，需要减少累计提现
            if ($oldStatus == 1 && $newStatus != 1) {
                $stmt = $db->prepare("UPDATE agents SET total_withdraw = total_withdraw - ? WHERE id = ?");
                $stmt->execute([$withdraw['actual_amount'], $withdraw['agent_id']]);
            }
            
            // 如果新状态是拒绝，退回余额
            if ($newStatus == 2 && $oldStatus != 2) {
                $stmt = $db->prepare("UPDATE agents SET balance = balance + ? WHERE id = ?");
                $stmt->execute([$withdraw['amount'], $withdraw['agent_id']]);
            }
            // 如果新状态是已完成，增加累计提现
            if ($newStatus == 1 && $oldStatus != 1) {
                $stmt = $db->prepare("UPDATE agents SET total_withdraw = total_withdraw + ? WHERE id = ?");
                $stmt->execute([$withdraw['actual_amount'], $withdraw['agent_id']]);
            }
            
            // 更新状态
            $stmt = $db->prepare("UPDATE agent_withdraws SET status = ?, admin_id = ?, audit_time = NOW(), audit_remark = ? WHERE id = ?");
            $stmt->execute([$newStatus, $_SESSION['admin_id'], $remark, $id]);
            
            $db->commit();
            
            $statusMap = [0 => '待审核', 1 => '已完成', 2 => '已拒绝', 3 => '处理中'];
            $statusText = $statusMap[$newStatus] ?? '未知';
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "提现审核ID: {$id} -> {$statusText}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '操作成功']);
        } catch (Exception $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '操作失败: ' . $e->getMessage()]);
        }
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}

// 辅助函数：获取表列表
function getTableList($db) {
    static $tables = null;
    if ($tables === null) {
        $tables = [];
        $stmt = $db->query("SHOW TABLES");
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $tables[] = $row[0];
        }
    }
    return $tables;
}
