<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

require_once '../api/config.php';

$softwareId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$softwareId) {
    header('Location: software_list.php');
    exit;
}

$pageTitle = '软件设置';
$breadcrumbs = ['软件管理', '软件设置'];

$pageStyles = "
.section-title {
    font-size: 14px;
    font-weight: 500;
    color: var(--el-text-color-primary);
    margin: 20px 0 16px 0;
    padding-bottom: 8px;
    border-bottom: 1px solid var(--el-border-color-lighter);
}
.section-title:first-child {
    margin-top: 0;
}
.form-tip {
    margin-left: 10px;
    font-size: 12px;
    color: var(--el-text-color-secondary);
}
.info-box {
    background: #f4f4f5;
    border-radius: 4px;
    padding: 12px 16px;
    margin-bottom: 20px;
    font-size: 13px;
    color: #606266;
}
.key-display {
    background: #f5f7fa;
    border: 1px solid #e4e7ed;
    border-radius: 4px;
    padding: 10px;
    font-family: monospace;
    font-size: 12px;
    word-break: break-all;
    max-height: 80px;
    overflow-y: auto;
}
";

ob_start();
?>

<el-card shadow="hover" v-loading="loading">
    <template #header><span style="font-size: 14px; font-weight: 500;">软件设置 - {{ form.name }}</span></template>
    
    <div class="info-box">
        <strong>V2 授权系统</strong> - 心跳间隔固定5秒，自动检测虚拟机/模拟器，风险设备需人工审核
    </div>
    
    <el-form :model="form" label-width="120px" size="default" style="max-width: 700px;">
        
        <div class="section-title">基本信息</div>
        <el-form-item label="软件名称">
            <el-input v-model="form.name" placeholder="请输入软件名称" style="max-width: 400px;"></el-input>
        </el-form-item>
        
        <el-form-item label="AppKey">
            <el-input v-model="form.app_key" disabled style="max-width: 400px;">
                <template #append>
                    <el-button @click="copyAppKey">复制</el-button>
                </template>
            </el-input>
        </el-form-item>
        
        <el-form-item label="软件状态">
            <el-radio-group v-model="form.status">
                <el-radio :label="1">启用</el-radio>
                <el-radio :label="0">禁用</el-radio>
            </el-radio-group>
            <span class="form-tip">禁用后客户端将无法连接</span>
        </el-form-item>
        
        <el-form-item label="公告内容">
            <el-input v-model="form.notice" type="textarea" :rows="3" placeholder="客户端登录时显示的公告内容（可选）" style="max-width: 500px;"></el-input>
        </el-form-item>
        
        <!-- 试用设置 -->
        <div class="section-title">试用设置</div>
        <el-form-item label="开启试用">
            <el-switch v-model="form.enable_trial"></el-switch>
            <span class="form-tip">允许新设备免费试用</span>
        </el-form-item>
        
        <el-form-item label="试用时长" v-if="form.enable_trial">
            <el-input-number v-model="form.trial_duration" :min="1" :max="9999" style="width: 120px;"></el-input-number>
            <el-select v-model="form.trial_unit" style="width: 100px; margin-left: 10px;">
                <el-option label="分钟" value="minute"></el-option>
                <el-option label="小时" value="hour"></el-option>
                <el-option label="天" value="day"></el-option>
            </el-select>
        </el-form-item>
        
        <!-- 安全配置（固定值展示） -->
        <div class="section-title">安全配置 <span style="background: #e6f7ff; color: #1890ff; border: 1px solid #91d5ff; padding: 2px 8px; border-radius: 4px; font-size: 12px; margin-left: 8px;">系统固定</span></div>
        
        <el-form-item label="传输加密">
            <el-input value="RSA-2048" disabled style="max-width: 200px;"></el-input>
            <span class="form-tip">非对称加密，安全性高</span>
        </el-form-item>
        
        <el-form-item label="存储加密">
            <el-input value="AES-256-GCM" disabled style="max-width: 200px;"></el-input>
            <span class="form-tip">敏感数据加密存储</span>
        </el-form-item>
        
        <el-form-item label="令牌签名">
            <el-input value="JWT (RS256)" disabled style="max-width: 200px;"></el-input>
            <span class="form-tip">24小时有效期</span>
        </el-form-item>
        
        <el-form-item label="心跳间隔">
            <el-input value="5 秒" disabled style="max-width: 200px;"></el-input>
            <span class="form-tip">全局固定，无需配置</span>
        </el-form-item>
        
        <el-form-item label="指纹算法">
            <el-input value="SHA-256 多硬件组合" disabled style="max-width: 200px;"></el-input>
            <span class="form-tip">CPU+硬盘+网卡+主板</span>
        </el-form-item>
        
        <el-form-item label="指纹容错">
            <el-input value="80% 匹配触发审核" disabled style="max-width: 200px;"></el-input>
            <span class="form-tip">硬件变更自动检测</span>
        </el-form-item>
        
        <el-form-item label="环境检测">
            <el-input value="自动检测虚拟机/模拟器" disabled style="max-width: 200px;"></el-input>
            <span class="form-tip">风险设备需人工审核</span>
        </el-form-item>
        
        <el-form-item label="防重放">
            <el-input value="timestamp + nonce + sign" disabled style="max-width: 200px;"></el-input>
            <span class="form-tip">30秒时间窗口</span>
        </el-form-item>
        
        <!-- RSA密钥 -->
        <div class="section-title">加密密钥</div>
        <el-form-item label="RSA公钥">
            <div style="width: 100%;">
                <el-input 
                    v-model="form.public_key" 
                    type="textarea" 
                    :rows="4" 
                    readonly
                    style="font-family: monospace; font-size: 12px;"
                ></el-input>
                <div style="margin-top: 8px;">
                    <el-button type="primary" @click="copyPublicKey">复制公钥</el-button>
                </div>
            </div>
        </el-form-item>
        
        <el-form-item label="重新生成">
            <el-button type="warning" @click="regenerateKeys" :loading="regenerating">
                重新生成密钥对
            </el-button>
            <span class="form-tip" style="color: #e6a23c;">警告：重新生成后，旧客户端将无法连接</span>
        </el-form-item>
        
        <el-form-item>
            <el-button type="primary" @click="handleSubmit" :loading="submitting">保存设置</el-button>
            <el-button @click="navigate('software_list.php')">取消</el-button>
        </el-form-item>
    </el-form>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
softwareId: " . $softwareId . ",
form: {
    id: " . $softwareId . ",
    name: '',
    app_key: '',
    status: 1,
    notice: '',
    enable_trial: false,
    trial_duration: 30,
    trial_unit: 'minute',
    public_key: ''
},
loading: false,
submitting: false,
regenerating: false
";

$vueMounted = "
this.loadData();
";

$vueMethods = "
navigate(url) { window.location.href = url; },
async loadData() {
    this.loading = true;
    try {
        var res = await fetch('api_software.php?action=get&id=' + this.form.id);
        var data = await res.json();
        if (data.code === 0) {
            var d = data.data;
            this.form = {
                id: d.id,
                name: d.name,
                app_key: d.app_key,
                status: parseInt(d.status),
                notice: d.notice || '',
                enable_trial: d.enable_trial == 1,
                trial_duration: parseInt(d.trial_duration || 30),
                trial_unit: d.trial_unit || 'minute',
                public_key: d.public_key || ''
            };
        } else {
            ElementPlus.ElMessage.error(data.msg);
            window.location.href = 'software_list.php';
        }
    } catch (e) {
        ElementPlus.ElMessage.error('网络错误');
        window.location.href = 'software_list.php';
    }
    this.loading = false;
},
copyAppKey() {
    navigator.clipboard.writeText(this.form.app_key).then(() => {
        ElementPlus.ElMessage.success('AppKey已复制到剪贴板');
    }).catch(() => {
        this.fallbackCopy(this.form.app_key, 'AppKey');
    });
},
copyPublicKey() {
    if (!this.form.public_key) {
        ElementPlus.ElMessage.warning('公钥不存在');
        return;
    }
    navigator.clipboard.writeText(this.form.public_key).then(() => {
        ElementPlus.ElMessage.success('公钥已复制到剪贴板');
    }).catch(() => {
        this.fallbackCopy(this.form.public_key, '公钥');
    });
},
fallbackCopy(text, label) {
    var textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    try {
        document.execCommand('copy');
        ElementPlus.ElMessage.success(label + '已复制到剪贴板');
    } catch (e) {
        ElementPlus.ElMessage.error('复制失败');
    }
    document.body.removeChild(textarea);
},
async regenerateKeys() {
    try {
        await ElementPlus.ElMessageBox.confirm(
            '重新生成密钥后，所有使用旧密钥的客户端将无法连接，确定要继续吗？',
            '警告',
            { type: 'warning', confirmButtonText: '确定', cancelButtonText: '取消' }
        );
    } catch (e) {
        return;
    }
    
    this.regenerating = true;
    try {
        var res = await fetch('api_software.php?action=regenerate_keys', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: this.form.id })
        });
        var data = await res.json();
        if (data.code === 0) {
            this.form.public_key = data.data.public_key;
            ElementPlus.ElMessage.success('密钥已重新生成');
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {
        ElementPlus.ElMessage.error('网络错误');
    }
    this.regenerating = false;
},
async handleSubmit() {
    if (!this.form.name || this.form.name.trim() === '') {
        ElementPlus.ElMessage.error('软件名称不能为空');
        return;
    }
    this.submitting = true;
    try {
        var res = await fetch('api_software.php?action=update_settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.form)
        });
        var data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success('保存成功');
            window.location.href = 'software_list.php';
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {
        ElementPlus.ElMessage.error('网络错误');
    }
    this.submitting = false;
}
";

include 'layout.php';
?>
