<?php
$pageTitle = '开发文档';
$breadcrumbs = ['开发文档'];

// 生成文档URL
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
// 获取当前完整路径，然后替换 /admin/docs.php 为 /docs/api.php
$currentUrl = $protocol . '://' . $host . $_SERVER['REQUEST_URI'];
$docUrl = str_replace('/admin/docs.php', '/docs/api.php', $currentUrl);
// 移除可能的查询参数
$docUrl = strtok($docUrl, '?');

$pageStyles = "
.doc-container {
    display: flex;
    justify-content: center;
    padding-top: 60px;
}
.doc-card {
    max-width: 700px;
    width: 100%;
}
.doc-header {
    text-align: center;
    margin-bottom: 30px;
}
.doc-title {
    font-size: 22px;
    font-weight: 600;
    color: #303133;
    margin-bottom: 12px;
}
.doc-desc {
    font-size: 14px;
    color: #909399;
    line-height: 1.6;
}
.doc-url-box {
    background: #f5f7fa;
    padding: 16px;
    border-radius: 8px;
    margin-bottom: 24px;
}
.doc-url {
    font-family: 'Consolas', 'Monaco', monospace;
    font-size: 14px;
    color: #409eff;
    word-break: break-all;
    text-align: center;
}
.doc-actions {
    display: flex;
    gap: 12px;
    justify-content: center;
}
.doc-footer {
    margin-top: 30px;
    padding-top: 24px;
    border-top: 1px solid #ebeef5;
    text-align: center;
    color: #909399;
    font-size: 13px;
}
";

ob_start();
?>

<div class="doc-container">
    <el-card shadow="hover" class="doc-card">
        <div class="doc-header">
            <div class="doc-title">API开发文档</div>
            <div class="doc-desc">
                解决API对接过程中遇到的问题，提供完整的API文档和多语言示例代码<br>
                支持 PHP、Java、Python、C#、Android Studio 等多种编程语言
            </div>
        </div>
        
        <div class="doc-url-box">
            <div class="doc-url">{{ docUrl }}</div>
        </div>
        
        <div class="doc-actions">
            <el-button type="primary" size="large" @click="copyUrl">
                复制文档链接
            </el-button>
            <el-button type="success" size="large" @click="openDoc">
                打开文档
            </el-button>
        </div>
        
        <div class="doc-footer">
            可以把这个地址发给对接的开发人员，方便对接API
        </div>
    </el-card>
</div>

<?php
$pageContent = ob_get_clean();

$vueData = "
docUrl: '" . addslashes($docUrl) . "'
";

$vueMethods = "
openDoc() {
    window.open(this.docUrl, '_blank');
},
copyUrl() {
    navigator.clipboard.writeText(this.docUrl).then(() => {
        ElementPlus.ElMessage.success('链接已复制到剪贴板');
    }).catch(() => {
        ElementPlus.ElMessage.error('复制失败');
    });
}
";

include 'layout.php';
?>
