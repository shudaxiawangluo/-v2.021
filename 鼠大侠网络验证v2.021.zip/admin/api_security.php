<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$db = getDB();

// 确保表存在并添加缺失字段
function ensureTables($db) {
    try {
        // IP白名单表
        $db->exec("CREATE TABLE IF NOT EXISTS ip_whitelist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ip VARCHAR(50) NOT NULL,
            software_id INT DEFAULT 0 COMMENT '0表示全局',
            remark VARCHAR(255) DEFAULT '',
            admin_id INT DEFAULT 0,
            create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_ip (ip),
            INDEX idx_software (software_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='IP白名单'");
        
        // IP黑名单表
        $db->exec("CREATE TABLE IF NOT EXISTS ip_blacklist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ip VARCHAR(50) NOT NULL,
            software_id INT DEFAULT 0 COMMENT '0表示全局',
            reason VARCHAR(255) DEFAULT '',
            admin_id INT DEFAULT 0,
            create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_ip (ip),
            INDEX idx_software (software_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='IP黑名单'");
        
        // 机器码黑名单表
        $db->exec("CREATE TABLE IF NOT EXISTS machine_blacklist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            machine_code VARCHAR(128) NOT NULL,
            software_id INT DEFAULT 0 COMMENT '0表示全局',
            reason VARCHAR(255) DEFAULT '',
            admin_id INT DEFAULT 0,
            create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_machine (machine_code),
            INDEX idx_software (software_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机器码黑名单'");
        
        // 检查并添加缺失字段
        $tables = [
            'ip_whitelist' => ['admin_id' => 'INT DEFAULT 0', 'remark' => 'VARCHAR(255) DEFAULT ""', 'software_id' => 'INT DEFAULT 0'],
            'ip_blacklist' => ['admin_id' => 'INT DEFAULT 0', 'reason' => 'VARCHAR(255) DEFAULT ""', 'software_id' => 'INT DEFAULT 0'],
            'machine_blacklist' => ['admin_id' => 'INT DEFAULT 0', 'reason' => 'VARCHAR(255) DEFAULT ""', 'software_id' => 'INT DEFAULT 0']
        ];
        
        foreach ($tables as $table => $columns) {
            foreach ($columns as $column => $definition) {
                try {
                    $db->exec("ALTER TABLE $table ADD COLUMN $column $definition");
                } catch (PDOException $e) {
                    // 字段已存在，忽略
                }
            }
        }
    } catch (PDOException $e) {
        // 忽略错误
    }
}

ensureTables($db);

switch ($action) {
    // ========== IP白名单 ==========
    case 'whitelist_list':
        $page = intval($_GET['page'] ?? 1);
        $pageSize = intval($_GET['pageSize'] ?? 20);
        $software_id = $_GET['software_id'] ?? '';
        $keyword = $_GET['keyword'] ?? '';
        
        $where = "1=1";
        $params = [];
        
        if ($software_id !== '') {
            $where .= " AND w.software_id = ?";
            $params[] = $software_id;
        }
        if ($keyword !== '') {
            $where .= " AND (w.ip LIKE ? OR w.remark LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        $countStmt = $db->prepare("SELECT COUNT(*) FROM ip_whitelist w WHERE $where");
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        $offset = ($page - 1) * $pageSize;
        $stmt = $db->prepare("SELECT w.*, s.name as software_name FROM ip_whitelist w 
            LEFT JOIN software s ON w.software_id = s.id 
            WHERE $where ORDER BY w.id DESC LIMIT $offset, $pageSize");
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        break;
        
    case 'whitelist_add':
        $input = json_decode(file_get_contents('php://input'), true);
        $ip = trim($input['ip'] ?? '');
        $software_id = intval($input['software_id'] ?? 0);
        $remark = trim($input['remark'] ?? '');
        
        if (empty($ip)) {
            echo json_encode(['code' => 1, 'msg' => 'IP不能为空']);
            exit;
        }
        
        // 支持批量添加（换行分隔）
        $ips = array_filter(array_map('trim', explode("\n", $ip)));
        $added = 0;
        $errors = [];
        
        foreach ($ips as $singleIp) {
            if (empty($singleIp)) continue;
            try {
                $stmt = $db->prepare("INSERT INTO ip_whitelist (ip, software_id, remark, admin_id, create_time) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$singleIp, $software_id, $remark, $_SESSION['admin_id']]);
                $added++;
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'Duplicate') !== false) {
                    $errors[] = "$singleIp 已存在";
                } else {
                    $errors[] = "$singleIp: " . $e->getMessage();
                }
            }
        }
        
        if ($added > 0) {
            echo json_encode(['code' => 0, 'msg' => "成功添加 $added 条"]);
        } else if (!empty($errors)) {
            echo json_encode(['code' => 1, 'msg' => implode('; ', $errors)]);
        } else {
            echo json_encode(['code' => 1, 'msg' => '添加失败']);
        }
        break;
        
    case 'whitelist_delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        $db->prepare("DELETE FROM ip_whitelist WHERE id = ?")->execute([$id]);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
        
    case 'whitelist_batch_delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (!empty($ids)) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("DELETE FROM ip_whitelist WHERE id IN ($placeholders)")->execute($ids);
        }
        echo json_encode(['code' => 0, 'msg' => '批量删除成功']);
        break;

    // ========== IP黑名单 ==========
    case 'blacklist_list':
        $page = intval($_GET['page'] ?? 1);
        $pageSize = intval($_GET['pageSize'] ?? 20);
        $software_id = $_GET['software_id'] ?? '';
        $keyword = $_GET['keyword'] ?? '';
        
        $where = "1=1";
        $params = [];
        
        if ($software_id !== '') {
            $where .= " AND b.software_id = ?";
            $params[] = $software_id;
        }
        if ($keyword !== '') {
            $where .= " AND (b.ip LIKE ? OR b.reason LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        $countStmt = $db->prepare("SELECT COUNT(*) FROM ip_blacklist b WHERE $where");
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        $offset = ($page - 1) * $pageSize;
        $stmt = $db->prepare("SELECT b.*, s.name as software_name FROM ip_blacklist b 
            LEFT JOIN software s ON b.software_id = s.id 
            WHERE $where ORDER BY b.id DESC LIMIT $offset, $pageSize");
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        break;
        
    case 'blacklist_add':
        $input = json_decode(file_get_contents('php://input'), true);
        $ip = trim($input['ip'] ?? '');
        $software_id = intval($input['software_id'] ?? 0);
        $reason = trim($input['reason'] ?? '');
        
        if (empty($ip)) {
            echo json_encode(['code' => 1, 'msg' => 'IP不能为空']);
            exit;
        }
        
        $ips = array_filter(array_map('trim', explode("\n", $ip)));
        $added = 0;
        $errors = [];
        
        foreach ($ips as $singleIp) {
            if (empty($singleIp)) continue;
            try {
                $stmt = $db->prepare("INSERT INTO ip_blacklist (ip, software_id, reason, admin_id, create_time) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$singleIp, $software_id, $reason, $_SESSION['admin_id']]);
                $added++;
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'Duplicate') !== false) {
                    $errors[] = "$singleIp 已存在";
                } else {
                    $errors[] = "$singleIp: " . $e->getMessage();
                }
            }
        }
        
        if ($added > 0) {
            // 记录运行日志
            logRuntime('warning', "IP封禁: {$ip}, 原因: {$reason}", 'security', $_SERVER['REMOTE_ADDR'] ?? '');
            
            // 发送IP封禁通知
            try {
                require_once '../api/notifier.php';
                $notifier = new Notifier($db);
                $notifier->send('ip_blocked', 'IP封禁', 
                    "封禁IP: {$ip}\n" .
                    "原因: {$reason}\n" .
                    "操作人: 管理员\n" .
                    "时间: " . date('Y-m-d H:i:s')
                );
            } catch (Exception $e) {}
            echo json_encode(['code' => 0, 'msg' => "成功添加 $added 条"]);
        } else if (!empty($errors)) {
            echo json_encode(['code' => 1, 'msg' => implode('; ', $errors)]);
        } else {
            echo json_encode(['code' => 1, 'msg' => '添加失败']);
        }
        break;
        
    case 'blacklist_delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        $db->prepare("DELETE FROM ip_blacklist WHERE id = ?")->execute([$id]);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
        
    case 'blacklist_batch_delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (!empty($ids)) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $db->prepare("DELETE FROM ip_blacklist WHERE id IN ($placeholders)")->execute($ids);
        }
        echo json_encode(['code' => 0, 'msg' => '批量删除成功']);
        break;

    // ========== 机器码黑名单 ==========
    case 'machine_list':
        $page = intval($_GET['page'] ?? 1);
        $pageSize = intval($_GET['pageSize'] ?? 20);
        $software_id = $_GET['software_id'] ?? '';
        $keyword = $_GET['keyword'] ?? '';
        
        $where = "1=1";
        $params = [];
        
        if ($software_id !== '') {
            $where .= " AND m.software_id = ?";
            $params[] = $software_id;
        }
        if ($keyword !== '') {
            $where .= " AND (m.machine_code LIKE ? OR m.reason LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        $countStmt = $db->prepare("SELECT COUNT(*) FROM machine_blacklist m WHERE $where");
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        $offset = ($page - 1) * $pageSize;
        $stmt = $db->prepare("SELECT m.*, s.name as software_name FROM machine_blacklist m 
            LEFT JOIN software s ON m.software_id = s.id 
            WHERE $where ORDER BY m.id DESC LIMIT $offset, $pageSize");
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $list, 'total' => $total]);
        break;
        
    case 'machine_add':
        $input = json_decode(file_get_contents('php://input'), true);
        $machine_code = trim($input['machine_code'] ?? '');
        $software_id = intval($input['software_id'] ?? 0);
        $reason = trim($input['reason'] ?? '');
        
        if (empty($machine_code)) {
            echo json_encode(['code' => 1, 'msg' => '机器码不能为空']);
            exit;
        }
        
        $codes = array_filter(array_map('trim', explode("\n", $machine_code)));
        $added = 0;
        $errors = [];
        
        foreach ($codes as $code) {
            if (empty($code)) continue;
            try {
                $stmt = $db->prepare("INSERT INTO machine_blacklist (machine_code, software_id, reason, admin_id, create_time) VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([$code, $software_id, $reason, $_SESSION['admin_id']]);
                $added++;
                // 强制该机器码的用户下线
                $db->prepare("UPDATE users SET is_online = 0, token = NULL WHERE machine_code = ?")->execute([$code]);
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'Duplicate') !== false) {
                    $errors[] = "机器码已存在";
                } else {
                    $errors[] = $e->getMessage();
                }
            }
        }
        
        if ($added > 0) {
            echo json_encode(['code' => 0, 'msg' => "成功添加 $added 条，相关用户已强制下线"]);
        } else if (!empty($errors)) {
            echo json_encode(['code' => 1, 'msg' => implode('; ', $errors)]);
        } else {
            echo json_encode(['code' => 1, 'msg' => '添加失败']);
        }
        break;
        
    case 'machine_delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        
        // 先获取机器码和软件ID
        $stmt = $db->prepare("SELECT machine_code, software_id FROM machine_blacklist WHERE id = ?");
        $stmt->execute([$id]);
        $blacklistRecord = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($blacklistRecord) {
            $machineCode = $blacklistRecord['machine_code'];
            $softwareId = $blacklistRecord['software_id'];
            
            // 删除黑名单记录
            $db->prepare("DELETE FROM machine_blacklist WHERE id = ?")->execute([$id]);
            
            // 同步恢复设备状态（根据机器码或指纹匹配）
            if ($softwareId > 0) {
                // 指定软件的黑名单，只恢复该软件的设备
                $db->prepare("UPDATE devices SET status = 1 WHERE (machine_code = ? OR fingerprint = ?) AND software_id = ? AND status = 0")->execute([$machineCode, $machineCode, $softwareId]);
            } else {
                // 全局黑名单，恢复所有匹配的设备
                $db->prepare("UPDATE devices SET status = 1 WHERE (machine_code = ? OR fingerprint = ?) AND status = 0")->execute([$machineCode, $machineCode]);
            }
            
            echo json_encode(['code' => 0, 'msg' => '解封成功，设备已恢复正常']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '记录不存在']);
        }
        break;
        
    case 'machine_batch_delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (!empty($ids)) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            
            // 先获取所有要删除的机器码
            $stmt = $db->prepare("SELECT machine_code, software_id FROM machine_blacklist WHERE id IN ($placeholders)");
            $stmt->execute($ids);
            $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 删除黑名单记录
            $db->prepare("DELETE FROM machine_blacklist WHERE id IN ($placeholders)")->execute($ids);
            
            // 同步恢复设备状态
            foreach ($records as $record) {
                $machineCode = $record['machine_code'];
                $softwareId = $record['software_id'];
                
                if ($softwareId > 0) {
                    $db->prepare("UPDATE devices SET status = 1 WHERE (machine_code = ? OR fingerprint = ?) AND software_id = ? AND status = 0")->execute([$machineCode, $machineCode, $softwareId]);
                } else {
                    $db->prepare("UPDATE devices SET status = 1 WHERE (machine_code = ? OR fingerprint = ?) AND status = 0")->execute([$machineCode, $machineCode]);
                }
            }
        }
        echo json_encode(['code' => 0, 'msg' => '批量解封成功，设备已恢复正常']);
        break;
    
    // ========== 登录日志 ==========
    case 'login_logs':
        $page = max(1, intval($_GET['page'] ?? 1));
        $pageSize = max(1, min(100, intval($_GET['pageSize'] ?? 20)));
        $offset = ($page - 1) * $pageSize;
        
        $where = "1=1";
        $params = [];
        
        if (!empty($_GET['account_type'])) {
            $where .= " AND action = ?";
            $params[] = $_GET['account_type'];
        }
        if (isset($_GET['success']) && $_GET['success'] !== '') {
            if ($_GET['success'] == 1) {
                $where .= " AND response_code = 200";
            } else {
                $where .= " AND response_code != 200";
            }
        }
        if (!empty($_GET['keyword'])) {
            $where .= " AND (fingerprint LIKE ? OR ip LIKE ? OR response_msg LIKE ?)";
            $keyword = '%' . $_GET['keyword'] . '%';
            $params[] = $keyword;
            $params[] = $keyword;
            $params[] = $keyword;
        }
        
        try {
            // 优先查询 auth_logs 表（V2系统）
            $countSql = "SELECT COUNT(*) FROM auth_logs WHERE $where";
            $stmt = $db->prepare($countSql);
            $stmt->execute($params);
            $total = $stmt->fetchColumn();
            
            $sql = "SELECT a.id, a.action as account_type, 
                           COALESCE(a.fingerprint, '-') as account, 
                           a.ip, 
                           CASE WHEN a.response_code = 200 THEN 1 ELSE 0 END as success, 
                           CONCAT('code=', a.response_code, ' ', COALESCE(a.response_msg, '')) as user_agent, 
                           a.create_time,
                           s.name as software_name
                    FROM auth_logs a
                    LEFT JOIN software s ON a.software_id = s.id
                    WHERE $where ORDER BY a.id DESC LIMIT $offset, $pageSize";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['code' => 0, 'data' => $list, 'total' => intval($total)]);
        } catch (Exception $e) {
            echo json_encode(['code' => 0, 'data' => [], 'total' => 0, 'error' => $e->getMessage()]);
        }
        break;
    
    case 'clear_login_logs':
        $db->exec("TRUNCATE TABLE auth_logs");
        
        $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$_SESSION['admin_id'], "清空认证日志", $_SERVER['REMOTE_ADDR']]);
        
        echo json_encode(['code' => 0, 'msg' => '清空成功']);
        break;

    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
