<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true);

switch ($action) {
    case 'encrypt':
        $code = $input['code'] ?? '';
        $language = $input['language'] ?? 'auto';
        
        if (empty($code)) {
            echo json_encode(['code' => 1, 'msg' => '代码不能为空']);
            exit;
        }
        
        if ($language === 'auto') {
            $language = detectLanguage($code);
        }
        
        $langNames = [
            'javascript' => 'JavaScript',
            'php' => 'PHP',
            'python' => 'Python',
            'java' => 'Java',
            'csharp' => 'C#',
            'html' => 'HTML'
        ];
        
        try {
            $result = encryptCode($code, $language);
            echo json_encode(['code' => 0, 'data' => $result, 'detected' => $langNames[$language] ?? $language]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '加密失败：' . $e->getMessage()]);
        }
        break;
        
    case 'decrypt':
        $code = $input['code'] ?? '';
        $language = $input['language'] ?? 'auto';
        
        if (empty($code)) {
            echo json_encode(['code' => 1, 'msg' => '代码不能为空']);
            exit;
        }
        
        if ($language === 'auto') {
            $language = detectLanguage($code);
        }
        
        try {
            $result = decryptCode($code, $language);
            echo json_encode(['code' => 0, 'data' => $result]);
        } catch (Exception $e) {
            echo json_encode(['code' => 1, 'msg' => '解密失败：' . $e->getMessage()]);
        }
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}

// 自动识别语言
function detectLanguage($code) {
    $code = trim($code);
    
    if (preg_match('/<\?php|\$[a-zA-Z_]|->|::|function\s+\w+\s*\(.*\)\s*{/', $code)) {
        return 'php';
    }
    if (preg_match('/\bdef\s+\w+\s*\(|\bimport\s+\w+|\bprint\s*\(/', $code)) {
        return 'python';
    }
    if (preg_match('/\bpublic\s+class\s+|\bSystem\.out\.print/', $code)) {
        return 'java';
    }
    if (preg_match('/\busing\s+System|\bConsole\.Write/', $code)) {
        return 'csharp';
    }
    if (preg_match('/<html|<div|<script|<!DOCTYPE/i', $code)) {
        return 'html';
    }
    return 'javascript';
}

// 加密主函数
function encryptCode($code, $language) {
    switch ($language) {
        case 'javascript':
            return encryptJS($code);
        case 'php':
            return encryptPHP($code);
        case 'python':
            return encryptPython($code);
        case 'java':
            return encryptJava($code);
        case 'csharp':
            return encryptCSharp($code);
        case 'html':
            return encryptHTML($code);
        default:
            return encryptJS($code);
    }
}

// 解密主函数
function decryptCode($code, $language) {
    switch ($language) {
        case 'php':
            return decryptPHP($code);
        case 'javascript':
            return decryptJS($code);
        case 'python':
            return decryptPython($code);
        default:
            // 尝试自动检测
            if (preg_match('/gzinflate\s*\(\s*base64_decode/', $code)) {
                return decryptPHP($code);
            }
            if (preg_match('/eval\s*\(\s*atob/', $code)) {
                return decryptJS($code);
            }
            return $code;
    }
}

// PHP解密
function decryptPHP($code) {
    // 方式1: 我们的加密方式 - 变量拆分 + gzinflate + base64
    // 提取所有变量赋值 (格式: $_xxxxxxxxxx = 'xxxxx';)
    preg_match_all('/\$(_[a-f0-9]+)\s*=\s*\'([^\']+)\';/i', $code, $varMatches);
    
    if (!empty($varMatches[1])) {
        // 构建变量名到值的映射
        $vars = [];
        for ($i = 0; $i < count($varMatches[1]); $i++) {
            $vars['$' . $varMatches[1][$i]] = $varMatches[2][$i];
        }
        
        // 查找 $_sdxData 的拼接表达式
        if (preg_match('/\$_sdxData\s*=\s*([^;]+);/', $code, $dataMatch)) {
            $varExpr = $dataMatch[1];
            
            // 提取拼接顺序中的变量名
            preg_match_all('/\$_[a-f0-9]+/', $varExpr, $orderMatches);
            
            $allData = '';
            foreach ($orderMatches[0] as $varName) {
                if (isset($vars[$varName])) {
                    $allData .= $vars[$varName];
                }
            }
            
            // 尝试解密
            if (!empty($allData)) {
                $decoded = base64_decode($allData);
                if ($decoded !== false) {
                    $decompressed = @gzinflate($decoded);
                    if ($decompressed !== false) {
                        return $decompressed;
                    }
                }
            }
        }
    }
    
    // 方式2: 简单的 eval(base64_decode('...'))
    if (preg_match("/eval\s*\(\s*base64_decode\s*\(\s*['\"]([^'\"]+)['\"]\s*\)\s*\)/", $code, $match)) {
        $decoded = base64_decode($match[1]);
        if ($decoded !== false) {
            return "<?php\n" . $decoded . "\n?>";
        }
    }
    
    // 方式3: eval(gzinflate(base64_decode('...')))
    if (preg_match("/eval\s*\(\s*gzinflate\s*\(\s*base64_decode\s*\(\s*['\"]([^'\"]+)['\"]\s*\)\s*\)\s*\)/", $code, $match)) {
        $decoded = base64_decode($match[1]);
        if ($decoded !== false) {
            $decompressed = @gzinflate($decoded);
            if ($decompressed !== false) {
                return "<?php\n" . $decompressed . "\n?>";
            }
        }
    }
    
    return "解密失败：无法识别的加密格式";
}

// JS解密
function decryptJS($code) {
    if (preg_match("/eval\s*\(\s*atob\s*\(\s*['\"]([^'\"]+)['\"]\s*\)\s*\)/", $code, $match)) {
        return base64_decode($match[1]);
    }
    return $code;
}

// Python解密
function decryptPython($code) {
    if (preg_match("/exec\s*\(\s*base64\.b64decode\s*\(\s*['\"]([^'\"]+)['\"]\s*\)/", $code, $match)) {
        return base64_decode($match[1]);
    }
    return $code;
}

// JavaScript加密
function encryptJS($code) {
    // 移除注释
    $code = preg_replace('/\/\/.*$/m', '', $code);
    $code = preg_replace('/\/\*[\s\S]*?\*\//', '', $code);
    // 压缩空白
    $code = preg_replace('/\s+/', ' ', $code);
    $code = trim($code);
    // base64编码
    $encoded = base64_encode($code);
    return "eval(atob('" . $encoded . "'));";
}

// PHP加密 - 变量拆分混淆方式
function encryptPHP($code) {
    // 不移除PHP标签，保持原样
    $originalCode = $code;
    
    // 生成混淆代码
    return generateObfuscatedPHP($originalCode);
}

// 生成混淆的PHP代码
function generateObfuscatedPHP($code) {
    // 先对整个代码进行gzip压缩，再base64编码
    $compressed = gzdeflate($code, 9);
    $encoded = base64_encode($compressed);
    
    // 将编码后的字符串拆分成多个变量
    $chunks = str_split($encoded, 70);
    
    $result = "<?php\n";
    $result .= "/*\n";
    $result .= " * Protected by ShuDaXia Code Protector\n";
    $result .= " * Generated: " . date('Y-m-d H:i:s') . "\n";
    $result .= " */\n\n";
    
    $varNames = [];
    foreach ($chunks as $index => $chunk) {
        // 生成随机变量名
        $varName = '_' . substr(md5('sdx' . $index . time()), 0, 10);
        $varNames[] = '$' . $varName;
        $result .= '$' . $varName . " = '" . $chunk . "';\n";
    }
    
    $result .= "\n";
    
    // 拼接所有变量
    $result .= '$_sdxData = ' . implode(" . \n", $varNames) . ";\n\n";
    
    // 解码并执行 - 使用 gzinflate 解压
    $result .= '$_sdxCode = gzinflate(base64_decode($_sdxData));' . "\n";
    $result .= 'eval("?>" . $_sdxCode);' . "\n";
    
    return $result;
}

// Python加密
function encryptPython($code) {
    // 移除注释（简单处理）
    $lines = explode("\n", $code);
    $result = [];
    foreach ($lines as $line) {
        $pos = strpos($line, '#');
        if ($pos !== false) {
            $line = substr($line, 0, $pos);
        }
        if (trim($line) !== '') {
            $result[] = $line;
        }
    }
    $code = implode("\n", $result);
    // base64编码
    $encoded = base64_encode($code);
    return "import base64\nexec(base64.b64decode('" . $encoded . "').decode('utf-8'))";
}

// Java加密（只做混淆压缩）
function encryptJava($code) {
    $code = preg_replace('/\/\/.*$/m', '', $code);
    $code = preg_replace('/\/\*[\s\S]*?\*\//', '', $code);
    $code = preg_replace('/\s+/', ' ', $code);
    return trim($code);
}

// C#加密（只做混淆压缩）
function encryptCSharp($code) {
    $code = preg_replace('/\/\/.*$/m', '', $code);
    $code = preg_replace('/\/\*[\s\S]*?\*\//', '', $code);
    $code = preg_replace('/\s+/', ' ', $code);
    return trim($code);
}

// HTML加密
function encryptHTML($code) {
    // 移除注释
    $code = preg_replace('/<!--[\s\S]*?-->/', '', $code);
    $code = preg_replace('/\/\*[\s\S]*?\*\//', '', $code);
    // 压缩
    $code = preg_replace('/\s+/', ' ', $code);
    $code = preg_replace('/>\s+</', '><', $code);
    return trim($code);
}
