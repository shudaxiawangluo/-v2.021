<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../api/config.php';

// 检测是否已安装
try {
    $db = getDB();
    $stmt = $db->query("SELECT COUNT(*) FROM admins");
    if ($stmt->fetchColumn() == 0) {
        header('Location: ../install.php');
        exit;
    }
} catch (Exception $e) {
    header('Location: ../install.php');
    exit;
}

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$envMode = isServerMode() ? '服务器模式' : '本地模式';
$envType = isServerMode() ? 'success' : 'warning';
$currentPage = basename($_SERVER['PHP_SELF'], '.php');

// 构建JavaScript代码
$vueDataStr = isset($vueData) && trim($vueData) !== '' ? trim($vueData) : '';
$vueMountedStr = isset($vueMounted) && trim($vueMounted) !== '' ? trim($vueMounted) : '';
$vueMethodsStr = isset($vueMethods) && trim($vueMethods) !== '' ? trim($vueMethods) : '';
$vueComputedStr = isset($vueComputed) && trim($vueComputed) !== '' ? trim($vueComputed) : '';
$pageStylesStr = isset($pageStyles) && trim($pageStyles) !== '' ? trim($pageStyles) : '';

// 构建完整的data对象
$dataCode = "{\n                    isDark: false";
if ($vueDataStr !== '') {
    $dataCode .= ",\n                    " . $vueDataStr;
}
$dataCode .= "\n                }";

// 构建mounted代码
$mountedCode = "const darkMode = localStorage.getItem('dark-mode');\n";
$mountedCode .= "                if (darkMode === 'true') {\n";
$mountedCode .= "                    this.isDark = true;\n";
$mountedCode .= "                    document.documentElement.classList.add('dark');\n";
$mountedCode .= "                }";
if ($vueMountedStr !== '') {
    $mountedCode .= "\n                " . $vueMountedStr;
}

// 构建methods对象
$methodsCode = "navigate(url) { window.location.href = url; },\n";
$methodsCode .= "                toggleDark() {\n";
$methodsCode .= "                    if (this.isDark) {\n";
$methodsCode .= "                        document.documentElement.classList.add('dark');\n";
$methodsCode .= "                        localStorage.setItem('dark-mode', 'true');\n";
$methodsCode .= "                    } else {\n";
$methodsCode .= "                        document.documentElement.classList.remove('dark');\n";
$methodsCode .= "                        localStorage.setItem('dark-mode', 'false');\n";
$methodsCode .= "                    }\n";
$methodsCode .= "                },\n";
$methodsCode .= "                handleCommand(cmd) {\n";
$methodsCode .= "                    if (cmd === 'logout') window.location.href = 'logout.php';\n";
$methodsCode .= "                    else if (cmd === 'profile') window.location.href = 'settings.php';\n";
$methodsCode .= "                    else if (cmd === 'settings') window.location.href = 'settings.php?tab=general';\n";
$methodsCode .= "                }";
if ($vueMethodsStr !== '') {
    $methodsCode .= ",\n                " . $vueMethodsStr;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? '鼠大侠授权系统') ?></title>
    <!-- 本地资源 -->
    <link rel="stylesheet" href="assets/libs/element-plus.min.css">
    <link rel="stylesheet" href="assets/libs/dark.css">
    <script src="assets/libs/vue.min.js"></script>
    <script src="assets/libs/element-plus.min.js"></script>
    <script src="assets/libs/icons-vue.min.js"></script>
    <?php 
    // 只在需要图表的页面加载echarts
    $needEcharts = in_array($currentPage, ['stats_overview', 'stats_user', 'stats_income', 'dashboard', 'api_stats_page']);
    if ($needEcharts): 
    ?>
    <script src="assets/libs/echarts.min.js"></script>
    <?php endif; ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; }
        html.dark { color-scheme: dark; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', 'Helvetica Neue', Helvetica, Arial, sans-serif; background: var(--el-bg-color-page); }
        [v-cloak] { display: none; }
        .layout { display: flex; height: 100vh; }
        .sidebar { width: 220px; background: var(--el-bg-color); border-right: 1px solid var(--el-border-color); display: flex; flex-direction: column; flex-shrink: 0; }
        .logo { height: 56px; display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 15px; font-weight: 500; color: var(--el-text-color-primary); padding: 0 16px; }
        .logo img { height: 32px; width: 32px; object-fit: contain; }
        .el-menu { border: none; flex: 1; overflow-y: auto; padding: 8px 12px; }
        .el-menu-item, .el-sub-menu__title { height: 40px !important; line-height: 40px !important; border-radius: 6px !important; margin-bottom: 4px !important; transition: background-color 0.2s ease !important; font-size: 14px !important; }
        .el-sub-menu .el-menu-item { height: 36px !important; line-height: 36px !important; padding-left: 48px !important; border-radius: 6px !important; margin: 2px 0 !important; font-size: 13px !important; }
        .el-menu-item.is-active { background-color: #e6f7ff !important; color: #1890ff !important; font-weight: 500 !important; }
        .el-menu-item:hover, .el-sub-menu__title:hover { background-color: #f5f7fa !important; }
        .el-menu-item.is-active:hover { background-color: #d6efff !important; }
        .el-menu--inline { background-color: transparent !important; }
        /* GPU加速菜单动画 */
        .el-sub-menu .el-menu { transform: translateZ(0); backface-visibility: hidden; }
        .el-sub-menu__icon-arrow { transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important; }
        .el-menu-vertical-demo .el-menu--inline { overflow: hidden; }
        html.dark .el-menu-item:hover, html.dark .el-sub-menu__title:hover { background-color: rgba(255, 255, 255, 0.05) !important; }
        html.dark .el-menu-item.is-active { background-color: rgba(64, 158, 255, 0.15) !important; }
        html.dark .el-menu-item.is-active:hover { background-color: rgba(64, 158, 255, 0.25) !important; }
        .sidebar-footer { padding: 12px; border-top: 1px solid var(--el-border-color); text-align: center; display: flex; justify-content: center; gap: 8px; }
        .main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .header { height: 56px; background: var(--el-bg-color); padding: 0 20px; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; border-bottom: 1px solid var(--el-border-color-light); }
        .content { flex: 1; padding: 16px; overflow-y: auto; background: var(--el-bg-color-page); }
        .breadcrumb-container { padding: 8px 0 4px 0; margin-bottom: 12px; }
        .el-breadcrumb { font-size: 13px; }
        .user-avatar { width: 28px; height: 28px; border-radius: 4px; background: var(--el-color-primary); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 14px; }
        .el-dropdown { outline: none !important; }
        .el-dropdown:focus { outline: none !important; }
        /* 移动端适配 */
        .menu-toggle { display: none; }
        @media screen and (max-width: 768px) {
            .layout { flex-direction: column; }
            .sidebar { width: 100%; height: auto; max-height: 56px; overflow: hidden; transition: max-height 0.3s ease; }
            .sidebar.expanded { max-height: 100vh; overflow-y: auto; }
            .logo { height: 56px; justify-content: space-between; }
            .menu-toggle { display: flex !important; cursor: pointer; padding: 8px; align-items: center; }
            .el-menu { display: none; padding: 4px 8px; }
            .sidebar.expanded .el-menu { display: block; }
            .sidebar-footer { display: none; }
            .main { height: calc(100vh - 56px); }
            .header { height: 50px; padding: 0 12px; }
            .content { padding: 12px; }
            .el-card { margin-bottom: 12px !important; }
            .el-table { font-size: 12px; }
            .el-button--small { padding: 5px 8px; font-size: 12px; }
            .el-row { margin-left: -6px !important; margin-right: -6px !important; }
            .el-col { padding-left: 6px !important; padding-right: 6px !important; margin-bottom: 12px; }
        }
        @media screen and (max-width: 480px) {
            .header > div:last-child > div:first-child { display: none; }
            .content { padding: 8px; }
        }
        <?= $pageStylesStr ?>
    </style>
</head>
<body>
    <div id="app" v-cloak>
        <div class="layout">
            <div class="sidebar" :class="{ expanded: menuExpanded }">
                <div class="logo">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <img src="../img/鼠大侠logo.png" alt="Logo">
                        <span>鼠大侠授权系统</span>
                    </div>
                    <div class="menu-toggle" @click="menuExpanded = !menuExpanded" style="display: none;">
                        <el-icon :size="20"><el-icon-menu /></el-icon>
                    </div>
                </div>
                <el-menu ref="sideMenu" :default-active="'<?= $currentPage ?>'" :default-openeds="openedMenus" @select="handleMenuSelect" @open="handleMenuOpen">
                    <el-menu-item index="dashboard"><el-icon><odometer /></el-icon><span>控制台</span></el-menu-item>
                    <el-sub-menu index="software">
                        <template #title><el-icon><box /></el-icon><span>软件管理</span></template>
                        <el-menu-item index="software_list">软件列表</el-menu-item>
                        <el-menu-item index="software_add">添加软件</el-menu-item>
                    </el-sub-menu>
                    <el-menu-item index="authcode_list"><el-icon><key /></el-icon><span>卡密管理</span></el-menu-item>
                    <el-menu-item index="device_list"><el-icon><monitor /></el-icon><span>设备管理</span></el-menu-item>
                    <el-sub-menu index="agent">
                        <template #title><el-icon><avatar /></el-icon><span>代理商</span></template>
                        <el-menu-item index="agent_list">代理列表</el-menu-item>
                        <el-menu-item index="agent_recharge">充值记录</el-menu-item>
                        <el-menu-item index="agent_withdraw">提现审核</el-menu-item>
                    </el-sub-menu>
                    <el-sub-menu index="order">
                        <template #title><el-icon><shopping-cart /></el-icon><span>订单管理</span></template>
                        <el-menu-item index="order_list">订单列表</el-menu-item>
                        <el-menu-item index="product_list">商品管理</el-menu-item>
                        <el-menu-item index="payment_config">支付配置</el-menu-item>
                    </el-sub-menu>
                    <el-sub-menu index="remote">
                        <template #title><el-icon><cloudy /></el-icon><span>云控制</span></template>
                        <el-menu-item index="remote_var">远程变量</el-menu-item>
                        <el-menu-item index="announcement">公告管理</el-menu-item>
                        <el-menu-item index="version_list">版本管理</el-menu-item>
                        <el-menu-item index="remote_switch">远程开关</el-menu-item>
                    </el-sub-menu>
                    <el-sub-menu index="security">
                        <template #title><el-icon><lock /></el-icon><span>安全中心</span></template>
                        <el-menu-item index="ip_whitelist">IP白名单</el-menu-item>
                        <el-menu-item index="ip_blacklist">IP黑名单</el-menu-item>
                        <el-menu-item index="machine_blacklist">机器码黑名单</el-menu-item>
                        <el-menu-item index="login_logs">登录日志</el-menu-item>
                    </el-sub-menu>
                    <el-sub-menu index="stats">
                        <template #title><el-icon><data-analysis /></el-icon><span>数据统计</span></template>
                        <el-menu-item index="stats_income">收入统计</el-menu-item>
                        <el-menu-item index="promotion_stats">推广统计</el-menu-item>
                    </el-sub-menu>
                    <el-sub-menu index="notify">
                        <template #title><el-icon><bell /></el-icon><span>消息通知</span></template>
                        <el-menu-item index="notify_config">通知配置</el-menu-item>
                        <el-menu-item index="notify_template">消息模板</el-menu-item>
                        <el-menu-item index="notify_logs">发送记录</el-menu-item>
                    </el-sub-menu>
                    <el-sub-menu index="api">
                        <template #title><el-icon><connection /></el-icon><span>API管理</span></template>
                        <el-menu-item index="custom_api">自定义API</el-menu-item>
                        <el-menu-item index="webhook_list">Webhook</el-menu-item>
                        <el-menu-item index="api_stats_page">调用统计</el-menu-item>
                    </el-sub-menu>
                    <el-sub-menu index="logs">
                        <template #title><el-icon><document /></el-icon><span>日志管理</span></template>
                        <el-menu-item index="log_operation">操作日志</el-menu-item>
                        <el-menu-item index="log_runtime">运行日志</el-menu-item>
                    </el-sub-menu>
                    <el-sub-menu index="tools">
                        <template #title><el-icon><tools /></el-icon><span>工具箱</span></template>
                        <el-menu-item index="code_encrypt">代码加密</el-menu-item>
                        <el-menu-item index="backup">数据备份</el-menu-item>
                    </el-sub-menu>
                    <el-menu-item index="settings"><el-icon><setting /></el-icon><span>系统设置</span></el-menu-item>
                    <el-menu-item index="docs"><el-icon><reading /></el-icon><span>开发文档</span></el-menu-item>
                </el-menu>
                <div class="sidebar-footer">
                    <el-tag size="small" style="cursor:default; background: #f4f4f5; border-color: #e4e7ed; color: #909399;">V2.02</el-tag>
                    <el-tag type="primary" size="small" style="cursor:pointer" @click="joinQQGroup">交流群</el-tag>
                    <el-tag type="<?= $envType ?>" size="small"><?= $envMode ?></el-tag>
                </div>
            </div>

            <div class="main">
                <div class="header">
                    <div></div>
                    <div style="display: flex; align-items: center; gap: 20px;">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span style="font-size: 13px; color: var(--el-text-color-secondary);">切换主题</span>
                            <el-switch v-model="isDark" size="small" @change="toggleDark" />
                        </div>
                        <el-dropdown @command="handleCommand">
                            <span style="cursor: pointer; display: flex; align-items: center; gap: 8px; outline: none;">
                                <div class="user-avatar"><el-icon><user /></el-icon></div>
                                <span style="font-size: 13px;"><?= htmlspecialchars($_SESSION['admin_name']) ?></span>
                                <el-icon :size="12"><arrow-down /></el-icon>
                            </span>
                            <template #dropdown>
                                <el-dropdown-menu>
                                    <el-dropdown-item command="profile"><el-icon><user /></el-icon>个人中心</el-dropdown-item>
                                    <el-dropdown-item command="settings"><el-icon><setting /></el-icon>账号设置</el-dropdown-item>
                                    <el-dropdown-item divided command="logout"><el-icon><switch-button /></el-icon>退出登录</el-dropdown-item>
                                </el-dropdown-menu>
                            </template>
                        </el-dropdown>
                    </div>
                </div>

                <div class="content">
                    <div class="breadcrumb-container">
                        <el-breadcrumb separator="/">
                            <el-breadcrumb-item>首页</el-breadcrumb-item>
                            <?php if (isset($breadcrumbs) && is_array($breadcrumbs)): ?>
                                <?php foreach ($breadcrumbs as $crumb): ?>
                                    <el-breadcrumb-item><?= htmlspecialchars($crumb) ?></el-breadcrumb-item>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </el-breadcrumb>
                    </div>
                    <?= $pageContent ?? '' ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // 检查依赖是否加载
        if (typeof Vue === 'undefined') {
            console.error('Vue未加载');
            document.body.innerHTML = '<div style="padding:50px;text-align:center;color:red;">Vue.js加载失败，请检查网络或刷新页面</div>';
        } else if (typeof ElementPlus === 'undefined') {
            console.error('ElementPlus未加载');
            document.body.innerHTML = '<div style="padding:50px;text-align:center;color:red;">Element Plus加载失败，请检查网络或刷新页面</div>';
        } else {
        
        const { createApp } = Vue;
        
        // 菜单与父级的映射关系
        const menuParentMap = {
            'software_list': 'software', 'software_add': 'software', 'software_edit': 'software',
            'agent_list': 'agent', 'agent_recharge': 'agent', 'agent_withdraw': 'agent',
            'order_list': 'order', 'product_list': 'order', 'payment_config': 'order',
            'remote_var': 'remote', 'announcement': 'remote', 'version_list': 'remote', 'remote_switch': 'remote',
            'ip_whitelist': 'security', 'ip_blacklist': 'security', 'machine_blacklist': 'security', 'login_logs': 'security',
            'stats_income': 'stats', 'promotion_stats': 'stats',
            'notify_config': 'notify', 'notify_template': 'notify', 'notify_logs': 'notify',
            'custom_api': 'api', 'webhook_list': 'api', 'api_stats_page': 'api',
            'log_operation': 'logs', 'log_runtime': 'logs',
            'code_encrypt': 'tools',
            'backup': 'tools'
        };
        
        // 获取当前页面需要展开的菜单 - 只展开当前页面所属的父菜单
        const currentPage = '<?= $currentPage ?>';
        const parentMenu = menuParentMap[currentPage];
        
        // 只展开当前页面的父菜单，不保存多个展开状态
        let initialOpeneds = parentMenu ? [parentMenu] : [];
        
        const app = createApp({
            data() {
                return {
                    isDark: false,
                    openedMenus: initialOpeneds,
                    currentOpenMenu: initialOpeneds[0] || '',
                    menuExpanded: false,
                    <?php if ($vueDataStr !== ''): ?><?= $vueDataStr ?><?php endif; ?>
                };
            },
            <?php if ($vueComputedStr !== ''): ?>
            computed: {
                <?= $vueComputedStr ?>
            },
            <?php endif; ?>
            mounted() {
                <?= $mountedCode ?>
            },
            methods: {
                handleMenuSelect(index) {
                    // 跳转页面
                    window.location.href = index + '.php';
                },
                handleMenuOpen(index) {
                    // 关闭其他已展开的菜单
                    var self = this;
                    if (self.currentOpenMenu && self.currentOpenMenu !== index && self.$refs.sideMenu) {
                        self.$refs.sideMenu.close(self.currentOpenMenu);
                    }
                    self.currentOpenMenu = index;
                },
                toggleDark() {
                    if (this.isDark) {
                        document.documentElement.classList.add('dark');
                        localStorage.setItem('dark-mode', 'true');
                    } else {
                        document.documentElement.classList.remove('dark');
                        localStorage.setItem('dark-mode', 'false');
                    }
                },
                joinQQGroup() {
                    // 打开QQ群
                    window.open('https://qm.qq.com/q/wNUZHrgVAk', '_blank');
                },
                handleCommand(cmd) {
                    if (cmd === 'logout') window.location.href = 'logout.php';
                    else if (cmd === 'profile') window.location.href = 'settings.php';
                    else if (cmd === 'settings') window.location.href = 'settings.php?tab=general';
                }<?php if ($vueMethodsStr !== ''): ?>,
                <?= $vueMethodsStr ?><?php endif; ?>
            }
        });
        app.use(ElementPlus);
        // 注册图标组件
        if (typeof ElementPlusIconsVue !== 'undefined') {
            for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
                app.component(key, component);
            }
        } else {
            console.warn('ElementPlusIconsVue未加载，图标可能无法显示');
        }
        app.mount('#app');
        
        } // end of else block for dependency check
    </script>
</body>
</html>
