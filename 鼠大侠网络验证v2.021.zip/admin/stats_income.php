<?php
$pageTitle = '收入统计';
$breadcrumbs = ['数据统计', '收入统计'];

$pageStyles = "
.stat-item { 
    padding: 16px 20px; 
    background: var(--el-bg-color-overlay); 
    border-radius: 8px; 
    border: 1px solid var(--el-border-color-lighter);
    transition: all 0.3s;
}
.stat-item:hover { box-shadow: 0 2px 12px rgba(0,0,0,0.08); transform: translateY(-2px); }
.stat-item-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.stat-title { font-size: 13px; color: var(--el-text-color-secondary); }
.stat-icon { width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
.stat-value { font-size: 28px; font-weight: 600; margin-bottom: 10px; line-height: 1; }
.color-blue { color: #409eff; } .bg-blue { background-color: rgba(64, 158, 255, 0.1); }
.color-orange { color: #e6a23c; } .bg-orange { background-color: rgba(230, 162, 60, 0.1); }
.card-header-title { font-size: 14px; font-weight: 500; }
";

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" value-format="YYYY-MM-DD" style="width: 260px;" @change="loadData"></el-date-picker>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon>查询</el-button>
    </div>
</div>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :span="12">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">订单数</span>
                <div class="stat-icon bg-blue color-blue"><el-icon><shopping-cart /></el-icon></div>
            </div>
            <div class="stat-value">{{ totalStats.orders || 0 }}</div>
        </div>
    </el-col>
    <el-col :span="12">
        <div class="stat-item">
            <div class="stat-item-header">
                <span class="stat-title">总收入</span>
                <div class="stat-icon bg-orange color-orange"><el-icon><money /></el-icon></div>
            </div>
            <div class="stat-value" style="color: #e6a23c;">¥{{ parseFloat(totalStats.income || 0).toFixed(2) }}</div>
        </div>
    </el-col>
</el-row>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :span="16">
        <el-card shadow="hover">
            <template #header><span class="card-header-title">收入趋势</span></template>
            <div ref="incomeChartRef" style="height: 350px;"></div>
        </el-card>
    </el-col>
    <el-col :span="8">
        <el-card shadow="hover">
            <template #header><span class="card-header-title">软件收入排行</span></template>
            <div ref="barChartRef" style="height: 350px;"></div>
        </el-card>
    </el-col>
</el-row>

<el-row :gutter="16">
    <el-col :span="12">
        <el-card shadow="hover">
            <template #header><span class="card-header-title">每日收入明细</span></template>
            <el-table :data="dailyData" size="small" max-height="300">
                <el-table-column prop="date" label="日期" width="120"></el-table-column>
                <el-table-column prop="orders" label="订单数" width="100" align="center"></el-table-column>
                <el-table-column label="收入" align="right">
                    <template #default="scope"><span style="color: #e6a23c; font-weight: 500;">¥{{ parseFloat(scope.row.income || 0).toFixed(2) }}</span></template>
                </el-table-column>
            </el-table>
        </el-card>
    </el-col>
    <el-col :span="12">
        <el-card shadow="hover">
            <template #header><span class="card-header-title">软件收入统计</span></template>
            <el-table :data="softwareData" size="small" max-height="300">
                <el-table-column prop="name" label="软件名称"></el-table-column>
                <el-table-column prop="orders" label="订单数" width="100" align="center"></el-table-column>
                <el-table-column label="收入" width="120" align="right">
                    <template #default="scope"><span style="color: #e6a23c; font-weight: 500;">¥{{ parseFloat(scope.row.income || 0).toFixed(2) }}</span></template>
                </el-table-column>
            </el-table>
        </el-card>
    </el-col>
</el-row>

<?php
$pageContent = ob_get_clean();

$vueData = "
dateRange: [new Date(new Date().setDate(1)).toISOString().split('T')[0], new Date().toISOString().split('T')[0]],
dailyData: [],
softwareData: [],
totalStats: { orders: 0, income: 0 },
incomeChart: null,
barChart: null
";

$vueMounted = "this.loadData();";

$vueMethods = "
loadData() {
    var self = this;
    var params = new URLSearchParams({
        action: 'income_stats',
        start_date: this.dateRange ? this.dateRange[0] : '',
        end_date: this.dateRange ? this.dateRange[1] : ''
    });
    fetch('api_stats.php?' + params)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.code === 0) {
                self.dailyData = data.data.daily || [];
                self.softwareData = data.data.software || [];
                self.totalStats = data.data.total || { orders: 0, income: 0 };
                self.\$nextTick(function() {
                    self.renderIncomeChart();
                    self.renderBarChart();
                });
            }
        })
        .catch(function(e) { console.error(e); });
},
renderIncomeChart() {
    if (typeof echarts === 'undefined' || !this.\$refs.incomeChartRef) return;
    if (!this.incomeChart) this.incomeChart = echarts.init(this.\$refs.incomeChartRef);
    var daily = this.dailyData || [];
    if (daily.length === 0) {
        this.incomeChart.setOption({ title: { text: '暂无数据', left: 'center', top: 'center', textStyle: { color: '#999', fontSize: 14 } } });
        return;
    }
    this.incomeChart.setOption({
        tooltip: { trigger: 'axis' },
        legend: { data: ['订单数', '收入'], bottom: 0 },
        grid: { left: '3%', right: '4%', bottom: '12%', top: '10%', containLabel: true },
        xAxis: { type: 'category', data: daily.map(function(i) { return i.date; }), boundaryGap: false, axisLine: { lineStyle: { color: '#e4e7ed' } }, axisTick: { show: false } },
        yAxis: [{ type: 'value', name: '订单', axisLine: { show: false }, axisTick: { show: false }, splitLine: { lineStyle: { color: '#f0f0f0' } } }, { type: 'value', name: '收入', axisLine: { show: false }, axisTick: { show: false }, splitLine: { show: false } }],
        series: [
            { name: '订单数', type: 'line', smooth: true, data: daily.map(function(i) { return parseInt(i.orders) || 0; }), itemStyle: { color: '#409eff' }, lineStyle: { width: 2, color: '#409eff' }, symbol: 'circle', symbolSize: 6, showSymbol: true, connectNulls: true },
            { name: '收入', type: 'line', yAxisIndex: 1, smooth: true, data: daily.map(function(i) { return parseFloat(i.income) || 0; }), itemStyle: { color: '#e6a23c' }, lineStyle: { width: 2, color: '#e6a23c' }, symbol: 'circle', symbolSize: 6, showSymbol: true, connectNulls: true }
        ]
    }, true);
},
renderBarChart() {
    if (typeof echarts === 'undefined' || !this.\$refs.barChartRef) return;
    if (!this.barChart) this.barChart = echarts.init(this.\$refs.barChartRef);
    var software = this.softwareData || [];
    if (software.length === 0) {
        this.barChart.setOption({ title: { text: '暂无数据', left: 'center', top: 'center', textStyle: { color: '#999', fontSize: 14 } } });
        return;
    }
    var names = software.map(function(i) { return i.name || '未知'; }).reverse();
    var values = software.map(function(i) { return parseFloat(i.income) || 0; }).reverse();
    var colors = ['#409eff', '#67c23a', '#e6a23c', '#f56c6c', '#9c27b0'];
    this.barChart.setOption({
        tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, formatter: function(params) { return params[0].name + ': ¥' + params[0].value.toFixed(2); } },
        grid: { left: '15%', right: '15%', top: '5%', bottom: '5%', containLabel: true },
        xAxis: { type: 'value', axisLine: { show: false }, axisTick: { show: false }, axisLabel: { show: false }, splitLine: { show: false } },
        yAxis: { type: 'category', data: names, axisLine: { show: false }, axisTick: { show: false } },
        series: [{ type: 'bar', data: values.map(function(v, i) { return { value: v, itemStyle: { color: colors[i % colors.length], borderRadius: [0, 4, 4, 0] } }; }), barWidth: 12, label: { show: true, position: 'right', formatter: function(p) { return '¥' + p.value.toFixed(0); }, fontSize: 11 }, showBackground: true, backgroundStyle: { color: 'rgba(220, 223, 230, 0.2)', borderRadius: [0, 4, 4, 0] } }]
    });
}
";

include 'layout.php';
?>
