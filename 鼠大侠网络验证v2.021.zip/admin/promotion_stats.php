<?php
$pageTitle = '推广统计';
$breadcrumbs = ['数据统计', '推广统计'];

ob_start();
?>

<el-row :gutter="16" style="margin-bottom: 16px;">
    <el-col :span="6">
        <el-card shadow="hover">
            <el-statistic title="推广渠道" :value="stats.channels"></el-statistic>
        </el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover">
            <el-statistic title="总访问量" :value="stats.total_visits"></el-statistic>
        </el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover">
            <el-statistic title="总订单数" :value="stats.total_orders"></el-statistic>
        </el-card>
    </el-col>
    <el-col :span="6">
        <el-card shadow="hover">
            <el-statistic title="总成交额" :value="stats.total_amount" prefix="¥" :precision="2"></el-statistic>
        </el-card>
    </el-col>
</el-row>

<el-card shadow="hover" style="margin-bottom: 16px;">
    <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span>推广渠道管理</span>
            <el-button type="primary" @click="showAddDialog"><el-icon><Plus /></el-icon>添加渠道</el-button>
        </div>
    </template>
    
    <el-table :data="channels" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60"></el-table-column>
        <el-table-column prop="channel" label="渠道名称" min-width="100"></el-table-column>
        <el-table-column prop="code" label="推广码" min-width="120">
            <template #default="scope">
                <el-tag>{{ scope.row.code }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column label="推广链接" min-width="300">
            <template #default="scope">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <el-input :value="getPromoUrl(scope.row.code)" readonly size="small" style="flex: 1;"></el-input>
                    <el-button type="primary" size="small" @click="copyUrl(scope.row.code)">复制</el-button>
                </div>
            </template>
        </el-table-column>
        <el-table-column prop="visits" label="访问量" min-width="80" align="center"></el-table-column>
        <el-table-column prop="registers" label="注册数" min-width="80" align="center"></el-table-column>
        <el-table-column prop="orders" label="订单数" min-width="80" align="center"></el-table-column>
        <el-table-column label="成交额" min-width="100" align="right">
            <template #default="scope">
                <span style="color: #67c23a; font-weight: 500;">¥{{ scope.row.amount }}</span>
            </template>
        </el-table-column>
        <el-table-column label="转化率" min-width="80" align="center">
            <template #default="scope">
                <span>{{ scope.row.visits > 0 ? ((scope.row.orders / scope.row.visits) * 100).toFixed(1) : 0 }}%</span>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="创建时间" min-width="160"></el-table-column>
        <el-table-column label="操作" width="150" fixed="right" align="center">
            <template #default="scope">
                <el-button type="primary" size="small" @click="editChannel(scope.row)">编辑</el-button>
                <el-button type="danger" size="small" @click="deleteChannel(scope.row)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
</el-card>

<!-- 添加/编辑对话框 -->
<el-dialog v-model="dialogVisible" :title="editMode ? '编辑渠道' : '添加渠道'" width="450px">
    <el-form :model="form" label-width="100px">
        <el-form-item label="渠道名称">
            <el-input v-model="form.channel" placeholder="如：抖音、微博、QQ群"></el-input>
        </el-form-item>
        <el-form-item label="推广码">
            <el-input v-model="form.code" placeholder="唯一标识，如：douyin" :disabled="editMode">
                <template #append v-if="!editMode">
                    <el-button @click="generateCode">随机生成</el-button>
                </template>
            </el-input>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveChannel">保存</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = <<<JS
stats: { channels: 0, total_visits: 0, total_orders: 0, total_amount: 0 },
channels: [],
loading: false,
dialogVisible: false,
editMode: false,
form: { id: 0, channel: '', code: '' },
baseUrl: window.location.origin + '/shop/'
JS;

$vueMounted = "this.loadStats(); this.loadChannels();";

$vueMethods = <<<JS
loadStats: function() {
    var self = this;
    fetch('api_promotion.php?action=stats').then(function(r) { return r.json(); }).then(function(data) {
        if (data.code === 0) self.stats = data.data;
    });
},
loadChannels: function() {
    var self = this;
    self.loading = true;
    fetch('api_promotion.php?action=list').then(function(r) { return r.json(); }).then(function(data) {
        self.loading = false;
        if (data.code === 0) self.channels = data.data;
    });
},
showAddDialog: function() {
    this.editMode = false;
    this.form = { id: 0, channel: '', code: '' };
    this.dialogVisible = true;
},
editChannel: function(row) {
    this.editMode = true;
    this.form = { id: row.id, channel: row.channel, code: row.code };
    this.dialogVisible = true;
},
saveChannel: function() {
    var self = this;
    if (!self.form.channel || !self.form.code) {
        ElementPlus.ElMessage.error('请填写完整信息');
        return;
    }
    fetch('api_promotion.php?action=save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(self.form)
    }).then(function(r) { return r.json(); }).then(function(data) {
        if (data.code === 0) {
            ElementPlus.ElMessage.success('保存成功');
            self.dialogVisible = false;
            self.loadChannels();
            self.loadStats();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    });
},
deleteChannel: function(row) {
    var self = this;
    ElementPlus.ElMessageBox.confirm('确定删除该推广渠道吗？', '提示', { type: 'warning' }).then(function() {
        fetch('api_promotion.php?action=delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        }).then(function(r) { return r.json(); }).then(function(data) {
            if (data.code === 0) {
                ElementPlus.ElMessage.success('删除成功');
                self.loadChannels();
                self.loadStats();
            }
        });
    }).catch(function() {});
},
generateCode: function() {
    this.form.code = 'promo_' + Math.random().toString(36).substr(2, 8);
},
getPromoUrl: function(code) {
    return this.baseUrl + '?ref=' + code;
},
copyUrl: function(code) {
    var url = this.getPromoUrl(code);
    navigator.clipboard.writeText(url).then(function() {
        ElementPlus.ElMessage.success('已复制推广链接');
    });
}
JS;

include 'layout.php';
?>
