<?php
/**
 * 风险设备审核API
 */

session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json; charset=utf-8');

$action = $_REQUEST['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'list':
        getRiskDeviceList($db);
        break;
    case 'approve':
        approveDevice($db);
        break;
    case 'reject':
        rejectDevice($db);
        break;
    default:
        echo json_encode(['code' => 400, 'message' => '未知操作']);
}

/**
 * 获取风险设备列表
 */
function getRiskDeviceList($db) {
    
    $page = max(1, intval($_GET['page'] ?? 1));
    $pageSize = max(1, min(100, intval($_GET['page_size'] ?? 20)));
    $riskLevel = $_GET['risk_level'] ?? '';
    $softwareId = intval($_GET['software_id'] ?? 0);
    
    $where = "d.risk_level > 0";
    $params = [];
    
    if ($riskLevel !== '') {
        $where .= " AND d.risk_level = ?";
        $params[] = intval($riskLevel);
    }
    
    if ($softwareId > 0) {
        $where .= " AND d.software_id = ?";
        $params[] = $softwareId;
    }
    
    // 获取总数
    $countSql = "SELECT COUNT(*) FROM devices d WHERE $where";
    $stmt = $db->prepare($countSql);
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // 获取列表
    $offset = ($page - 1) * $pageSize;
    $sql = "SELECT d.*, s.name as software_name
            FROM devices d
            LEFT JOIN software s ON d.software_id = s.id
            WHERE $where
            ORDER BY d.create_time DESC
            LIMIT $offset, $pageSize";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 脱敏处理
    foreach ($list as &$item) {
        if ($item['fingerprint']) {
            $item['fingerprint_masked'] = substr($item['fingerprint'], 0, 8) . '...' . substr($item['fingerprint'], -8);
        }
    }
    
    echo json_encode([
        'code' => 200,
        'data' => [
            'list' => $list,
            'total' => $total,
            'page' => $page,
            'page_size' => $pageSize
        ]
    ]);
}

/**
 * 审核通过（允许风险设备）
 */
function approveDevice($db) {
    
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    $stmt = $db->prepare("UPDATE devices SET risk_level = 0 WHERE id = ? AND risk_level = 1");
    $result = $stmt->execute([$id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['code' => 200, 'message' => '已通过，设备可正常使用']);
    } else {
        echo json_encode(['code' => 404, 'message' => '设备不存在或状态已变更']);
    }
}

/**
 * 审核拒绝（禁用风险设备）
 */
function rejectDevice($db) {
    
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['code' => 400, 'message' => '参数错误']);
        return;
    }
    
    $db->beginTransaction();
    
    try {
        // 更新设备状态
        $stmt = $db->prepare("UPDATE devices SET risk_level = 2, status = 0 WHERE id = ? AND risk_level = 1");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() === 0) {
            $db->rollBack();
            echo json_encode(['code' => 404, 'message' => '设备不存在或状态已变更']);
            return;
        }
        
        // 使所有会话失效
        $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0 WHERE device_id = ?");
        $stmt->execute([$id]);
        
        $db->commit();
        
        echo json_encode(['code' => 200, 'message' => '已拒绝，设备已禁用']);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['code' => 500, 'message' => '操作失败']);
    }
}
