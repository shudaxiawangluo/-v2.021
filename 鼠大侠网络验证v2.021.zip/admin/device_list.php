<?php
$pageTitle = '设备管理';
$breadcrumbs = ['设备管理'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; margin-bottom: 16px; flex-shrink: 0;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 150px;" @change="loadData">
            <el-option label="全部软件" value=""></el-option>
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
        <el-select v-model="searchForm.status" placeholder="状态" clearable style="width: 100px;" @change="loadData">
            <el-option label="全部" value=""></el-option>
            <el-option label="正常" value="1"></el-option>
            <el-option label="禁用" value="0"></el-option>
        </el-select>
        <el-select v-model="searchForm.online_only" placeholder="在线状态" clearable style="width: 120px;" @change="loadData">
            <el-option label="全部" value=""></el-option>
            <el-option label="仅在线" value="1"></el-option>
        </el-select>
        <el-input v-model="searchForm.keyword" placeholder="搜索指纹/IP" clearable style="width: 180px;" @keyup.enter="loadData">
            <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" @click="loadData"><el-icon><Search /></el-icon></el-button>
    </div>
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-tag type="success">在线: {{ onlineCount }}</el-tag>
        <el-tag type="info">总数: {{ totalCount }}</el-tag>
    </div>
</div>

<el-card shadow="hover">
    <el-table :data="dataList" v-loading="loading" stripe style="width: 100%;" table-layout="auto">
        <el-table-column prop="id" label="ID" width="50" align="center"></el-table-column>
        <el-table-column prop="software_name" label="软件" min-width="80" align="center">
            <template #default="scope">{{ scope.row.software_name || '-' }}</template>
        </el-table-column>
        <el-table-column label="机器码" min-width="140" align="center">
            <template #default="scope">
                <el-tooltip :content="scope.row.fingerprint || scope.row.machine_code" placement="top">
                    <code style="cursor: pointer; font-size: 12px; color: #409eff;" @click="copyText(scope.row.fingerprint || scope.row.machine_code)">
                        {{ (scope.row.fingerprint || scope.row.machine_code || '-').substring(0, 16) }}...
                    </code>
                </el-tooltip>
            </template>
        </el-table-column>
        <el-table-column label="平台" min-width="70" align="center">
            <template #default="scope">{{ scope.row.platform || '-' }}</template>
        </el-table-column>
        <el-table-column label="在线" min-width="60" align="center">
            <template #default="scope">
                <el-tag v-if="scope.row.is_online == 1" type="success" size="small">在线</el-tag>
                <el-tag v-else type="info" size="small">离线</el-tag>
            </template>
        </el-table-column>
        <el-table-column label="IP/归属地" min-width="120" align="center">
            <template #default="scope">
                <div>{{ scope.row.last_ip || '-' }}</div>
                <div style="font-size: 11px; color: #409EFF;">{{ scope.row.ip_location || '' }}</div>
            </template>
        </el-table-column>
        <el-table-column label="到期时间/点数" min-width="140" align="center">
            <template #default="scope">
                <template v-if="scope.row.is_point_card == 1">
                    <div style="color: #E6A23C; font-weight: 500;">{{ scope.row.remaining_points }} / {{ scope.row.total_points }} 点</div>
                    <span v-if="scope.row.remaining_points <= 0" style="color: #F56C6C; font-size: 11px;">点数已用完</span>
                    <span v-else style="color: #67C23A; font-size: 11px;">点卡模式</span>
                </template>
                <template v-else>
                    <div>{{ scope.row.expire_time || '-' }}</div>
                    <span v-if="scope.row.is_expired" style="color: #F56C6C; font-size: 11px;">已过期</span>
                    <span v-else style="color: #67C23A; font-size: 11px;">剩余{{ scope.row.remain_days }}天</span>
                </template>
            </template>
        </el-table-column>
        <el-table-column label="生效时间" min-width="140" align="center">
            <template #default="scope">{{ scope.row.activate_time || '-' }}</template>
        </el-table-column>
        <el-table-column label="最后心跳" min-width="140" align="center">
            <template #default="scope">{{ scope.row.last_heartbeat || '-' }}</template>
        </el-table-column>
        <el-table-column label="状态" min-width="60" align="center">
            <template #default="scope">
                <el-tag v-if="scope.row.status == 1" type="success" size="small">正常</el-tag>
                <el-tag v-else type="danger" size="small">禁用</el-tag>
            </template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right" align="center">
            <template #default="scope">
                <div style="display: flex; gap: 4px; justify-content: center; flex-wrap: nowrap;">
                    <el-button v-if="scope.row.is_online == 1" type="warning" size="small" @click="kickDevice(scope.row.id)">下线</el-button>
                    <el-button v-if="scope.row.status == 1" type="warning" size="small" @click="disableDevice(scope.row.id)">禁用</el-button>
                    <el-button v-else type="success" size="small" @click="enableDevice(scope.row.id)">启用</el-button>
                    <el-button type="danger" size="small" @click="deleteDevice(scope.row.id)">删除</el-button>
                </div>
            </template>
        </el-table-column>
    </el-table>
    
    <div class="pagination-container" style="justify-content: flex-end; margin-top: 16px;">
        <el-pagination
            v-model:current-page="pagination.page"
            v-model:page-size="pagination.pageSize"
            :page-sizes="[20, 50, 100]"
            :total="pagination.total"
            layout="total, sizes, prev, pager, next"
            @size-change="loadData"
            @current-change="loadData"
        />
    </div>
</el-card>

<?php
$pageContent = ob_get_clean();

$vueData = "
dataList: [],
softwareList: [],
loading: false,
onlineCount: 0,
totalCount: 0,
searchForm: { software_id: '', status: '', online_only: '', keyword: '' },
pagination: { page: 1, pageSize: 20, total: 0 },
refreshTimer: null
";

$vueMounted = "
this.loadSoftwareList();
this.loadData();
this.loadOnlineCount();
this.refreshTimer = setInterval(() => { this.loadOnlineCount(); }, 5000);
";

$vueMethods = "
async loadSoftwareList() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 200) {
            this.softwareList = data.data.list || [];
        }
    } catch (e) { console.error(e); }
},
async loadOnlineCount() {
    try {
        let url = 'api_devices.php?action=online_count';
        if (this.searchForm.software_id) url += '&software_id=' + this.searchForm.software_id;
        const res = await fetch(url);
        const data = await res.json();
        if (data.code === 200) {
            this.onlineCount = data.data.online;
            this.totalCount = data.data.total;
        }
    } catch (e) { console.error(e); }
},
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({
            action: 'list',
            page: this.pagination.page,
            page_size: this.pagination.pageSize,
            software_id: this.searchForm.software_id,
            status: this.searchForm.status,
            online_only: this.searchForm.online_only,
            keyword: this.searchForm.keyword
        });
        const res = await fetch('api_devices.php?' + params);
        const data = await res.json();
        if (data.code === 200) {
            this.dataList = data.data.list || [];
            this.pagination.total = data.data.total || 0;
        } else {
            ElementPlus.ElMessage.error(data.message || '加载失败');
        }
    } catch (e) { 
        console.error(e);
        ElementPlus.ElMessage.error('加载失败');
    }
    this.loading = false;
    this.loadOnlineCount();
},
async kickDevice(id) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定强制下线此设备？客户端将在5秒内断开', '提示', { type: 'warning' });
        const res = await fetch('api_devices.php?action=kick', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        const data = await res.json();
        if (data.code === 200) {
            ElementPlus.ElMessage.success(data.message);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.message || '操作失败');
        }
    } catch (e) { 
        if (e !== 'cancel') {
            console.error(e);
            ElementPlus.ElMessage.error('操作失败');
        }
    }
},
async disableDevice(id) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定禁用此设备？设备将被加入机器码黑名单，客户端将在5秒内断开', '提示', { type: 'warning' });
        const res = await fetch('api_devices.php?action=disable', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        const data = await res.json();
        if (data.code === 200) {
            ElementPlus.ElMessage.success(data.message);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.message || '操作失败');
        }
    } catch (e) { 
        if (e !== 'cancel') {
            console.error(e);
            ElementPlus.ElMessage.error('操作失败');
        }
    }
},
async enableDevice(id) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定启用此设备？设备将从机器码黑名单移除', '提示', { type: 'info' });
        const res = await fetch('api_devices.php?action=enable', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: id })
        });
        const data = await res.json();
        if (data.code === 200) {
            ElementPlus.ElMessage.success(data.message);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.message || '操作失败');
        }
    } catch (e) { 
        if (e !== 'cancel') {
            console.error(e);
            ElementPlus.ElMessage.error('操作失败');
        }
    }
},
copyText(text) {
    if (!text) return;
    navigator.clipboard.writeText(text).then(() => {
        ElementPlus.ElMessage.success('已复制');
    });
},
async deleteDevice(id) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除此设备？删除后设备需要重新激活', '警告', { type: 'warning' });
        const formData = new FormData();
        formData.append('id', id);
        const res = await fetch('api_devices.php?action=delete', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.code === 200) {
            ElementPlus.ElMessage.success(data.message);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.message || '删除失败');
        }
    } catch (e) { 
        if (e !== 'cancel') {
            console.error(e);
            ElementPlus.ElMessage.error('删除失败');
        }
    }
}
";

include 'layout.php';
?>
