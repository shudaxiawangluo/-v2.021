<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

switch ($action) {
    case 'list':
        // API调用统计列表
        $softwareId = $_GET['software_id'] ?? '';
        $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-7 days'));
        $endDate = $_GET['end_date'] ?? date('Y-m-d');
        
        $list = [];
        $totalCalls = 0;
        $successCalls = 0;
        $failCalls = 0;
        $avgTime = 0;
        
        try {
            $where = "WHERE date BETWEEN ? AND ?";
            $params = [$startDate, $endDate];
            
            if ($softwareId !== '') {
                $where .= " AND a.software_id = ?";
                $params[] = $softwareId;
            }
            
            // 获取明细数据
            $sql = "SELECT a.*, COALESCE(s.name, '全局') as software_name 
                    FROM api_stats a 
                    LEFT JOIN software s ON a.software_id = s.id 
                    $where 
                    ORDER BY a.date DESC, a.call_count DESC";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // 统计汇总
            $totalTime = 0;
            $timeCount = 0;
            
            foreach ($list as $row) {
                $totalCalls += intval($row['call_count']);
                $successCalls += intval($row['success_count']);
                $failCalls += intval($row['fail_count']);
                if ($row['avg_time'] > 0) {
                    $totalTime += $row['avg_time'] * $row['call_count'];
                    $timeCount += $row['call_count'];
                }
            }
            $avgTime = $timeCount > 0 ? round($totalTime / $timeCount) : 0;
        } catch (Exception $e) {
            // 表可能不存在
        }
        
        echo json_encode(['code' => 0, 'data' => [
            'list' => $list,
            'trend' => $list,
            'stats' => [
                'totalCalls' => $totalCalls,
                'successCalls' => $successCalls,
                'failCalls' => $failCalls,
                'avgTime' => $avgTime
            ]
        ]]);
        break;
    case 'api_list':
        $where = "1=1";
        $params = [];
        if (!empty($_GET['software_id'])) {
            $where .= " AND a.software_id = ?";
            $params[] = $_GET['software_id'];
        }
        $sql = "SELECT a.*, s.name as software_name FROM custom_apis a LEFT JOIN software s ON a.software_id = s.id WHERE $where ORDER BY a.id DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;
        
    case 'add':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("INSERT INTO custom_apis (software_id, name, path, method, params, response, response_type, auth_required, rate_limit, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $input['software_id'] ?? null,
            $input['name'] ?? $input['api_name'],
            $input['path'] ?? $input['api_path'],
            $input['method'] ?? 'GET',
            $input['params'] ?? '',
            $input['response'] ?? $input['response_template'] ?? '',
            $input['response_type'] ?? 'json',
            $input['auth_required'] ?? ($input['require_auth'] ? 1 : 0),
            $input['rate_limit'] ?? 0,
            $input['status'] ?? 1
        ]);
        echo json_encode(['code' => 0, 'msg' => '添加成功']);
        break;
        
    case 'update':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("UPDATE custom_apis SET name = ?, method = ?, params = ?, response = ?, response_type = ?, auth_required = ?, rate_limit = ?, status = ? WHERE id = ?");
        $stmt->execute([
            $input['name'] ?? $input['api_name'],
            $input['method'] ?? 'GET',
            $input['params'] ?? '',
            $input['response'] ?? $input['response_template'] ?? '',
            $input['response_type'] ?? 'json',
            $input['auth_required'] ?? ($input['require_auth'] ? 1 : 0),
            $input['rate_limit'] ?? 0,
            $input['status'] ?? 1,
            $input['id']
        ]);
        echo json_encode(['code' => 0, 'msg' => '修改成功']);
        break;
        
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("DELETE FROM custom_apis WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    // Webhook
    case 'webhook_list':
        $where = "1=1";
        $params = [];
        if (!empty($_GET['software_id'])) {
            $where .= " AND (w.software_id = ? OR w.software_id = 0)";
            $params[] = $_GET['software_id'];
        }
        $sql = "SELECT w.*, s.name as software_name FROM webhooks w LEFT JOIN software s ON w.software_id = s.id WHERE $where ORDER BY w.id DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;
        
    case 'webhook_add':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("INSERT INTO webhooks (software_id, name, url, events, secret, headers, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $input['software_id'] ?? 0,
            $input['name'] ?? $input['webhook_name'],
            $input['url'] ?? $input['webhook_url'],
            $input['events'] ?? '',
            $input['secret'] ?? $input['secret_key'] ?? '',
            $input['headers'] ?? '',
            $input['status'] ?? 1
        ]);
        echo json_encode(['code' => 0, 'msg' => '添加成功']);
        break;
        
    case 'webhook_update':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("UPDATE webhooks SET software_id = ?, name = ?, url = ?, events = ?, secret = ?, headers = ?, status = ? WHERE id = ?");
        $stmt->execute([
            $input['software_id'] ?? 0,
            $input['name'] ?? $input['webhook_name'],
            $input['url'] ?? $input['webhook_url'],
            $input['events'] ?? '',
            $input['secret'] ?? $input['secret_key'] ?? '',
            $input['headers'] ?? '',
            $input['status'] ?? 1,
            $input['id']
        ]);
        echo json_encode(['code' => 0, 'msg' => '修改成功']);
        break;
        
    case 'webhook_delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $stmt = $db->prepare("DELETE FROM webhooks WHERE id = ?");
        $stmt->execute([$input['id']]);
        echo json_encode(['code' => 0, 'msg' => '删除成功']);
        break;
    
    // API统计
    case 'api_stats':
        $days = intval($_GET['days'] ?? 7);
        $software_id = $_GET['software_id'] ?? '';
        
        $where = "date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)";
        $params = [$days];
        
        if ($software_id !== '') {
            $where .= " AND software_id = ?";
            $params[] = $software_id;
        }
        
        $sql = "SELECT date, api_name, call_count, success_count, fail_count, avg_time FROM api_stats WHERE $where ORDER BY date DESC, call_count DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode(['code' => 0, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
