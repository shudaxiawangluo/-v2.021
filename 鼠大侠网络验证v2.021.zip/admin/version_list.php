<?php
$pageTitle = '版本管理';
$breadcrumbs = ['云控制', '版本管理'];

ob_start();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <div style="display: flex; gap: 12px; align-items: center;">
        <el-select v-model="searchForm.software_id" placeholder="选择软件" clearable style="width: 160px;" @change="loadData">
            <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
        </el-select>
    </div>
    <el-button type="primary" @click="handleAdd"><el-icon><Plus /></el-icon>发布版本</el-button>
</div>

<el-card shadow="hover">
    <el-table :data="versionList" v-loading="loading" stripe>
        <el-table-column prop="id" label="ID" width="60" align="center"></el-table-column>
        <el-table-column prop="software_name" label="软件" width="120"></el-table-column>
        <el-table-column prop="version" label="版本号" width="100">
            <template #default="scope">
                <el-tag type="success">v{{ scope.row.version }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="version_code" label="版本代码" width="90" align="center"></el-table-column>
        <el-table-column prop="title" label="更新标题" min-width="150"></el-table-column>
        <el-table-column label="强制更新" width="90" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.force_update ? 'danger' : 'info'" size="small">{{ scope.row.force_update ? '是' : '否' }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="file_size" label="文件大小" width="100"></el-table-column>
        <el-table-column label="状态" width="80" align="center">
            <template #default="scope">
                <el-tag :type="scope.row.status === 1 ? 'success' : 'info'" size="small">{{ scope.row.status === 1 ? '启用' : '禁用' }}</el-tag>
            </template>
        </el-table-column>
        <el-table-column prop="create_time" label="发布时间" width="160"></el-table-column>
        <el-table-column label="操作" width="200" fixed="right" align="center">
            <template #default="scope">
                <el-button :type="scope.row.status === 1 ? 'warning' : 'success'" size="small" @click="handleToggleStatus(scope.row)">{{ scope.row.status === 1 ? '禁用' : '启用' }}</el-button>
                <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
                <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
</el-card>

<!-- 添加/编辑版本对话框 -->
<el-dialog v-model="showDialog" :title="editForm.id ? '编辑版本' : '发布版本'" width="600px">
    <el-form :model="editForm" label-width="100px">
        <el-form-item label="所属软件" required>
            <el-select v-model="editForm.software_id" placeholder="选择软件" style="width: 100%;">
                <el-option v-for="s in softwareList" :key="s.id" :label="s.name" :value="s.id"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="版本号" required>
            <el-input v-model="editForm.version" placeholder="如：1.0.0" style="width: 150px;"></el-input>
        </el-form-item>
        <el-form-item label="版本代码">
            <el-input-number v-model="editForm.version_code" :min="0" style="width: 150px;"></el-input-number>
            <span style="margin-left: 12px; color: #909399;">用于版本比较，数字越大版本越新</span>
        </el-form-item>
        <el-form-item label="更新标题">
            <el-input v-model="editForm.title" placeholder="如：修复已知问题"></el-input>
        </el-form-item>
        <el-form-item label="更新日志">
            <el-input v-model="editForm.changelog" type="textarea" :rows="4" placeholder="更新内容说明"></el-input>
        </el-form-item>
        <el-form-item label="下载地址">
            <el-input v-model="editForm.download_url" placeholder="更新包下载URL"></el-input>
        </el-form-item>
        <el-form-item label="文件大小">
            <el-input v-model="editForm.file_size" placeholder="如：15.6MB" style="width: 150px;"></el-input>
        </el-form-item>
        <el-form-item label="文件MD5">
            <el-input v-model="editForm.file_md5" placeholder="文件MD5校验值"></el-input>
        </el-form-item>
        <el-form-item label="强制更新">
            <el-switch v-model="editForm.force_update"></el-switch>
            <span style="margin-left: 12px; color: #909399;">启用后低版本用户必须更新</span>
        </el-form-item>
        <el-form-item label="最低版本">
            <el-input v-model="editForm.min_version" placeholder="如：0.9.0" style="width: 150px;"></el-input>
            <span style="margin-left: 12px; color: #909399;">低于此版本强制更新</span>
        </el-form-item>
        <el-form-item label="状态">
            <el-switch v-model="editForm.status" :active-value="1" :inactive-value="0" active-text="启用" inactive-text="禁用"></el-switch>
        </el-form-item>
    </el-form>
    <template #footer>
        <el-button @click="showDialog = false">取消</el-button>
        <el-button type="primary" @click="handleSave" :loading="saving">保存</el-button>
    </template>
</el-dialog>

<?php
$pageContent = ob_get_clean();

$vueData = "
versionList: [],
softwareList: [],
loading: false,
saving: false,
showDialog: false,
searchForm: { software_id: '' },
editForm: { id: '', software_id: '', version: '', version_code: 0, title: '', changelog: '', download_url: '', file_size: '', file_md5: '', force_update: false, min_version: '', status: 1 }
";

$vueMounted = "this.loadData(); this.loadSoftware();";

$vueMethods = "
async loadData() {
    this.loading = true;
    try {
        const params = new URLSearchParams({ action: 'version_list', ...this.searchForm });
        const res = await fetch('api_remote.php?' + params);
        const data = await res.json();
        if (data.code === 0) this.versionList = data.data;
    } catch (e) { console.error(e); }
    this.loading = false;
},
async loadSoftware() {
    try {
        const res = await fetch('api_software.php?action=list');
        const data = await res.json();
        if (data.code === 0) this.softwareList = data.data;
    } catch (e) {}
},
handleAdd() {
    this.editForm = { id: '', software_id: '', version: '', version_code: 0, title: '', changelog: '', download_url: '', file_size: '', file_md5: '', force_update: false, min_version: '', status: 1 };
    this.showDialog = true;
},
handleEdit(row) {
    this.editForm = {
        id: row.id,
        software_id: row.software_id,
        version: row.version,
        version_code: row.version_code || 0,
        title: row.title || '',
        changelog: row.changelog || '',
        download_url: row.download_url || '',
        file_size: row.file_size || '',
        file_md5: row.file_md5 || '',
        force_update: row.force_update == 1,
        min_version: row.min_version || '',
        status: row.status == 1 ? 1 : 0
    };
    this.showDialog = true;
},
async handleSave() {
    if (!this.editForm.software_id || !this.editForm.version) {
        ElementPlus.ElMessage.error('请填写必填项');
        return;
    }
    this.saving = true;
    try {
        const res = await fetch('api_remote.php?action=' + (this.editForm.id ? 'update_version' : 'add_version'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.editForm)
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.showDialog = false;
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('请求失败'); }
    this.saving = false;
},
async handleToggleStatus(row) {
    try {
        const newStatus = row.status === 1 ? 0 : 1;
        const res = await fetch('api_remote.php?action=toggle_version', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id, status: newStatus })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) { ElementPlus.ElMessage.error('请求失败'); }
},
async handleDelete(row) {
    try {
        await ElementPlus.ElMessageBox.confirm('确定删除该版本吗？', '删除确认', { type: 'warning' });
        const res = await fetch('api_remote.php?action=delete_version', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: row.id })
        });
        const data = await res.json();
        if (data.code === 0) {
            ElementPlus.ElMessage.success(data.msg);
            this.loadData();
        } else {
            ElementPlus.ElMessage.error(data.msg);
        }
    } catch (e) {}
}
";

include 'layout.php';
?>
