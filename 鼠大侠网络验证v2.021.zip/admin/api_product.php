<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    die(json_encode(['code' => -1, 'msg' => '未登录']));
}

require_once '../api/config.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$db = getDB();

// 自动修复数据库
autoFixDatabase();

switch ($action) {
    case 'list':
        $where = "1=1";
        $params = [];
        
        if (!empty($_GET['software_id'])) {
            $where .= " AND p.software_id = ?";
            $params[] = $_GET['software_id'];
        }
        if (isset($_GET['status']) && $_GET['status'] !== '') {
            $where .= " AND p.status = ?";
            $params[] = $_GET['status'];
        }
        
        // 实时计算库存（从关联的未使用卡密数量）
        $sql = "SELECT p.*, s.name as software_name,
                (SELECT COUNT(*) FROM auth_codes WHERE product_id = p.id AND status = 0) as real_stock
                FROM products p 
                LEFT JOIN software s ON p.software_id = s.id 
                WHERE $where 
                ORDER BY p.sort_order DESC, p.id DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 用实时库存替换stock字段
        foreach ($list as &$item) {
            $item['stock'] = intval($item['real_stock']);
            unset($item['real_stock']);
        }
        unset($item);
        
        echo json_encode(['code' => 0, 'data' => $list]);
        break;
    
    // 获取可用卡密（未关联商品、未使用的）
    case 'getAvailableCodes':
        $softwareId = intval($_GET['software_id'] ?? 0);
        $productId = intval($_GET['product_id'] ?? 0);
        
        if ($softwareId <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        // 获取未关联商品或关联当前商品的未使用卡密
        $sql = "SELECT id, code, card_type, days, minutes, is_point_card, total_points, create_time 
                FROM auth_codes 
                WHERE software_id = ? AND status = 0 AND (product_id IS NULL OR product_id = 0 OR product_id = ?)
                ORDER BY id DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute([$softwareId, $productId]);
        $codes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $codes]);
        break;
    
    // 获取商品关联的卡密
    case 'getProductCodes':
        $productId = intval($_GET['product_id'] ?? 0);
        
        $sql = "SELECT id, code FROM auth_codes WHERE product_id = ? AND status = 0";
        $stmt = $db->prepare($sql);
        $stmt->execute([$productId]);
        $codes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['code' => 0, 'data' => $codes]);
        break;
        
    case 'add':
        $input = json_decode(file_get_contents('php://input'), true);
        
        $softwareId = intval($input['software_id'] ?? 0);
        $name = trim($input['name'] ?? '');
        $codeIds = $input['code_ids'] ?? [];
        
        if ($softwareId <= 0 || empty($name) || empty($codeIds)) {
            echo json_encode(['code' => 1, 'msg' => '请填写完整信息并选择卡密']);
            break;
        }
        
        try {
            $db->beginTransaction();
            
            // 获取第一张卡密的信息作为商品类型
            $stmt = $db->prepare("SELECT card_type, days, minutes, is_point_card, total_points, deduct_type, deduct_amount FROM auth_codes WHERE id = ?");
            $stmt->execute([$codeIds[0]]);
            $firstCode = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // 创建商品
            $stmt = $db->prepare("INSERT INTO products (software_id, name, card_type, duration, days, is_point_card, points, deduct_type, deduct_amount, price, original_price, agent_price, description, sort_order, status, stock, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([
                $softwareId,
                $name,
                $firstCode['card_type'] ?? 'month',
                $firstCode['days'] ?? 30,
                $firstCode['days'] ?? 30,
                $firstCode['is_point_card'] ?? 0,
                $firstCode['total_points'] ?? 0,
                $firstCode['deduct_type'] ?? 'per_use',
                $firstCode['deduct_amount'] ?? 1,
                $input['price'] ?? 0,
                $input['original_price'] ?? 0,
                $input['agent_price'] ?? 0,
                $input['description'] ?? '',
                $input['sort_order'] ?? 0,
                $input['status'] ?? 1,
                count($codeIds)
            ]);
            
            $productId = $db->lastInsertId();
            
            // 关联卡密
            $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
            $stmt = $db->prepare("UPDATE auth_codes SET product_id = ? WHERE id IN ($placeholders) AND software_id = ? AND status = 0");
            $stmt->execute(array_merge([$productId], $codeIds, [$softwareId]));
            
            $db->commit();
            
            // 记录日志
            try {
                $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
                $stmt->execute([$_SESSION['admin_id'], "添加商品: {$name}, 关联{$stmt->rowCount()}张卡密", $_SERVER['REMOTE_ADDR']]);
            } catch (Exception $e) {}
            
            echo json_encode(['code' => 0, 'msg' => '添加成功']);
        } catch (PDOException $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '添加失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'update':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        $codeIds = $input['code_ids'] ?? [];
        
        if ($id <= 0) {
            echo json_encode(['code' => 1, 'msg' => '参数错误']);
            break;
        }
        
        try {
            $db->beginTransaction();
            
            // 获取商品信息
            $stmt = $db->prepare("SELECT software_id FROM products WHERE id = ?");
            $stmt->execute([$id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$product) {
                echo json_encode(['code' => 1, 'msg' => '商品不存在']);
                break;
            }
            
            // 释放原来关联的卡密
            $stmt = $db->prepare("UPDATE auth_codes SET product_id = NULL WHERE product_id = ?");
            $stmt->execute([$id]);
            
            // 更新商品信息
            $stmt = $db->prepare("UPDATE products SET name = ?, price = ?, original_price = ?, agent_price = ?, description = ?, sort_order = ?, status = ?, stock = ? WHERE id = ?");
            $stmt->execute([
                $input['name'] ?? '',
                $input['price'] ?? 0,
                $input['original_price'] ?? 0,
                $input['agent_price'] ?? 0,
                $input['description'] ?? '',
                $input['sort_order'] ?? 0,
                $input['status'] ?? 1,
                count($codeIds),
                $id
            ]);
            
            // 重新关联卡密
            if (!empty($codeIds)) {
                $placeholders = implode(',', array_fill(0, count($codeIds), '?'));
                $stmt = $db->prepare("UPDATE auth_codes SET product_id = ? WHERE id IN ($placeholders) AND software_id = ? AND status = 0");
                $stmt->execute(array_merge([$id], $codeIds, [$product['software_id']]));
            }
            
            $db->commit();
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "修改商品ID: {$id}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '修改成功']);
        } catch (PDOException $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '修改失败: ' . $e->getMessage()]);
        }
        break;
        
    case 'toggle':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        $status = $input['status'] ?? 0;
        
        $stmt = $db->prepare("UPDATE products SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        
        echo json_encode(['code' => 0, 'msg' => '操作成功']);
        break;
        
    case 'delete':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? 0;
        
        try {
            $db->beginTransaction();
            
            // 释放关联的卡密
            $stmt = $db->prepare("UPDATE auth_codes SET product_id = NULL WHERE product_id = ?");
            $stmt->execute([$id]);
            
            // 删除商品
            $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            
            $db->commit();
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "删除商品ID: {$id}", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => '删除成功']);
        } catch (PDOException $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        break;
    
    case 'batchDelete':
        $input = json_decode(file_get_contents('php://input'), true);
        $ids = $input['ids'] ?? [];
        
        if (empty($ids) || !is_array($ids)) {
            echo json_encode(['code' => 1, 'msg' => '请选择要删除的商品']);
            break;
        }
        
        try {
            $db->beginTransaction();
            
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            
            // 释放关联的卡密
            $stmt = $db->prepare("UPDATE auth_codes SET product_id = NULL WHERE product_id IN ($placeholders)");
            $stmt->execute($ids);
            
            // 删除商品
            $stmt = $db->prepare("DELETE FROM products WHERE id IN ($placeholders)");
            $stmt->execute($ids);
            $count = $stmt->rowCount();
            
            $db->commit();
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "批量删除商品: {$count}个", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => "成功删除 {$count} 个商品"]);
        } catch (PDOException $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        break;
    
    case 'deleteAll':
        try {
            $db->beginTransaction();
            
            $stmt = $db->query("SELECT COUNT(*) FROM products");
            $count = $stmt->fetchColumn();
            
            if ($count == 0) {
                echo json_encode(['code' => 1, 'msg' => '没有可删除的商品']);
                break;
            }
            
            // 释放所有关联的卡密
            $db->exec("UPDATE auth_codes SET product_id = NULL WHERE product_id IS NOT NULL");
            
            // 删除所有商品
            $db->exec("DELETE FROM products");
            
            $db->commit();
            
            $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['admin_id'], "删除全部商品: {$count}个", $_SERVER['REMOTE_ADDR']]);
            
            echo json_encode(['code' => 0, 'msg' => "成功删除全部 {$count} 个商品"]);
        } catch (PDOException $e) {
            $db->rollBack();
            echo json_encode(['code' => 1, 'msg' => '删除失败']);
        }
        break;
        
    default:
        echo json_encode(['code' => 1, 'msg' => '未知操作']);
}
