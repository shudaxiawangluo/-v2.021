<?php
// 数据库更新脚本执行页面
require_once '../api/config.php';

$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = getDB();
        
        // 读取SQL文件
        $sql = file_get_contents('../api/update_software_table.sql');
        
        // 分割SQL语句
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        
        $executed = 0;
        foreach ($statements as $statement) {
            if (empty($statement) || strpos($statement, '--') === 0) {
                continue;
            }
            
            try {
                $db->exec($statement);
                $executed++;
            } catch (PDOException $e) {
                // 忽略已存在的字段错误
                if (strpos($e->getMessage(), 'Duplicate column name') === false) {
                    throw $e;
                }
            }
        }
        
        $message = "数据库更新成功！执行了 {$executed} 条SQL语句。";
        $success = true;
    } catch (Exception $e) {
        $message = "数据库更新失败：" . $e->getMessage();
        $success = false;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据库更新</title>
    <link rel="stylesheet" href="https://unpkg.com/element-plus/dist/index.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://unpkg.com/element-plus"></script>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC'; background: #f5f7fa; padding: 40px; }
        .container { max-width: 800px; margin: 0 auto; }
    </style>
</head>
<body>
    <div id="app">
        <div class="container">
            <el-card>
                <template #header>
                    <h2 style="margin: 0;">数据库更新</h2>
                </template>
                
                <?php if ($message): ?>
                    <el-alert
                        title="<?= htmlspecialchars($message) ?>"
                        type="<?= $success ? 'success' : 'error' ?>"
                        :closable="false"
                        style="margin-bottom: 20px;">
                    </el-alert>
                <?php endif; ?>
                
                <p>此操作将更新 software 表结构，添加新的功能字段。</p>
                
                <h3>将添加以下字段：</h3>
                <ul>
                    <li>machine_code_type - 机器码组成类型</li>
                    <li>trial_duration / trial_unit - 试用时长（支持分钟/小时/天）</li>
                    <li>enable_signature - 签名验证</li>
                    <li>enable_request_encrypt - 请求加密</li>
                    <li>detect_vm / vm_action - 虚拟机检测</li>
                    <li>detect_sandbox / sandbox_action - 沙盒检测</li>
                    <li>detect_debugger / debugger_action - 调试器检测</li>
                    <li>enable_ip_whitelist - IP白名单</li>
                    <li>enable_ip_blacklist - IP黑名单</li>
                    <li>enable_region_limit - 地区限制</li>
                </ul>
                
                <form method="POST">
                    <el-button type="primary" native-type="submit" <?= $success ? 'disabled' : '' ?>>
                        <?= $success ? '已更新' : '执行更新' ?>
                    </el-button>
                    <el-button onclick="window.location.href='dashboard.php'">返回后台</el-button>
                </form>
            </el-card>
        </div>
    </div>
    
    <script>
        const { createApp } = Vue;
        const app = createApp({});
        app.use(ElementPlus);
        app.mount('#app');
    </script>
</body>
</html>
