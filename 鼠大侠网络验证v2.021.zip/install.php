<?php
/**
 * 鼠大侠网络验证系统 - 安装向导
 */
$configFile = __DIR__ . '/api/config.php';
$installed = false;
if (file_exists($configFile)) {
    require_once $configFile;
    try {
        $db = getDB();
        $stmt = $db->query("SELECT COUNT(*) FROM admins");
        if ($stmt->fetchColumn() > 0) { $installed = true; }
    } catch (Exception $e) {}
}

$step = isset($_GET['step']) ? intval($_GET['step']) : 1;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step == 2) {
        $dbHost = trim($_POST['db_host'] ?? 'localhost');
        $dbName = trim($_POST['db_name'] ?? '');
        $dbUser = trim($_POST['db_user'] ?? '');
        $dbPass = $_POST['db_pass'] ?? '';
        if (empty($dbName) || empty($dbUser)) { $error = '请填写完整的数据库信息'; }
        else {
            try {
                $testPdo = new PDO("mysql:host={$dbHost};charset=utf8mb4", $dbUser, $dbPass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                $testPdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $configContent = "<?php\n// 数据库配置\ndefine('DB_HOST', '{$dbHost}');\ndefine('DB_NAME', '{$dbName}');\ndefine('DB_USER', '{$dbUser}');\ndefine('DB_PASS', '{$dbPass}');\n";
                $originalConfig = file_get_contents($configFile);
                $otherContent = preg_replace('/^<\?php\s*\n\/\/\s*数据库配置\s*\ndefine\(\'DB_HOST\'.*?\ndefine\(\'DB_NAME\'.*?\ndefine\(\'DB_USER\'.*?\ndefine\(\'DB_PASS\'.*?\n/s', '', $originalConfig);
                file_put_contents($configFile, $configContent . $otherContent);
                header('Location: install.php?step=3'); exit;
            } catch (PDOException $e) { $error = '数据库连接失败：' . $e->getMessage(); }
        }
    } elseif ($step == 3) {
        require_once $configFile;
        try {
            $db = getDB();
            $importErrors = [];
            
            // V2版本：导入基础表和V2表
            foreach (['api/install.sql', 'api/v2/install.sql', 'api/create_visit_tables.sql'] as $file) {
                $path = __DIR__ . '/' . $file;
                if (file_exists($path)) {
                    $sql = file_get_contents($path);
                    // 移除注释
                    $sql = preg_replace('/--.*$/m', '', $sql);
                    $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
                    // 移除DELIMITER语句（存储过程相关）
                    $sql = preg_replace('/DELIMITER\s+\/\/.*?DELIMITER\s+;/s', '', $sql);
                    // 移除CREATE EVENT语句
                    $sql = preg_replace('/CREATE EVENT.*?;/s', '', $sql);
                    $statements = array_filter(array_map('trim', explode(';', $sql)));
                    foreach ($statements as $st) {
                        if (!empty($st) && strlen($st) > 5) {
                            try {
                                $db->exec($st);
                            } catch (PDOException $e) {
                                // 忽略表已存在、列已存在的错误
                                $msg = $e->getMessage();
                                if (strpos($msg, 'already exists') === false && 
                                    strpos($msg, '1050') === false &&
                                    strpos($msg, '1060') === false &&
                                    strpos($msg, 'Duplicate column') === false) {
                                    $importErrors[] = $e->getMessage();
                                }
                            }
                        }
                    }
                }
            }
            
            // 创建系统设置表
            $db->exec("CREATE TABLE IF NOT EXISTS `system_settings` (`id` int(11) NOT NULL AUTO_INCREMENT, `setting_key` varchar(50) NOT NULL, `setting_value` text, `setting_group` varchar(50) DEFAULT 'general', `create_time` datetime DEFAULT CURRENT_TIMESTAMP, `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY (`id`), UNIQUE KEY `setting_key` (`setting_key`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            
            // 验证关键表是否创建成功（V2版本检查devices表）
            $checkTables = ['admins', 'software', 'auth_codes', 'devices', 'online_sessions'];
            foreach ($checkTables as $table) {
                $result = $db->query("SHOW TABLES LIKE '{$table}'")->fetch();
                if (!$result) {
                    $error = "数据库导入失败：关键表 {$table} 未创建成功";
                    break;
                }
            }
            
            if (empty($error)) {
                header('Location: install.php?step=4');
                exit;
            }
        } catch (PDOException $e) {
            $error = '数据库导入失败：' . $e->getMessage();
        }
    } elseif ($step == 4) {
        $adminUser = trim($_POST['admin_user'] ?? 'admin');
        $adminPass = $_POST['admin_pass'] ?? '';
        $adminPass2 = $_POST['admin_pass2'] ?? '';
        if (empty($adminUser) || empty($adminPass)) { $error = '请填写管理员账号和密码'; }
        elseif (strlen($adminPass) < 6) { $error = '密码长度至少6位'; }
        elseif ($adminPass !== $adminPass2) { $error = '两次输入的密码不一致'; }
        else {
            require_once $configFile;
            try {
                $db = getDB();
                $hashedPass = password_hash($adminPass, PASSWORD_DEFAULT);
                $stmt = $db->query("SELECT COUNT(*) FROM admins");
                if ($stmt->fetchColumn() > 0) { $db->prepare("UPDATE admins SET username = ?, password = ? WHERE id = 1")->execute([$adminUser, $hashedPass]); }
                else { $db->prepare("INSERT INTO admins (username, password, create_time) VALUES (?, ?, NOW())")->execute([$adminUser, $hashedPass]); }
                header('Location: install.php?step=5'); exit;
            } catch (PDOException $e) { $error = '创建管理员失败：' . $e->getMessage(); }
        }
    }
}

function checkEnvironment() {
    $checks = [];
    $checks[] = ['name' => 'PHP版本', 'required' => '7.4+', 'current' => PHP_VERSION, 'pass' => version_compare(PHP_VERSION, '7.4.0', '>=')];
    $checks[] = ['name' => 'PDO扩展', 'required' => '已安装', 'current' => extension_loaded('pdo') ? '已安装' : '未安装', 'pass' => extension_loaded('pdo')];
    $checks[] = ['name' => 'PDO MySQL', 'required' => '已安装', 'current' => extension_loaded('pdo_mysql') ? '已安装' : '未安装', 'pass' => extension_loaded('pdo_mysql')];
    $checks[] = ['name' => 'OpenSSL', 'required' => '已安装', 'current' => extension_loaded('openssl') ? '已安装' : '未安装', 'pass' => extension_loaded('openssl')];
    $checks[] = ['name' => 'cURL', 'required' => '已安装', 'current' => extension_loaded('curl') ? '已安装' : '未安装', 'pass' => extension_loaded('curl')];
    $checks[] = ['name' => 'JSON', 'required' => '已安装', 'current' => extension_loaded('json') ? '已安装' : '未安装', 'pass' => extension_loaded('json')];
    $configFile = __DIR__ . '/api/config.php';
    $checks[] = ['name' => '配置文件', 'required' => '可写', 'current' => is_writable($configFile) ? '可写' : '不可写', 'pass' => is_writable($configFile)];
    return $checks;
}
$envChecks = checkEnvironment();
$envPass = true;
foreach ($envChecks as $c) { if (!$c['pass']) { $envPass = false; break; } }
$stepTitles = ['环境检测', '数据库配置', '导入数据', '管理员设置', '安装完成'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装向导 - 鼠大侠网络验证系统</title>
    <link rel="stylesheet" href="https://unpkg.com/element-plus/dist/index.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Microsoft YaHei', Arial, sans-serif; background: #f5f7fa; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 40px 20px; }
        .install-box { background: white; border-radius: 8px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); width: 100%; max-width: 560px; padding: 40px; }
        .install-header { text-align: center; margin-bottom: 30px; }
        .install-header h1 { font-size: 20px; color: #303133; font-weight: 500; margin-bottom: 6px; }
        .install-header p { font-size: 13px; color: #909399; }
        
        .step-bar { display: flex; justify-content: space-between; margin-bottom: 35px; padding: 0 10px; }
        .step-item { display: flex; flex-direction: column; align-items: center; flex: 1; position: relative; }
        .step-item:not(:last-child)::after { content: ''; position: absolute; top: 12px; left: 60%; width: 80%; height: 1px; background: #e4e7ed; }
        .step-item.done:not(:last-child)::after { background: #67c23a; }
        .step-num { width: 26px; height: 26px; border-radius: 50%; background: #e4e7ed; color: #909399; display: flex; align-items: center; justify-content: center; font-size: 12px; margin-bottom: 8px; position: relative; z-index: 1; }
        .step-item.active .step-num { background: #409eff; color: white; }
        .step-item.done .step-num { background: #67c23a; color: white; }
        .step-text { font-size: 12px; color: #909399; }
        .step-item.active .step-text { color: #409eff; }
        .step-item.done .step-text { color: #67c23a; }
        
        .card-title { font-size: 16px; font-weight: 500; color: #303133; margin-bottom: 6px; }
        .card-desc { color: #909399; font-size: 13px; margin-bottom: 20px; }
        
        .env-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .env-table th, .env-table td { padding: 10px 12px; text-align: left; font-size: 13px; border-bottom: 1px solid #ebeef5; }
        .env-table th { background: #fafafa; color: #606266; font-weight: 500; }
        .env-table td { color: #606266; }
        .status-pass { color: #67c23a; }
        .status-fail { color: #f56c6c; }
        
        .form-group { margin-bottom: 18px; }
        .form-label { display: block; margin-bottom: 6px; color: #606266; font-size: 13px; }
        .form-input { width: 100%; padding: 8px 12px; border: 1px solid #dcdfe6; border-radius: 4px; font-size: 13px; }
        .form-input:focus { outline: none; border-color: #409eff; }
        .form-tip { font-size: 12px; color: #909399; margin-top: 4px; }
        
        .btn-group { display: flex; gap: 12px; margin-top: 25px; justify-content: center; }
        .btn { padding: 8px 20px; border: none; border-radius: 4px; font-size: 13px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-default { background: white; color: #606266; border: 1px solid #dcdfe6; }
        .btn-default:hover { color: #409eff; border-color: #c6e2ff; background: #ecf5ff; }
        .btn-primary { background: #409eff; color: white; }
        .btn-primary:hover { background: #66b1ff; }
        
        .alert { padding: 10px 14px; border-radius: 4px; margin-bottom: 18px; font-size: 13px; }
        .alert-error { background: #fef0f0; color: #f56c6c; }
        .alert-warning { background: #fdf6ec; color: #e6a23c; }
        .alert-info { background: #f4f4f5; color: #909399; }
        
        .feature-list { display: flex; flex-wrap: wrap; gap: 8px; margin: 15px 0; }
        .feature-item { background: #ecf5ff; color: #409eff; padding: 5px 12px; border-radius: 4px; font-size: 12px; }
        
        .complete-icon { text-align: center; margin-bottom: 15px; }
        .complete-icon svg { width: 50px; height: 50px; fill: #67c23a; }
        .info-box { background: #f5f7fa; border-radius: 4px; padding: 15px; margin: 15px 0; }
        .info-box p { margin-bottom: 8px; font-size: 13px; color: #606266; }
        .info-box p:last-child { margin-bottom: 0; }
        .info-box strong { color: #303133; display: inline-block; width: 80px; }
        .install-footer { text-align: center; margin-top: 25px; color: #c0c4cc; font-size: 12px; }
    </style>
</head>
<body>
    <div class="install-box">
        <div class="install-header">
            <h1>鼠大侠网络验证系统</h1>
            <p>安装向导 v2.0</p>
        </div>
        
        <?php if ($installed && $step < 5): ?>
        <div class="alert alert-warning">系统已安装，如需重新安装请清空 admins 表。</div>
        <div class="btn-group" style="justify-content: center;">
            <a href="admin/login.php" class="btn btn-primary">进入后台</a>
        </div>
        <?php else: ?>
        
        <div class="step-bar">
            <?php for ($i = 1; $i <= 5; $i++): ?>
            <div class="step-item <?php echo $step > $i ? 'done' : ($step == $i ? 'active' : ''); ?>">
                <div class="step-num"><?php echo $i; ?></div>
                <div class="step-text"><?php echo $stepTitles[$i-1]; ?></div>
            </div>
            <?php endfor; ?>
        </div>
        
        <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($step == 1): ?>
        <div class="card-title">环境检测</div>
        <div class="card-desc">检测服务器环境是否满足要求</div>
        <table class="env-table">
            <thead><tr><th>检测项</th><th>要求</th><th>当前</th><th>状态</th></tr></thead>
            <tbody>
            <?php foreach ($envChecks as $c): ?>
            <tr>
                <td><?php echo $c['name']; ?></td>
                <td><?php echo $c['required']; ?></td>
                <td><?php echo $c['current']; ?></td>
                <td class="<?php echo $c['pass'] ? 'status-pass' : 'status-fail'; ?>"><?php echo $c['pass'] ? '通过' : '不通过'; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if (!$envPass): ?>
        <div class="alert alert-error">环境检测未通过，请先解决问题。</div>
        <?php endif; ?>
        <div class="btn-group">
            <a href="install.php?step=2" class="btn btn-primary" <?php echo !$envPass ? 'style="pointer-events:none;opacity:0.5;"' : ''; ?>>下一步</a>
        </div>
        
        <?php elseif ($step == 2): ?>
        <div class="card-title">数据库配置</div>
        <div class="card-desc">填写数据库连接信息</div>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">数据库主机</label>
                <input type="text" name="db_host" class="form-input" value="localhost" required>
                <div class="form-tip">一般为 localhost</div>
            </div>
            <div class="form-group">
                <label class="form-label">数据库名称</label>
                <input type="text" name="db_name" class="form-input" placeholder="请输入数据库名称" required>
                <div class="form-tip">不存在会自动创建</div>
            </div>
            <div class="form-group">
                <label class="form-label">数据库用户名</label>
                <input type="text" name="db_user" class="form-input" placeholder="请输入用户名" required>
            </div>
            <div class="form-group">
                <label class="form-label">数据库密码</label>
                <input type="password" name="db_pass" class="form-input" placeholder="请输入密码">
            </div>
            <div class="btn-group">
                <a href="install.php?step=1" class="btn btn-default">上一步</a>
                <button type="submit" class="btn btn-primary">下一步</button>
            </div>
        </form>
        
        <?php elseif ($step == 3): ?>
        <div class="card-title">导入数据库</div>
        <div class="card-desc">创建所需的数据表</div>
        <div class="alert alert-info">点击按钮导入数据库表结构</div>
        <div class="feature-list">
            <span class="feature-item">软件管理</span>
            <span class="feature-item">设备管理(V2)</span>
            <span class="feature-item">授权码</span>
            <span class="feature-item">指纹审核(V2)</span>
            <span class="feature-item">风险设备(V2)</span>
            <span class="feature-item">代理商</span>
            <span class="feature-item">支付系统</span>
            <span class="feature-item">订单</span>
            <span class="feature-item">远程变量</span>
            <span class="feature-item">通知</span>
        </div>
        <form method="POST">
            <div class="btn-group">
                <a href="install.php?step=2" class="btn btn-default">上一步</a>
                <button type="submit" class="btn btn-primary">开始导入</button>
            </div>
        </form>
        
        <?php elseif ($step == 4): ?>
        <div class="card-title">设置管理员</div>
        <div class="card-desc">创建管理员账号</div>
        <form method="POST">
            <div class="form-group">
                <label class="form-label">用户名</label>
                <input type="text" name="admin_user" class="form-input" value="admin" required>
            </div>
            <div class="form-group">
                <label class="form-label">密码</label>
                <input type="password" name="admin_pass" class="form-input" placeholder="至少6位" required>
            </div>
            <div class="form-group">
                <label class="form-label">确认密码</label>
                <input type="password" name="admin_pass2" class="form-input" placeholder="再次输入" required>
            </div>
            <div class="btn-group">
                <a href="install.php?step=3" class="btn btn-default">上一步</a>
                <button type="submit" class="btn btn-primary">完成安装</button>
            </div>
        </form>
        
        <?php elseif ($step == 5): ?>
        <div class="complete-icon">
            <svg viewBox="0 0 1024 1024"><path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm193.5 301.7l-210.6 292a31.8 31.8 0 01-51.7 0L318.5 484.9c-3.8-5.3 0-12.7 6.5-12.7h46.9c10.2 0 19.9 4.9 25.9 13.3l71.2 98.8 157.2-218c6-8.3 15.6-13.3 25.9-13.3H699c6.5 0 10.3 7.4 6.5 12.7z"/></svg>
        </div>
        <div class="card-title" style="text-align:center;">安装完成</div>
        <div class="card-desc" style="text-align:center;">系统已成功安装</div>
        <div class="info-box">
            <p><strong>后台</strong><?php echo 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/admin/'; ?></p>
            <p><strong>代理商</strong><?php echo 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/agent/'; ?></p>
            <p><strong>商城</strong><?php echo 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/shop/'; ?></p>
            <p><strong>API文档</strong><?php echo 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/docs/api_v2.md'; ?></p>
        </div>
        <div class="alert alert-warning">请立即删除 install.php 文件</div>
        <div class="btn-group" style="justify-content:center;">
            <a href="admin/login.php" class="btn btn-primary">进入后台</a>
        </div>
        <?php endif; ?>
        
        <?php endif; ?>
        
        <div class="install-footer">© 2026 鼠大侠网络验证系统</div>
    </div>
</body>
</html>
