<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'shouquan');
define('DB_USER', 'shouquan');
define('DB_PASS', 'shouquan');

// ==================== V2版本配置 ====================
// AES加密密钥（用于加密存储RSA私钥等敏感数据）
// 重要：安装后请修改为随机生成的64位十六进制字符串
define('AES_SECRET_KEY', 'a3f8c2e1d4b7a6f9c0e3d2b1a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9');

// 客户端密钥（用于防重放签名验证）
// 重要：安装后请修改为随机字符串，并在客户端代码中混淆隐藏
define('CLIENT_SECRET', 'ShuDaXia2026SecretKey!@#$%^');

// V2心跳配置（固定值，不可修改）
define('V2_HEARTBEAT_INTERVAL', 5);  // 心跳间隔：5秒
define('V2_ONLINE_TIMEOUT', 15);     // 在线超时：15秒
define('V2_TOKEN_EXPIRE_HOURS', 24); // JWT令牌有效期：24小时
define('V2_TIMESTAMP_TOLERANCE', 30); // 时间戳容差：30秒
define('V2_NONCE_EXPIRE_MINUTES', 30); // nonce过期时间：30分钟
define('V2_FINGERPRINT_MATCH_THRESHOLD', 80); // 指纹匹配阈值：80%

// 环境检测
function isServerMode() {
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return !in_array($host, ['localhost', '127.0.0.1', 'localhost:80']);
}

// 数据库连接
function getDB() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $pdo;
    } catch (PDOException $e) {
        die('数据库连接失败：' . $e->getMessage() . '<br>请检查 api/config.php 中的数据库配置');
    }
}

// 返回JSON（兼容v1和v2格式）
function jsonResponse($code, $msg = '', $data = null) {
    header('Content-Type: application/json');
    $response = ['code' => $code];
    if ($msg) {
        $response['msg'] = $msg;
        $response['message'] = $msg; // 兼容v2
    }
    if ($data !== null) {
        $response['data'] = $data;
    }
    $response['timestamp'] = time();
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

// ==================== 加密相关 ====================

// AES-256加密
function aesEncrypt($data, $key) {
    $key = hash('sha256', $key, true);
    $iv = openssl_random_pseudo_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $encrypted);
}

// AES-256解密
function aesDecrypt($data, $key) {
    $key = hash('sha256', $key, true);
    $data = base64_decode($data);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
}

// RSA生成密钥对
function rsaGenerateKeyPair() {
    $config = [
        'private_key_bits' => 2048,
        'private_key_type' => OPENSSL_KEYTYPE_RSA,
    ];
    $res = openssl_pkey_new($config);
    openssl_pkey_export($res, $privateKey);
    $publicKey = openssl_pkey_get_details($res)['key'];
    return ['private' => $privateKey, 'public' => $publicKey];
}

// RSA公钥加密
function rsaEncrypt($data, $publicKey) {
    openssl_public_encrypt($data, $encrypted, $publicKey);
    return base64_encode($encrypted);
}

// RSA私钥解密
function rsaDecrypt($data, $privateKey) {
    $data = base64_decode($data);
    openssl_private_decrypt($data, $decrypted, $privateKey);
    return $decrypted;
}

// 签名生成
function generateSignature($data, $secret) {
    if (is_array($data)) {
        ksort($data);
        $data = http_build_query($data);
    }
    return hash_hmac('sha256', $data . $secret, $secret);
}

// 签名验证
function verifySignature($data, $signature, $secret) {
    return hash_equals(generateSignature($data, $secret), $signature);
}

// ==================== Token相关 ====================

// 生成Token
function generateToken($userId, $softwareId) {
    $payload = [
        'user_id' => $userId,
        'software_id' => $softwareId,
        'exp' => time() + 86400,
        'rand' => bin2hex(random_bytes(16))
    ];
    $token = base64_encode(json_encode($payload));
    
    // 使用软件密钥签名
    $db = getDB();
    $stmt = $db->prepare("SELECT app_key FROM software WHERE id = ?");
    $stmt->execute([$softwareId]);
    $appKey = $stmt->fetchColumn();
    
    $signature = hash_hmac('sha256', $token, $appKey);
    return $token . '.' . $signature;
}

// 验证Token
function verifyToken($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 2) {
        return false;
    }
    
    list($tokenData, $signature) = $parts;
    $payload = json_decode(base64_decode($tokenData), true);
    
    if (!$payload || $payload['exp'] < time()) {
        return false;
    }
    
    // 验证签名
    $db = getDB();
    $stmt = $db->prepare("SELECT app_key FROM software WHERE id = ?");
    $stmt->execute([$payload['software_id']]);
    $appKey = $stmt->fetchColumn();
    
    $expectedSignature = hash_hmac('sha256', $tokenData, $appKey);
    if (!hash_equals($expectedSignature, $signature)) {
        return false;
    }
    
    return $payload['user_id'];
}

// ==================== 环境检测 ====================

// 虚拟机检测（服务器端通过客户端上报）
function detectVM($clientInfo) {
    $vmIndicators = [
        'VMware', 'VirtualBox', 'QEMU', 'Xen', 'Hyper-V',
        'Parallels', 'Virtual', 'VM', 'vbox', 'vmware'
    ];
    
    $info = strtolower(json_encode($clientInfo));
    foreach ($vmIndicators as $indicator) {
        if (stripos($info, strtolower($indicator)) !== false) {
            return true;
        }
    }
    return false;
}

// 沙盒检测（服务器端通过客户端上报）
function detectSandbox($clientInfo) {
    $sandboxIndicators = [
        'Sandboxie', 'sandbox', 'cuckoo', 'anubis', 'joebox',
        'threatexpert', 'cwsandbox', 'comodo'
    ];
    
    $info = strtolower(json_encode($clientInfo));
    foreach ($sandboxIndicators as $indicator) {
        if (stripos($info, strtolower($indicator)) !== false) {
            return true;
        }
    }
    return false;
}

// 调试器检测（服务器端通过客户端上报）
function detectDebugger($clientInfo) {
    return isset($clientInfo['debugger_detected']) && $clientInfo['debugger_detected'] === true;
}

// ==================== 机器码相关 ====================

// 生成机器码（根据策略）
function generateMachineCode($hardwareInfo, $strategy = 'cpu_disk') {
    $components = [];
    
    switch ($strategy) {
        case 'cpu_disk':
            $components[] = $hardwareInfo['cpu_id'] ?? '';
            $components[] = $hardwareInfo['disk_id'] ?? '';
            break;
        case 'cpu_board':
            $components[] = $hardwareInfo['cpu_id'] ?? '';
            $components[] = $hardwareInfo['board_id'] ?? '';
            break;
        case 'all':
            $components[] = $hardwareInfo['cpu_id'] ?? '';
            $components[] = $hardwareInfo['disk_id'] ?? '';
            $components[] = $hardwareInfo['board_id'] ?? '';
            $components[] = $hardwareInfo['mac'] ?? '';
            break;
    }
    
    return hash('sha256', implode('|', $components));
}

// 验证机器码
function verifyMachineCode($providedCode, $storedCode, $strategy) {
    return hash_equals($storedCode, $providedCode);
}

// ==================== IP相关 ====================

// IP白名单检查
// 注意：IP白名单是"仅允许"模式，如果软件开启了白名单，则只有白名单中的IP才能访问
function checkIPWhitelist($ip, $softwareId) {
    $db = getDB();
    // 检查全局白名单（software_id为0）和指定软件的白名单
    $stmt = $db->prepare("SELECT COUNT(*) FROM ip_whitelist WHERE ip = ? AND (software_id = ? OR software_id = 0)");
    $stmt->execute([$ip, $softwareId]);
    return $stmt->fetchColumn() > 0;
}

// 检查软件是否开启了IP白名单模式
function isWhitelistEnabled($softwareId) {
    $db = getDB();
    // 检查该软件是否有白名单记录（有记录则表示开启了白名单模式）
    $stmt = $db->prepare("SELECT COUNT(*) FROM ip_whitelist WHERE software_id = ? OR software_id = 0");
    $stmt->execute([$softwareId]);
    return $stmt->fetchColumn() > 0;
}

// IP黑名单检查
function checkIPBlacklist($ip, $softwareId = null) {
    $db = getDB();
    // 检查全局黑名单（software_id为NULL或0）和指定软件的黑名单
    if ($softwareId) {
        $stmt = $db->prepare("SELECT COUNT(*) FROM ip_blacklist WHERE ip = ? AND (software_id = ? OR software_id IS NULL OR software_id = 0)");
        $stmt->execute([$ip, $softwareId]);
    } else {
        // 不指定软件ID时，检查所有黑名单
        $stmt = $db->prepare("SELECT COUNT(*) FROM ip_blacklist WHERE ip = ?");
        $stmt->execute([$ip]);
    }
    return $stmt->fetchColumn() > 0;
}

// 机器码黑名单检查
function checkMachineBlacklist($machineCode, $softwareId = null) {
    $db = getDB();
    if ($softwareId) {
        $stmt = $db->prepare("SELECT COUNT(*) FROM machine_blacklist WHERE machine_code = ? AND (software_id = ? OR software_id IS NULL)");
        $stmt->execute([$machineCode, $softwareId]);
    } else {
        $stmt = $db->prepare("SELECT COUNT(*) FROM machine_blacklist WHERE machine_code = ?");
        $stmt->execute([$machineCode]);
    }
    return $stmt->fetchColumn() > 0;
}

// 地区限制检查
function checkRegionLimit($ip, $softwareId) {
    $db = getDB();
    
    // 获取IP所在地区（使用免费IP地理位置API）
    $region = getIPRegion($ip);
    if (!$region) {
        return true; // 无法获取地区信息时允许访问
    }
    
    // 检查是否有地区限制规则
    $stmt = $db->prepare("SELECT * FROM region_limits WHERE software_id = ?");
    $stmt->execute([$softwareId]);
    $rules = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($rules)) {
        return true; // 没有规则时允许访问
    }
    
    // 检查是否在允许/禁止列表中
    foreach ($rules as $rule) {
        if (stripos($region, $rule['region_name']) !== false || $region === $rule['region_code']) {
            return $rule['type'] === 'allow';
        }
    }
    
    // 默认允许
    return true;
}

// 获取IP所在地区
function getIPRegion($ip) {
    // 使用免费的IP地理位置API
    $url = "http://ip-api.com/json/{$ip}?lang=zh-CN";
    
    $context = stream_context_create([
        'http' => [
            'timeout' => 3,
            'method' => 'GET'
        ]
    ]);
    
    $response = @file_get_contents($url, false, $context);
    if ($response) {
        $data = json_decode($response, true);
        if ($data && $data['status'] === 'success') {
            return $data['country'] . '|' . ($data['regionName'] ?? '') . '|' . ($data['city'] ?? '');
        }
    }
    
    return null;
}

// 根据IP获取地区代码（用于授权码区域限制）
function getRegionByIP($ip) {
    $url = "http://ip-api.com/json/{$ip}?fields=countryCode";
    
    $context = stream_context_create([
        'http' => [
            'timeout' => 3,
            'method' => 'GET'
        ]
    ]);
    
    $response = @file_get_contents($url, false, $context);
    if ($response) {
        $data = json_decode($response, true);
        if ($data && isset($data['countryCode'])) {
            return $data['countryCode'];
        }
    }
    
    return 'OTHER';
}

// ==================== 试用时长转换 ====================

// 将试用时长转换为秒
function trialToSeconds($duration, $unit) {
    switch ($unit) {
        case 'minute':
            return $duration * 60;
        case 'hour':
            return $duration * 3600;
        case 'day':
            return $duration * 86400;
        default:
            return $duration * 60;
    }
}

// ==================== 多开检测 ====================

// 检查用户是否在线
function isUserOnline($userId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM online_users WHERE user_id = ? AND last_heartbeat > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
    $stmt->execute([$userId]);
    return $stmt->fetchColumn() > 0;
}

// 获取用户在线数量
function getOnlineCount($userId) {
    $db = getDB();
    $stmt = $db->prepare("SELECT COUNT(*) FROM online_users WHERE user_id = ? AND last_heartbeat > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
    $stmt->execute([$userId]);
    return $stmt->fetchColumn();
}

// ==================== 日志记录 ====================

// 记录运行日志
function logRuntime($type, $content, $module = '', $ip = null, $userId = 0, $softwareId = 0) {
    try {
        $db = getDB();
        $ip = $ip ?? ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $stmt = $db->prepare("INSERT INTO runtime_logs (type, module, content, ip, user_id, software_id, create_time) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$type, $module, $content, $ip, $userId, $softwareId]);
    } catch (Exception $e) {
        // 忽略日志写入错误
    }
}

// 记录操作日志
function logOperation($adminId, $action, $ip = null) {
    $db = getDB();
    $ip = $ip ?? ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $stmt = $db->prepare("INSERT INTO operation_logs (admin_id, action, ip, create_time) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$adminId, $action, $ip]);
}

// ==================== 安全检查（黑白名单） ====================

/**
 * 检查IP是否在白名单中
 * @param string $ip IP地址
 * @param int $softwareId 软件ID，0表示检查全局
 * @return bool
 */
function isIPWhitelisted($ip, $softwareId = 0) {
    $db = getDB();
    
    // 检查精确匹配和全局白名单
    $stmt = $db->prepare("SELECT ip FROM ip_whitelist WHERE (software_id = ? OR software_id = 0)");
    $stmt->execute([$softwareId]);
    $whitelist = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($whitelist as $pattern) {
        if (matchIP($ip, $pattern)) {
            return true;
        }
    }
    
    return false;
}

/**
 * 检查IP是否在黑名单中
 * @param string $ip IP地址
 * @param int $softwareId 软件ID，0表示检查全局
 * @return bool
 */
function isIPBlacklisted($ip, $softwareId = 0) {
    $db = getDB();
    
    $stmt = $db->prepare("SELECT ip FROM ip_blacklist WHERE (software_id = ? OR software_id = 0)");
    $stmt->execute([$softwareId]);
    $blacklist = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($blacklist as $pattern) {
        if (matchIP($ip, $pattern)) {
            return true;
        }
    }
    
    return false;
}

/**
 * 检查机器码是否在黑名单中
 * @param string $machineCode 机器码
 * @param int $softwareId 软件ID，0表示检查全局
 * @return bool
 */
function isMachineBlacklisted($machineCode, $softwareId = 0) {
    $db = getDB();
    
    $stmt = $db->prepare("SELECT COUNT(*) FROM machine_blacklist WHERE machine_code = ? AND (software_id = ? OR software_id = 0)");
    $stmt->execute([$machineCode, $softwareId]);
    
    return $stmt->fetchColumn() > 0;
}

/**
 * IP匹配（支持通配符和CIDR）
 * @param string $ip 要检查的IP
 * @param string $pattern 匹配模式
 * @return bool
 */
function matchIP($ip, $pattern) {
    // 精确匹配
    if ($ip === $pattern) {
        return true;
    }
    
    // 通配符匹配（如 192.168.*.*）
    if (strpos($pattern, '*') !== false) {
        $regex = '/^' . str_replace(['.', '*'], ['\.', '\d+'], $pattern) . '$/';
        return preg_match($regex, $ip) === 1;
    }
    
    // CIDR匹配（如 192.168.1.0/24）
    if (strpos($pattern, '/') !== false) {
        list($subnet, $mask) = explode('/', $pattern);
        $ipLong = ip2long($ip);
        $subnetLong = ip2long($subnet);
        $maskLong = -1 << (32 - intval($mask));
        return ($ipLong & $maskLong) === ($subnetLong & $maskLong);
    }
    
    return false;
}

/**
 * 综合安全检查
 * @param string $ip IP地址
 * @param string $machineCode 机器码
 * @param int $softwareId 软件ID
 * @return array ['pass' => bool, 'reason' => string]
 */
function securityCheck($ip, $machineCode, $softwareId) {
    // 1. 先检查IP白名单（白名单优先放行）
    if (isIPWhitelisted($ip, $softwareId)) {
        return ['pass' => true, 'reason' => ''];
    }
    
    // 2. 检查IP黑名单
    if (isIPBlacklisted($ip, $softwareId)) {
        return ['pass' => false, 'reason' => 'IP已被封禁'];
    }
    
    // 3. 检查机器码黑名单
    if (!empty($machineCode) && isMachineBlacklisted($machineCode, $softwareId)) {
        return ['pass' => false, 'reason' => '设备已被封禁'];
    }
    
    return ['pass' => true, 'reason' => ''];
}

/**
 * 获取客户端真实IP
 * @return string
 */
function getClientIP() {
    $ip = '';
    
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        // Cloudflare
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // 代理
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } elseif (isset($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    } elseif (isset($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}

// ==================== IP归属地相关 ====================

/**
 * 获取IP归属地（使用太平洋IP库，国内IP更准确）
 * @param string $ip IP地址
 * @return string 归属地（省市区）
 */
function getIpLocationSimple($ip) {
    if (empty($ip) || $ip == '127.0.0.1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0 || strpos($ip, '172.') === 0) {
        return '本地网络';
    }
    
    // 简单的内存缓存
    static $cache = [];
    if (isset($cache[$ip])) {
        return $cache[$ip];
    }
    
    $location = '';
    
    // 使用太平洋IP库（国内IP准确度高）
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "http://whois.pconline.com.cn/ipJson.jsp?ip=" . urlencode($ip) . "&json=true");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        if ($response) {
            $response = @mb_convert_encoding($response, 'UTF-8', 'GBK');
            $data = @json_decode($response, true);
            if ($data) {
                // addr字段包含完整地址
                if (!empty($data['addr'])) {
                    $location = trim($data['addr']);
                } else {
                    $parts = [];
                    if (!empty($data['pro'])) $parts[] = $data['pro'];
                    if (!empty($data['city'])) $parts[] = $data['city'];
                    if (!empty($data['region'])) $parts[] = $data['region'];
                    $location = implode('', $parts);
                }
            }
        }
    }
    
    if (empty($location)) {
        $location = '';
    }
    
    $cache[$ip] = $location;
    return $location;
}

/**
 * 使用curl获取IP归属地
 */
function curlGetIpLocation($url, $type) {
    // 保留此函数以兼容
    return '';
}

/**
 * 记录用户地区分布（用于地图展示）
 * @param PDO $db 数据库连接
 * @param int $userId 用户ID
 * @param string $ip IP地址
 */
function recordUserRegion($db, $userId, $ip) {
    if (empty($ip) || $ip == '127.0.0.1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0) {
        return;
    }
    
    try {
        // 确保表存在
        $db->exec("CREATE TABLE IF NOT EXISTS user_regions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            ip VARCHAR(50),
            province VARCHAR(50),
            city VARCHAR(50),
            create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uk_user (user_id),
            INDEX idx_province (province)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        // 获取省份信息
        $province = '';
        $city = '';
        
        $url = "https://whois.pconline.com.cn/ipJson.jsp?ip=" . urlencode($ip) . "&json=true";
        $context = stream_context_create(['http' => ['timeout' => 3]]);
        $response = @file_get_contents($url, false, $context);
        
        if ($response) {
            $response = mb_convert_encoding($response, 'UTF-8', 'GBK');
            $data = json_decode($response, true);
            if ($data) {
                $province = $data['pro'] ?? '';
                $city = $data['city'] ?? '';
            }
        }
        
        // 备用API
        if (empty($province)) {
            $url2 = "http://ip-api.com/json/" . urlencode($ip) . "?lang=zh-CN&fields=regionName,city";
            $response2 = @file_get_contents($url2, false, $context);
            if ($response2) {
                $data2 = json_decode($response2, true);
                if ($data2) {
                    $province = $data2['regionName'] ?? '';
                    $city = $data2['city'] ?? '';
                }
            }
        }
        
        if (!empty($province)) {
            // 使用 REPLACE INTO 更新或插入
            $stmt = $db->prepare("REPLACE INTO user_regions (user_id, ip, province, city, update_time) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$userId, $ip, $province, $city]);
        }
    } catch (Exception $e) {
        // 静默失败，不影响登录流程
    }
}

// ==================== 数据库自动修复 ====================

/**
 * 自动修复数据库缺失的字段和表
 * 在需要的地方调用此函数
 */
function autoFixDatabase() {
    static $fixed = false;
    if ($fixed) return; // 只执行一次
    $fixed = true;
    
    try {
        $db = getDB();
        
        // 1. 修复orders表
        $columns = getTableColumns($db, 'orders');
        $orderFields = [
            'quantity' => 'INT DEFAULT 1',
            'unit_price' => 'DECIMAL(10,2) DEFAULT 0',
            'total_amount' => 'DECIMAL(10,2) DEFAULT 0',
            'pay_amount' => 'DECIMAL(10,2) DEFAULT 0',
            'auth_codes' => 'TEXT',
            'buyer_email' => 'VARCHAR(100) DEFAULT NULL',
            'buyer_ip' => 'VARCHAR(50) DEFAULT NULL',
            'ip_location' => 'VARCHAR(100) DEFAULT NULL',
            'buyer_info' => 'TEXT DEFAULT NULL',
            'is_manual' => 'TINYINT DEFAULT 0',
            'expire_time' => 'DATETIME DEFAULT NULL',
            'card_type' => "VARCHAR(20) DEFAULT 'day'",
            'duration' => 'INT DEFAULT 30'
        ];
        addMissingColumns($db, 'orders', $columns, $orderFields);
        
        // 2. 修复products表
        $columns = getTableColumns($db, 'products');
        $productFields = [
            'sales' => 'INT DEFAULT 0',
            'stock' => 'INT DEFAULT 0'
        ];
        addMissingColumns($db, 'products', $columns, $productFields);
        
        // 3. 修复auth_codes表
        $columns = getTableColumns($db, 'auth_codes');
        $authCodeFields = [
            'minutes' => 'INT DEFAULT 0',
            'card_type' => "VARCHAR(20) DEFAULT 'month'",
            'activate_mode' => "VARCHAR(20) DEFAULT 'first_use'",
            'start_time' => 'DATETIME DEFAULT NULL',
            'expire_time' => 'DATETIME DEFAULT NULL',
            'activate_time' => 'DATETIME DEFAULT NULL',
            'max_devices' => 'INT DEFAULT 1',
            'allow_multi' => 'TINYINT DEFAULT 0',
            'allow_unbind' => 'TINYINT DEFAULT 0',
            'max_unbind' => 'INT DEFAULT 3',
            'unbind_count' => 'INT DEFAULT 0',
            'single_online' => 'TINYINT DEFAULT 1',
            'ip_limit' => 'TINYINT DEFAULT 0',
            'max_ip' => 'INT DEFAULT 5',
            'used_ips' => 'TEXT',
            'use_limit' => 'TINYINT DEFAULT 0',
            'max_use' => 'INT DEFAULT 100',
            'use_count' => 'INT DEFAULT 0',
            'region_limit' => 'TINYINT DEFAULT 0',
            'allowed_regions' => 'VARCHAR(500) DEFAULT NULL',
            'bound_fingerprint' => 'VARCHAR(64) DEFAULT NULL',
            'bound_components' => 'TEXT',
            'allow_rebind' => 'INT DEFAULT 0',
            'rebind_count' => 'INT DEFAULT 0',
            // 商品关联字段
            'product_id' => 'INT DEFAULT NULL',
            // 代理商关联字段
            'agent_id' => 'INT DEFAULT NULL',
            // 点卡相关字段
            'is_point_card' => 'TINYINT DEFAULT 0',
            'total_points' => 'INT DEFAULT 0',
            'remaining_points' => 'INT DEFAULT 0',
            'deduct_type' => "VARCHAR(20) DEFAULT 'per_use'",
            'deduct_amount' => 'INT DEFAULT 1',
            'last_deduct_date' => 'DATE DEFAULT NULL'
        ];
        addMissingColumns($db, 'auth_codes', $columns, $authCodeFields);
        
        // 4. 修复agent_withdraws表
        $columns = getTableColumns($db, 'agent_withdraws');
        $withdrawFields = [
            'withdraw_type' => "VARCHAR(20) DEFAULT 'alipay'",
            'account_type' => "VARCHAR(20) DEFAULT 'alipay'"
        ];
        addMissingColumns($db, 'agent_withdraws', $columns, $withdrawFields);
        
        // 5. 修复devices表
        $columns = getTableColumns($db, 'devices');
        $deviceFields = [
            'fingerprint' => 'VARCHAR(64) DEFAULT NULL',
            'fingerprint_components' => 'TEXT',
            'platform' => 'VARCHAR(50) DEFAULT NULL',
            'os_version' => 'VARCHAR(50) DEFAULT NULL',
            'is_virtual' => 'TINYINT DEFAULT 0',
            'virtual_type' => 'VARCHAR(50) DEFAULT NULL',
            'last_ip' => 'VARCHAR(50) DEFAULT NULL',
            'activate_time' => 'DATETIME DEFAULT NULL'
        ];
        addMissingColumns($db, 'devices', $columns, $deviceFields);
        
        // 6. 修复online_sessions表
        $columns = getTableColumns($db, 'online_sessions');
        $sessionFields = [
            'auth_code_id' => 'INT DEFAULT NULL',
            'bound_ip' => 'VARCHAR(50) DEFAULT NULL',
            'bound_env_hash' => 'VARCHAR(64) DEFAULT NULL',
            'is_valid' => 'TINYINT DEFAULT 1',
            'token_expire_time' => 'DATETIME DEFAULT NULL'
        ];
        addMissingColumns($db, 'online_sessions', $columns, $sessionFields);
        
        // 7. 创建agent_orders表
        $result = $db->query("SHOW TABLES LIKE 'agent_orders'");
        if ($result->rowCount() == 0) {
            $db->exec("CREATE TABLE `agent_orders` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `order_no` varchar(50) NOT NULL,
                `agent_id` int(11) NOT NULL,
                `software_id` int(11) NOT NULL,
                `product_id` int(11) DEFAULT NULL,
                `product_name` varchar(100) DEFAULT NULL,
                `quantity` int(11) DEFAULT 1,
                `unit_price` decimal(10,2) DEFAULT 0,
                `amount` decimal(10,2) NOT NULL,
                `auth_codes` text,
                `status` tinyint(1) DEFAULT 1,
                `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `order_no` (`order_no`),
                KEY `agent_id` (`agent_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }
        
        // 8. 创建auth_logs表
        $result = $db->query("SHOW TABLES LIKE 'auth_logs'");
        if ($result->rowCount() == 0) {
            $db->exec("CREATE TABLE `auth_logs` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `software_id` int(11) DEFAULT NULL,
                `action` varchar(50) NOT NULL,
                `fingerprint` varchar(64) DEFAULT NULL,
                `ip` varchar(50) DEFAULT NULL,
                `response_code` int(11) DEFAULT NULL,
                `response_msg` varchar(255) DEFAULT NULL,
                `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `software_id` (`software_id`),
                KEY `create_time` (`create_time`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }
        
        // 9. 修复login_logs表
        $columns = getTableColumns($db, 'login_logs');
        $loginLogFields = [
            'user_agent' => 'VARCHAR(500) DEFAULT NULL'
        ];
        addMissingColumns($db, 'login_logs', $columns, $loginLogFields);
        
        // 10. 创建visit_logs表（如果不存在）
        $result = $db->query("SHOW TABLES LIKE 'visit_logs'");
        if ($result->rowCount() == 0) {
            $db->exec("CREATE TABLE `visit_logs` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `software_id` int(11) DEFAULT NULL,
                `ip` varchar(50) DEFAULT NULL,
                `region` varchar(100) DEFAULT NULL,
                `user_agent` varchar(500) DEFAULT NULL,
                `referer` varchar(500) DEFAULT NULL,
                `path` varchar(200) DEFAULT NULL,
                `method` varchar(10) DEFAULT 'GET',
                `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `create_time` (`create_time`),
                KEY `ip` (`ip`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }
        
        // 11. 创建point_logs表（点卡扣点/充值日志）
        $result = $db->query("SHOW TABLES LIKE 'point_logs'");
        if ($result->rowCount() == 0) {
            $db->exec("CREATE TABLE `point_logs` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `auth_code_id` int(11) NOT NULL,
                `software_id` int(11) DEFAULT NULL,
                `device_id` int(11) DEFAULT NULL,
                `action` varchar(20) NOT NULL COMMENT 'deduct=扣点, recharge=充值',
                `amount` int(11) NOT NULL COMMENT '变动点数',
                `before_points` int(11) DEFAULT 0 COMMENT '变动前点数',
                `after_points` int(11) DEFAULT 0 COMMENT '变动后点数',
                `reason` varchar(200) DEFAULT NULL COMMENT '原因',
                `ip` varchar(50) DEFAULT NULL,
                `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `auth_code_id` (`auth_code_id`),
                KEY `create_time` (`create_time`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }
        
    } catch (Exception $e) {
        // 静默失败
    }
}

/**
 * 获取表的所有字段名
 */
function getTableColumns($db, $table) {
    $columns = [];
    try {
        $result = $db->query("SHOW COLUMNS FROM `$table`");
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            $columns[] = $row['Field'];
        }
    } catch (Exception $e) {}
    return $columns;
}

/**
 * 添加缺失的字段
 */
function addMissingColumns($db, $table, $existingColumns, $fields) {
    foreach ($fields as $col => $def) {
        if (!in_array($col, $existingColumns)) {
            try {
                $db->exec("ALTER TABLE `$table` ADD COLUMN `$col` $def");
            } catch (Exception $e) {}
        }
    }
}
