<?php
/**
 * 微信支付异步回调
 */
require_once '../config.php';
require_once 'wechat.php';

$xmlData = file_get_contents('php://input');
$logFile = __DIR__ . '/../../logs/pay_callback.log';
$logDir = dirname($logFile);
if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
@file_put_contents($logFile, date('Y-m-d H:i:s') . " [WECHAT] XML: " . $xmlData . "\n", FILE_APPEND);

$db = getDB();

$stmt = $db->prepare("SELECT extra_config FROM payment_configs WHERE pay_type = 'wechat' AND status = 1");
$stmt->execute();
$configRow = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$configRow) {
    die('<xml><return_code><![CDATA[FAIL]]></return_code></xml>');
}

$config = json_decode($configRow['extra_config'] ?: '{}', true);
$wechat = new WechatNativePay($config);
$data = $wechat->parseNotify($xmlData);

if (empty($data) || ($data['return_code'] ?? '') !== 'SUCCESS' || ($data['result_code'] ?? '') !== 'SUCCESS') {
    die($wechat->responseFail());
}

$orderNo = $data['out_trade_no'] ?? '';
$tradeNo = $data['transaction_id'] ?? '';

@file_put_contents($logFile, date('Y-m-d H:i:s') . " [WECHAT] INFO: 订单号={$orderNo}, 交易号={$tradeNo}\n", FILE_APPEND);

$stmt = $db->prepare("SELECT * FROM orders WHERE order_no = ? AND status = 0");
$stmt->execute([$orderNo]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die($wechat->responseSuccess());
}

try {
    $db->beginTransaction();
    
    $stmt = $db->prepare("UPDATE orders SET status = 1, trade_no = ?, pay_time = NOW() WHERE order_no = ? AND status = 0");
    $stmt->execute([$tradeNo, $orderNo]);
    
    if ($stmt->rowCount() > 0) {
        $authCodes = [];
        for ($i = 0; $i < $order['quantity']; $i++) {
            $code = strtoupper(bin2hex(random_bytes(16)));
            $days = intval($order['duration'] ?? 30);
            $cardType = $order['card_type'] ?? 'day';
            $expireTime = null;
            
            switch ($cardType) {
                case 'minute': $expireTime = date('Y-m-d H:i:s', strtotime("+{$days} minutes")); $days = 0; break;
                case 'hour': $expireTime = date('Y-m-d H:i:s', strtotime("+{$days} hours")); $days = 0; break;
                case 'day': $expireTime = date('Y-m-d H:i:s', strtotime("+{$days} days")); break;
                case 'week': $expireTime = date('Y-m-d H:i:s', strtotime("+{$days} weeks")); $days = $days * 7; break;
                case 'month': $expireTime = date('Y-m-d H:i:s', strtotime("+{$days} months")); $days = $days * 30; break;
                case 'quarter': $expireTime = date('Y-m-d H:i:s', strtotime("+" . ($days * 3) . " months")); $days = $days * 90; break;
                case 'year': $expireTime = date('Y-m-d H:i:s', strtotime("+{$days} years")); $days = $days * 365; break;
                case 'permanent': $days = 36500; $expireTime = null; break;
            }
            
            $stmt = $db->prepare("INSERT INTO auth_codes (software_id, code, card_type, days, expire_time, status, remark) VALUES (?, ?, ?, ?, ?, 0, ?)");
            $stmt->execute([$order['software_id'], $code, $cardType, $days, $expireTime, '订单:' . $orderNo]);
            $authCodes[] = $code;
        }
        
        @file_put_contents($logFile, date('Y-m-d H:i:s') . " [WECHAT] INFO: 生成授权码=" . implode(',', $authCodes) . "\n", FILE_APPEND);
        
        $stmt = $db->prepare("UPDATE orders SET auth_codes = ? WHERE order_no = ?");
        $stmt->execute([json_encode($authCodes), $orderNo]);
        
        if ($order['product_id']) {
            $stmt = $db->prepare("UPDATE products SET sales = sales + ? WHERE id = ?");
            $stmt->execute([$order['quantity'], $order['product_id']]);
        }
    }
    
    $db->commit();
    @file_put_contents($logFile, date('Y-m-d H:i:s') . " [WECHAT] SUCCESS: 订单处理完成\n", FILE_APPEND);
    
    // 记录运行日志
    logRuntime('info', "微信订单支付成功: {$orderNo}, 金额: {$order['amount']}", 'payment', $_SERVER['REMOTE_ADDR'] ?? '', 0, $order['software_id']);
    
    // 发送订单支付成功通知
    try {
        require_once __DIR__ . '/../notifier.php';
        $notifier = new Notifier($db);
        $notifier->send('order_paid', '订单支付成功', 
            "订单号: {$orderNo}\n" .
            "金额: ¥{$order['amount']}\n" .
            "商品: {$order['product_name']}\n" .
            "数量: {$order['quantity']}\n" .
            "授权码: " . implode(', ', $authCodes) . "\n" .
            "时间: " . date('Y-m-d H:i:s')
        );
    } catch (Exception $e) {}
    
    echo $wechat->responseSuccess();
} catch (Exception $e) {
    $db->rollBack();
    @file_put_contents($logFile, date('Y-m-d H:i:s') . " [WECHAT] ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
    echo $wechat->responseFail();
}
