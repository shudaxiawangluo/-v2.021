<?php
/**
 * USDT支付回调处理
 */
require_once '../config.php';
require_once 'usdt.php';

// 记录回调日志
$logFile = __DIR__ . '/../../logs/pay_callback.log';
$logDir = dirname($logFile);
if (!is_dir($logDir)) @mkdir($logDir, 0755, true);

$db = getDB();

// 获取回调数据
$input = file_get_contents('php://input');
$params = json_decode($input, true);
if (empty($params)) {
    $params = $_POST;
}

$logData = date('Y-m-d H:i:s') . " [USDT] DATA: " . json_encode($params, JSON_UNESCAPED_UNICODE) . "\n";
@file_put_contents($logFile, $logData, FILE_APPEND);

// 获取订单号
$orderNo = $params['order_id'] ?? $params['out_trade_no'] ?? '';
if (empty($orderNo)) {
    @file_put_contents($logFile, date('Y-m-d H:i:s') . " [USDT] ERROR: 订单号为空\n", FILE_APPEND);
    die('fail');
}

@file_put_contents($logFile, date('Y-m-d H:i:s') . " [USDT] INFO: 订单号={$orderNo}\n", FILE_APPEND);

// 查询订单
$stmt = $db->prepare("SELECT * FROM orders WHERE order_no = ? AND status = 0");
$stmt->execute([$orderNo]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    @file_put_contents($logFile, date('Y-m-d H:i:s') . " [USDT] INFO: 订单不存在或已处理\n", FILE_APPEND);
    die('order not found');
}

// 检查支付状态
$status = $params['status'] ?? '';
if ($status == 2 || $status == 'paid' || $status == 'completed' || $status == 'success') {
    $tradeNo = $params['trade_id'] ?? $params['transaction_id'] ?? $orderNo;
    
    @file_put_contents($logFile, date('Y-m-d H:i:s') . " [USDT] INFO: 找到订单，开始处理\n", FILE_APPEND);
    
    try {
        $db->beginTransaction();
        
        // 更新订单状态
        $stmt = $db->prepare("UPDATE orders SET status = 1, trade_no = ?, pay_time = NOW() WHERE order_no = ? AND status = 0");
        $stmt->execute([$tradeNo, $orderNo]);
        
        if ($stmt->rowCount() > 0) {
            // 生成授权码
            $authCodes = [];
            for ($i = 0; $i < $order['quantity']; $i++) {
                $code = strtoupper(bin2hex(random_bytes(16)));
                
                // 计算过期时间和天数
                $expireTime = null;
                $days = intval($order['duration'] ?? 30);
                $cardType = $order['card_type'] ?? 'day';
                
                // 根据卡类型计算天数
                switch ($cardType) {
                    case 'minute': $days = 0; break;
                    case 'hour': $days = 0; break;
                    case 'day': break;
                    case 'week': $days = $days * 7; break;
                    case 'month': $days = $days * 30; break;
                    case 'quarter': $days = $days * 90; break;
                    case 'year': $days = $days * 365; break;
                    case 'permanent': $days = 36500; break;
                }
                
                // 计算过期时间
                if ($cardType !== 'permanent') {
                    $duration = intval($order['duration'] ?? 30);
                    switch ($cardType) {
                        case 'minute': $expireTime = date('Y-m-d H:i:s', strtotime("+{$duration} minutes")); break;
                        case 'hour': $expireTime = date('Y-m-d H:i:s', strtotime("+{$duration} hours")); break;
                        case 'day': $expireTime = date('Y-m-d H:i:s', strtotime("+{$duration} days")); break;
                        case 'week': $expireTime = date('Y-m-d H:i:s', strtotime("+{$duration} weeks")); break;
                        case 'month': $expireTime = date('Y-m-d H:i:s', strtotime("+{$duration} months")); break;
                        case 'quarter': $expireTime = date('Y-m-d H:i:s', strtotime("+" . ($duration * 3) . " months")); break;
                        case 'year': $expireTime = date('Y-m-d H:i:s', strtotime("+{$duration} years")); break;
                    }
                }
                
                // 使用正确的字段名
                $stmt = $db->prepare("INSERT INTO auth_codes (software_id, code, card_type, days, expire_time, status, remark) VALUES (?, ?, ?, ?, ?, 0, ?)");
                $stmt->execute([
                    $order['software_id'],
                    $code,
                    $cardType,
                    $days,
                    $expireTime,
                    '订单:' . $orderNo
                ]);
                
                $authCodes[] = $code;
            }
            
            @file_put_contents($logFile, date('Y-m-d H:i:s') . " [USDT] INFO: 生成授权码=" . implode(',', $authCodes) . "\n", FILE_APPEND);
            
            // 更新订单授权码
            $stmt = $db->prepare("UPDATE orders SET auth_codes = ? WHERE order_no = ?");
            $stmt->execute([json_encode($authCodes), $orderNo]);
            
            // 更新商品销量
            if ($order['product_id']) {
                $stmt = $db->prepare("UPDATE products SET sales = sales + ? WHERE id = ?");
                $stmt->execute([$order['quantity'], $order['product_id']]);
            }
        }
        
        $db->commit();
        @file_put_contents($logFile, date('Y-m-d H:i:s') . " [USDT] SUCCESS: 订单处理完成\n", FILE_APPEND);
        
        // 发送订单支付成功通知
        try {
            require_once __DIR__ . '/../notifier.php';
            $notifier = new Notifier($db);
            $notifier->send('order_paid', '💰 订单支付成功', 
                "> 订单号: {$orderNo}\n" .
                "> 金额: ¥{$order['amount']}\n" .
                "> 商品: {$order['product_name']}\n" .
                "> 数量: {$order['quantity']}\n" .
                "> 授权码: " . implode(', ', $authCodes) . "\n" .
                "> 时间: " . date('Y-m-d H:i:s')
            );
        } catch (Exception $e) {}
        
        echo 'success';
    } catch (Exception $e) {
        $db->rollBack();
        @file_put_contents($logFile, date('Y-m-d H:i:s') . " [USDT] ERROR: " . $e->getMessage() . "\n", FILE_APPEND);
        error_log('USDT Notify Error: ' . $e->getMessage());
        die('error');
    }
} else {
    @file_put_contents($logFile, date('Y-m-d H:i:s') . " [USDT] INFO: 状态不是成功，status={$status}\n", FILE_APPEND);
    die('status error');
}
