<?php
/**
 * USDT支付接口类
 * 支持对接 Epusdt / Mugglepay / TokenPay 等USDT支付网关
 * 支持手动地址模式（用户自行转账到指定地址）
 */
class UsdtPay {
    private $apiUrl;
    private $apiToken;
    private $notifyUrl;
    private $returnUrl;
    private $usdtRate; // 人民币兑USDT汇率
    private $mode; // gateway=网关模式, manual=手动地址模式
    private $trc20Address; // TRC20收款地址
    private $erc20Address; // ERC20收款地址
    
    public function __construct($config) {
        $this->mode = $config['mode'] ?? 'gateway';
        $this->apiUrl = rtrim($config['api_url'] ?? '', '/');
        $this->apiToken = $config['api_token'] ?? '';
        $this->notifyUrl = $config['notify_url'] ?? '';
        $this->returnUrl = $config['return_url'] ?? '';
        $this->usdtRate = floatval($config['usdt_rate'] ?? 7.2); // 默认汇率
        $this->trc20Address = $config['trc20_address'] ?? '';
        $this->erc20Address = $config['erc20_address'] ?? '';
    }
    
    /**
     * 创建USDT支付订单
     * @param string $orderNo 订单号
     * @param float $amount 人民币金额
     * @param string $subject 商品名称
     * @return array
     */
    public function createOrder($orderNo, $amount, $subject) {
        // 将人民币转换为USDT金额
        $usdtAmount = round($amount / $this->usdtRate, 2);
        
        // 手动地址模式
        if ($this->mode === 'manual') {
            return $this->createManualOrder($orderNo, $usdtAmount);
        }
        
        // 网关模式
        return $this->createGatewayOrder($orderNo, $usdtAmount, $subject);
    }
    
    /**
     * 手动地址模式 - 直接返回收款地址
     */
    private function createManualOrder($orderNo, $usdtAmount) {
        $address = $this->trc20Address ?: $this->erc20Address;
        
        if (empty($address)) {
            return ['code' => 1, 'msg' => 'USDT收款地址未配置'];
        }
        
        return [
            'code' => 0,
            'trade_id' => $orderNo,
            'amount' => $usdtAmount,
            'address' => $address,
            'network' => $this->trc20Address ? 'TRC20' : 'ERC20',
            'qr_code' => '', // 前端会生成二维码
            'pay_url' => '',
            'mode' => 'manual',
            'tip' => '请转账 ' . $usdtAmount . ' USDT 到上述地址，转账完成后请联系客服确认'
        ];
    }
    
    /**
     * 网关模式 - 调用第三方支付网关
     */
    private function createGatewayOrder($orderNo, $usdtAmount, $subject) {
        $params = [
            'order_id' => $orderNo,
            'amount' => $usdtAmount,
            'actual_amount' => $usdtAmount,
            'token' => $this->apiToken,
            'notify_url' => $this->notifyUrl,
            'redirect_url' => $this->returnUrl,
            'product_name' => $subject
        ];
        
        // 生成签名
        $params['signature'] = $this->generateSign($params);
        
        $response = $this->httpPost($this->apiUrl . '/api/v1/order/create-transaction', $params);
        $result = json_decode($response, true);
        
        if ($result && isset($result['status_code']) && $result['status_code'] == 200) {
            return [
                'code' => 0,
                'trade_id' => $result['data']['trade_id'] ?? '',
                'amount' => $usdtAmount,
                'address' => $result['data']['token'] ?? '', // USDT收款地址
                'qr_code' => $result['data']['qr_code'] ?? '',
                'pay_url' => $result['data']['payment_url'] ?? '',
                'expire_time' => $result['data']['expiration_time'] ?? '',
                'mode' => 'gateway'
            ];
        }
        
        // 如果是Epusdt格式
        if ($result && isset($result['code']) && $result['code'] == 200) {
            return [
                'code' => 0,
                'trade_id' => $result['data']['trade_id'] ?? $orderNo,
                'amount' => $usdtAmount,
                'address' => $result['data']['token'] ?? '',
                'qr_code' => $result['data']['qrcode_url'] ?? '',
                'pay_url' => $result['data']['payment_url'] ?? '',
                'mode' => 'gateway'
            ];
        }
        
        return ['code' => 1, 'msg' => $result['message'] ?? $result['msg'] ?? '创建USDT订单失败'];
    }
    
    /**
     * 查询订单状态
     */
    public function queryOrder($orderNo) {
        // 手动模式不支持自动查询，需要管理员手动确认
        if ($this->mode === 'manual') {
            return ['code' => 1, 'msg' => '手动模式请联系客服确认支付'];
        }
        
        $params = [
            'order_id' => $orderNo,
            'token' => $this->apiToken
        ];
        $params['signature'] = $this->generateSign($params);
        
        $response = $this->httpPost($this->apiUrl . '/api/v1/order/query', $params);
        $result = json_decode($response, true);
        
        if ($result) {
            // 状态：1待支付 2已支付 3已过期
            $status = $result['data']['status'] ?? $result['status'] ?? 0;
            if ($status == 2 || $status == 'paid' || $status == 'completed') {
                return [
                    'code' => 0,
                    'status' => 1, // 已支付
                    'trade_no' => $result['data']['trade_id'] ?? $orderNo
                ];
            }
        }
        
        return ['code' => 1, 'msg' => '订单未支付或查询失败'];
    }
    
    /**
     * 验证回调签名
     */
    public function verifyNotify($params) {
        if (empty($params['signature'])) return false;
        
        $sign = $params['signature'];
        unset($params['signature']);
        
        return $this->generateSign($params) === $sign;
    }
    
    /**
     * 生成签名
     */
    private function generateSign($params) {
        ksort($params);
        $signStr = '';
        foreach ($params as $k => $v) {
            if ($v !== '' && $v !== null && $k !== 'signature') {
                $signStr .= $k . '=' . $v . '&';
            }
        }
        $signStr = rtrim($signStr, '&');
        return md5($signStr . $this->apiToken);
    }
    
    /**
     * HTTP POST请求
     */
    private function httpPost($url, $data) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json'
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}
