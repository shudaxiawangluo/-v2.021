<?php
/**
 * 易支付/彩虹易支付 对接类
 */
class EpayClient {
    private $apiUrl;
    private $pid;
    private $key;
    private $notifyUrl;
    private $returnUrl;
    
    public function __construct($config) {
        $this->apiUrl = rtrim($config['api_url'] ?? '', '/');
        $this->pid = $config['pid'] ?? '';
        $this->key = $config['key'] ?? '';
        $this->notifyUrl = $config['notify_url'] ?? '';
        $this->returnUrl = $config['return_url'] ?? '';
    }
    
    /**
     * 生成支付跳转URL
     * @param string $orderNo 订单号
     * @param float $amount 金额
     * @param string $subject 商品名称
     * @param string $payType 支付类型：alipay/wxpay/qqpay
     */
    public function createPayUrl($orderNo, $amount, $subject, $payType = 'alipay') {
        $params = [
            'pid' => $this->pid,
            'type' => $payType,
            'out_trade_no' => $orderNo,
            'notify_url' => $this->notifyUrl,
            'return_url' => $this->returnUrl,
            'name' => $subject,
            'money' => number_format($amount, 2, '.', ''),
            'sitename' => '鼠大侠授权系统'
        ];
        
        $params['sign'] = $this->generateSign($params);
        $params['sign_type'] = 'MD5';
        
        return $this->apiUrl . '/submit.php?' . http_build_query($params);
    }
    
    /**
     * 获取支付二维码（API模式）
     */
    public function getQrCode($orderNo, $amount, $subject, $payType = 'alipay') {
        $params = [
            'pid' => $this->pid,
            'type' => $payType,
            'out_trade_no' => $orderNo,
            'notify_url' => $this->notifyUrl,
            'name' => $subject,
            'money' => number_format($amount, 2, '.', '')
        ];
        
        $params['sign'] = $this->generateSign($params);
        $params['sign_type'] = 'MD5';
        
        $url = $this->apiUrl . '/mapi.php?' . http_build_query($params);
        $response = $this->httpGet($url);
        $result = json_decode($response, true);
        
        if ($result && $result['code'] == 1) {
            return ['code' => 0, 'qr_code' => $result['qrcode'] ?? '', 'pay_url' => $result['payurl'] ?? ''];
        }
        
        return ['code' => 1, 'msg' => $result['msg'] ?? '获取支付信息失败'];
    }
    
    /**
     * 查询订单状态
     */
    public function queryOrder($orderNo) {
        $params = [
            'act' => 'order',
            'pid' => $this->pid,
            'key' => $this->key,
            'out_trade_no' => $orderNo
        ];
        
        $url = $this->apiUrl . '/api.php?' . http_build_query($params);
        $response = $this->httpGet($url);
        $result = json_decode($response, true);
        
        if ($result && $result['code'] == 1) {
            return [
                'code' => 0,
                'status' => $result['status'], // 1已支付 0未支付
                'trade_no' => $result['trade_no'] ?? ''
            ];
        }
        
        return ['code' => 1, 'msg' => $result['msg'] ?? '查询失败'];
    }
    
    /**
     * 验证异步通知签名
     */
    public function verifyNotify($params) {
        if (empty($params['sign'])) return false;
        
        $sign = $params['sign'];
        unset($params['sign'], $params['sign_type']);
        
        return $this->generateSign($params) === $sign;
    }
    
    /**
     * 生成签名
     */
    private function generateSign($params) {
        ksort($params);
        $signStr = '';
        foreach ($params as $k => $v) {
            if ($v !== '' && $v !== null && $k !== 'sign' && $k !== 'sign_type') {
                $signStr .= $k . '=' . $v . '&';
            }
        }
        $signStr = rtrim($signStr, '&') . $this->key;
        return md5($signStr);
    }
    
    /**
     * HTTP GET请求
     */
    private function httpGet($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}
