<?php
/**
 * 支付宝当面付 - 无SDK版本
 * 使用RSA2签名，直接调用支付宝API
 */
class AlipayFacePay {
    private $appId;
    private $privateKey;
    private $alipayPublicKey;
    private $notifyUrl;
    private $gatewayUrl = 'https://openapi.alipay.com/gateway.do';
    
    public function __construct($config) {
        $this->appId = $config['app_id'] ?? '';
        $this->privateKey = $config['private_key'] ?? '';
        $this->alipayPublicKey = $config['alipay_public_key'] ?? '';
        $this->notifyUrl = $config['notify_url'] ?? '';
    }
    
    /**
     * 创建当面付订单，返回二维码链接
     */
    public function createQrCode($orderNo, $amount, $subject) {
        // 确保商品名称是UTF-8编码，并限制长度
        $subject = mb_substr($subject, 0, 128, 'UTF-8');
        
        $bizContent = json_encode([
            'out_trade_no' => $orderNo,
            'total_amount' => number_format($amount, 2, '.', ''),
            'subject' => $subject,
            'timeout_express' => '30m'
        ], JSON_UNESCAPED_UNICODE);
        
        $params = [
            'app_id' => $this->appId,
            'method' => 'alipay.trade.precreate',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'notify_url' => $this->notifyUrl,
            'biz_content' => $bizContent
        ];
        
        $params['sign'] = $this->generateSign($params);
        
        $response = $this->httpPost($this->gatewayUrl, $params);
        $result = json_decode($response, true);
        
        if (isset($result['alipay_trade_precreate_response'])) {
            $res = $result['alipay_trade_precreate_response'];
            if ($res['code'] == '10000') {
                return ['code' => 0, 'qr_code' => $res['qr_code']];
            }
            return ['code' => 1, 'msg' => $res['sub_msg'] ?? $res['msg'] ?? '创建订单失败'];
        }
        
        return ['code' => 1, 'msg' => '请求支付宝失败'];
    }
    
    /**
     * 查询订单状态
     */
    public function queryOrder($orderNo) {
        $bizContent = json_encode(['out_trade_no' => $orderNo], JSON_UNESCAPED_UNICODE);
        
        $params = [
            'app_id' => $this->appId,
            'method' => 'alipay.trade.query',
            'format' => 'JSON',
            'charset' => 'utf-8',
            'sign_type' => 'RSA2',
            'timestamp' => date('Y-m-d H:i:s'),
            'version' => '1.0',
            'biz_content' => $bizContent
        ];
        
        $params['sign'] = $this->generateSign($params);
        
        $response = $this->httpPost($this->gatewayUrl, $params);
        $result = json_decode($response, true);
        
        if (isset($result['alipay_trade_query_response'])) {
            $res = $result['alipay_trade_query_response'];
            if ($res['code'] == '10000') {
                return [
                    'code' => 0,
                    'trade_status' => $res['trade_status'],
                    'trade_no' => $res['trade_no'] ?? ''
                ];
            }
        }
        
        return ['code' => 1, 'msg' => '查询失败'];
    }
    
    /**
     * 验证异步通知签名
     */
    public function verifyNotify($params) {
        if (empty($params['sign'])) return false;
        
        $sign = $params['sign'];
        unset($params['sign'], $params['sign_type']);
        
        ksort($params);
        $signStr = '';
        foreach ($params as $k => $v) {
            if ($v !== '' && $v !== null) {
                $signStr .= $k . '=' . $v . '&';
            }
        }
        $signStr = rtrim($signStr, '&');
        
        $publicKey = "-----BEGIN PUBLIC KEY-----\n" . 
                     wordwrap($this->alipayPublicKey, 64, "\n", true) . 
                     "\n-----END PUBLIC KEY-----";
        
        return openssl_verify($signStr, base64_decode($sign), $publicKey, OPENSSL_ALGO_SHA256) === 1;
    }
    
    /**
     * 生成RSA2签名
     */
    private function generateSign($params) {
        ksort($params);
        $signStr = '';
        foreach ($params as $k => $v) {
            if ($v !== '' && $v !== null && $k !== 'sign') {
                $signStr .= $k . '=' . $v . '&';
            }
        }
        $signStr = rtrim($signStr, '&');
        
        $privateKey = "-----BEGIN RSA PRIVATE KEY-----\n" . 
                      wordwrap($this->privateKey, 64, "\n", true) . 
                      "\n-----END RSA PRIVATE KEY-----";
        
        openssl_sign($signStr, $sign, $privateKey, OPENSSL_ALGO_SHA256);
        return base64_encode($sign);
    }
    
    /**
     * HTTP POST请求
     */
    private function httpPost($url, $data) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data, '', '&', PHP_QUERY_RFC3986));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded; charset=utf-8']);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}
