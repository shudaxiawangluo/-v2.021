<?php
/**
 * 微信支付 Native支付 - V2版本（无SDK）
 */
class WechatNativePay {
    private $appId;
    private $mchId;
    private $apiKey;
    private $notifyUrl;
    private $apiUrl = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
    private $queryUrl = 'https://api.mch.weixin.qq.com/pay/orderquery';
    
    public function __construct($config) {
        $this->appId = $config['app_id'] ?? '';
        $this->mchId = $config['mch_id'] ?? '';
        $this->apiKey = $config['api_key'] ?? '';
        $this->notifyUrl = $config['notify_url'] ?? '';
    }
    
    /**
     * 创建Native支付订单，返回二维码链接
     */
    public function createQrCode($orderNo, $amount, $subject, $clientIp = '') {
        $params = [
            'appid' => $this->appId,
            'mch_id' => $this->mchId,
            'nonce_str' => $this->generateNonceStr(),
            'body' => $subject,
            'out_trade_no' => $orderNo,
            'total_fee' => intval($amount * 100), // 微信金额单位是分
            'spbill_create_ip' => $clientIp ?: $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'notify_url' => $this->notifyUrl,
            'trade_type' => 'NATIVE',
            'time_expire' => date('YmdHis', time() + 1800) // 30分钟过期
        ];
        
        $params['sign'] = $this->generateSign($params);
        
        $xml = $this->arrayToXml($params);
        $response = $this->httpPost($this->apiUrl, $xml);
        $result = $this->xmlToArray($response);
        
        if ($result && $result['return_code'] == 'SUCCESS') {
            if ($result['result_code'] == 'SUCCESS') {
                return ['code' => 0, 'qr_code' => $result['code_url']];
            }
            return ['code' => 1, 'msg' => $result['err_code_des'] ?? '创建订单失败'];
        }
        
        return ['code' => 1, 'msg' => $result['return_msg'] ?? '请求微信支付失败'];
    }
    
    /**
     * 查询订单状态
     */
    public function queryOrder($orderNo) {
        $params = [
            'appid' => $this->appId,
            'mch_id' => $this->mchId,
            'out_trade_no' => $orderNo,
            'nonce_str' => $this->generateNonceStr()
        ];
        
        $params['sign'] = $this->generateSign($params);
        
        $xml = $this->arrayToXml($params);
        $response = $this->httpPost($this->queryUrl, $xml);
        $result = $this->xmlToArray($response);
        
        if ($result && $result['return_code'] == 'SUCCESS' && $result['result_code'] == 'SUCCESS') {
            return [
                'code' => 0,
                'trade_state' => $result['trade_state'],
                'transaction_id' => $result['transaction_id'] ?? ''
            ];
        }
        
        return ['code' => 1, 'msg' => '查询失败'];
    }
    
    /**
     * 验证异步通知签名
     */
    public function verifyNotify($xmlData) {
        $data = $this->xmlToArray($xmlData);
        if (empty($data) || empty($data['sign'])) return false;
        
        $sign = $data['sign'];
        unset($data['sign']);
        
        return $this->generateSign($data) === $sign;
    }
    
    /**
     * 解析通知数据
     */
    public function parseNotify($xmlData) {
        return $this->xmlToArray($xmlData);
    }
    
    /**
     * 生成响应XML
     */
    public function responseSuccess() {
        return '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>';
    }
    
    public function responseFail($msg = 'FAIL') {
        return '<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[' . $msg . ']]></return_msg></xml>';
    }
    
    /**
     * 生成签名
     */
    private function generateSign($params) {
        ksort($params);
        $signStr = '';
        foreach ($params as $k => $v) {
            if ($v !== '' && $v !== null && $k !== 'sign') {
                $signStr .= $k . '=' . $v . '&';
            }
        }
        $signStr .= 'key=' . $this->apiKey;
        return strtoupper(md5($signStr));
    }
    
    /**
     * 生成随机字符串
     */
    private function generateNonceStr($length = 32) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $str = '';
        for ($i = 0; $i < $length; $i++) {
            $str .= $chars[mt_rand(0, strlen($chars) - 1)];
        }
        return $str;
    }
    
    /**
     * 数组转XML
     */
    private function arrayToXml($data) {
        $xml = '<xml>';
        foreach ($data as $k => $v) {
            $xml .= '<' . $k . '><![CDATA[' . $v . ']]></' . $k . '>';
        }
        $xml .= '</xml>';
        return $xml;
    }
    
    /**
     * XML转数组
     */
    private function xmlToArray($xml) {
        if (empty($xml)) return [];
        libxml_disable_entity_loader(true);
        $result = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
        return json_decode(json_encode($result), true);
    }
    
    /**
     * HTTP POST请求
     */
    private function httpPost($url, $data) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: text/xml']);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
}
