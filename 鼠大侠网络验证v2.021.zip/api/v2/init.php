<?php
/**
 * V2 初始化接口
 * 获取服务端公钥和配置信息
 * 
 * 请求: POST
 * 参数: app_key - 软件AppKey
 * 
 * 响应:
 * {
 *   "code": 200,
 *   "data": {
 *     "public_key": "RSA公钥",
 *     "server_time": 时间戳,
 *     "heartbeat_interval": 5
 *   }
 * }
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// 处理OPTIONS预检请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 只允许POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/lib/RSAHelper.php';
require_once __DIR__ . '/lib/AESHelper.php';

// 获取数据库连接
$db = getDB();

// 心跳间隔固定5秒
define('HEARTBEAT_INTERVAL', 5);

/**
 * 记录日志（同时写入auth_logs和runtime_logs）
 */
function logAuth($softwareId, $action, $responseCode, $message, $ip, $fingerprint = null) {
    global $db;
    try {
        // 写入auth_logs
        $stmt = $db->prepare("INSERT INTO auth_logs (software_id, action, fingerprint, ip, response_code, response_msg, create_time) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$softwareId, $action, $fingerprint, $ip, $responseCode, $message]);
        
        // 同时写入runtime_logs（后台可见）
        $type = $responseCode == 200 ? 'info' : 'error';
        $content = "[{$action}] code={$responseCode}, {$message}" . ($fingerprint ? ", fp=" . substr($fingerprint, 0, 16) . "..." : "");
        $stmt2 = $db->prepare("INSERT INTO runtime_logs (type, module, content, ip, software_id, create_time) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt2->execute([$type, 'v2_api', $content, $ip, $softwareId]);
    } catch (Exception $e) {
        // 忽略日志错误
    }
}

try {
    // 获取请求数据
    $input = file_get_contents('php://input');
    $request = json_decode($input, true);
    
    if (!$request) {
        // 尝试从POST获取
        $request = $_POST;
    }
    
    // 验证app_key
    $appKey = trim($request['app_key'] ?? '');
    if (empty($appKey)) {
        jsonResponse(400, '缺少app_key参数');
    }
    
    // 获取客户端IP
    $clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    if (strpos($clientIp, ',') !== false) {
        $clientIp = trim(explode(',', $clientIp)[0]);
    }
    
    // 检查IP黑名单（白名单IP跳过黑名单检查）
    if (!checkIPWhitelist($clientIp, 0) && checkIPBlacklist($clientIp)) {
        logRuntime('warning', "[init] IP黑名单拦截: {$clientIp}", 'v2_api', $clientIp);
        jsonResponse(403, 'IP已被封禁');
    }
    
    // 查询软件信息
    $stmt = $db->prepare("SELECT id, name, public_key, private_key, status FROM software WHERE app_key = ?");
    $stmt->execute([$appKey]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software) {
        logAuth(0, 'init', 404, '软件不存在: ' . $appKey, $clientIp);
        jsonResponse(404, '软件不存在');
    }
    
    if ($software['status'] != 1) {
        logAuth($software['id'], 'init', 403, '软件已禁用', $clientIp);
        jsonResponse(403, '软件已禁用');
    }
    
    // 检查是否有RSA密钥
    if (empty($software['public_key']) || empty($software['private_key'])) {
        // 自动生成密钥对
        $keyPair = RSAHelper::generateKeyPair();
        
        // AES加密私钥存储
        $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
        $aes = new AESHelper($aesKey);
        $encryptedPrivateKey = $aes->encrypt($keyPair['private_key']);
        
        // 更新数据库
        $updateStmt = $db->prepare("UPDATE software SET public_key = ?, private_key = ? WHERE id = ?");
        $updateStmt->execute([$keyPair['public_key'], $encryptedPrivateKey, $software['id']]);
        
        $publicKey = $keyPair['public_key'];
    } else {
        $publicKey = $software['public_key'];
    }
    
    // 记录成功日志
    logAuth($software['id'], 'init', 200, '初始化成功', $clientIp);
    
    // 返回响应
    jsonResponse(200, '成功', [
        'public_key' => $publicKey,
        'server_time' => time(),
        'heartbeat_interval' => HEARTBEAT_INTERVAL
    ]);
    
} catch (Exception $e) {
    logAuth(0, 'init', 500, $e->getMessage(), $clientIp ?? '');
    jsonResponse(500, '服务器错误');
}
