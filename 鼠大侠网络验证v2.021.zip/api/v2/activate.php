<?php
/**
 * V2 激活接口
 * 使用授权码激活软件
 * 
 * 文件版本: 2026-01-15 v4
 * 修复: 
 * - 卡密时间计算问题，优先使用minutes字段
 * - 不再叠加设备已有时间
 * - days字段始终按天数计算
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/lib/RSAHelper.php';
require_once __DIR__ . '/lib/JWTHelper.php';
require_once __DIR__ . '/lib/AESHelper.php';
require_once __DIR__ . '/lib/AntiReplay.php';
require_once __DIR__ . '/lib/FingerprintHelper.php';

// 自动修复数据库字段
autoFixDatabase();

$db = getDB();

function logAuth($db, $softwareId, $action, $responseCode, $message, $ip, $fingerprint = null) {
    try {
        $stmt = $db->prepare("INSERT INTO auth_logs (software_id, action, fingerprint, ip, response_code, response_msg, create_time) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$softwareId, $action, $fingerprint, $ip, $responseCode, $message]);
        
        $type = $responseCode == 200 ? 'info' : 'error';
        $content = "[{$action}] code={$responseCode}, {$message}" . ($fingerprint ? ", fp=" . substr($fingerprint, 0, 16) . "..." : "");
        $stmt2 = $db->prepare("INSERT INTO runtime_logs (type, module, content, ip, software_id, create_time) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt2->execute([$type, 'v2_api', $content, $ip, $softwareId]);
    } catch (Exception $e) {}
}

/**
 * 根据卡密信息计算到期秒数
 * 优先使用 minutes 字段，这是最精确的
 */
function calculateExpireSeconds($codeInfo) {
    $minutes = intval($codeInfo['minutes'] ?? 0);
    $days = intval($codeInfo['days'] ?? 0);
    $cardType = $codeInfo['card_type'] ?? 'month';
    
    // 优先使用minutes字段（最精确）
    if ($minutes > 0) {
        return $minutes * 60;
    }
    
    // 如果没有minutes，使用days字段（days始终是天数）
    if ($days > 0) {
        return $days * 86400;
    }
    
    // 都没有，使用默认值
    switch ($cardType) {
        case 'minute': return 60;                  // 默认1分钟
        case 'hour': return 3600;                  // 默认1小时
        case 'day': return 86400;                  // 默认1天
        case 'week': return 7 * 86400;             // 7天
        case 'month': return 30 * 86400;           // 30天
        case 'quarter': return 90 * 86400;         // 90天
        case 'year': return 365 * 86400;           // 365天
        case 'permanent': return 36500 * 86400;    // 100年
        default: return 30 * 86400;                // 默认30天
    }
}

try {
    $clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    if (strpos($clientIp, ',') !== false) {
        $clientIp = trim(explode(',', $clientIp)[0]);
    }
    
    // 检查IP黑名单
    if (!checkIPWhitelist($clientIp, 0) && checkIPBlacklist($clientIp)) {
        logRuntime('warning', "[activate] IP黑名单拦截: {$clientIp}", 'v2_api', $clientIp);
        jsonResponse(403, 'IP已被封禁');
    }
    
    $input = file_get_contents('php://input');
    $rawRequest = json_decode($input, true);
    
    if (!$rawRequest) {
        jsonResponse(400, '无效的请求数据');
    }
    
    $appKey = trim($rawRequest['app_key'] ?? '');
    if (empty($appKey)) {
        jsonResponse(400, '缺少app_key参数');
    }
    
    // 查询软件信息
    $stmt = $db->prepare("SELECT id, name, public_key, private_key, status FROM software WHERE app_key = ?");
    $stmt->execute([$appKey]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software) {
        logAuth($db, 0, 'activate', 404, '软件不存在', $clientIp);
        jsonResponse(404, '软件不存在');
    }
    
    if ($software['status'] != 1) {
        logAuth($db, $software['id'], 'activate', 403, '软件已禁用', $clientIp);
        jsonResponse(403, '软件已禁用');
    }
    
    // 解密私钥
    $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
    $aes = new AESHelper($aesKey);
    
    try {
        $privateKey = $aes->decrypt($software['private_key']);
    } catch (Exception $e) {
        $privateKey = $software['private_key'];
    }
    
    // RSA解密请求数据（支持明文模式）
    $rsa = new RSAHelper();
    $rsa->setPrivateKey($privateKey);
    $rsa->setPublicKey($software['public_key']);
    
    $encryptedData = $rawRequest['data'] ?? '';
    if (empty($encryptedData)) {
        jsonResponse(400, '缺少加密数据');
    }
    
    // 判断是否为明文模式（兼容不支持RSA的客户端）
    if (is_array($encryptedData)) {
        // 明文模式：data字段直接是JSON对象
        $request = $encryptedData;
        logRuntime('debug', "[activate] 使用明文模式", 'v2_api', $clientIp, 0, $software['id']);
    } else {
        // 加密模式：data字段是RSA加密的字符串
        try {
            $request = $rsa->decryptJson($encryptedData);
        } catch (Exception $e) {
            logAuth($db, $software['id'], 'activate', 400, 'RSA解密失败', $clientIp);
            jsonResponse(400, '数据解密失败');
        }
    }
    
    // 防重放校验
    $clientSecret = defined('CLIENT_SECRET') ? CLIENT_SECRET : 'default_client_secret_v2';
    $antiReplay = new AntiReplay($db, $clientSecret);
    
    $businessParams = [
        'app_key' => $appKey,
        'auth_code' => $request['auth_code'] ?? ''
    ];
    
    $verifyResult = $antiReplay->verify($request, $businessParams);
    if (!$verifyResult['success']) {
        logAuth($db, $software['id'], 'activate', 400, $verifyResult['error'], $clientIp);
        jsonResponse(400, $verifyResult['error']);
    }
    
    $authCode = trim($request['auth_code'] ?? '');
    $fingerprint = $request['fingerprint'] ?? [];
    $deviceInfo = $request['device_info'] ?? [];
    
    if (empty($authCode)) {
        jsonResponse(400, '缺少授权码');
    }
    
    $finalFingerprint = $fingerprint['final'] ?? '';
    $components = $fingerprint['components'] ?? [];
    
    $fpHelper = new FingerprintHelper();
    
    if (!$fpHelper->validateFormat($finalFingerprint)) {
        logAuth($db, $software['id'], 'activate', 400, '指纹格式无效', $clientIp);
        jsonResponse(400, '机器指纹格式无效');
    }
    
    if (!$fpHelper->validateComponents($components)) {
        logAuth($db, $software['id'], 'activate', 400, '指纹组件无效', $clientIp);
        jsonResponse(400, '指纹组件无效');
    }
    
    // 检测虚拟机
    $virtualCheck = $fpHelper->detectVirtualEnvironment($deviceInfo);
    $riskLevel = $virtualCheck['risk_level'];
    
    // 检查机器码黑名单
    $stmt = $db->prepare("SELECT id FROM machine_blacklist WHERE machine_code = ? AND (software_id = ? OR software_id = 0)");
    $stmt->execute([$finalFingerprint, $software['id']]);
    if ($stmt->fetch()) {
        logAuth($db, $software['id'], 'activate', 403, '机器码已被封禁', $clientIp, $finalFingerprint);
        jsonResponse(403, '该设备已被封禁');
    }
    
    // 查询授权码
    $stmt = $db->prepare("SELECT * FROM auth_codes WHERE code = ? AND software_id = ?");
    $stmt->execute([$authCode, $software['id']]);
    $codeInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$codeInfo) {
        logAuth($db, $software['id'], 'activate', 404, '授权码不存在', $clientIp, $finalFingerprint);
        jsonResponse(404, '授权码不存在');
    }
    
    if ($codeInfo['status'] == 2) {
        logAuth($db, $software['id'], 'activate', 403, '授权码已禁用', $clientIp, $finalFingerprint);
        jsonResponse(403, '授权码已禁用');
    }
    
    if ($codeInfo['status'] == 3) {
        logAuth($db, $software['id'], 'activate', 410, '授权码已过期', $clientIp, $finalFingerprint);
        jsonResponse(410, '授权码已过期');
    }
    
    // 限制检查
    if ($codeInfo['ip_limit']) {
        $maxIp = intval($codeInfo['max_ip'] ?? 5);
        $usedIps = $codeInfo['used_ips'] ? json_decode($codeInfo['used_ips'], true) : [];
        if (!is_array($usedIps)) $usedIps = [];
        
        if (!in_array($clientIp, $usedIps) && count($usedIps) >= $maxIp) {
            logAuth($db, $software['id'], 'activate', 403, 'IP数量超限', $clientIp, $finalFingerprint);
            jsonResponse(403, '已达到最大IP数量限制');
        }
    }
    
    if ($codeInfo['use_limit']) {
        $maxUse = intval($codeInfo['max_use'] ?? 100);
        $useCount = intval($codeInfo['use_count'] ?? 0);
        
        if ($useCount >= $maxUse) {
            logAuth($db, $software['id'], 'activate', 403, '使用次数超限', $clientIp, $finalFingerprint);
            jsonResponse(403, '已达到最大使用次数限制');
        }
    }
    
    if ($codeInfo['activate_mode'] === 'scheduled' && $codeInfo['start_time']) {
        if (strtotime($codeInfo['start_time']) > time()) {
            logAuth($db, $software['id'], 'activate', 403, '授权码未到生效时间', $clientIp, $finalFingerprint);
            jsonResponse(403, '授权码尚未到生效时间');
        }
    }
    
    // 开始事务
    $db->beginTransaction();
    
    try {
        $deviceId = null;
        $expireTime = null;
        $isNewActivation = false;
        $isPointCard = intval($codeInfo['is_point_card'] ?? 0);
        $deductAmount = 0; // 本次需要扣除的点数
        
        // 点卡模式：检查点数是否足够
        if ($isPointCard) {
            $remainingPoints = intval($codeInfo['remaining_points'] ?? 0);
            $deductType = $codeInfo['deduct_type'] ?? 'per_use';
            
            // 根据扣点方式确定扣点数量
            // per_use: 每次使用扣点（每次登录都扣）
            // per_day: 每天扣点（同一天只扣一次）
            // per_activate: 仅首次激活扣点
            if ($deductType === 'per_use') {
                $deductAmount = intval($codeInfo['deduct_amount'] ?? 1);
            } elseif ($deductType === 'per_day') {
                // 检查今天是否已经扣过点
                $today = date('Y-m-d');
                $lastDeductDate = $codeInfo['last_deduct_date'] ?? '';
                if ($lastDeductDate !== $today) {
                    $deductAmount = intval($codeInfo['deduct_amount'] ?? 1);
                }
            } elseif ($deductType === 'per_activate') {
                // 仅首次激活扣点
                if ($codeInfo['status'] == 0) {
                    $deductAmount = intval($codeInfo['deduct_amount'] ?? 1);
                }
            }
            
            // 检查点数是否足够
            if ($deductAmount > 0 && $remainingPoints < $deductAmount) {
                logAuth($db, $software['id'], 'activate', 411, "点数不足，剩余{$remainingPoints}点，需要{$deductAmount}点", $clientIp, $finalFingerprint);
                jsonResponse(411, '点数不足', [
                    'remaining_points' => $remainingPoints,
                    'required_points' => $deductAmount
                ]);
            }
        }
        
        // 检查授权码是否已使用（已绑定设备）
        if ($codeInfo['status'] == 1 && !empty($codeInfo['bound_fingerprint'])) {
            // 卡密已激活过，先检查是否已过期（仅时长卡检查）
            if (!$isPointCard && !empty($codeInfo['expire_time']) && strtotime($codeInfo['expire_time']) < time()) {
                // 更新卡密状态为已过期
                $db->prepare("UPDATE auth_codes SET status = 3 WHERE id = ?")->execute([$codeInfo['id']]);
                $db->commit();
                logAuth($db, $software['id'], 'activate', 410, '授权码已过期', $clientIp, $finalFingerprint);
                jsonResponse(410, '授权码已过期');
            }
            
            $boundComponents = $codeInfo['bound_components'] ? json_decode($codeInfo['bound_components'], true) : [];
            if (!is_array($boundComponents)) $boundComponents = [];
            
            $compareResult = $fpHelper->compareComponents($components, $boundComponents);
            
            if ($compareResult['matched']) {
                // 同一设备重复登录，使用已有的到期时间
                $stmt = $db->prepare("SELECT * FROM devices WHERE software_id = ? AND fingerprint = ?");
                $stmt->execute([$software['id'], $finalFingerprint]);
                $device = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($device) {
                    $deviceId = $device['id'];
                    $expireTime = $codeInfo['expire_time']; // 使用卡密的到期时间
                    
                    // 单设备在线检查
                    if ($codeInfo['single_online']) {
                        $stmt = $db->prepare("SELECT COUNT(*) FROM online_sessions WHERE auth_code_id = ? AND device_id != ? AND is_valid = 1 AND last_heartbeat > DATE_SUB(NOW(), INTERVAL 15 SECOND)");
                        $stmt->execute([$codeInfo['id'], $deviceId]);
                        if ($stmt->fetchColumn() > 0 && !$codeInfo['allow_multi']) {
                            $db->rollBack();
                            jsonResponse(403, '此授权码已在其他设备登录');
                        }
                    }
                }
            } elseif ($compareResult['need_review']) {
                // 需要审核
                $db->commit();
                jsonResponse(423, '硬件信息变更，等待审核');
            } else {
                // 不同设备，检查是否允许换绑
                $maxDevices = intval($codeInfo['max_devices'] ?? 1);
                $allowRebind = intval($codeInfo['max_unbind'] ?? 0);
                $rebindCount = intval($codeInfo['unbind_count'] ?? 0);
                
                if ($maxDevices > 1) {
                    $isNewActivation = true;
                } elseif ($codeInfo['allow_unbind'] && $rebindCount < $allowRebind) {
                    $isNewActivation = true;
                    $db->prepare("UPDATE auth_codes SET unbind_count = unbind_count + 1 WHERE id = ?")->execute([$codeInfo['id']]);
                } else {
                    $db->rollBack();
                    jsonResponse(403, '此授权码已绑定其他设备');
                }
            }
        } else {
            // 首次激活
            $isNewActivation = true;
        }
        
        // 点卡模式：执行扣点
        if ($isPointCard && $deductAmount > 0) {
            $newPoints = intval($codeInfo['remaining_points']) - $deductAmount;
            $updateSql = "UPDATE auth_codes SET remaining_points = ?, last_deduct_date = ? WHERE id = ?";
            $db->prepare($updateSql)->execute([$newPoints, date('Y-m-d'), $codeInfo['id']]);
            
            // 更新本地变量
            $codeInfo['remaining_points'] = $newPoints;
            
            logRuntime('info', "[activate] 点卡扣点: 扣除{$deductAmount}点，剩余{$newPoints}点，code={$authCode}", 'v2_api', $clientIp, 0, $software['id']);
            
            // 记录扣点日志
            try {
                $stmt = $db->prepare("INSERT INTO point_logs (auth_code_id, software_id, device_id, action, amount, before_points, after_points, reason, ip, create_time) VALUES (?, ?, ?, 'deduct', ?, ?, ?, '登录扣点', ?, NOW())");
                $stmt->execute([$codeInfo['id'], $software['id'], $deviceId ?? 0, $deductAmount, intval($codeInfo['remaining_points']) + $deductAmount, $newPoints, $clientIp]);
            } catch (Exception $e) {
                // 表可能不存在，忽略
            }
        }
        
        // 新激活
        if ($isNewActivation) {
            if ($isPointCard) {
                // 点卡模式：设置一个很长的到期时间（100年），实际由点数控制
                $expireTime = date('Y-m-d H:i:s', time() + 36500 * 86400);
                $remainingPoints = intval($codeInfo['remaining_points'] ?? 0);
                $totalPoints = intval($codeInfo['total_points'] ?? 0);
                logRuntime('debug', "[activate] 点卡模式: total={$totalPoints}, remaining={$remainingPoints}", 'v2_api', $clientIp, 0, $software['id']);
            } else {
                // 时长卡模式：计算到期秒数
                $expireSeconds = calculateExpireSeconds($codeInfo);
                
                // 记录调试日志
                $cardType = $codeInfo['card_type'] ?? 'month';
                $minutes = intval($codeInfo['minutes'] ?? 0);
                $days = intval($codeInfo['days'] ?? 0);
                logRuntime('debug', "[activate] 卡密: type={$cardType}, minutes={$minutes}, days={$days}, expireSeconds={$expireSeconds}", 'v2_api', $clientIp, 0, $software['id']);
                
                // 计算到期时间（从当前时间开始）
                $expireTime = date('Y-m-d H:i:s', time() + $expireSeconds);
            }
            
            // 查找设备
            $stmt = $db->prepare("SELECT id, expire_time FROM devices WHERE software_id = ? AND fingerprint = ?");
            $stmt->execute([$software['id'], $finalFingerprint]);
            $existingDevice = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $encryptedComponents = $aes->encryptJson($components);
            
            if ($existingDevice) {
                $deviceId = $existingDevice['id'];
                
                // 注意：这里不再叠加时间，每次新卡密激活都使用新卡密的时间
                // 如果需要续费叠加，应该使用专门的续费接口
                logRuntime('debug', "[activate] 设备已存在: 原到期={$existingDevice['expire_time']}, 新到期={$expireTime}", 'v2_api', $clientIp, 0, $software['id']);
                
                // 更新设备（首次激活时设置activate_time）
                $activateTime = date('Y-m-d H:i:s');
                $stmt = $db->prepare("UPDATE devices SET fingerprint_components = ?, platform = ?, os_version = ?, is_virtual = ?, virtual_type = ?, risk_level = ?, expire_time = ?, activate_time = COALESCE(activate_time, ?), last_ip = ?, last_heartbeat = NOW() WHERE id = ?");
                $stmt->execute([
                    $encryptedComponents,
                    $deviceInfo['platform'] ?? '',
                    $deviceInfo['os_version'] ?? '',
                    $virtualCheck['is_virtual'] ? 1 : 0,
                    $virtualCheck['virtual_type'] ?? '',
                    $riskLevel,
                    $expireTime,
                    $activateTime,
                    $clientIp,
                    $deviceId
                ]);
            } else {
                // 创建新设备
                $activateTime = date('Y-m-d H:i:s');
                $stmt = $db->prepare("INSERT INTO devices (software_id, machine_code, fingerprint, fingerprint_components, platform, os_version, is_virtual, virtual_type, risk_level, status, expire_time, activate_time, last_ip, last_heartbeat, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, NOW(), NOW())");
                $stmt->execute([
                    $software['id'],
                    $finalFingerprint,
                    $finalFingerprint,
                    $encryptedComponents,
                    $deviceInfo['platform'] ?? '',
                    $deviceInfo['os_version'] ?? '',
                    $virtualCheck['is_virtual'] ? 1 : 0,
                    $virtualCheck['virtual_type'] ?? '',
                    $riskLevel,
                    $expireTime,
                    $activateTime,
                    $clientIp
                ]);
                $deviceId = $db->lastInsertId();
            }
            
            // 更新授权码
            $activateTime = date('Y-m-d H:i:s');
            $stmt = $db->prepare("UPDATE auth_codes SET status = 1, machine_code = ?, bound_fingerprint = ?, bound_components = ?, expire_time = ?, activate_time = COALESCE(activate_time, ?), used_time = NOW(), use_count = use_count + 1 WHERE id = ?");
            $stmt->execute([$finalFingerprint, $finalFingerprint, json_encode($components), $expireTime, $activateTime, $codeInfo['id']]);
            
            // 更新IP记录
            if ($codeInfo['ip_limit']) {
                $usedIps = $codeInfo['used_ips'] ? json_decode($codeInfo['used_ips'], true) : [];
                if (!is_array($usedIps)) $usedIps = [];
                if (!in_array($clientIp, $usedIps)) {
                    $usedIps[] = $clientIp;
                    $db->prepare("UPDATE auth_codes SET used_ips = ? WHERE id = ?")->execute([json_encode($usedIps), $codeInfo['id']]);
                }
            }
        }
        
        // 风险设备审核
        if ($riskLevel > 0) {
            $db->prepare("UPDATE devices SET risk_level = 1 WHERE id = ?")->execute([$deviceId]);
            $db->commit();
            jsonResponse(423, '检测到虚拟环境，等待审核');
        }
        
        // 生成JWT令牌
        $jwt = new JWTHelper();
        $jwt->setKeys($privateKey, $software['public_key']);
        
        $payload = [
            'device_id' => $deviceId,
            'software_id' => $software['id'],
            'auth_code_id' => $codeInfo['id'],
            'fingerprint' => $finalFingerprint,
            'platform' => $deviceInfo['platform'] ?? ''
        ];
        
        $token = $jwt->generate($payload);
        $refreshToken = $jwt->generateRefreshToken($deviceId);
        
        // 创建会话
        $tokenHash = $jwt->getTokenHash($token);
        $refreshTokenHash = hash('sha256', $refreshToken);
        $envHash = $fpHelper->generateEnvHash($deviceInfo);
        $tokenExpireTime = date('Y-m-d H:i:s', time() + 86400);
        
        // 清除旧会话
        if ($codeInfo['single_online'] && !$codeInfo['allow_multi']) {
            $db->prepare("UPDATE online_sessions SET is_valid = 0 WHERE auth_code_id = ?")->execute([$codeInfo['id']]);
        } else {
            $db->prepare("UPDATE online_sessions SET is_valid = 0 WHERE device_id = ?")->execute([$deviceId]);
        }
        
        // 创建新会话
        $stmt = $db->prepare("INSERT INTO online_sessions (device_id, software_id, auth_code_id, token_hash, refresh_token_hash, bound_ip, bound_env_hash, is_valid, login_time, last_heartbeat, token_expire_time) VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW(), NOW(), ?)");
        $stmt->execute([$deviceId, $software['id'], $codeInfo['id'], $tokenHash, $refreshTokenHash, $clientIp, $envHash, $tokenExpireTime]);
        
        $db->commit();
        
        // 计算剩余时间
        $expireTimestamp = strtotime($expireTime);
        $remainSeconds = max(0, $expireTimestamp - time());
        $remainDays = floor($remainSeconds / 86400);
        
        // 检查是否是点卡模式
        $isPointCard = intval($codeInfo['is_point_card'] ?? 0);
        
        logAuth($db, $software['id'], 'activate', 200, '激活成功', $clientIp, $finalFingerprint);
        logRuntime('info', "激活成功: code={$authCode}, expire={$expireTime}", 'activate', $clientIp, 0, $software['id']);
        
        // 构建响应数据
        $responseData = [
            'token' => $token,
            'refresh_token' => $refreshToken,
            'expire_time' => $expireTime,
            'remain_days' => $remainDays,
            'remain_seconds' => $remainSeconds,
            'is_point_card' => $isPointCard
        ];
        
        // 点卡模式添加点数信息
        if ($isPointCard) {
            $responseData['total_points'] = intval($codeInfo['total_points'] ?? 0);
            $responseData['remaining_points'] = intval($codeInfo['remaining_points'] ?? 0);
            $responseData['deduct_type'] = $codeInfo['deduct_type'] ?? 'per_use';
            $responseData['deduct_amount'] = intval($codeInfo['deduct_amount'] ?? 1);
            // 本次扣点信息
            if ($deductAmount > 0) {
                $responseData['this_deduct'] = $deductAmount;
            }
        }
        
        jsonResponse(200, '激活成功', $responseData);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    logAuth($db, $software['id'] ?? 0, 'activate', 500, $e->getMessage(), $clientIp ?? '');
    jsonResponse(500, '服务器错误');
}
