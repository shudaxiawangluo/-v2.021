<?php
/**
 * SHA256哈希辅助接口
 * 为不支持SHA256的客户端提供在线哈希服务
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

function jsonResponse($code, $message, $data = null) {
    $response = ['code' => $code, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $input = file_get_contents('php://input');
    $request = json_decode($input, true);
    
    if (!$request) {
        jsonResponse(400, '无效的请求数据');
    }
    
    $data = $request['data'] ?? '';
    
    if ($data === '') {
        jsonResponse(400, '缺少data参数');
    }
    
    // 计算SHA256哈希
    $hash = hash('sha256', $data);
    
    jsonResponse(200, '计算成功', [
        'hash' => $hash
    ]);
    
} catch (Exception $e) {
    jsonResponse(500, '服务器错误: ' . $e->getMessage());
}
