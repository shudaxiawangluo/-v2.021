<?php
/**
 * V2 令牌刷新接口
 * 刷新JWT令牌（24小时有效期内）
 * 
 * 请求: POST
 * 参数:
 *   - timestamp: 时间戳
 *   - nonce: 随机字符串
 *   - sign: 签名
 *   - token: 当前JWT令牌
 *   - refresh_token: 刷新令牌
 *   - fingerprint: 当前机器指纹
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/lib/JWTHelper.php';
require_once __DIR__ . '/lib/AESHelper.php';
require_once __DIR__ . '/lib/AntiReplay.php';
require_once __DIR__ . '/lib/FingerprintHelper.php';

// 获取数据库连接
$db = getDB();

try {
    $clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    if (strpos($clientIp, ',') !== false) {
        $clientIp = trim(explode(',', $clientIp)[0]);
    }
    
    // 检查IP黑名单（白名单IP跳过黑名单检查）
    if (!checkIPWhitelist($clientIp, 0) && checkIPBlacklist($clientIp)) {
        logRuntime('warning', "[refresh] IP黑名单拦截: {$clientIp}", 'v2_api', $clientIp);
        jsonResponse(403, 'IP已被封禁');
    }
    
    // 获取请求数据
    $input = file_get_contents('php://input');
    $request = json_decode($input, true);
    
    if (!$request) {
        jsonResponse(400, '无效的请求数据');
    }
    
    // 验证必需参数
    $token = trim($request['token'] ?? '');
    $refreshToken = trim($request['refresh_token'] ?? '');
    $fingerprint = trim($request['fingerprint'] ?? '');
    $deviceInfo = $request['device_info'] ?? [];
    
    if (empty($token)) {
        jsonResponse(400, '缺少令牌');
    }
    
    if (empty($refreshToken)) {
        jsonResponse(400, '缺少刷新令牌');
    }
    
    if (empty($fingerprint)) {
        jsonResponse(400, '缺少机器指纹');
    }
    
    // 解析JWT获取信息
    $jwt = new JWTHelper();
    $payload = $jwt->decode($token);
    
    if (!$payload || !isset($payload['software_id'])) {
        jsonResponse(401, '无效的令牌');
    }
    
    $softwareId = $payload['software_id'];
    $deviceId = $payload['device_id'];
    $tokenFingerprint = $payload['fingerprint'];
    
    // 验证指纹一致性
    if ($fingerprint !== $tokenFingerprint) {
        jsonResponse(403, '设备指纹不匹配');
    }
    
    // 查询软件信息
    $stmt = $db->prepare("SELECT id, public_key, private_key, status FROM software WHERE id = ?");
    $stmt->execute([$softwareId]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software || $software['status'] != 1) {
        jsonResponse(403, '软件已禁用');
    }
    
    // 解密私钥
    $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
    $aes = new AESHelper($aesKey);
    
    try {
        $privateKey = $aes->decrypt($software['private_key']);
    } catch (Exception $e) {
        $privateKey = $software['private_key'];
    }
    
    // 设置JWT密钥
    $jwt->setKeys($privateKey, $software['public_key']);
    
    // 验证原令牌（允许已过期但签名有效的令牌）
    // 先验证签名
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        jsonResponse(401, '令牌格式无效');
    }
    
    // 检查令牌是否在有效期内或刚过期不久（允许1小时宽限期）
    if (isset($payload['exp'])) {
        $expTime = $payload['exp'];
        $gracePeriod = 3600; // 1小时宽限期
        
        if (time() > $expTime + $gracePeriod) {
            jsonResponse(401, '令牌已过期太久，请重新登录');
        }
    }
    
    // 防重放校验
    $clientSecret = defined('CLIENT_SECRET') ? CLIENT_SECRET : 'default_client_secret_v2';
    $antiReplay = new AntiReplay($db, $clientSecret);
    
    $businessParams = [
        'fingerprint' => $fingerprint,
        'refresh_token' => $refreshToken,
        'token' => $token
    ];
    
    $verifyResult = $antiReplay->verify($request, $businessParams);
    if (!$verifyResult['success']) {
        jsonResponse(400, $verifyResult['error']);
    }
    
    // 查询会话
    $tokenHash = $jwt->getTokenHash($token);
    $refreshTokenHash = hash('sha256', $refreshToken);
    
    $stmt = $db->prepare("SELECT * FROM online_sessions WHERE device_id = ? AND token_hash = ? AND refresh_token_hash = ?");
    $stmt->execute([$deviceId, $tokenHash, $refreshTokenHash]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$session) {
        jsonResponse(401, '会话不存在或刷新令牌无效');
    }
    
    // 检查会话是否有效
    if ($session['is_valid'] != 1) {
        jsonResponse(403, '会话已失效，请重新登录');
    }
    
    // 验证IP一致性
    if ($session['bound_ip'] && $session['bound_ip'] !== $clientIp) {
        jsonResponse(403, 'IP地址变更，请重新登录');
    }
    
    // 验证设备环境一致性
    if (!empty($deviceInfo) && $session['bound_env_hash']) {
        $fpHelper = new FingerprintHelper();
        $currentEnvHash = $fpHelper->generateEnvHash($deviceInfo);
        
        if ($currentEnvHash !== $session['bound_env_hash']) {
            jsonResponse(403, '设备环境变更，请重新登录');
        }
    }
    
    // 查询设备状态
    $stmt = $db->prepare("SELECT * FROM devices WHERE id = ?");
    $stmt->execute([$deviceId]);
    $device = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$device || $device['status'] != 1) {
        jsonResponse(403, '设备已禁用');
    }
    
    // 检查授权是否过期
    if (strtotime($device['expire_time']) < time()) {
        jsonResponse(410, '授权已过期');
    }
    
    // 生成新令牌
    $newPayload = [
        'device_id' => $deviceId,
        'software_id' => $softwareId,
        'fingerprint' => $fingerprint,
        'platform' => $payload['platform'] ?? ''
    ];
    
    $newToken = $jwt->generate($newPayload);
    $newRefreshToken = $jwt->generateRefreshToken($deviceId);
    
    // 更新会话
    $newTokenHash = $jwt->getTokenHash($newToken);
    $newRefreshTokenHash = hash('sha256', $newRefreshToken);
    $newExpireTime = date('Y-m-d H:i:s', time() + 86400);
    
    $stmt = $db->prepare("UPDATE online_sessions SET token_hash = ?, refresh_token_hash = ?, last_heartbeat = NOW(), expire_time = ? WHERE id = ?");
    $stmt->execute([$newTokenHash, $newRefreshTokenHash, $newExpireTime, $session['id']]);
    
    // 返回新令牌
    jsonResponse(200, '刷新成功', [
        'token' => $newToken,
        'refresh_token' => $newRefreshToken
    ]);
    
} catch (Exception $e) {
    jsonResponse(500, '服务器错误');
}
