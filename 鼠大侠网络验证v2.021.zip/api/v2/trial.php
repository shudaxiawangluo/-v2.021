<?php
/**
 * V2 试用接口
 * 申请试用授权
 * 
 * 请求: POST (RSA加密)
 * 参数:
 *   - timestamp: 时间戳
 *   - nonce: 随机字符串
 *   - sign: 签名
 *   - app_key: 软件AppKey
 *   - fingerprint: {final, components}
 *   - device_info: {platform, os_version, is_virtual, virtual_type}
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/lib/RSAHelper.php';
require_once __DIR__ . '/lib/JWTHelper.php';
require_once __DIR__ . '/lib/AESHelper.php';
require_once __DIR__ . '/lib/AntiReplay.php';
require_once __DIR__ . '/lib/FingerprintHelper.php';

// 获取数据库连接
$db = getDB();

function logAuth($softwareId, $action, $responseCode, $message, $ip, $fingerprint = null) {
    global $db;
    try {
        // 写入auth_logs
        $stmt = $db->prepare("INSERT INTO auth_logs (software_id, action, fingerprint, ip, response_code, response_msg, create_time) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$softwareId, $action, $fingerprint, $ip, $responseCode, $message]);
        
        // 同时写入runtime_logs（后台可见）
        $type = $responseCode == 200 ? 'info' : 'error';
        $content = "[{$action}] code={$responseCode}, {$message}" . ($fingerprint ? ", fp=" . substr($fingerprint, 0, 16) . "..." : "");
        $stmt2 = $db->prepare("INSERT INTO runtime_logs (type, module, content, ip, software_id, create_time) VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt2->execute([$type, 'v2_api', $content, $ip, $softwareId]);
    } catch (Exception $e) {}
}

try {
    $clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    if (strpos($clientIp, ',') !== false) {
        $clientIp = trim(explode(',', $clientIp)[0]);
    }
    
    // 检查IP黑名单（白名单IP跳过黑名单检查）
    if (!checkIPWhitelist($clientIp, 0) && checkIPBlacklist($clientIp)) {
        logRuntime('warning', "[trial] IP黑名单拦截: {$clientIp}", 'v2_api', $clientIp);
        jsonResponse(403, 'IP已被封禁');
    }
    
    // 获取请求数据
    $input = file_get_contents('php://input');
    $rawRequest = json_decode($input, true);
    
    if (!$rawRequest) {
        jsonResponse(400, '无效的请求数据');
    }
    
    // 获取app_key（未加密）
    $appKey = trim($rawRequest['app_key'] ?? '');
    if (empty($appKey)) {
        jsonResponse(400, '缺少app_key参数');
    }
    
    // 查询软件信息
    $stmt = $db->prepare("SELECT id, name, public_key, private_key, status, enable_trial, trial_duration, trial_unit FROM software WHERE app_key = ?");
    $stmt->execute([$appKey]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software) {
        logAuth(0, 'trial', 404, '软件不存在', $clientIp);
        jsonResponse(404, '软件不存在');
    }
    
    if ($software['status'] != 1) {
        logAuth($software['id'], 'trial', 403, '软件已禁用', $clientIp);
        jsonResponse(403, '软件已禁用');
    }
    
    // 检查是否开启试用
    if (!$software['enable_trial']) {
        logAuth($software['id'], 'trial', 403, '未开启试用', $clientIp);
        jsonResponse(403, '该软件未开启试用功能');
    }
    
    // 解密私钥
    $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
    $aes = new AESHelper($aesKey);
    
    try {
        $privateKey = $aes->decrypt($software['private_key']);
    } catch (Exception $e) {
        $privateKey = $software['private_key'];
    }
    
    // RSA解密请求数据
    $rsa = new RSAHelper();
    $rsa->setPrivateKey($privateKey);
    $rsa->setPublicKey($software['public_key']);
    
    $encryptedData = $rawRequest['data'] ?? '';
    if (empty($encryptedData)) {
        jsonResponse(400, '缺少加密数据');
    }
    
    try {
        $request = $rsa->decryptJson($encryptedData);
    } catch (Exception $e) {
        logAuth($software['id'], 'trial', 400, 'RSA解密失败: ' . $e->getMessage(), $clientIp);
        jsonResponse(400, '数据解密失败: ' . $e->getMessage());
    }
    
    // 防重放校验
    $clientSecret = defined('CLIENT_SECRET') ? CLIENT_SECRET : 'default_client_secret_v2';
    $antiReplay = new AntiReplay($db, $clientSecret);
    
    $businessParams = ['app_key' => $appKey];
    $verifyResult = $antiReplay->verify($request, $businessParams);
    
    if (!$verifyResult['success']) {
        logAuth($software['id'], 'trial', 400, $verifyResult['error'], $clientIp);
        jsonResponse(400, $verifyResult['error']);
    }
    
    // 验证指纹
    $fingerprint = $request['fingerprint'] ?? [];
    $deviceInfo = $request['device_info'] ?? [];
    
    $finalFingerprint = $fingerprint['final'] ?? '';
    $components = $fingerprint['components'] ?? [];
    
    $fpHelper = new FingerprintHelper();
    
    if (!$fpHelper->validateFormat($finalFingerprint)) {
        logAuth($software['id'], 'trial', 400, '指纹格式无效', $clientIp);
        jsonResponse(400, '机器指纹格式无效');
    }
    
    if (!$fpHelper->validateComponents($components)) {
        logAuth($software['id'], 'trial', 400, '指纹组件无效', $clientIp);
        jsonResponse(400, '指纹组件无效');
    }
    
    // 检测虚拟机/模拟器
    $virtualCheck = $fpHelper->detectVirtualEnvironment($deviceInfo);
    $riskLevel = $virtualCheck['risk_level'];
    
    // 检查机器码黑名单
    $stmt = $db->prepare("SELECT id FROM machine_blacklist WHERE machine_code = ? AND (software_id = ? OR software_id = 0)");
    $stmt->execute([$finalFingerprint, $software['id']]);
    if ($stmt->fetch()) {
        logAuth($software['id'], 'trial', 403, '机器码已被封禁', $clientIp, $finalFingerprint);
        jsonResponse(403, '该设备已被封禁');
    }
    
    // 检查是否已试用过
    $stmt = $db->prepare("SELECT id, expire_time FROM devices WHERE software_id = ? AND fingerprint = ?");
    $stmt->execute([$software['id'], $finalFingerprint]);
    $existingDevice = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existingDevice) {
        logAuth($software['id'], 'trial', 403, '已试用过', $clientIp, $finalFingerprint);
        jsonResponse(403, '该设备已试用过，请购买授权');
    }
    
    // 计算试用到期时间
    $trialDuration = $software['trial_duration'] ?: 30;
    $trialUnit = $software['trial_unit'] ?: 'minute';
    
    switch ($trialUnit) {
        case 'hour':
            $expireTime = date('Y-m-d H:i:s', strtotime('+' . $trialDuration . ' hours'));
            break;
        case 'day':
            $expireTime = date('Y-m-d H:i:s', strtotime('+' . $trialDuration . ' days'));
            break;
        case 'minute':
        default:
            $expireTime = date('Y-m-d H:i:s', strtotime('+' . $trialDuration . ' minutes'));
            break;
    }
    
    // 开始事务
    $db->beginTransaction();
    
    try {
        // 加密组件存储
        $encryptedComponents = $aes->encryptJson($components);
        
        // 创建设备记录
        $stmt = $db->prepare("INSERT INTO devices (software_id, machine_code, fingerprint, fingerprint_components, platform, os_version, is_virtual, virtual_type, risk_level, status, expire_time, last_ip, last_heartbeat, create_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, NOW(), NOW())");
        $stmt->execute([
            $software['id'],
            $finalFingerprint,
            $finalFingerprint,
            $encryptedComponents,
            $deviceInfo['platform'] ?? '',
            $deviceInfo['os_version'] ?? '',
            $virtualCheck['is_virtual'] ? 1 : 0,
            $virtualCheck['virtual_type'],
            $riskLevel,
            $expireTime,
            $clientIp
        ]);
        $deviceId = $db->lastInsertId();
        
        // 风险设备需要审核
        if ($riskLevel > 0) {
            $db->commit();
            logAuth($software['id'], 'trial', 423, '风险设备待审核', $clientIp, $finalFingerprint);
            jsonResponse(423, '检测到虚拟环境，等待审核');
        }
        
        // 生成JWT令牌
        $jwt = new JWTHelper();
        $jwt->setKeys($privateKey, $software['public_key']);
        
        $payload = [
            'device_id' => $deviceId,
            'software_id' => $software['id'],
            'fingerprint' => $finalFingerprint,
            'platform' => $deviceInfo['platform'] ?? '',
            'is_trial' => true
        ];
        
        $token = $jwt->generate($payload);
        $refreshToken = $jwt->generateRefreshToken($deviceId);
        
        // 创建在线会话
        $tokenHash = $jwt->getTokenHash($token);
        $refreshTokenHash = hash('sha256', $refreshToken);
        $envHash = $fpHelper->generateEnvHash($deviceInfo);
        $tokenExpireTime = date('Y-m-d H:i:s', time() + 86400);
        
        $stmt = $db->prepare("INSERT INTO online_sessions (device_id, software_id, token_hash, refresh_token_hash, bound_ip, bound_env_hash, is_valid, login_time, last_heartbeat, token_expire_time) VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), NOW(), ?)");
        $stmt->execute([$deviceId, $software['id'], $tokenHash, $refreshTokenHash, $clientIp, $envHash, $tokenExpireTime]);
        
        $db->commit();
        
        // 计算剩余时间
        $remainSeconds = max(0, strtotime($expireTime) - time());
        
        logAuth($software['id'], 'trial', 200, '试用激活成功', $clientIp, $finalFingerprint);
        
        jsonResponse(200, '试用激活成功', [
            'token' => $token,
            'refresh_token' => $refreshToken,
            'expire_time' => $expireTime,
            'remain_seconds' => $remainSeconds,
            'is_trial' => true
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    logAuth($software['id'] ?? 0, 'trial', 500, $e->getMessage(), $clientIp ?? '');
    jsonResponse(500, '服务器错误');
}
