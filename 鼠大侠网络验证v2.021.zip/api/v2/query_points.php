<?php
/**
 * V2 查询点数接口
 * 查询用户剩余点数
 * 
 * 请求: POST
 * 参数: 
 *   - timestamp: 时间戳
 *   - nonce: 随机数
 *   - sign: 签名
 *   - token: JWT令牌
 * 
 * 响应:
 * {
 *   "code": 200,
 *   "msg": "查询成功",
 *   "data": {
 *     "total_points": 100,
 *     "remaining_points": 99,
 *     "used_points": 1,
 *     "is_point_card": 1,
 *     "deduct_type": "per_use"
 *   }
 * }
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/lib/JWTHelper.php';
require_once __DIR__ . '/lib/AESHelper.php';
require_once __DIR__ . '/lib/AntiReplay.php';

$db = getDB();

// 获取客户端IP
$clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
if (strpos($clientIp, ',') !== false) {
    $clientIp = trim(explode(',', $clientIp)[0]);
}

try {
    // 获取请求数据
    $input = file_get_contents('php://input');
    $request = json_decode($input, true);
    
    if (!$request) {
        $request = $_POST;
    }
    
    // 验证必需参数
    $timestamp = trim($request['timestamp'] ?? '');
    $nonce = trim($request['nonce'] ?? '');
    $sign = trim($request['sign'] ?? '');
    $token = trim($request['token'] ?? '');
    
    if (empty($timestamp) || empty($nonce) || empty($sign) || empty($token)) {
        jsonResponse(400, '缺少必需参数');
    }
    
    // 验证时间戳（5分钟内有效）
    if (abs(time() - intval($timestamp)) > 300) {
        jsonResponse(401, '请求已过期');
    }
    
    // 解析JWT获取信息
    $jwt = new JWTHelper();
    $payload = $jwt->decode($token);
    
    if (!$payload || !isset($payload['software_id'])) {
        jsonResponse(401, '无效的令牌');
    }
    
    $softwareId = $payload['software_id'];
    $authCodeId = $payload['auth_code_id'] ?? null;
    
    if (!$authCodeId) {
        jsonResponse(400, '令牌中缺少授权码信息');
    }
    
    // 查询软件信息
    $stmt = $db->prepare("SELECT id, public_key, private_key, status FROM software WHERE id = ?");
    $stmt->execute([$softwareId]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software || $software['status'] != 1) {
        jsonResponse(403, '软件已禁用');
    }
    
    // 解密私钥
    $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
    $aes = new AESHelper($aesKey);
    
    try {
        $privateKey = $aes->decrypt($software['private_key']);
    } catch (Exception $e) {
        $privateKey = $software['private_key'];
    }
    
    // 验证JWT
    $jwt->setKeys($privateKey, $software['public_key']);
    $verifiedPayload = $jwt->verify($token);
    
    if (!$verifiedPayload) {
        jsonResponse(401, '令牌无效或已过期');
    }
    
    // 防重放校验
    $clientSecret = defined('CLIENT_SECRET') ? CLIENT_SECRET : 'default_client_secret_v2';
    $antiReplay = new AntiReplay($db, $clientSecret);
    
    $businessParams = ['token' => $token];
    $verifyResult = $antiReplay->verify($request, $businessParams);
    
    if (!$verifyResult['success']) {
        jsonResponse(400, $verifyResult['error']);
    }
    
    // 查询授权码信息
    $stmt = $db->prepare("SELECT * FROM auth_codes WHERE id = ?");
    $stmt->execute([$authCodeId]);
    $authCode = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$authCode) {
        jsonResponse(404, '授权码不存在');
    }
    
    // 检查授权码状态
    if ($authCode['status'] == 2) {
        jsonResponse(403, '授权码已禁用');
    }
    if ($authCode['status'] == 3) {
        jsonResponse(410, '授权已过期');
    }
    
    // 计算已使用点数
    $totalPoints = intval($authCode['total_points'] ?? 0);
    $remainingPoints = intval($authCode['remaining_points'] ?? 0);
    $usedPoints = $totalPoints - $remainingPoints;
    
    // 返回响应
    jsonResponse(200, '查询成功', [
        'is_point_card' => intval($authCode['is_point_card'] ?? 0),
        'total_points' => $totalPoints,
        'remaining_points' => $remainingPoints,
        'used_points' => $usedPoints,
        'deduct_type' => $authCode['deduct_type'] ?? 'per_use',
        'expire_time' => $authCode['expire_time']
    ]);
    
} catch (Exception $e) {
    logRuntime('error', '[query_points] 异常: ' . $e->getMessage(), 'v2_api', $clientIp ?? '');
    jsonResponse(500, '服务器错误');
}
