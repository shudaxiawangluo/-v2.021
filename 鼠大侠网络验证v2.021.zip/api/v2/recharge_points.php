<?php
/**
 * V2 充值点数接口
 * 使用充值卡密为现有授权充值点数
 * 
 * 请求: POST
 * 参数: 
 *   - timestamp: 时间戳
 *   - nonce: 随机数
 *   - sign: 签名
 *   - token: JWT令牌
 *   - recharge_code: 充值卡密
 * 
 * 响应:
 * {
 *   "code": 200,
 *   "msg": "充值成功",
 *   "data": {
 *     "before_points": 99,
 *     "recharge_points": 100,
 *     "after_points": 199
 *   }
 * }
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/lib/JWTHelper.php';
require_once __DIR__ . '/lib/AESHelper.php';
require_once __DIR__ . '/lib/AntiReplay.php';

$db = getDB();

// 获取客户端IP
$clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
if (strpos($clientIp, ',') !== false) {
    $clientIp = trim(explode(',', $clientIp)[0]);
}

try {
    // 获取请求数据
    $input = file_get_contents('php://input');
    $request = json_decode($input, true);
    
    if (!$request) {
        $request = $_POST;
    }
    
    // 验证必需参数
    $timestamp = trim($request['timestamp'] ?? '');
    $nonce = trim($request['nonce'] ?? '');
    $sign = trim($request['sign'] ?? '');
    $token = trim($request['token'] ?? '');
    $rechargeCode = trim($request['recharge_code'] ?? '');
    
    if (empty($timestamp) || empty($nonce) || empty($sign) || empty($token) || empty($rechargeCode)) {
        jsonResponse(400, '缺少必需参数');
    }
    
    // 验证时间戳（5分钟内有效）
    if (abs(time() - intval($timestamp)) > 300) {
        jsonResponse(401, '请求已过期');
    }
    
    // 解析JWT获取信息
    $jwt = new JWTHelper();
    $payload = $jwt->decode($token);
    
    if (!$payload || !isset($payload['software_id'])) {
        jsonResponse(401, '无效的令牌');
    }
    
    $softwareId = $payload['software_id'];
    $deviceId = $payload['device_id'];
    $authCodeId = $payload['auth_code_id'] ?? null;
    
    if (!$authCodeId) {
        jsonResponse(400, '令牌中缺少授权码信息');
    }
    
    // 查询软件信息
    $stmt = $db->prepare("SELECT id, public_key, private_key, status FROM software WHERE id = ?");
    $stmt->execute([$softwareId]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software || $software['status'] != 1) {
        jsonResponse(403, '软件已禁用');
    }
    
    // 解密私钥
    $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
    $aes = new AESHelper($aesKey);
    
    try {
        $privateKey = $aes->decrypt($software['private_key']);
    } catch (Exception $e) {
        $privateKey = $software['private_key'];
    }
    
    // 验证JWT
    $jwt->setKeys($privateKey, $software['public_key']);
    $verifiedPayload = $jwt->verify($token);
    
    if (!$verifiedPayload) {
        jsonResponse(401, '令牌无效或已过期');
    }
    
    // 防重放校验
    $clientSecret = defined('CLIENT_SECRET') ? CLIENT_SECRET : 'default_client_secret_v2';
    $antiReplay = new AntiReplay($db, $clientSecret);
    
    $businessParams = ['recharge_code' => $rechargeCode, 'token' => $token];
    $verifyResult = $antiReplay->verify($request, $businessParams);
    
    if (!$verifyResult['success']) {
        jsonResponse(400, $verifyResult['error']);
    }
    
    // 查询授权码信息
    $stmt = $db->prepare("SELECT * FROM auth_codes WHERE id = ?");
    $stmt->execute([$authCodeId]);
    $authCode = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$authCode) {
        jsonResponse(404, '授权码不存在');
    }
    
    // 检查是否是点卡类型
    if (intval($authCode['is_point_card']) != 1) {
        jsonResponse(400, '该卡密不是点卡类型，无法充值点数');
    }
    
    // 检查授权码状态
    if ($authCode['status'] == 2) {
        jsonResponse(403, '授权码已禁用');
    }
    
    // 开始事务
    $db->beginTransaction();
    
    try {
        // 查询充值卡密（必须是同一软件的点卡，且未使用）
        $stmt = $db->prepare("
            SELECT * FROM auth_codes 
            WHERE code = ? AND software_id = ? AND is_point_card = 1 AND status = 0
        ");
        $stmt->execute([$rechargeCode, $softwareId]);
        $rechargeCard = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$rechargeCard) {
            $db->rollBack();
            logRuntime('warning', "[recharge_points] 充值卡密无效或已使用: {$rechargeCode}", 'v2_api', $clientIp, 0, $softwareId);
            jsonResponse(404, '充值卡密无效或已使用');
        }
        
        // 获取充值点数
        $rechargePoints = intval($rechargeCard['total_points']);
        if ($rechargePoints <= 0) {
            $db->rollBack();
            jsonResponse(400, '充值卡密点数无效');
        }
        
        // 锁定授权码记录
        $stmt = $db->prepare("SELECT remaining_points, total_points FROM auth_codes WHERE id = ? FOR UPDATE");
        $stmt->execute([$authCode['id']]);
        $currentInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        $beforePoints = intval($currentInfo['remaining_points']);
        $beforeTotal = intval($currentInfo['total_points']);
        
        // 计算充值后点数
        $afterPoints = $beforePoints + $rechargePoints;
        $afterTotal = $beforeTotal + $rechargePoints;
        
        // 更新授权码点数
        $stmt = $db->prepare("UPDATE auth_codes SET remaining_points = ?, total_points = ? WHERE id = ?");
        $stmt->execute([$afterPoints, $afterTotal, $authCode['id']]);
        
        // 标记充值卡密为已使用
        $stmt = $db->prepare("UPDATE auth_codes SET status = 1, used_time = NOW() WHERE id = ?");
        $stmt->execute([$rechargeCard['id']]);
        
        // 记录充值日志（如果表存在）
        try {
            $stmt = $db->prepare("
                INSERT INTO point_logs 
                (auth_code_id, software_id, device_id, action, amount, before_points, after_points, reason, ip, create_time)
                VALUES (?, ?, ?, 'recharge', ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $authCode['id'],
                $softwareId,
                $deviceId,
                $rechargePoints,
                $beforePoints,
                $afterPoints,
                "使用卡密充值: {$rechargeCode}",
                $clientIp
            ]);
        } catch (Exception $e) {
            // 表可能不存在，忽略
        }
        
        // 提交事务
        $db->commit();
        
        // 记录成功日志
        logRuntime('info', "[recharge_points] 充值{$rechargePoints}点成功，code={$authCode['code']}", 'v2_api', $clientIp, 0, $softwareId);
        
        // 返回响应
        jsonResponse(200, '充值成功', [
            'before_points' => $beforePoints,
            'recharge_points' => $rechargePoints,
            'after_points' => $afterPoints,
            'total_points' => $afterTotal
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    logRuntime('error', '[recharge_points] 异常: ' . $e->getMessage(), 'v2_api', $clientIp ?? '');
    jsonResponse(500, '服务器错误');
}
