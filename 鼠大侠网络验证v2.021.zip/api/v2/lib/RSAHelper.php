<?php
/**
 * RSA加密助手类
 * 实现RSA-2048密钥管理和加解密
 */

class RSAHelper {
    
    private $publicKey;
    private $privateKey;
    
    /**
     * 生成RSA密钥对
     * @return array ['public_key' => string, 'private_key' => string]
     */
    public static function generateKeyPair() {
        $config = [
            'digest_alg' => 'sha256',
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ];
        
        $res = openssl_pkey_new($config);
        if (!$res) {
            throw new Exception('生成RSA密钥对失败: ' . openssl_error_string());
        }
        
        // 导出私钥
        openssl_pkey_export($res, $privateKey);
        
        // 导出公钥
        $publicKeyDetails = openssl_pkey_get_details($res);
        $publicKey = $publicKeyDetails['key'];
        
        return [
            'public_key' => $publicKey,
            'private_key' => $privateKey
        ];
    }
    
    /**
     * 设置公钥
     * @param string $publicKey PEM格式公钥
     */
    public function setPublicKey($publicKey) {
        $this->publicKey = $publicKey;
    }
    
    /**
     * 设置私钥
     * @param string $privateKey PEM格式私钥
     */
    public function setPrivateKey($privateKey) {
        $this->privateKey = $privateKey;
    }
    
    /**
     * 使用公钥加密数据
     * @param string $data 要加密的数据
     * @return string Base64编码的加密数据
     */
    public function encrypt($data) {
        if (empty($this->publicKey)) {
            throw new Exception('公钥未设置');
        }
        
        $publicKeyResource = openssl_pkey_get_public($this->publicKey);
        if (!$publicKeyResource) {
            throw new Exception('无效的公钥: ' . openssl_error_string());
        }
        
        // RSA加密有长度限制，对于2048位密钥，最大加密长度为245字节
        // 对于较长数据，需要分段加密
        $maxLength = 245;
        $dataLength = strlen($data);
        $encrypted = '';
        
        for ($i = 0; $i < $dataLength; $i += $maxLength) {
            $chunk = substr($data, $i, $maxLength);
            $encryptedChunk = '';
            
            if (!openssl_public_encrypt($chunk, $encryptedChunk, $publicKeyResource, OPENSSL_PKCS1_PADDING)) {
                throw new Exception('RSA加密失败: ' . openssl_error_string());
            }
            
            $encrypted .= $encryptedChunk;
        }
        
        return base64_encode($encrypted);
    }
    
    /**
     * 使用私钥解密数据
     * @param string $encryptedData Base64编码的加密数据
     * @return string 解密后的原始数据
     */
    public function decrypt($encryptedData) {
        if (empty($this->privateKey)) {
            throw new Exception('私钥未设置');
        }
        
        $privateKeyResource = openssl_pkey_get_private($this->privateKey);
        if (!$privateKeyResource) {
            throw new Exception('无效的私钥: ' . openssl_error_string());
        }
        
        $encrypted = base64_decode($encryptedData);
        if ($encrypted === false) {
            throw new Exception('Base64解码失败');
        }
        
        // 分段解密，每段256字节（2048位密钥）
        $chunkSize = 256;
        $dataLength = strlen($encrypted);
        $decrypted = '';
        
        for ($i = 0; $i < $dataLength; $i += $chunkSize) {
            $chunk = substr($encrypted, $i, $chunkSize);
            $decryptedChunk = '';
            
            if (!openssl_private_decrypt($chunk, $decryptedChunk, $privateKeyResource, OPENSSL_PKCS1_PADDING)) {
                throw new Exception('RSA解密失败: ' . openssl_error_string());
            }
            
            $decrypted .= $decryptedChunk;
        }
        
        return $decrypted;
    }
    
    /**
     * 使用私钥签名数据
     * @param string $data 要签名的数据
     * @return string Base64编码的签名
     */
    public function sign($data) {
        if (empty($this->privateKey)) {
            throw new Exception('私钥未设置');
        }
        
        $privateKeyResource = openssl_pkey_get_private($this->privateKey);
        if (!$privateKeyResource) {
            throw new Exception('无效的私钥');
        }
        
        $signature = '';
        if (!openssl_sign($data, $signature, $privateKeyResource, OPENSSL_ALGO_SHA256)) {
            throw new Exception('签名失败: ' . openssl_error_string());
        }
        
        return base64_encode($signature);
    }
    
    /**
     * 使用公钥验证签名
     * @param string $data 原始数据
     * @param string $signature Base64编码的签名
     * @return bool 验证是否通过
     */
    public function verify($data, $signature) {
        if (empty($this->publicKey)) {
            throw new Exception('公钥未设置');
        }
        
        $publicKeyResource = openssl_pkey_get_public($this->publicKey);
        if (!$publicKeyResource) {
            throw new Exception('无效的公钥');
        }
        
        $signatureDecoded = base64_decode($signature);
        if ($signatureDecoded === false) {
            return false;
        }
        
        $result = openssl_verify($data, $signatureDecoded, $publicKeyResource, OPENSSL_ALGO_SHA256);
        
        return $result === 1;
    }
    
    /**
     * 加密JSON数据
     * @param array $data 要加密的数组
     * @return string Base64编码的加密数据
     */
    public function encryptJson($data) {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);
        return $this->encrypt($json);
    }
    
    /**
     * 解密JSON数据
     * @param string $encryptedData Base64编码的加密数据
     * @return array 解密后的数组
     */
    public function decryptJson($encryptedData) {
        $json = $this->decrypt($encryptedData);
        $data = json_decode($json, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('JSON解析失败: ' . json_last_error_msg());
        }
        
        return $data;
    }
}
