<?php
/**
 * AES-256加密助手类
 * 实现敏感数据的加密存储
 */

class AESHelper {
    
    private $key;
    private $cipher = 'aes-256-gcm';
    
    /**
     * 构造函数
     * @param string $key 加密密钥（32字节）
     */
    public function __construct($key = null) {
        if ($key) {
            $this->setKey($key);
        }
    }
    
    /**
     * 设置加密密钥
     * @param string $key 加密密钥
     */
    public function setKey($key) {
        // 确保密钥长度为32字节（256位）
        if (strlen($key) < 32) {
            $this->key = hash('sha256', $key, true);
        } else {
            $this->key = substr($key, 0, 32);
        }
    }
    
    /**
     * 生成随机密钥
     * @return string 32字节的随机密钥（十六进制）
     */
    public static function generateKey() {
        return bin2hex(random_bytes(32));
    }
    
    /**
     * 加密数据
     * @param string $data 要加密的数据
     * @return string Base64编码的加密数据（包含IV和Tag）
     */
    public function encrypt($data) {
        if (empty($this->key)) {
            throw new Exception('加密密钥未设置');
        }
        
        // 生成随机IV
        $ivLength = openssl_cipher_iv_length($this->cipher);
        $iv = random_bytes($ivLength);
        
        // 加密
        $tag = '';
        $encrypted = openssl_encrypt(
            $data,
            $this->cipher,
            $this->key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag,
            '',
            16 // tag长度
        );
        
        if ($encrypted === false) {
            throw new Exception('AES加密失败: ' . openssl_error_string());
        }
        
        // 组合: IV + Tag + 密文
        $combined = $iv . $tag . $encrypted;
        
        return base64_encode($combined);
    }
    
    /**
     * 解密数据
     * @param string $encryptedData Base64编码的加密数据
     * @return string 解密后的原始数据
     */
    public function decrypt($encryptedData) {
        if (empty($this->key)) {
            throw new Exception('加密密钥未设置');
        }
        
        $combined = base64_decode($encryptedData);
        if ($combined === false) {
            throw new Exception('Base64解码失败');
        }
        
        // 分离IV、Tag和密文
        $ivLength = openssl_cipher_iv_length($this->cipher);
        $tagLength = 16;
        
        if (strlen($combined) < $ivLength + $tagLength) {
            throw new Exception('加密数据格式错误');
        }
        
        $iv = substr($combined, 0, $ivLength);
        $tag = substr($combined, $ivLength, $tagLength);
        $encrypted = substr($combined, $ivLength + $tagLength);
        
        // 解密
        $decrypted = openssl_decrypt(
            $encrypted,
            $this->cipher,
            $this->key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag
        );
        
        if ($decrypted === false) {
            throw new Exception('AES解密失败: ' . openssl_error_string());
        }
        
        return $decrypted;
    }
    
    /**
     * 加密JSON数据
     * @param array $data 要加密的数组
     * @return string Base64编码的加密数据
     */
    public function encryptJson($data) {
        $json = json_encode($data, JSON_UNESCAPED_UNICODE);
        return $this->encrypt($json);
    }
    
    /**
     * 解密JSON数据
     * @param string $encryptedData Base64编码的加密数据
     * @return array 解密后的数组
     */
    public function decryptJson($encryptedData) {
        $json = $this->decrypt($encryptedData);
        $data = json_decode($json, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('JSON解析失败: ' . json_last_error_msg());
        }
        
        return $data;
    }
    
    /**
     * 加密字段（用于数据库存储）
     * 如果数据为空，返回null
     * @param mixed $data 要加密的数据
     * @return string|null
     */
    public function encryptField($data) {
        if ($data === null || $data === '') {
            return null;
        }
        
        if (is_array($data)) {
            return $this->encryptJson($data);
        }
        
        return $this->encrypt((string)$data);
    }
    
    /**
     * 解密字段（从数据库读取）
     * 如果数据为空，返回null
     * @param string $encryptedData 加密的数据
     * @param bool $isJson 是否为JSON数据
     * @return mixed
     */
    public function decryptField($encryptedData, $isJson = false) {
        if ($encryptedData === null || $encryptedData === '') {
            return null;
        }
        
        try {
            if ($isJson) {
                return $this->decryptJson($encryptedData);
            }
            return $this->decrypt($encryptedData);
        } catch (Exception $e) {
            // 解密失败，可能是未加密的旧数据
            return $encryptedData;
        }
    }
    
    /**
     * 哈希数据（不可逆，用于比对）
     * @param string $data 要哈希的数据
     * @return string 64位十六进制哈希值
     */
    public static function hash($data) {
        return hash('sha256', $data);
    }
    
    /**
     * 带盐哈希（用于密码等）
     * @param string $data 要哈希的数据
     * @param string $salt 盐值
     * @return string 64位十六进制哈希值
     */
    public static function hashWithSalt($data, $salt) {
        return hash('sha256', $salt . $data . $salt);
    }
}
