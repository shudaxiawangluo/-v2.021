<?php
/**
 * 响应助手类
 * 统一API响应格式
 */

class Response {
    
    /**
     * 成功响应
     */
    public static function success($data = null, $message = '成功') {
        self::json(200, $message, $data);
    }
    
    /**
     * 错误响应
     */
    public static function error($code, $message) {
        self::json($code, $message);
    }
    
    /**
     * JSON响应
     */
    public static function json($code, $message = '', $data = null) {
        header('Content-Type: application/json; charset=utf-8');
        
        $response = ['code' => $code];
        if ($message) {
            $response['message'] = $message;
        }
        if ($data !== null) {
            $response['data'] = $data;
        }
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * 参数错误
     */
    public static function badRequest($message = '参数错误') {
        self::json(400, $message);
    }
    
    /**
     * 未授权
     */
    public static function unauthorized($message = '未授权') {
        self::json(401, $message);
    }
    
    /**
     * 禁止访问
     */
    public static function forbidden($message = '禁止访问') {
        self::json(403, $message);
    }
    
    /**
     * 资源不存在
     */
    public static function notFound($message = '资源不存在') {
        self::json(404, $message);
    }
    
    /**
     * 已过期
     */
    public static function expired($message = '已过期') {
        self::json(410, $message);
    }
    
    /**
     * 待审核
     */
    public static function pendingReview($message = '待审核') {
        self::json(423, $message);
    }
    
    /**
     * 请求过于频繁
     */
    public static function tooManyRequests($message = '请求过于频繁') {
        self::json(429, $message);
    }
    
    /**
     * 服务器错误
     */
    public static function serverError($message = '服务器错误') {
        self::json(500, $message);
    }
}
