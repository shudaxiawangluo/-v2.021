<?php
/**
 * 防重放攻击助手类
 * 实现timestamp、nonce、sign校验
 */

class AntiReplay {
    
    private $db;
    private $clientSecret;
    private $timestampTolerance = 30; // 时间戳容差（秒）
    private $nonceExpireMinutes = 30; // nonce过期时间（分钟）
    
    /**
     * 构造函数
     * @param PDO $db 数据库连接
     * @param string $clientSecret 客户端密钥
     */
    public function __construct($db, $clientSecret) {
        $this->db = $db;
        $this->clientSecret = $clientSecret;
    }
    
    /**
     * 设置时间戳容差
     * @param int $seconds 秒数
     */
    public function setTimestampTolerance($seconds) {
        $this->timestampTolerance = $seconds;
    }
    
    /**
     * 设置nonce过期时间
     * @param int $minutes 分钟数
     */
    public function setNonceExpireMinutes($minutes) {
        $this->nonceExpireMinutes = $minutes;
    }
    
    /**
     * 验证请求
     * @param array $request 请求数据，必须包含timestamp、nonce、sign
     * @param array $businessParams 业务参数（用于签名验证）
     * @return array ['success' => bool, 'error' => string|null]
     */
    public function verify($request, $businessParams = []) {
        // 1. 检查必需字段
        if (!isset($request['timestamp']) || !isset($request['nonce']) || !isset($request['sign'])) {
            return ['success' => false, 'error' => '缺少防重放参数'];
        }
        
        $timestamp = intval($request['timestamp']);
        $nonce = trim($request['nonce']);
        $sign = trim($request['sign']);
        
        // 2. 验证nonce长度
        if (strlen($nonce) < 10) {
            return ['success' => false, 'error' => 'nonce长度不足'];
        }
        
        // 3. 验证timestamp
        $timestampResult = $this->verifyTimestamp($timestamp);
        if (!$timestampResult['success']) {
            return $timestampResult;
        }
        
        // 4. 验证nonce唯一性
        $nonceResult = $this->verifyNonce($nonce);
        if (!$nonceResult['success']) {
            return $nonceResult;
        }
        
        // 5. 验证签名
        $signResult = $this->verifySign($timestamp, $nonce, $businessParams, $sign);
        if (!$signResult['success']) {
            return $signResult;
        }
        
        // 6. 存储nonce
        $this->storeNonce($nonce);
        
        return ['success' => true, 'error' => null];
    }
    
    /**
     * 验证时间戳
     * @param int $timestamp 客户端时间戳
     * @return array
     */
    public function verifyTimestamp($timestamp) {
        $serverTime = time();
        $diff = abs($serverTime - $timestamp);
        
        if ($diff > $this->timestampTolerance) {
            return [
                'success' => false, 
                'error' => '请求已过期（时间戳差异: ' . $diff . '秒）'
            ];
        }
        
        return ['success' => true, 'error' => null];
    }
    
    /**
     * 验证nonce唯一性
     * @param string $nonce 随机字符串
     * @return array
     */
    public function verifyNonce($nonce) {
        try {
            $stmt = $this->db->prepare("SELECT id FROM nonce_history WHERE nonce = ?");
            $stmt->execute([$nonce]);
            
            if ($stmt->fetch()) {
                return ['success' => false, 'error' => '重复请求'];
            }
            
            return ['success' => true, 'error' => null];
        } catch (Exception $e) {
            // 表不存在时自动创建
            $this->createNonceTable();
            return ['success' => true, 'error' => null];
        }
    }
    
    /**
     * 验证签名
     * @param int $timestamp 时间戳
     * @param string $nonce 随机字符串
     * @param array $businessParams 业务参数
     * @param string $clientSign 客户端签名
     * @return array
     */
    public function verifySign($timestamp, $nonce, $businessParams, $clientSign) {
        // 计算SHA256签名
        $serverSignSha256 = $this->calculateSign($timestamp, $nonce, $businessParams);
        
        // 计算MD5签名（兼容易语言等客户端）
        $serverSignMd5 = $this->calculateSignMd5($timestamp, $nonce, $businessParams);
        
        // 同时支持SHA256和MD5
        if ($serverSignSha256 !== $clientSign && $serverSignMd5 !== $clientSign) {
            return ['success' => false, 'error' => '签名错误'];
        }
        
        return ['success' => true, 'error' => null];
    }
    
    /**
     * 计算签名（SHA256）
     * @param int $timestamp 时间戳
     * @param string $nonce 随机字符串
     * @param array $businessParams 业务参数
     * @return string 签名值
     */
    public function calculateSign($timestamp, $nonce, $businessParams) {
        $dataToSign = $this->buildSignString($timestamp, $nonce, $businessParams);
        return hash('sha256', $dataToSign);
    }
    
    /**
     * 计算签名（MD5，兼容易语言）
     * @param int $timestamp 时间戳
     * @param string $nonce 随机字符串
     * @param array $businessParams 业务参数
     * @return string 签名值
     */
    public function calculateSignMd5($timestamp, $nonce, $businessParams) {
        $dataToSign = $this->buildSignString($timestamp, $nonce, $businessParams);
        return md5($dataToSign);
    }
    
    /**
     * 构建签名字符串
     * @param int $timestamp 时间戳
     * @param string $nonce 随机字符串
     * @param array $businessParams 业务参数
     * @return string 待签名字符串
     */
    private function buildSignString($timestamp, $nonce, $businessParams) {
        // 1. 业务参数按key字母顺序排序
        ksort($businessParams);
        
        // 2. 拼接参数值
        $paramValues = '';
        foreach ($businessParams as $value) {
            if (is_array($value)) {
                $paramValues .= json_encode($value, JSON_UNESCAPED_UNICODE);
            } else {
                $paramValues .= $value;
            }
        }
        
        // 3. 拼接字符串: timestamp + nonce + 参数值 + 客户端密钥
        return $timestamp . $nonce . $paramValues . $this->clientSecret;
    }
    
    /**
     * 存储nonce
     * @param string $nonce 随机字符串
     */
    public function storeNonce($nonce) {
        try {
            $stmt = $this->db->prepare("INSERT INTO nonce_history (nonce, create_time) VALUES (?, NOW())");
            $stmt->execute([$nonce]);
        } catch (Exception $e) {
            // 忽略重复插入错误
        }
    }
    
    /**
     * 清理过期的nonce
     */
    public function cleanupExpiredNonce() {
        try {
            $stmt = $this->db->prepare(
                "DELETE FROM nonce_history WHERE create_time < DATE_SUB(NOW(), INTERVAL ? MINUTE)"
            );
            $stmt->execute([$this->nonceExpireMinutes]);
        } catch (Exception $e) {
            // 忽略错误
        }
    }
    
    /**
     * 创建nonce表
     */
    private function createNonceTable() {
        $sql = "CREATE TABLE IF NOT EXISTS `nonce_history` (
            `id` BIGINT PRIMARY KEY AUTO_INCREMENT,
            `nonce` VARCHAR(64) NOT NULL,
            `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `uk_nonce` (`nonce`),
            INDEX `idx_create_time` (`create_time`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        
        $this->db->exec($sql);
    }
    
    /**
     * 生成客户端签名（用于测试）
     * @param int $timestamp 时间戳
     * @param string $nonce 随机字符串
     * @param array $businessParams 业务参数
     * @return string 签名值
     */
    public function generateClientSign($timestamp, $nonce, $businessParams) {
        return $this->calculateSign($timestamp, $nonce, $businessParams);
    }
    
    /**
     * 生成随机nonce
     * @param int $length 长度（默认16）
     * @return string
     */
    public static function generateNonce($length = 16) {
        return bin2hex(random_bytes($length / 2));
    }
}
