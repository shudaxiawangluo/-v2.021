<?php
/**
 * 机器指纹助手类
 * 实现指纹验证和容错逻辑
 */

class FingerprintHelper {
    
    // 指纹组件名称
    const COMPONENT_CPU = 'cpu';
    const COMPONENT_DISK = 'disk';
    const COMPONENT_MAC = 'mac';
    const COMPONENT_BOARD = 'board';
    const COMPONENT_BIOS = 'bios';
    
    // 匹配阈值
    private $matchThreshold = 80; // 80%以上匹配触发审核
    
    /**
     * 设置匹配阈值
     * @param int $threshold 阈值百分比
     */
    public function setMatchThreshold($threshold) {
        $this->matchThreshold = $threshold;
    }
    
    /**
     * 验证指纹格式
     * @param string $fingerprint 机器指纹
     * @return bool
     */
    public function validateFormat($fingerprint) {
        // 支持32位MD5或64位SHA256
        $len = strlen($fingerprint);
        if ($len !== 32 && $len !== 64) {
            return false;
        }
        
        return ctype_xdigit($fingerprint);
    }
    
    /**
     * 验证指纹组件格式
     * @param array $components 指纹组件
     * @return bool
     */
    public function validateComponents($components) {
        if (!is_array($components) || empty($components)) {
            return false;
        }
        
        // 至少需要2个组件（兼容易语言SDK）
        if (count($components) < 2) {
            return false;
        }
        
        // 每个组件必须是32位MD5或64位SHA256
        foreach ($components as $key => $value) {
            if (!$this->validateFormat($value)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * 计算最终指纹
     * 客户端应该使用相同的算法
     * @param array $components 指纹组件（已哈希）
     * @return string 64位最终指纹
     */
    public function calculateFinalFingerprint($components) {
        // 按固定顺序排列组件
        $orderedKeys = [
            self::COMPONENT_CPU,
            self::COMPONENT_DISK,
            self::COMPONENT_MAC,
            self::COMPONENT_BOARD,
            self::COMPONENT_BIOS
        ];
        
        $combined = '';
        foreach ($orderedKeys as $key) {
            if (isset($components[$key])) {
                $combined .= $components[$key];
            }
        }
        
        // 对于未按顺序的组件，按key排序后追加
        ksort($components);
        foreach ($components as $key => $value) {
            if (!in_array($key, $orderedKeys)) {
                $combined .= $value;
            }
        }
        
        // 最终SHA256哈希
        return hash('sha256', $combined);
    }
    
    /**
     * 比较两组指纹组件
     * @param array $newComponents 新指纹组件
     * @param array $boundComponents 已绑定的指纹组件
     * @return array ['matched' => bool, 'rate' => float, 'need_review' => bool, 'changed' => array]
     */
    public function compareComponents($newComponents, $boundComponents) {
        if (empty($boundComponents)) {
            // 首次绑定，完全匹配
            return [
                'matched' => true,
                'rate' => 100,
                'need_review' => false,
                'changed' => []
            ];
        }
        
        $totalComponents = 0;
        $matchedComponents = 0;
        $changedComponents = [];
        
        // 获取所有组件键
        $allKeys = array_unique(array_merge(
            array_keys($newComponents),
            array_keys($boundComponents)
        ));
        
        foreach ($allKeys as $key) {
            $newValue = $newComponents[$key] ?? null;
            $boundValue = $boundComponents[$key] ?? null;
            
            if ($newValue !== null && $boundValue !== null) {
                $totalComponents++;
                if ($newValue === $boundValue) {
                    $matchedComponents++;
                } else {
                    $changedComponents[] = $key;
                }
            } elseif ($boundValue !== null) {
                // 新指纹缺少组件
                $totalComponents++;
                $changedComponents[] = $key;
            }
        }
        
        // 计算匹配率
        $matchRate = $totalComponents > 0 ? ($matchedComponents / $totalComponents) * 100 : 0;
        
        // 判断结果
        $matched = $matchRate >= 100;
        $needReview = !$matched && $matchRate >= $this->matchThreshold;
        
        return [
            'matched' => $matched,
            'rate' => round($matchRate, 2),
            'need_review' => $needReview,
            'changed' => $changedComponents
        ];
    }
    
    /**
     * 检查是否允许硬件变更
     * @param array $changedComponents 变更的组件列表
     * @return bool 是否允许（最多1项变更）
     */
    public function isChangeAllowed($changedComponents) {
        return count($changedComponents) <= 1;
    }
    
    /**
     * 检测虚拟机/模拟器特征
     * @param array $deviceInfo 设备信息
     * @return array ['is_virtual' => bool, 'virtual_type' => string|null, 'risk_level' => int]
     */
    public function detectVirtualEnvironment($deviceInfo) {
        $isVirtual = false;
        $virtualType = null;
        $riskLevel = 0;
        
        $platform = strtolower($deviceInfo['platform'] ?? '');
        $osVersion = strtolower($deviceInfo['os_version'] ?? '');
        
        // 客户端已检测的虚拟机标识
        if (!empty($deviceInfo['is_virtual'])) {
            $isVirtual = true;
            $virtualType = $deviceInfo['virtual_type'] ?? 'unknown';
            $riskLevel = 1;
        }
        
        // Windows虚拟机检测
        if ($platform === 'windows') {
            $vmKeywords = ['vmware', 'virtualbox', 'hyper-v', 'qemu', 'xen', 'parallels'];
            foreach ($vmKeywords as $keyword) {
                if (strpos($osVersion, $keyword) !== false) {
                    $isVirtual = true;
                    $virtualType = $keyword;
                    $riskLevel = 1;
                    break;
                }
            }
        }
        
        // Android模拟器检测
        if ($platform === 'android') {
            $emulatorKeywords = [
                'nox', '夜神', 'bluestacks', 'ldplayer', '雷电', 
                'memu', 'genymotion', 'andy', 'droid4x', 'windroy',
                'sdk', 'emulator', 'google_sdk'
            ];
            foreach ($emulatorKeywords as $keyword) {
                if (strpos($osVersion, $keyword) !== false) {
                    $isVirtual = true;
                    $virtualType = $keyword;
                    $riskLevel = 1;
                    break;
                }
            }
        }
        
        return [
            'is_virtual' => $isVirtual,
            'virtual_type' => $virtualType,
            'risk_level' => $riskLevel
        ];
    }
    
    /**
     * 生成设备环境哈希（用于令牌刷新校验）
     * @param array $deviceInfo 设备信息
     * @return string 环境哈希
     */
    public function generateEnvHash($deviceInfo) {
        $envData = [
            'platform' => $deviceInfo['platform'] ?? '',
            'os_version' => $deviceInfo['os_version'] ?? ''
        ];
        
        return hash('sha256', json_encode($envData));
    }
    
    /**
     * 验证设备环境一致性
     * @param array $currentDeviceInfo 当前设备信息
     * @param string $boundEnvHash 绑定的环境哈希
     * @return bool
     */
    public function verifyEnvConsistency($currentDeviceInfo, $boundEnvHash) {
        $currentEnvHash = $this->generateEnvHash($currentDeviceInfo);
        return $currentEnvHash === $boundEnvHash;
    }
    
    /**
     * 脱敏指纹（用于日志）
     * @param string $fingerprint 完整指纹
     * @return string 脱敏后的指纹
     */
    public function maskFingerprint($fingerprint) {
        if (strlen($fingerprint) < 16) {
            return '****';
        }
        return substr($fingerprint, 0, 8) . '...' . substr($fingerprint, -8);
    }
    
    /**
     * 脱敏组件（用于日志）
     * @param array $components 指纹组件
     * @return array 脱敏后的组件
     */
    public function maskComponents($components) {
        $masked = [];
        foreach ($components as $key => $value) {
            $masked[$key] = $this->maskFingerprint($value);
        }
        return $masked;
    }
}
