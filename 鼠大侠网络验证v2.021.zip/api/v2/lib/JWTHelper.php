<?php
/**
 * JWT令牌助手类
 * 实现RS256签名的JWT生成和验证
 */

class JWTHelper {
    
    private $privateKey;
    private $publicKey;
    private $expireHours = 24; // 默认24小时有效期
    
    /**
     * 设置RSA密钥
     * @param string $privateKey PEM格式私钥
     * @param string $publicKey PEM格式公钥
     */
    public function setKeys($privateKey, $publicKey) {
        $this->privateKey = $privateKey;
        $this->publicKey = $publicKey;
    }
    
    /**
     * 设置令牌有效期
     * @param int $hours 有效期（小时）
     */
    public function setExpireHours($hours) {
        $this->expireHours = $hours;
    }
    
    /**
     * 生成JWT令牌
     * @param array $payload 载荷数据
     * @return string JWT令牌
     */
    public function generate($payload) {
        if (empty($this->privateKey)) {
            throw new Exception('私钥未设置');
        }
        
        // Header
        $header = [
            'alg' => 'RS256',
            'typ' => 'JWT'
        ];
        
        // 添加标准声明
        $now = time();
        $payload['iat'] = $now; // 签发时间
        $payload['exp'] = $now + ($this->expireHours * 3600); // 过期时间
        $payload['jti'] = bin2hex(random_bytes(16)); // 唯一标识
        
        // 编码
        $headerEncoded = $this->base64UrlEncode(json_encode($header));
        $payloadEncoded = $this->base64UrlEncode(json_encode($payload));
        
        // 签名
        $dataToSign = $headerEncoded . '.' . $payloadEncoded;
        $signature = $this->sign($dataToSign);
        
        return $headerEncoded . '.' . $payloadEncoded . '.' . $signature;
    }
    
    /**
     * 验证并解析JWT令牌
     * @param string $token JWT令牌
     * @return array|false 成功返回payload，失败返回false
     */
    public function verify($token) {
        if (empty($this->publicKey)) {
            throw new Exception('公钥未设置');
        }
        
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return false;
        }
        
        list($headerEncoded, $payloadEncoded, $signatureEncoded) = $parts;
        
        // 验证签名
        $dataToVerify = $headerEncoded . '.' . $payloadEncoded;
        if (!$this->verifySignature($dataToVerify, $signatureEncoded)) {
            return false;
        }
        
        // 解析payload
        $payload = json_decode($this->base64UrlDecode($payloadEncoded), true);
        if (!$payload) {
            return false;
        }
        
        // 检查过期时间
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            return false;
        }
        
        return $payload;
    }
    
    /**
     * 解析JWT令牌（不验证签名）
     * @param string $token JWT令牌
     * @return array|false 成功返回payload，失败返回false
     */
    public function decode($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return false;
        }
        
        $payload = json_decode($this->base64UrlDecode($parts[1]), true);
        return $payload ?: false;
    }
    
    /**
     * 检查令牌是否即将过期（剩余时间小于1小时）
     * @param string $token JWT令牌
     * @return bool
     */
    public function isExpiringSoon($token) {
        $payload = $this->decode($token);
        if (!$payload || !isset($payload['exp'])) {
            return true;
        }
        
        $remainingTime = $payload['exp'] - time();
        return $remainingTime < 3600; // 小于1小时
    }
    
    /**
     * 获取令牌剩余有效时间（秒）
     * @param string $token JWT令牌
     * @return int 剩余秒数，过期返回0
     */
    public function getRemainingTime($token) {
        $payload = $this->decode($token);
        if (!$payload || !isset($payload['exp'])) {
            return 0;
        }
        
        $remaining = $payload['exp'] - time();
        return max(0, $remaining);
    }
    
    /**
     * 生成刷新令牌
     * @param int $deviceId 设备ID
     * @return string 刷新令牌
     */
    public function generateRefreshToken($deviceId) {
        $data = $deviceId . ':' . time() . ':' . bin2hex(random_bytes(16));
        return hash('sha256', $data);
    }
    
    /**
     * 获取令牌哈希（用于存储）
     * @param string $token JWT令牌
     * @return string 令牌哈希
     */
    public function getTokenHash($token) {
        return hash('sha256', $token);
    }
    
    /**
     * RS256签名
     * @param string $data 要签名的数据
     * @return string Base64Url编码的签名
     */
    private function sign($data) {
        $privateKeyResource = openssl_pkey_get_private($this->privateKey);
        if (!$privateKeyResource) {
            throw new Exception('无效的私钥');
        }
        
        $signature = '';
        if (!openssl_sign($data, $signature, $privateKeyResource, OPENSSL_ALGO_SHA256)) {
            throw new Exception('签名失败');
        }
        
        return $this->base64UrlEncode($signature);
    }
    
    /**
     * 验证RS256签名
     * @param string $data 原始数据
     * @param string $signature Base64Url编码的签名
     * @return bool
     */
    private function verifySignature($data, $signature) {
        $publicKeyResource = openssl_pkey_get_public($this->publicKey);
        if (!$publicKeyResource) {
            return false;
        }
        
        $signatureDecoded = $this->base64UrlDecode($signature);
        $result = openssl_verify($data, $signatureDecoded, $publicKeyResource, OPENSSL_ALGO_SHA256);
        
        return $result === 1;
    }
    
    /**
     * Base64Url编码
     * @param string $data
     * @return string
     */
    private function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    /**
     * Base64Url解码
     * @param string $data
     * @return string
     */
    private function base64UrlDecode($data) {
        return base64_decode(strtr($data, '-_', '+/'));
    }
}
