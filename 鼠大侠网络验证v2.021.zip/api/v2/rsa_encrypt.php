<?php
/**
 * RSA加密辅助接口
 * 为不支持RSA加密的客户端提供在线加密服务
 * 注意：此接口仅用于开发测试，生产环境建议使用本地RSA库
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

function jsonResponse($code, $message, $data = null) {
    $response = ['code' => $code, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $input = file_get_contents('php://input');
    $request = json_decode($input, true);
    
    if (!$request) {
        jsonResponse(400, '无效的请求数据');
    }
    
    $data = $request['data'] ?? '';
    $publicKey = $request['public_key'] ?? '';
    
    if (empty($data)) {
        jsonResponse(400, '缺少data参数');
    }
    
    if (empty($publicKey)) {
        jsonResponse(400, '缺少public_key参数');
    }
    
    // 使用OpenSSL进行RSA加密
    $key = openssl_pkey_get_public($publicKey);
    if (!$key) {
        jsonResponse(400, '无效的公钥格式');
    }
    
    $encrypted = '';
    $success = openssl_public_encrypt($data, $encrypted, $key, OPENSSL_PKCS1_PADDING);
    
    if (!$success) {
        jsonResponse(500, 'RSA加密失败');
    }
    
    $base64Encrypted = base64_encode($encrypted);
    
    jsonResponse(200, '加密成功', [
        'encrypted' => $base64Encrypted
    ]);
    
} catch (Exception $e) {
    jsonResponse(500, '服务器错误: ' . $e->getMessage());
}
