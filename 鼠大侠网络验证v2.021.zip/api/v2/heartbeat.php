<?php
/**
 * V2 心跳接口
 * 维持在线状态，固定5秒间隔
 * 
 * 请求: POST
 * 参数:
 *   - timestamp: 时间戳
 *   - nonce: 随机字符串
 *   - sign: 签名
 *   - token: JWT令牌
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/lib/JWTHelper.php';
require_once __DIR__ . '/lib/AESHelper.php';
require_once __DIR__ . '/lib/AntiReplay.php';

$db = getDB();

// 心跳间隔固定5秒
define('HEARTBEAT_INTERVAL', 5);
// 在线超时时间（3倍心跳间隔）
define('ONLINE_TIMEOUT', 15);

try {
    $clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
    if (strpos($clientIp, ',') !== false) {
        $clientIp = trim(explode(',', $clientIp)[0]);
    }
    
    // 检查IP黑名单（白名单IP跳过黑名单检查）
    if (!checkIPWhitelist($clientIp, 0) && checkIPBlacklist($clientIp)) {
        logRuntime('warning', "[heartbeat] IP黑名单拦截: {$clientIp}", 'v2_api', $clientIp);
        jsonResponse(403, 'IP已被封禁');
    }
    
    // 获取请求数据
    $input = file_get_contents('php://input');
    $request = json_decode($input, true);
    
    if (!$request) {
        jsonResponse(400, '无效的请求数据');
    }
    
    // 获取token
    $token = trim($request['token'] ?? '');
    if (empty($token)) {
        jsonResponse(401, '缺少令牌');
    }
    
    // 解析JWT获取软件ID
    $jwt = new JWTHelper();
    $payload = $jwt->decode($token);
    
    if (!$payload || !isset($payload['software_id'])) {
        jsonResponse(401, '无效的令牌');
    }
    
    $softwareId = $payload['software_id'];
    $deviceId = $payload['device_id'];
    $fingerprint = $payload['fingerprint'];
    $authCodeId = $payload['auth_code_id'] ?? null;
    
    // 查询软件信息
    $stmt = $db->prepare("SELECT id, public_key, private_key, status FROM software WHERE id = ?");
    $stmt->execute([$softwareId]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software || $software['status'] != 1) {
        jsonResponse(403, '软件已禁用');
    }
    
    // 解密私钥
    $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
    $aes = new AESHelper($aesKey);
    
    try {
        $privateKey = $aes->decrypt($software['private_key']);
    } catch (Exception $e) {
        $privateKey = $software['private_key'];
    }
    
    // 验证JWT
    $jwt->setKeys($privateKey, $software['public_key']);
    $verifiedPayload = $jwt->verify($token);
    
    if (!$verifiedPayload) {
        jsonResponse(401, '令牌无效或已过期');
    }
    
    // 防重放校验
    $clientSecret = defined('CLIENT_SECRET') ? CLIENT_SECRET : 'default_client_secret_v2';
    $antiReplay = new AntiReplay($db, $clientSecret);
    
    $businessParams = ['token' => $token];
    $verifyResult = $antiReplay->verify($request, $businessParams);
    
    if (!$verifyResult['success']) {
        jsonResponse(400, $verifyResult['error']);
    }
    
    // 查询设备信息
    $stmt = $db->prepare("SELECT * FROM devices WHERE id = ? AND software_id = ?");
    $stmt->execute([$deviceId, $softwareId]);
    $device = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$device) {
        jsonResponse(404, '设备不存在');
    }
    
    // 检查设备状态
    if ($device['status'] != 1) {
        jsonResponse(403, '设备已禁用');
    }
    
    // 检查风险等级
    if ($device['risk_level'] == 1) {
        jsonResponse(423, '设备待审核');
    }
    
    if ($device['risk_level'] == 2) {
        jsonResponse(403, '设备已被拒绝');
    }
    
    // 检查授权是否过期
    $expireTime = strtotime($device['expire_time']);
    $now = time();
    
    if ($expireTime < $now) {
        // 使会话失效
        $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0 WHERE device_id = ?");
        $stmt->execute([$deviceId]);
        
        // 更新卡密状态为已过期
        if ($authCodeId) {
            $db->prepare("UPDATE auth_codes SET status = 3 WHERE id = ? AND status != 3")->execute([$authCodeId]);
        }
        
        jsonResponse(410, '授权已过期');
    }
    
    // 同时检查卡密的到期时间（双重保险）
    if ($authCodeId) {
        $stmt = $db->prepare("SELECT expire_time, status FROM auth_codes WHERE id = ?");
        $stmt->execute([$authCodeId]);
        $codeInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // 卡密被删除，立即掉线
        if (!$codeInfo) {
            $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0, force_offline = 1 WHERE device_id = ?");
            $stmt->execute([$deviceId]);
            logRuntime('info', "[heartbeat] 卡密已被删除, auth_code_id={$authCodeId}, device_id={$deviceId}", 'v2_api', $clientIp);
            jsonResponse(403, '授权码已失效');
        }
        
        // 检查卡密状态
        if ($codeInfo['status'] == 2) {
            $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0, force_offline = 1 WHERE device_id = ?");
            $stmt->execute([$deviceId]);
            logRuntime('info', "[heartbeat] 卡密已被禁用, auth_code_id={$authCodeId}, device_id={$deviceId}", 'v2_api', $clientIp);
            jsonResponse(403, '授权码已禁用');
        }
        if ($codeInfo['status'] == 3) {
            $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0 WHERE device_id = ?");
            $stmt->execute([$deviceId]);
            jsonResponse(410, '授权已过期');
        }
        
        // 检查卡密到期时间
        if (!empty($codeInfo['expire_time']) && strtotime($codeInfo['expire_time']) < $now) {
            $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0 WHERE device_id = ?");
            $stmt->execute([$deviceId]);
            $db->prepare("UPDATE auth_codes SET status = 3 WHERE id = ?")->execute([$authCodeId]);
            jsonResponse(410, '授权已过期');
        }
    }
    
    // 查询会话状态（包括已失效的，用于检查强制下线）
    $tokenHash = $jwt->getTokenHash($token);
    $stmt = $db->prepare("SELECT * FROM online_sessions WHERE device_id = ? AND token_hash = ?");
    $stmt->execute([$deviceId, $tokenHash]);
    $session = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$session) {
        // 记录日志
        logRuntime('warning', "[heartbeat] 会话不存在, device_id={$deviceId}", 'v2_api', $clientIp);
        jsonResponse(403, '会话不存在，请重新登录');
    }
    
    // 检查是否被强制下线
    if ($session['force_offline'] == 1) {
        // 记录日志
        logRuntime('info', "[heartbeat] 设备被强制下线, device_id={$deviceId}", 'v2_api', $clientIp);
        jsonResponse(403, '您已被强制下线');
    }
    
    // 检查会话是否有效
    if ($session['is_valid'] != 1) {
        // 记录日志
        logRuntime('warning', "[heartbeat] 会话已失效, device_id={$deviceId}", 'v2_api', $clientIp);
        jsonResponse(403, '会话已失效，请重新登录');
    }
    
    // 获取授权码信息，检查单设备在线限制
    if ($authCodeId) {
        $stmt = $db->prepare("SELECT single_online, allow_multi FROM auth_codes WHERE id = ?");
        $stmt->execute([$authCodeId]);
        $codeInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($codeInfo && $codeInfo['single_online'] && !$codeInfo['allow_multi']) {
            // 检查是否有其他设备在线（排除当前会话）
            $stmt = $db->prepare("SELECT id FROM online_sessions WHERE auth_code_id = ? AND id != ? AND is_valid = 1 AND last_heartbeat > DATE_SUB(NOW(), INTERVAL ? SECOND)");
            $stmt->execute([$authCodeId, $session['id'], ONLINE_TIMEOUT]);
            $otherSession = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($otherSession) {
                // 当前会话被顶掉
                $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0, force_offline = 1 WHERE id = ?");
                $stmt->execute([$session['id']]);
                jsonResponse(403, '您的账号已在其他设备登录');
            }
        }
    }
    
    // 更新心跳时间
    $stmt = $db->prepare("UPDATE online_sessions SET last_heartbeat = NOW() WHERE id = ?");
    $stmt->execute([$session['id']]);
    
    $stmt = $db->prepare("UPDATE devices SET last_heartbeat = NOW(), last_ip = ? WHERE id = ?");
    $stmt->execute([$clientIp, $deviceId]);
    
    // 清理过期nonce（随机执行，1%概率）
    if (rand(1, 100) == 1) {
        $antiReplay->cleanupExpiredNonce();
        
        // 同时清理过期会话
        $stmt = $db->prepare("UPDATE online_sessions SET is_valid = 0 WHERE is_valid = 1 AND last_heartbeat < DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
        $stmt->execute();
    }
    
    // 计算剩余时间
    $remainSeconds = max(0, $expireTime - $now);
    
    // 获取云控制数据
    $cloudData = [];
    
    // 1. 获取远程变量
    $stmt = $db->prepare("SELECT var_name, var_value, var_type FROM remote_vars WHERE (software_id = ? OR software_id = 0) AND status = 1");
    $stmt->execute([$softwareId]);
    $vars = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $value = $row['var_value'];
        if ($row['var_type'] === 'number') $value = floatval($value);
        elseif ($row['var_type'] === 'boolean') $value = $value === '1' || $value === 'true';
        $vars[$row['var_name']] = $value;
    }
    if (!empty($vars)) $cloudData['vars'] = $vars;
    
    // 2. 获取公告
    // 先确保show_once字段存在
    try {
        $db->exec("ALTER TABLE announcements ADD COLUMN show_once TINYINT(1) DEFAULT 1 COMMENT '1=只显示一次,0=每次启动显示'");
    } catch (Exception $e) {
        // 字段已存在，忽略
    }
    
    $stmt = $db->prepare("SELECT id, title, content, type, is_popup, show_once FROM announcements WHERE (software_id = ? OR software_id = 0) AND status = 1 AND (start_time IS NULL OR start_time <= NOW()) AND (end_time IS NULL OR end_time >= NOW()) ORDER BY sort_order DESC, id DESC LIMIT 5");
    $stmt->execute([$softwareId]);
    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 确保show_once有默认值
    foreach ($announcements as &$ann) {
        $ann['show_once'] = isset($ann['show_once']) ? intval($ann['show_once']) : 1;
    }
    unset($ann);
    if (!empty($announcements)) $cloudData['announcements'] = $announcements;
    
    // 3. 获取最新版本
    $stmt = $db->prepare("SELECT version, version_code, title, changelog, download_url, file_size, file_md5, force_update, min_version FROM versions WHERE software_id = ? AND status = 1 ORDER BY version_code DESC LIMIT 1");
    $stmt->execute([$softwareId]);
    $latestVersion = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($latestVersion) $cloudData['latest_version'] = $latestVersion;
    
    // 4. 获取远程开关
    $stmt = $db->prepare("SELECT switch_key, switch_value FROM remote_switches WHERE (software_id = ? OR software_id = 0)");
    $stmt->execute([$softwareId]);
    $switches = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $switches[$row['switch_key']] = $row['switch_value'] == 1;
    }
    if (!empty($switches)) $cloudData['switches'] = $switches;
    
    // 返回响应
    $responseData = [
        'status' => 'online',
        'server_time' => $now,
        'expire_time' => $device['expire_time'],
        'remain_seconds' => $remainSeconds,
        'next_heartbeat' => HEARTBEAT_INTERVAL
    ];
    
    // 如果是点卡，添加点数信息
    if ($authCodeId) {
        $stmt = $db->prepare("SELECT is_point_card, total_points, remaining_points, deduct_type FROM auth_codes WHERE id = ?");
        $stmt->execute([$authCodeId]);
        $pointInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($pointInfo && intval($pointInfo['is_point_card']) == 1) {
            $responseData['is_point_card'] = 1;
            $responseData['total_points'] = intval($pointInfo['total_points']);
            $responseData['remaining_points'] = intval($pointInfo['remaining_points']);
            $responseData['deduct_type'] = $pointInfo['deduct_type'] ?? 'per_use';
            
            // 点卡模式下，如果点数为0，返回点数用完的错误
            if (intval($pointInfo['remaining_points']) <= 0) {
                jsonResponse(411, '点数已用完', [
                    'remaining_points' => 0,
                    'total_points' => intval($pointInfo['total_points'])
                ]);
            }
        }
    }
    
    if (!empty($cloudData)) {
        $responseData['cloud'] = $cloudData;
    }
    
    jsonResponse(200, '成功', $responseData);
    
} catch (Exception $e) {
    logRuntime('error', '心跳接口异常: ' . $e->getMessage(), 'heartbeat', $clientIp ?? '');
    jsonResponse(500, '服务器错误');
}
