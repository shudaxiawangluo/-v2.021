<?php
/**
 * V2 扣点接口
 * 扣除用户点数
 * 
 * 请求: POST
 * 参数: 
 *   - timestamp: 时间戳
 *   - nonce: 随机数
 *   - sign: 签名
 *   - token: JWT令牌
 *   - deduct_amount: 扣除点数（可选，默认1）
 *   - reason: 扣点原因（可选）
 * 
 * 响应:
 * {
 *   "code": 200,
 *   "msg": "扣点成功",
 *   "data": {
 *     "remaining_points": 99,
 *     "deduct_amount": 1
 *   }
 * }
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['code' => 405, 'message' => '请求方法不允许']);
    exit;
}

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/lib/JWTHelper.php';
require_once __DIR__ . '/lib/AESHelper.php';
require_once __DIR__ . '/lib/AntiReplay.php';

$db = getDB();

// 获取客户端IP
$clientIp = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
if (strpos($clientIp, ',') !== false) {
    $clientIp = trim(explode(',', $clientIp)[0]);
}

try {
    // 获取请求数据
    $input = file_get_contents('php://input');
    $request = json_decode($input, true);
    
    if (!$request) {
        $request = $_POST;
    }
    
    // 验证必需参数
    $timestamp = trim($request['timestamp'] ?? '');
    $nonce = trim($request['nonce'] ?? '');
    $sign = trim($request['sign'] ?? '');
    $token = trim($request['token'] ?? '');
    $deductAmount = intval($request['deduct_amount'] ?? 1);
    $reason = trim($request['reason'] ?? '使用功能');
    
    if (empty($timestamp) || empty($nonce) || empty($sign) || empty($token)) {
        jsonResponse(400, '缺少必需参数');
    }
    
    if ($deductAmount <= 0) {
        jsonResponse(400, '扣除点数必须大于0');
    }
    
    // 验证时间戳（5分钟内有效）
    if (abs(time() - intval($timestamp)) > 300) {
        jsonResponse(401, '请求已过期');
    }
    
    // 解析JWT获取信息
    $jwt = new JWTHelper();
    $payload = $jwt->decode($token);
    
    if (!$payload || !isset($payload['software_id'])) {
        jsonResponse(401, '无效的令牌');
    }
    
    $softwareId = $payload['software_id'];
    $deviceId = $payload['device_id'];
    $authCodeId = $payload['auth_code_id'] ?? null;
    
    if (!$authCodeId) {
        jsonResponse(400, '令牌中缺少授权码信息');
    }
    
    // 查询软件信息
    $stmt = $db->prepare("SELECT id, public_key, private_key, status FROM software WHERE id = ?");
    $stmt->execute([$softwareId]);
    $software = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$software || $software['status'] != 1) {
        jsonResponse(403, '软件已禁用');
    }
    
    // 解密私钥
    $aesKey = defined('AES_SECRET_KEY') ? AES_SECRET_KEY : 'default_aes_key_for_v2_system';
    $aes = new AESHelper($aesKey);
    
    try {
        $privateKey = $aes->decrypt($software['private_key']);
    } catch (Exception $e) {
        $privateKey = $software['private_key'];
    }
    
    // 验证JWT
    $jwt->setKeys($privateKey, $software['public_key']);
    $verifiedPayload = $jwt->verify($token);
    
    if (!$verifiedPayload) {
        jsonResponse(401, '令牌无效或已过期');
    }
    
    // 防重放校验
    $clientSecret = defined('CLIENT_SECRET') ? CLIENT_SECRET : 'default_client_secret_v2';
    $antiReplay = new AntiReplay($db, $clientSecret);
    
    $businessParams = ['token' => $token];
    $verifyResult = $antiReplay->verify($request, $businessParams);
    
    if (!$verifyResult['success']) {
        jsonResponse(400, $verifyResult['error']);
    }
    
    // 查询授权码信息
    $stmt = $db->prepare("SELECT * FROM auth_codes WHERE id = ?");
    $stmt->execute([$authCodeId]);
    $authCode = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$authCode) {
        jsonResponse(404, '授权码不存在');
    }
    
    // 检查是否是点卡类型
    if (intval($authCode['is_point_card']) != 1) {
        jsonResponse(400, '该卡密不是点卡类型，无需扣点');
    }
    
    // 检查授权码状态
    if ($authCode['status'] == 2) {
        jsonResponse(403, '授权码已禁用');
    }
    if ($authCode['status'] == 3) {
        jsonResponse(410, '授权已过期');
    }
    
    // 开始事务
    $db->beginTransaction();
    
    try {
        // 锁定授权码记录（防止并发扣点）
        $stmt = $db->prepare("SELECT remaining_points FROM auth_codes WHERE id = ? FOR UPDATE");
        $stmt->execute([$authCode['id']]);
        $currentPoints = intval($stmt->fetchColumn());
        
        // 检查点数是否足够
        if ($currentPoints < $deductAmount) {
            $db->rollBack();
            logRuntime('warning', "[deduct_points] 点数不足，剩余{$currentPoints}点，需要{$deductAmount}点", 'v2_api', $clientIp, 0, $softwareId);
            jsonResponse(411, '点数不足', [
                'remaining_points' => $currentPoints,
                'required_points' => $deductAmount
            ]);
        }
        
        // 扣除点数
        $newPoints = $currentPoints - $deductAmount;
        $stmt = $db->prepare("UPDATE auth_codes SET remaining_points = ? WHERE id = ?");
        $stmt->execute([$newPoints, $authCode['id']]);
        
        // 记录扣点日志（如果表存在）
        try {
            $stmt = $db->prepare("
                INSERT INTO point_logs 
                (auth_code_id, software_id, device_id, action, amount, before_points, after_points, reason, ip, create_time)
                VALUES (?, ?, ?, 'deduct', ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $authCode['id'],
                $softwareId,
                $deviceId,
                $deductAmount,
                $currentPoints,
                $newPoints,
                $reason,
                $clientIp
            ]);
        } catch (Exception $e) {
            // 表可能不存在，忽略
        }
        
        // 提交事务
        $db->commit();
        
        // 记录成功日志
        logRuntime('info', "[deduct_points] 扣除{$deductAmount}点，剩余{$newPoints}点，code={$authCode['code']}", 'v2_api', $clientIp, 0, $softwareId);
        
        // 返回响应
        jsonResponse(200, '扣点成功', [
            'remaining_points' => $newPoints,
            'deduct_amount' => $deductAmount,
            'before_points' => $currentPoints
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    logRuntime('error', '[deduct_points] 异常: ' . $e->getMessage(), 'v2_api', $clientIp ?? '');
    jsonResponse(500, '服务器错误');
}
