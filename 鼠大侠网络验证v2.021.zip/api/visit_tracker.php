<?php
/**
 * 访问追踪器 - 记录所有访问并检测异常
 */

require_once __DIR__ . '/config.php';

class VisitTracker {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    /**
     * 记录访问
     */
    public function track() {
        $ip = $this->getClientIP();
        $path = $_SERVER['REQUEST_URI'] ?? '/';
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        
        // 检查是否在黑名单
        if ($this->isBlocked($ip)) {
            http_response_code(403);
            die(json_encode(['code' => -1, 'msg' => 'Access Denied']));
        }
        
        // 检查访问频率
        $this->checkRateLimit($ip);
        
        // 获取IP地理位置
        $location = $this->getIPLocation($ip);
        
        try {
            $stmt = $this->db->prepare("INSERT INTO visit_logs (ip, location, path, method, user_agent, referer, create_time) VALUES (?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$ip, $location, $path, $method, $userAgent, $referer]);
        } catch (Exception $e) {
            // 静默失败，不影响正常访问
        }
    }
    
    /**
     * 获取客户端真实IP
     */
    public function getClientIP() {
        $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }
    
    /**
     * 获取IP地理位置
     */
    public function getIPLocation($ip) {
        if ($ip === '127.0.0.1' || $ip === '::1') {
            return '本地访问';
        }
        
        // 使用免费的IP定位API
        $apis = [
            "http://ip-api.com/json/{$ip}?lang=zh-CN",
            "https://ipapi.co/{$ip}/json/"
        ];
        
        foreach ($apis as $api) {
            try {
                $ctx = stream_context_create(['http' => ['timeout' => 2]]);
                $response = @file_get_contents($api, false, $ctx);
                if ($response) {
                    $data = json_decode($response, true);
                    if (isset($data['country']) && isset($data['city'])) {
                        $country = $data['country'] ?? '';
                        $region = $data['regionName'] ?? $data['region'] ?? '';
                        $city = $data['city'] ?? '';
                        return trim("{$country} {$region} {$city}");
                    }
                }
            } catch (Exception $e) {
                continue;
            }
        }
        return '未知';
    }
    
    /**
     * 检查是否被封禁
     */
    public function isBlocked($ip) {
        try {
            $stmt = $this->db->prepare("SELECT id FROM ip_blacklist WHERE ip = ? AND status = 1");
            $stmt->execute([$ip]);
            return $stmt->fetch() !== false;
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * 检查访问频率限制
     */
    public function checkRateLimit($ip) {
        try {
            // 默认每分钟120次
            $limit = 120;
            
            // 统计最近1分钟的访问次数
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM visit_logs WHERE ip = ? AND create_time > DATE_SUB(NOW(), INTERVAL 1 MINUTE)");
            $stmt->execute([$ip]);
            $count = $stmt->fetchColumn();
            
            if ($count > $limit) {
                // 自动加入黑名单
                $this->autoBlock($ip, "访问频率超限: {$count}次/分钟");
                http_response_code(429);
                die(json_encode(['code' => -1, 'msg' => 'Too Many Requests']));
            }
        } catch (Exception $e) {
            // 静默失败
        }
    }
    
    /**
     * 自动封禁IP
     */
    public function autoBlock($ip, $reason) {
        try {
            $location = $this->getIPLocation($ip);
            $stmt = $this->db->prepare("INSERT INTO ip_blacklist (ip, location, reason, is_auto, status, create_time) VALUES (?, ?, ?, 1, 1, NOW()) ON DUPLICATE KEY UPDATE reason = ?, status = 1");
            $stmt->execute([$ip, $location, $reason, $reason]);
        } catch (Exception $e) {
            // 静默失败
        }
    }
    
    /**
     * 获取访问统计
     */
    public function getStats($days = 7) {
        $stats = [];
        
        // 总访问量
        $stmt = $this->db->query("SELECT COUNT(*) FROM visit_logs");
        $stats['total'] = $stmt->fetchColumn();
        
        // 今日访问
        $stmt = $this->db->query("SELECT COUNT(*) FROM visit_logs WHERE DATE(create_time) = CURDATE()");
        $stats['today'] = $stmt->fetchColumn();
        
        // 独立IP数
        $stmt = $this->db->query("SELECT COUNT(DISTINCT ip) FROM visit_logs WHERE DATE(create_time) = CURDATE()");
        $stats['unique_ip_today'] = $stmt->fetchColumn();
        
        // 被拦截次数
        $stmt = $this->db->query("SELECT COUNT(*) FROM ip_blacklist WHERE status = 1");
        $stats['blocked_count'] = $stmt->fetchColumn();
        
        return $stats;
    }
}

// 初始化追踪器
function initVisitTracker() {
    global $db;
    if (!isset($db)) {
        require_once __DIR__ . '/config.php';
    }
    return new VisitTracker($db);
}
