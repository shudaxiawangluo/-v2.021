<?php
/**
 * 通知发送器 - 支持邮件、微信、钉钉、Telegram
 */

class Notifier {
    private $db;
    private $config = [];
    
    public function __construct($db) {
        $this->db = $db;
        $this->loadConfig();
    }
    
    /**
     * 加载通知配置
     */
    private function loadConfig() {
        try {
            // 从 notify_configs 表加载配置
            $stmt = $this->db->query("SELECT type, config, status FROM notify_configs");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $config = json_decode($row['config'] ?: '{}', true) ?: [];
                $config['enabled'] = $row['status'] == 1;
                $this->config["notify_{$row['type']}"] = $config;
            }
            
            // 加载事件设置
            $stmt = $this->db->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'notify_events'");
            $stmt->execute();
            $eventsJson = $stmt->fetchColumn();
            if ($eventsJson) {
                $events = json_decode($eventsJson, true);
                if (is_array($events)) {
                    $eventMap = [];
                    foreach ($events as $e) {
                        if (isset($e['key'])) {
                            $eventMap[$e['key']] = $e;
                        }
                    }
                    $this->config['notify_events'] = $eventMap;
                }
            }
        } catch (Exception $e) {
            error_log('Notifier loadConfig error: ' . $e->getMessage());
        }
    }
    
    /**
     * 发送通知
     */
    public function send($event, $title, $content, $extra = []) {
        $results = [];
        
        // 根据事件配置决定发送哪些渠道
        $channels = $this->getEventChannels($event);
        
        foreach ($channels as $channel) {
            try {
                switch ($channel) {
                    case 'email':
                        // 如果指定了邮箱就用指定的，否则用管理员邮箱
                        $toEmail = $extra['email'] ?? $this->getAdminEmail();
                        if (!empty($toEmail)) {
                            $results['email'] = $this->sendEmail($toEmail, $title, $content);
                        }
                        break;
                    case 'wechat':
                        $results['wechat'] = $this->sendWechat($title, $content);
                        break;
                    case 'dingtalk':
                        $results['dingtalk'] = $this->sendDingtalk($title, $content);
                        break;
                    case 'telegram':
                        $results['telegram'] = $this->sendTelegram($title . "\n" . $content);
                        break;
                }
            } catch (Exception $e) {
                $results[$channel] = ['success' => false, 'error' => $e->getMessage()];
            }
        }
        
        // 记录发送日志
        $this->logNotify($event, $title, $content, $results);
        
        return $results;
    }
    
    /**
     * 获取管理员邮箱
     */
    private function getAdminEmail() {
        try {
            // 从邮件配置中获取发件邮箱作为管理员邮箱
            $config = $this->config['notify_email'] ?? [];
            return $config['smtp_user'] ?? '';
        } catch (Exception $e) {
            return '';
        }
    }
    
    /**
     * 获取事件对应的通知渠道
     */
    private function getEventChannels($event) {
        $channels = [];
        $eventConfig = $this->config['notify_events'] ?? [];
        
        if (isset($eventConfig[$event])) {
            $eventSetting = $eventConfig[$event];
            foreach (['email', 'wechat', 'dingtalk', 'telegram'] as $ch) {
                // 检查事件是否开启了该渠道，并且该渠道本身是启用的
                if (!empty($eventSetting[$ch]) && $this->isChannelEnabled($ch)) {
                    $channels[] = $ch;
                }
            }
        } else {
            // 默认发送到所有已启用的渠道
            if ($this->isChannelEnabled('email')) $channels[] = 'email';
            if ($this->isChannelEnabled('wechat')) $channels[] = 'wechat';
            if ($this->isChannelEnabled('dingtalk')) $channels[] = 'dingtalk';
            if ($this->isChannelEnabled('telegram')) $channels[] = 'telegram';
        }
        
        return $channels;
    }
    
    /**
     * 检查渠道是否启用
     */
    private function isChannelEnabled($channel) {
        $config = $this->config["notify_{$channel}"] ?? [];
        return !empty($config['enabled']);
    }
    
    /**
     * 生成Element Plus风格的邮件HTML模板
     */
    private function buildEmailHtml($title, $content) {
        $lines = explode("\n", $content);
        $contentHtml = '';
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            $line = ltrim($line, '> ');
            if (strpos($line, ':') !== false) {
                list($label, $value) = explode(':', $line, 2);
                $contentHtml .= '<tr><td style="padding:12px 16px;color:#606266;border-bottom:1px solid #ebeef5;width:120px;background:#fafafa;">' . htmlspecialchars(trim($label)) . '</td><td style="padding:12px 16px;color:#303133;border-bottom:1px solid #ebeef5;">' . htmlspecialchars(trim($value)) . '</td></tr>';
            } else {
                $contentHtml .= '<tr><td colspan="2" style="padding:12px 16px;color:#303133;border-bottom:1px solid #ebeef5;">' . htmlspecialchars($line) . '</td></tr>';
            }
        }
        
        return '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body style="margin:0;padding:0;background:#f5f7fa;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif;">
<div style="max-width:560px;margin:30px auto;background:#fff;border-radius:4px;box-shadow:0 2px 12px 0 rgba(0,0,0,0.1);">
<div style="padding:20px;border-bottom:1px solid #ebeef5;">
<h1 style="margin:0;color:#303133;font-size:18px;font-weight:500;">' . htmlspecialchars($title) . '</h1>
</div>
<div style="padding:20px;">
<table style="width:100%;border-collapse:collapse;border:1px solid #ebeef5;border-radius:4px;">' . $contentHtml . '</table>
</div>
<div style="padding:16px 20px;background:#fafafa;color:#909399;font-size:12px;text-align:center;border-top:1px solid #ebeef5;">
此邮件由系统自动发送 | ' . date('Y-m-d H:i:s') . '
</div>
</div>
</body></html>';
    }
    
    /**
     * 发送邮件
     */
    public function sendEmail($to, $subject, $body) {
        $config = $this->config['notify_email'] ?? [];
        if (empty($config['enabled']) || empty($config['smtp_host'])) {
            return ['success' => false, 'error' => '邮件未配置'];
        }
        
        $host = $config['smtp_host'];
        $port = $config['smtp_port'] ?? 465;
        $user = $config['smtp_user'];
        $pass = $config['smtp_pass'];
        $fromName = $config['from_name'] ?? '授权系统';
        
        // 如果内容不是HTML，则使用模板美化
        if (strpos($body, '<html') === false && strpos($body, '<div') === false) {
            $body = $this->buildEmailHtml($subject, $body);
        }
        
        // 使用 fsockopen 发送邮件
        try {
            $socket = @fsockopen("ssl://{$host}", $port, $errno, $errstr, 10);
            if (!$socket) {
                return ['success' => false, 'error' => "连接失败: {$errstr}"];
            }
            
            $this->smtpRead($socket);
            $this->smtpWrite($socket, "EHLO localhost\r\n");
            $this->smtpRead($socket);
            $this->smtpWrite($socket, "AUTH LOGIN\r\n");
            $this->smtpRead($socket);
            $this->smtpWrite($socket, base64_encode($user) . "\r\n");
            $this->smtpRead($socket);
            $this->smtpWrite($socket, base64_encode($pass) . "\r\n");
            $this->smtpRead($socket);
            $this->smtpWrite($socket, "MAIL FROM:<{$user}>\r\n");
            $this->smtpRead($socket);
            $this->smtpWrite($socket, "RCPT TO:<{$to}>\r\n");
            $this->smtpRead($socket);
            $this->smtpWrite($socket, "DATA\r\n");
            $this->smtpRead($socket);
            
            $headers = "From: {$fromName} <{$user}>\r\n";
            $headers .= "To: {$to}\r\n";
            $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $headers .= "\r\n";
            
            $this->smtpWrite($socket, $headers . $body . "\r\n.\r\n");
            $this->smtpRead($socket);
            $this->smtpWrite($socket, "QUIT\r\n");
            fclose($socket);
            
            return ['success' => true];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    private function smtpWrite($socket, $data) {
        fwrite($socket, $data);
    }
    
    private function smtpRead($socket) {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (substr($line, 3, 1) == ' ') break;
        }
        return $response;
    }
    
    /**
     * 发送微信通知（企业微信机器人）
     */
    public function sendWechat($title, $content) {
        $config = $this->config['notify_wechat'] ?? [];
        if (empty($config['enabled']) || empty($config['webhook_url'])) {
            return ['success' => false, 'error' => '微信未配置'];
        }
        
        $data = [
            'msgtype' => 'markdown',
            'markdown' => [
                'content' => "### {$title}\n{$content}"
            ]
        ];
        
        return $this->httpPost($config['webhook_url'], $data);
    }
    
    /**
     * 发送钉钉通知
     */
    public function sendDingtalk($title, $content) {
        $config = $this->config['notify_dingtalk'] ?? [];
        if (empty($config['enabled']) || empty($config['webhook_url'])) {
            return ['success' => false, 'error' => '钉钉未配置'];
        }
        
        $url = $config['webhook_url'];
        
        // 如果有加签密钥
        if (!empty($config['secret'])) {
            $timestamp = time() * 1000;
            $sign = urlencode(base64_encode(hash_hmac('sha256', $timestamp . "\n" . $config['secret'], $config['secret'], true)));
            $url .= "&timestamp={$timestamp}&sign={$sign}";
        }
        
        $data = [
            'msgtype' => 'markdown',
            'markdown' => [
                'title' => $title,
                'text' => "### {$title}\n{$content}"
            ]
        ];
        
        return $this->httpPost($url, $data);
    }
    
    /**
     * 发送Telegram通知
     */
    public function sendTelegram($message) {
        $config = $this->config['notify_telegram'] ?? [];
        if (empty($config['enabled']) || empty($config['bot_token']) || empty($config['chat_id'])) {
            return ['success' => false, 'error' => 'Telegram未配置'];
        }
        
        $url = "https://api.telegram.org/bot{$config['bot_token']}/sendMessage";
        $data = [
            'chat_id' => $config['chat_id'],
            'text' => $message,
            'parse_mode' => 'Markdown'
        ];
        
        // 支持代理
        $proxy = $config['proxy'] ?? '';
        return $this->httpPost($url, $data, $proxy);
    }
    
    /**
     * HTTP POST请求
     */
    private function httpPost($url, $data, $proxy = '') {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        // 设置代理
        if (!empty($proxy)) {
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return ['success' => false, 'error' => $error];
        }
        
        $result = json_decode($response, true);
        if ($httpCode >= 200 && $httpCode < 300) {
            return ['success' => true, 'response' => $result];
        }
        
        return ['success' => false, 'error' => $response];
    }
    
    /**
     * 记录通知日志
     */
    private function logNotify($event, $title, $content, $results) {
        try {
            // 使用 notify_logs 表的实际字段
            foreach ($results as $type => $result) {
                $status = $result['success'] ? 1 : 0;
                $errorMsg = $result['error'] ?? '';
                $stmt = $this->db->prepare("INSERT INTO notify_logs (type, event, title, content, status, error_msg, create_time) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                $stmt->execute([$type, $event, $title, $content, $status, $errorMsg]);
            }
        } catch (Exception $e) {
            error_log('Notifier logNotify error: ' . $e->getMessage());
        }
    }
}

/**
 * 快捷发送通知函数
 */
function sendNotify($event, $title, $content, $extra = []) {
    global $db;
    $notifier = new Notifier($db);
    return $notifier->send($event, $title, $content, $extra);
}
