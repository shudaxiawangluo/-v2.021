-- =====================================================
-- 鼠大侠授权验证系统 - 完整数据库
-- 版本: V2.0
-- =====================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. 管理员表
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_ip` varchar(50) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. 软件表
CREATE TABLE IF NOT EXISTS `software` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_key` varchar(64) NOT NULL,
  `client_secret` varchar(64) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `notice` text,
  `version` varchar(20) DEFAULT '1.0.0',
  `download_url` varchar(500) DEFAULT NULL,
  `update_log` text,
  `force_update` tinyint(1) DEFAULT 0,
  `public_key` text,
  `private_key` text,
  `enable_trial` tinyint(1) DEFAULT 0,
  `trial_duration` int(11) DEFAULT 30,
  `trial_unit` varchar(10) DEFAULT 'minute',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_key` (`app_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. 授权码表
CREATE TABLE IF NOT EXISTS `auth_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `days` int(11) DEFAULT 30,
  `minutes` int(11) DEFAULT 0,
  `card_type` varchar(20) DEFAULT 'month',
  `price` decimal(10,2) DEFAULT 0,
  `agent_id` int(11) DEFAULT NULL,
  `activate_mode` varchar(20) DEFAULT 'first_use',
  `start_time` datetime DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `max_devices` int(11) DEFAULT 1,
  `allow_multi` tinyint(1) DEFAULT 0,
  `allow_unbind` tinyint(1) DEFAULT 0,
  `max_unbind` int(11) DEFAULT 3,
  `unbind_count` int(11) DEFAULT 0,
  `single_online` tinyint(1) DEFAULT 1,
  `ip_limit` tinyint(1) DEFAULT 0,
  `max_ip` int(11) DEFAULT 5,
  `used_ips` text,
  `use_limit` tinyint(1) DEFAULT 0,
  `max_use` int(11) DEFAULT 100,
  `use_count` int(11) DEFAULT 0,
  `region_limit` tinyint(1) DEFAULT 0,
  `allowed_regions` varchar(500) DEFAULT NULL,
  `machine_code` varchar(128) DEFAULT NULL,
  `bound_fingerprint` varchar(64) DEFAULT NULL,
  `bound_components` text,
  `allow_rebind` int(11) DEFAULT 0,
  `rebind_count` int(11) DEFAULT 0,
  `is_point_card` tinyint(1) DEFAULT 0 COMMENT '是否点卡：0=时长卡，1=点卡',
  `total_points` int(11) DEFAULT 0 COMMENT '总点数',
  `remaining_points` int(11) DEFAULT 0 COMMENT '剩余点数',
  `deduct_type` varchar(20) DEFAULT NULL COMMENT '扣点类型：per_use=按次，per_hour=按小时',
  `status` tinyint(1) DEFAULT 0,
  `used_time` datetime DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `software_id` (`software_id`),
  KEY `status` (`status`),
  KEY `machine_code` (`machine_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. 用户表
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `machine_code` varchar(100) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `remark` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. 代理商表
CREATE TABLE IF NOT EXISTS `agents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `level` tinyint(1) DEFAULT 1,
  `parent_id` int(11) DEFAULT 0,
  `discount` decimal(3,2) DEFAULT 1.00,
  `qq` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `allowed_software` text,
  `balance` decimal(10,2) DEFAULT 0,
  `total_income` decimal(10,2) DEFAULT 0,
  `total_recharge` decimal(10,2) DEFAULT 0,
  `total_withdraw` decimal(10,2) DEFAULT 0,
  `total_sales` decimal(10,2) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `last_ip` varchar(50) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. 代理充值记录表
CREATE TABLE IF NOT EXISTS `agent_recharges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `before_balance` decimal(10,2) DEFAULT 0,
  `after_balance` decimal(10,2) DEFAULT 0,
  `admin_id` int(11) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. 代理提现记录表
CREATE TABLE IF NOT EXISTS `agent_withdraws` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `actual_amount` decimal(10,2) DEFAULT 0,
  `fee` decimal(10,2) DEFAULT 0,
  `withdraw_type` varchar(20) DEFAULT 'alipay',
  `account_type` varchar(20) DEFAULT 'alipay',
  `account_name` varchar(50) DEFAULT NULL,
  `account_no` varchar(100) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `admin_id` int(11) DEFAULT NULL,
  `audit_time` datetime DEFAULT NULL,
  `audit_remark` varchar(200) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7.1 代理订单表
CREATE TABLE IF NOT EXISTS `agent_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `software_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `unit_price` decimal(10,2) DEFAULT 0,
  `amount` decimal(10,2) NOT NULL,
  `auth_codes` text,
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. 订单表
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) NOT NULL,
  `software_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `unit_price` decimal(10,2) DEFAULT 0,
  `total_amount` decimal(10,2) DEFAULT 0,
  `pay_amount` decimal(10,2) DEFAULT 0,
  `amount` decimal(10,2) NOT NULL,
  `pay_type` varchar(20) DEFAULT NULL,
  `pay_time` datetime DEFAULT NULL,
  `trade_no` varchar(100) DEFAULT NULL,
  `auth_codes` text,
  `buyer_email` varchar(100) DEFAULT NULL,
  `buyer_contact` varchar(100) DEFAULT NULL,
  `buyer_ip` varchar(50) DEFAULT NULL,
  `ip_location` varchar(100) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `is_manual` tinyint(1) DEFAULT 0,
  `expire_time` datetime DEFAULT NULL,
  `card_type` varchar(20) DEFAULT 'day',
  `duration` int(11) DEFAULT 30,
  `agent_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. 商品表
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `card_type` varchar(20) DEFAULT 'month',
  `days` int(11) DEFAULT 30,
  `duration` int(11) DEFAULT 30,
  `price` decimal(10,2) NOT NULL,
  `original_price` decimal(10,2) DEFAULT NULL,
  `agent_price` decimal(10,2) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `is_point_card` tinyint(1) DEFAULT 0 COMMENT '是否点卡：0=时长卡，1=点卡',
  `points` int(11) DEFAULT 0 COMMENT '点数（点卡类型时有效）',
  `deduct_type` varchar(20) DEFAULT NULL COMMENT '扣点类型：per_use=按次，per_hour=按小时',
  `deduct_amount` int(11) DEFAULT 1 COMMENT '每次扣除点数',
  `sort_order` int(11) DEFAULT 0,
  `sales` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. 支付配置表
CREATE TABLE IF NOT EXISTS `payment_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pay_type` varchar(20) NOT NULL,
  `pay_name` varchar(50) NOT NULL,
  `merchant_id` varchar(100) DEFAULT NULL,
  `merchant_key` varchar(500) DEFAULT NULL,
  `api_url` varchar(255) DEFAULT NULL,
  `notify_url` varchar(255) DEFAULT NULL,
  `extra_config` text,
  `status` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pay_type` (`pay_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. 远程变量表
CREATE TABLE IF NOT EXISTS `remote_vars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `var_name` varchar(50) NOT NULL,
  `var_value` text,
  `var_type` varchar(20) DEFAULT 'string',
  `description` varchar(200) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. 公告表
CREATE TABLE IF NOT EXISTS `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `content` text,
  `type` varchar(20) DEFAULT 'info',
  `is_popup` tinyint(1) DEFAULT 0,
  `show_once` tinyint(1) DEFAULT 1 COMMENT '1=只显示一次,0=每次启动显示',
  `status` tinyint(1) DEFAULT 1,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. 版本管理表
CREATE TABLE IF NOT EXISTS `versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `version` varchar(20) NOT NULL,
  `version_code` int(11) DEFAULT 0,
  `title` varchar(200) DEFAULT NULL,
  `changelog` text,
  `download_url` varchar(500) DEFAULT NULL,
  `update_log` text,
  `file_size` varchar(50) DEFAULT NULL,
  `file_md5` varchar(32) DEFAULT NULL,
  `force_update` tinyint(1) DEFAULT 0,
  `min_version` varchar(20) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. 远程开关表
CREATE TABLE IF NOT EXISTS `remote_switches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `switch_name` varchar(50) NOT NULL,
  `switch_key` varchar(50) NOT NULL,
  `switch_value` tinyint(1) DEFAULT 0,
  `description` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 15. IP白名单表
CREATE TABLE IF NOT EXISTS `ip_whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `ip` varchar(50) NOT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 16. IP黑名单表
CREATE TABLE IF NOT EXISTS `ip_blacklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `ip` varchar(50) NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 17. 机器码黑名单表
CREATE TABLE IF NOT EXISTS `machine_blacklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `machine_code` varchar(128) NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `machine_code` (`machine_code`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 18. 登录日志表
CREATE TABLE IF NOT EXISTS `login_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `machine_code` varchar(100) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `fail_reason` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 19. 访问统计表
CREATE TABLE IF NOT EXISTS `visit_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `pv` int(11) DEFAULT 0,
  `uv` int(11) DEFAULT 0,
  `ip_count` int(11) DEFAULT 0,
  `new_users` int(11) DEFAULT 0,
  `active_users` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `software_date` (`software_id`, `date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 20. 访问记录表
CREATE TABLE IF NOT EXISTS `visit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `referer` varchar(500) DEFAULT NULL,
  `path` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 21. 通知配置表
CREATE TABLE IF NOT EXISTS `notify_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `config` text,
  `status` tinyint(1) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 22. 通知模板表
CREATE TABLE IF NOT EXISTS `notify_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` text,
  `channels` varchar(100) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `event` (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 23. 通知日志表
CREATE TABLE IF NOT EXISTS `notify_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `event` varchar(50) DEFAULT NULL,
  `receiver` varchar(200) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` text,
  `status` tinyint(1) DEFAULT 1,
  `error_msg` varchar(500) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 24. 自定义API表
CREATE TABLE IF NOT EXISTS `custom_apis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `path` varchar(100) NOT NULL,
  `method` varchar(10) DEFAULT 'GET',
  `params` text,
  `response` text,
  `response_type` varchar(20) DEFAULT 'json',
  `auth_required` tinyint(1) DEFAULT 0,
  `rate_limit` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `path` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 25. Webhook表
CREATE TABLE IF NOT EXISTS `webhooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `url` varchar(500) NOT NULL,
  `events` varchar(500) DEFAULT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `headers` text,
  `status` tinyint(1) DEFAULT 1,
  `last_trigger` datetime DEFAULT NULL,
  `success_count` int(11) DEFAULT 0,
  `fail_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 26. API调用统计表
CREATE TABLE IF NOT EXISTS `api_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `api_name` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `call_count` int(11) DEFAULT 0,
  `success_count` int(11) DEFAULT 0,
  `fail_count` int(11) DEFAULT 0,
  `avg_time` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `software_api_date` (`software_id`, `api_name`, `date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 27. 操作日志表
CREATE TABLE IF NOT EXISTS `operation_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `action` varchar(200) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 28. 运行日志表
CREATE TABLE IF NOT EXISTS `runtime_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  `content` text,
  `ip` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT 0,
  `software_id` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `create_time` (`create_time`),
  KEY `type` (`type`),
  KEY `software_id` (`software_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 29. 系统设置表
CREATE TABLE IF NOT EXISTS `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text,
  `setting_group` varchar(50) DEFAULT 'general',
  `description` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 30. 收入统计表
CREATE TABLE IF NOT EXISTS `income_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `order_count` int(11) DEFAULT 0,
  `total_amount` decimal(10,2) DEFAULT 0,
  `paid_amount` decimal(10,2) DEFAULT 0,
  `refund_amount` decimal(10,2) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `software_date` (`software_id`, `date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 31. 推广统计表
CREATE TABLE IF NOT EXISTS `promotion_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `click_count` int(11) DEFAULT 0,
  `register_count` int(11) DEFAULT 0,
  `order_count` int(11) DEFAULT 0,
  `order_amount` decimal(10,2) DEFAULT 0,
  `commission` decimal(10,2) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 32. V2设备表
CREATE TABLE IF NOT EXISTS `devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) NOT NULL,
  `machine_code` varchar(64) DEFAULT NULL,
  `fingerprint` varchar(64) NOT NULL,
  `fingerprint_components` text,
  `fingerprint_data` text,
  `auth_code_id` int(11) DEFAULT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `os_version` varchar(50) DEFAULT NULL,
  `is_virtual` tinyint(1) DEFAULT 0,
  `virtual_type` varchar(50) DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `is_trial` tinyint(1) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  `risk_level` tinyint(1) DEFAULT 0,
  `risk_reason` varchar(255) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `last_ip` varchar(50) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `last_heartbeat` datetime DEFAULT NULL,
  `unbind_count` int(11) DEFAULT 0,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `software_fingerprint` (`software_id`, `fingerprint`),
  KEY `software_machine` (`software_id`, `machine_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 33. 在线会话表
CREATE TABLE IF NOT EXISTS `online_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `software_id` int(11) NOT NULL,
  `auth_code_id` int(11) DEFAULT NULL,
  `token_hash` varchar(64) NOT NULL,
  `refresh_token_hash` varchar(64) DEFAULT NULL,
  `bound_ip` varchar(50) DEFAULT NULL,
  `bound_env_hash` varchar(64) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `is_valid` tinyint(1) DEFAULT 1,
  `login_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_heartbeat` datetime DEFAULT CURRENT_TIMESTAMP,
  `token_expire_time` datetime DEFAULT NULL,
  `force_offline` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  KEY `token_hash` (`token_hash`),
  KEY `auth_code_id` (`auth_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 34. 指纹审核表
CREATE TABLE IF NOT EXISTS `fingerprint_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(11) NOT NULL,
  `software_id` int(11) DEFAULT NULL,
  `old_fingerprint` varchar(64) NOT NULL,
  `new_fingerprint` varchar(64) NOT NULL,
  `old_fingerprint_data` text,
  `new_fingerprint_data` text,
  `old_components` text,
  `new_components` text,
  `match_rate` decimal(5,2) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `review_admin` int(11) DEFAULT NULL,
  `review_time` datetime DEFAULT NULL,
  `review_remark` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `device_id` (`device_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 38. 授权日志表
CREATE TABLE IF NOT EXISTS `auth_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `fingerprint` varchar(64) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `response_code` int(11) DEFAULT NULL,
  `response_msg` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `software_id` (`software_id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 39. 点卡扣点日志表
CREATE TABLE IF NOT EXISTS `point_deduct_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_code_id` int(11) NOT NULL COMMENT '授权码ID',
  `auth_code` varchar(50) DEFAULT NULL COMMENT '授权码',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `deduct_type` varchar(20) DEFAULT NULL COMMENT '扣点类型：per_use=按次，per_hour=按小时',
  `deduct_amount` int(11) NOT NULL COMMENT '扣除点数',
  `remaining_points` int(11) NOT NULL COMMENT '剩余点数',
  `reason` varchar(200) DEFAULT NULL COMMENT '扣点原因',
  `ip` varchar(50) DEFAULT NULL COMMENT '操作IP',
  `device_id` int(11) DEFAULT NULL COMMENT '设备ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `auth_code_id` (`auth_code_id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='点卡扣点日志表';

-- 40. 点卡充值日志表
CREATE TABLE IF NOT EXISTS `point_recharge_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_code_id` int(11) NOT NULL COMMENT '授权码ID',
  `auth_code` varchar(50) DEFAULT NULL COMMENT '授权码',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `recharge_points` int(11) NOT NULL COMMENT '充值点数',
  `before_points` int(11) NOT NULL COMMENT '充值前点数',
  `after_points` int(11) NOT NULL COMMENT '充值后点数',
  `recharge_code` varchar(50) DEFAULT NULL COMMENT '充值卡密',
  `ip` varchar(50) DEFAULT NULL COMMENT '操作IP',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `auth_code_id` (`auth_code_id`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='点卡充值日志表';

-- 35. 防重放nonce表
CREATE TABLE IF NOT EXISTS `nonce_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nonce` varchar(64) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nonce` (`nonce`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 36. 在线用户表
CREATE TABLE IF NOT EXISTS `online_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `software_id` int(11) DEFAULT NULL,
  `token` varchar(255) NOT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `machine_code` varchar(100) DEFAULT NULL,
  `login_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_heartbeat` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 37. 风险设备表
CREATE TABLE IF NOT EXISTS `risk_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `software_id` int(11) DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL,
  `machine_code` varchar(100) NOT NULL,
  `risk_type` varchar(50) NOT NULL,
  `risk_level` tinyint(1) DEFAULT 1,
  `risk_reason` varchar(500) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `handle_admin` int(11) DEFAULT NULL,
  `handle_time` datetime DEFAULT NULL,
  `handle_remark` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 插入默认支付配置
INSERT INTO `payment_configs` (`pay_type`, `pay_name`, `status`, `sort_order`) VALUES
('alipay', '支付宝', 0, 1),
('wechat', '微信支付', 0, 2),
('epay', '易支付', 0, 3),
('usdt', 'USDT', 0, 4)
ON DUPLICATE KEY UPDATE `pay_name` = VALUES(`pay_name`);

-- 插入默认通知配置
INSERT INTO `notify_configs` (`type`, `name`, `status`) VALUES
('email', '邮件通知', 0),
('sms', '短信通知', 0),
('wechat', '微信通知', 0),
('webhook', 'Webhook通知', 0)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- 插入默认系统设置
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `setting_group`, `description`) VALUES
('site_name', '鼠大侠授权验证系统', 'general', '站点名称'),
('site_logo', '', 'general', '站点Logo'),
('site_footer', 'Copyright © 2024 鼠大侠', 'general', '页脚信息'),
('heartbeat_interval', '5', 'security', '心跳间隔(秒)'),
('token_expire', '7200', 'security', 'Token过期时间(秒)'),
('shop_enabled', '1', 'shop', '发卡页面开关')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================
-- 安装完成
-- =====================================================
