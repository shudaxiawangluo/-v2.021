<?php
/**
 * 到期提醒定时任务
 * 建议每天执行一次: 0 9 * * * php /path/to/cron_expire_remind.php
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/notifier.php';

$db = getDB();

// 确保remind_sent字段存在
try {
    $db->exec("ALTER TABLE auth_codes ADD COLUMN remind_sent TINYINT DEFAULT 0");
} catch (PDOException $e) {}

// 获取提醒设置
$stmt = $db->query("SELECT * FROM settings WHERE `key` = 'expire_remind_days'");
$setting = $stmt->fetch(PDO::FETCH_ASSOC);
$remindDays = $setting ? intval($setting['value']) : 3; // 默认提前3天提醒

if ($remindDays <= 0) {
    echo "到期提醒已关闭\n";
    exit;
}

// 查找即将到期的授权（状态为已激活，且在提醒天数内到期）
$stmt = $db->prepare("
    SELECT ac.*, s.name as software_name 
    FROM auth_codes ac 
    LEFT JOIN software s ON ac.software_id = s.id 
    WHERE ac.status = 1 
    AND ac.expire_time IS NOT NULL 
    AND ac.expire_time > NOW() 
    AND ac.expire_time <= DATE_ADD(NOW(), INTERVAL ? DAY)
    AND (ac.remind_sent IS NULL OR ac.remind_sent = 0)
");
$stmt->execute([$remindDays]);
$expiring = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($expiring)) {
    echo "没有即将到期的授权\n";
    exit;
}

echo "找到 " . count($expiring) . " 个即将到期的授权\n";

$notifier = new Notifier($db);
$sentCount = 0;

foreach ($expiring as $code) {
    $expireTime = $code['expire_time'];
    $remainDays = ceil((strtotime($expireTime) - time()) / 86400);
    
    $content = "软件: {$code['software_name']}\n";
    $content .= "授权码: " . substr($code['code'], 0, 8) . "****\n";
    $content .= "到期时间: {$expireTime}\n";
    $content .= "剩余天数: {$remainDays} 天\n";
    $content .= "请及时续费以免影响使用";
    
    try {
        $notifier->send('auth_expiring', '授权即将到期', $content);
        
        // 标记已发送提醒
        $updateStmt = $db->prepare("UPDATE auth_codes SET remind_sent = 1 WHERE id = ?");
        $updateStmt->execute([$code['id']]);
        
        $sentCount++;
        echo "已发送提醒: {$code['code']}\n";
    } catch (Exception $e) {
        echo "发送失败: {$code['code']} - " . $e->getMessage() . "\n";
    }
}

echo "完成，共发送 {$sentCount} 条提醒\n";
