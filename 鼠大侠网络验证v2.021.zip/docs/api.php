<?php
/**
 * V2 授权验证系统 - 开发文档
 */
session_start();

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$domain = $_SERVER['HTTP_HOST'] ?? 'your-domain.com';
$baseUrl = $protocol . '://' . $domain;
$apiUrl = $baseUrl . '/api/v2/';

// 读取服务端配置
require_once __DIR__ . '/../api/config.php';
$clientSecret = defined('CLIENT_SECRET') ? CLIENT_SECRET : 'your_client_secret';

// PHP SDK代码 - 使用Nowdoc避免变量解析
$phpSdkCode = <<<'PHPSDK'
<?php
/**
 * V2 授权验证 PHP SDK
 * API地址: {API_URL}
 * 
 * 使用方法:
 * require_once 'AuthVerify.php';
 * $auth = new AuthVerify();
 * if ($auth->init() && $auth->activate('授权码')) {
 *     echo '激活成功';
 * }
 */

class AuthVerify {
    // ==================== 配置区 ====================
    private $apiUrl = '{API_URL}';
    private $appKey = 'your_app_key';           // 从后台获取
    private $clientSecret = '{CLIENT_SECRET}';  // 从开发文档获取
    // ================================================
    
    private $publicKey = '';
    private $token = '';
    private $refreshToken = '';
    private $expireTime = '';
    private $machineCode = '';
    
    /**
     * 1. 初始化 - 获取RSA公钥
     */
    public function init() {
        $response = $this->post('init.php', ['app_key' => $this->appKey]);
        if ($response && $response['code'] == 200) {
            $this->publicKey = $response['data']['public_key'];
            return true;
        }
        return false;
    }
    
    /**
     * 2. 激活授权
     */
    public function activate($authCode) {
        if (empty($this->publicKey) && !$this->init()) {
            return false;
        }
        
        $this->machineCode = $this->getMachineCode();
        $timestamp = time();
        $nonce = $this->generateNonce();
        
        // 构建签名（只拼接参数值，不包含key）
        $bizParams = ['app_key' => $this->appKey, 'auth_code' => $authCode];
        ksort($bizParams);
        $signStr = $timestamp . $nonce . implode('', $bizParams) . $this->clientSecret;
        $sign = hash('sha256', $signStr);
        
        // 构建内层数据
        $innerData = [
            'timestamp' => $timestamp,
            'nonce' => $nonce,
            'sign' => $sign,
            'auth_code' => $authCode,
            'fingerprint' => $this->getFingerprint(),
            'device_info' => $this->getDeviceInfo()
        ];
        
        // RSA加密
        $encryptedData = $this->rsaEncrypt(json_encode($innerData));
        
        $response = $this->post('activate.php', [
            'app_key' => $this->appKey,
            'data' => $encryptedData
        ]);
        
        if ($response && $response['code'] == 200) {
            $this->token = $response['data']['token'];
            $this->refreshToken = $response['data']['refresh_token'];
            $this->expireTime = $response['data']['expire_time'];
            return true;
        }
        return false;
    }
    
    /**
     * 3. 心跳保活 (每5秒调用一次)
     */
    public function heartbeat() {
        if (empty($this->token)) return false;
        
        $timestamp = time();
        $nonce = $this->generateNonce();
        // 签名：timestamp + nonce + token值 + client_secret
        $signStr = $timestamp . $nonce . $this->token . $this->clientSecret;
        $sign = hash('sha256', $signStr);
        
        $response = $this->post('heartbeat.php', [
            'timestamp' => $timestamp,
            'nonce' => $nonce,
            'sign' => $sign,
            'token' => $this->token
        ]);
        
        if ($response && $response['code'] == 200) {
            // 处理云控制数据
            $this->handleCloudData($response['data']);
            return true;
        }
        return false;
    }
    
    /**
     * 处理云控制数据
     */
    private function handleCloudData($data) {
        if (!isset($data['cloud'])) return;
        
        $cloud = $data['cloud'];
        
        // 处理公告
        if (isset($cloud['announcements'])) {
            foreach ($cloud['announcements'] as $announcement) {
                $typeText = [
                    'notice' => '通知',
                    'warning' => '警告', 
                    'update' => '更新',
                    'ad' => '广告'
                ][$announcement['type']] ?? '公告';
                
                echo "[{$typeText}] {$announcement['title']}: {$announcement['content']}\n";
                
                // 如果需要弹窗显示，可以记录到日志或数据库
                if ($announcement['is_popup'] == 1) {
                    error_log("弹窗公告: [{$typeText}] {$announcement['title']}");
                }
            }
        }
        
        // 处理远程变量
        if (isset($cloud['vars'])) {
            foreach ($cloud['vars'] as $key => $value) {
                echo "远程变量 {$key}: {$value}\n";
            }
        }
        
        // 处理版本更新
        if (isset($cloud['latest_version'])) {
            $version = $cloud['latest_version'];
            echo "最新版本: {$version['version']} (代码: {$version['version_code']})\n";
            if ($version['force_update']) {
                echo "强制更新: {$version['title']}\n";
            }
        }
    }
    
    /**
     * 4. 刷新令牌
     */
    public function refresh() {
        if (empty($this->token) || empty($this->refreshToken)) return false;
        
        $timestamp = time();
        $nonce = $this->generateNonce();
        // 签名：timestamp + nonce + 参数值（按key字母排序：fingerprint, refresh_token, token）+ client_secret
        $bizParams = ['fingerprint' => $this->machineCode, 'refresh_token' => $this->refreshToken, 'token' => $this->token];
        ksort($bizParams);
        $signStr = $timestamp . $nonce . implode('', $bizParams) . $this->clientSecret;
        $sign = hash('sha256', $signStr);
        
        $response = $this->post('refresh.php', [
            'timestamp' => $timestamp,
            'nonce' => $nonce,
            'sign' => $sign,
            'token' => $this->token,
            'refresh_token' => $this->refreshToken,
            'fingerprint' => $this->machineCode
        ]);
        
        if ($response && $response['code'] == 200) {
            $this->token = $response['data']['token'];
            $this->refreshToken = $response['data']['refresh_token'];
            return true;
        }
        return false;
    }
    
    public function getExpireTime() { return $this->expireTime; }
    public function getToken() { return $this->token; }
    
    // ==================== 私有方法 ====================
    
    private function generateNonce($length = 16) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $nonce = '';
        for ($i = 0; $i < $length; $i++) {
            $nonce .= $chars[random_int(0, strlen($chars) - 1)];
        }
        return $nonce;
    }
    
    private function getMachineCode() {
        $data = [];
        if (function_exists('php_uname')) $data[] = php_uname();
        if (isset($_SERVER['SERVER_ADDR'])) $data[] = $_SERVER['SERVER_ADDR'];
        $data[] = __DIR__;
        return hash('sha256', implode('|', $data));
    }
    
    private function getFingerprint() {
        // 获取原始硬件信息（PHP环境下使用服务器信息）
        $rawCpu = php_uname('m') . php_uname('r');
        $rawDisk = __DIR__;
        $rawMac = $_SERVER['SERVER_ADDR'] ?? gethostname();
        $rawBoard = php_uname('n');
        
        // 每个组件单独SHA256哈希（必须是64位十六进制）
        $components = [
            'cpu' => hash('sha256', $rawCpu),
            'disk' => hash('sha256', $rawDisk),
            'mac' => hash('sha256', $rawMac),
            'board' => hash('sha256', $rawBoard)
        ];
        
        // final = SHA256(cpu + disk + mac + board)
        $combined = $components['cpu'] . $components['disk'] . $components['mac'] . $components['board'];
        return [
            'final' => hash('sha256', $combined),
            'components' => $components
        ];
    }
    
    private function getDeviceInfo() {
        return [
            'platform' => 'PHP',
            'os_version' => PHP_OS . ' ' . PHP_VERSION,
            'is_virtual' => false,
            'virtual_type' => ''
        ];
    }
    
    private function rsaEncrypt($data) {
        $publicKey = "-----BEGIN PUBLIC KEY-----\n" . 
                     chunk_split($this->publicKey, 64, "\n") . 
                     "-----END PUBLIC KEY-----";
        
        // RSA-2048最大加密长度245字节，需要分段加密
        $maxLength = 245;
        $dataLength = strlen($data);
        $encrypted = '';
        
        for ($i = 0; $i < $dataLength; $i += $maxLength) {
            $chunk = substr($data, $i, $maxLength);
            $encryptedChunk = '';
            if (!openssl_public_encrypt($chunk, $encryptedChunk, $publicKey, OPENSSL_PKCS1_PADDING)) {
                return false;
            }
            $encrypted .= $encryptedChunk;
        }
        
        return base64_encode($encrypted);
    }
    
    private function post($api, $data) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->apiUrl . $api,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }
}

// ==================== 使用示例 ====================
/*
$auth = new AuthVerify();

// 初始化
if (!$auth->init()) {
    die('初始化失败');
}

// 激活
if ($auth->activate('你的授权码')) {
    echo "激活成功，到期时间: " . $auth->getExpireTime() . "\n";
    
    // 心跳循环 (实际使用时应该用定时任务)
    while (true) {
        sleep(5);
        if (!$auth->heartbeat()) {
            echo "心跳失败，尝试刷新令牌\n";
            if (!$auth->refresh()) {
                echo "刷新失败，需要重新激活\n";
                break;
            }
        }
        // 心跳成功时会自动处理公告、远程变量等云控制数据
        // 公告会输出到控制台，弹窗公告会记录到错误日志
    }
} else {
    echo "激活失败\n";
}
*/
PHPSDK;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>V2 授权系统 - 开发文档</title>
    <link rel="stylesheet" href="../admin/assets/libs/element-plus.min.css">
    <link rel="stylesheet" href="../admin/assets/libs/dark.css">
    <script src="../admin/assets/libs/vue.min.js"></script>
    <script src="../admin/assets/libs/element-plus.min.js"></script>
    <script src="../admin/assets/libs/icons-vue.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { height: 100%; }
        html.dark { color-scheme: dark; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', 'Helvetica Neue', Helvetica, Arial, sans-serif; background: var(--el-bg-color-page); }
        [v-cloak] { display: none; }
        .layout { display: flex; height: 100vh; }
        .sidebar { width: 220px; background: var(--el-bg-color); border-right: 1px solid var(--el-border-color); display: flex; flex-direction: column; flex-shrink: 0; }
        .logo { height: 56px; display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 15px; font-weight: 500; color: var(--el-text-color-primary); padding: 0 16px; border-bottom: 1px solid var(--el-border-color-light); }
        .logo img { height: 32px; width: 32px; object-fit: contain; }
        .el-menu { border: none; flex: 1; overflow-y: auto; padding: 8px 12px; }
        .el-menu-item, .el-sub-menu__title { height: 40px !important; line-height: 40px !important; border-radius: 6px !important; margin-bottom: 4px !important; font-size: 14px !important; }
        .el-sub-menu .el-menu-item { height: 36px !important; line-height: 36px !important; padding-left: 48px !important; border-radius: 6px !important; margin: 2px 0 !important; font-size: 13px !important; }
        .el-menu-item.is-active { background-color: #e6f7ff !important; color: #1890ff !important; font-weight: 500 !important; }
        .el-menu-item:hover, .el-sub-menu__title:hover { background-color: #f5f7fa !important; }
        html.dark .el-menu-item:hover, html.dark .el-sub-menu__title:hover { background-color: rgba(255, 255, 255, 0.05) !important; }
        html.dark .el-menu-item.is-active { background-color: rgba(64, 158, 255, 0.15) !important; }
        .main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .header { height: 56px; background: var(--el-bg-color); padding: 0 20px; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; border-bottom: 1px solid var(--el-border-color-light); }
        .content { flex: 1; padding: 16px; overflow-y: auto; background: var(--el-bg-color-page); }
        .api-card { margin-bottom: 16px; }
        .api-url-box { background: var(--el-fill-color-light); padding: 12px 16px; border-radius: 6px; margin-bottom: 16px; display: flex; align-items: center; gap: 12px; }
        .method-tag { background: #67c23a; color: #fff; padding: 4px 10px; border-radius: 4px; font-size: 12px; font-weight: 600; }
        .url-text { font-family: Consolas, Monaco, monospace; font-size: 14px; color: var(--el-text-color-primary); word-break: break-all; }
        .code-block { background: #1e1e1e; border-radius: 6px; margin: 12px 0; overflow: hidden; }
        .code-header { background: #2d2d2d; padding: 8px 16px; display: flex; justify-content: space-between; align-items: center; }
        .code-lang { color: #909399; font-size: 13px; }
        .code-body { padding: 16px; color: #d4d4d4; font-family: Consolas, Monaco, monospace; font-size: 13px; line-height: 1.6; overflow-x: auto; white-space: pre; max-height: 600px; overflow-y: auto; }
        .section-title { font-size: 15px; font-weight: 500; color: var(--el-text-color-primary); margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid var(--el-border-color-lighter); }
        /* 快速开始步骤卡片样式 - 简洁白色风格 */
        .step-cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
        .step-card { background: var(--el-bg-color); border: 1px solid var(--el-border-color); border-radius: 8px; padding: 20px; position: relative; transition: all 0.3s; }
        .step-card:hover { border-color: var(--el-color-primary); box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); }
        .step-num { position: absolute; top: 16px; right: 16px; font-size: 32px; font-weight: 700; color: var(--el-color-primary); opacity: 0.15; }
        .step-title { font-size: 15px; font-weight: 600; color: var(--el-text-color-primary); margin-bottom: 10px; }
        .step-desc { font-size: 13px; color: var(--el-text-color-secondary); line-height: 1.6; }
        /* 复制按钮样式 */
        .copy-url-btn { margin-left: 8px; cursor: pointer; color: var(--el-color-primary); }
        .copy-url-btn:hover { color: var(--el-color-primary-light-3); }
        .api-url-box { background: var(--el-fill-color-light); padding: 12px 16px; border-radius: 6px; margin-bottom: 16px; display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
        .url-copy-wrap { display: flex; align-items: center; flex: 1; }
    </style>
</head>
<body>
<div id="app" v-cloak>
    <div class="layout">
        <div class="sidebar">
            <div class="logo">
                <img src="../img/鼠大侠logo.png" alt="Logo">
                <span>开发文档 V2</span>
            </div>
            <el-menu :default-active="tab" @select="tab = $event">
                <el-menu-item index="quickstart"><el-icon><guide /></el-icon><span>快速开始</span></el-menu-item>
                <el-sub-menu index="api">
                    <template #title><el-icon><connection /></el-icon><span>API接口</span></template>
                    <el-menu-item index="init">初始化</el-menu-item>
                    <el-menu-item index="activate">激活授权</el-menu-item>
                    <el-menu-item index="heartbeat">心跳保活</el-menu-item>
                    <el-menu-item index="refresh">刷新令牌</el-menu-item>
                    <el-menu-item index="trial">试用申请</el-menu-item>
                    <el-menu-item index="deduct_points">扣除点数</el-menu-item>
                    <el-menu-item index="query_points">查询点数</el-menu-item>
                    <el-menu-item index="recharge_points">充值点数</el-menu-item>
                </el-sub-menu>
                <el-sub-menu index="example">
                    <template #title><el-icon><document /></el-icon><span>SDK示例</span></template>
                    <el-menu-item index="sdk_csharp">C# (Visual Studio)</el-menu-item>
                    <el-menu-item index="sdk_vbnet">VB.NET</el-menu-item>
                    <el-menu-item index="sdk_e">易语言</el-menu-item>
                    <el-menu-item index="sdk_python">Python</el-menu-item>
                    <el-menu-item index="sdk_android_java">Android Studio</el-menu-item>
                    <el-menu-item index="sdk_go">Go</el-menu-item>
                    <el-menu-item index="sdk_php">PHP</el-menu-item>
                </el-sub-menu>
                <el-menu-item index="errors"><el-icon><warning /></el-icon><span>错误码</span></el-menu-item>
                <el-menu-item index="security"><el-icon><lock /></el-icon><span>安全机制</span></el-menu-item>
            </el-menu>
        </div>
        
        <div class="main">
            <div class="header">
                <el-breadcrumb separator="/">
                    <el-breadcrumb-item>开发文档</el-breadcrumb-item>
                    <el-breadcrumb-item>{{ tabNames[tab] }}</el-breadcrumb-item>
                </el-breadcrumb>
                <div style="display: flex; align-items: center; gap: 16px;">
                    <el-button type="primary" size="small" @click="window.open('../admin/dashboard.php')">返回后台</el-button>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 13px; color: var(--el-text-color-secondary);">主题</span>
                        <el-switch v-model="isDark" size="small" @change="toggleDark" />
                    </div>
                </div>
            </div>
            
            <div class="content">
                <!-- 快速开始 -->
                <div v-show="tab==='quickstart'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">快速开始</span></template>
                        <el-alert type="success" :closable="false" style="margin-bottom: 20px;">
                            V2 授权验证系统采用"客户端采集 + 服务端判定"架构，支持 Windows / Android 双端，RSA-2048加密传输，JWT令牌认证
                        </el-alert>
                        <el-table :data="configTable" border style="width:100%">
                            <el-table-column prop="name" label="配置项" width="150"></el-table-column>
                            <el-table-column prop="value" label="值"></el-table-column>
                            <el-table-column prop="desc" label="说明" width="200"></el-table-column>
                        </el-table>
                        
                        <h4 style="margin: 24px 0 16px; font-size: 15px; font-weight: 500;">接入流程</h4>
                        <div class="step-cards">
                            <div class="step-card">
                                <div class="step-num">1</div>
                                <div class="step-title">初始化</div>
                                <div class="step-desc">调用 init.php 接口获取RSA公钥，用于后续数据加密传输。这是接入的第一步，必须先完成初始化才能进行后续操作。</div>
                            </div>
                            <div class="step-card">
                                <div class="step-num">2</div>
                                <div class="step-title">采集指纹</div>
                                <div class="step-desc">采集设备硬件信息生成唯一机器码。Windows采集CPU、硬盘、MAC地址、主板序列号；Android采集Android ID、设备品牌、型号等。</div>
                            </div>
                            <div class="step-card">
                                <div class="step-num">3</div>
                                <div class="step-title">激活授权</div>
                                <div class="step-desc">调用 activate.php 接口，使用授权码+机器指纹激活，成功后获取JWT令牌和刷新令牌，令牌有效期24小时。</div>
                            </div>
                            <div class="step-card">
                                <div class="step-num">4</div>
                                <div class="step-title">心跳保活</div>
                                <div class="step-desc">调用 heartbeat.php 接口，固定每5秒发送一次心跳维持在线状态。连续15秒无心跳将被判定为离线。</div>
                            </div>
                        </div>
                        
                        <h4 style="margin: 24px 0 16px; font-size: 15px; font-weight: 500;">统一响应格式</h4>
                        <el-alert type="info" :closable="false" style="margin-bottom: 16px;">
                            所有API接口返回统一的JSON格式，包含code、message/msg、data、timestamp字段
                        </el-alert>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span></div><div class="code-body">{
    "code": 200,           // 状态码，200表示成功
    "message": "成功",     // 消息说明
    "msg": "成功",         // 消息说明（兼容字段）
    "data": { ... },       // 业务数据
    "timestamp": 1705123456 // 服务器时间戳
}</div></div>
                        <p style="color:var(--el-text-color-secondary);font-size:13px;margin-top:12px">注意：message 和 msg 字段内容相同，为兼容不同版本客户端，建议优先使用 message 字段</p>
                    </el-card>
                </div>
                
                <!-- 初始化接口 -->
                <div v-show="tab==='init'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">初始化接口</span></template>
                        <div class="api-url-box">
                            <span class="method-tag">POST</span>
                            <div class="url-copy-wrap">
                                <span class="url-text"><?php echo $apiUrl; ?>init.php</span>
                                <el-button type="primary" link class="copy-url-btn" @click="copyUrl('<?php echo $apiUrl; ?>init.php')"><el-icon><document-copy /></el-icon></el-button>
                            </div>
                        </div>
                        <p style="color:var(--el-text-color-secondary);margin-bottom:16px">获取RSA公钥和服务器配置，这是接入的第一步。</p>
                        <h4 style="margin:16px 0 12px;font-size:14px">请求参数</h4>
                        <el-table :data="initParams" border size="small">
                            <el-table-column prop="name" label="参数" width="120"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag :type="s.row.required?'danger':'info'" size="small">{{s.row.required?'是':'否'}}</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">响应示例</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "code": 200,
    "message": "成功",
    "data": {
        "public_key": "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhki...\n-----END PUBLIC KEY-----",
        "server_time": 1705123456,
        "heartbeat_interval": 5
    }
}</div></div>
                    </el-card>
                </div>

                <!-- 激活接口 -->
                <div v-show="tab==='activate'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">激活接口</span></template>
                        <div class="api-url-box">
                            <span class="method-tag">POST</span>
                            <div class="url-copy-wrap">
                                <span class="url-text"><?php echo $apiUrl; ?>activate.php</span>
                                <el-button type="primary" link class="copy-url-btn" @click="copyUrl('<?php echo $apiUrl; ?>activate.php')"><el-icon><document-copy /></el-icon></el-button>
                            </div>
                        </div>
                        <el-alert type="warning" :closable="false" style="margin-bottom:16px">data字段需要RSA公钥加密后Base64编码，app_key明文传输</el-alert>
                        <h4 style="margin:16px 0 12px;font-size:14px">请求参数（外层）</h4>
                        <el-table :data="activateOuterParams" border size="small">
                            <el-table-column prop="name" label="参数" width="120"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag type="danger" size="small">是</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">加密数据内容（data解密后）</h4>
                        <el-table :data="activateInnerParams" border size="small">
                            <el-table-column prop="name" label="参数" width="120"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag type="danger" size="small">是</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        
                        <el-alert type="error" :closable="false" style="margin:16px 0">
                            <template #title>指纹组件格式要求（重要）</template>
                            fingerprint 必须包含 final 和 components 两个字段，components 至少需要2个组件，每个组件值支持32位MD5或64位SHA256十六进制哈希
                        </el-alert>
                        <h4 style="margin:16px 0 12px;font-size:14px">fingerprint 对象结构</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "final": "32位MD5或64位SHA256十六进制字符串",
    "components": {
        "cpu": "32位MD5或64位SHA256（CPU序列号的哈希）",
        "mac": "32位MD5或64位SHA256（MAC地址的哈希）",
        "disk": "可选 - 硬盘序列号的哈希",
        "board": "可选 - 主板序列号的哈希"
    }
}

// 示例1（易语言SDK - 使用MD5，2个组件）:
{
    "final": "df2c7aa05ffabd0787db4d86feeb909e",
    "components": {
        "cpu": "b014b7d94b33ea5181da4e54ca40730d",
        "mac": "141df94074a9704483b51d2fe774e6ca"
    }
}
// final 计算方法: MD5(cpu哈希 + mac哈希)

// 示例2（完整版 - 使用SHA256，4个组件）:
{
    "final": "a1b2c3d4e5f6...共64位",
    "components": {
        "cpu": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "disk": "d7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592",
        "mac": "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",
        "board": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2"
    }
}
// final 计算方法: SHA256(cpu + disk + mac + board)</div></div>
                        
                        <h4 style="margin:16px 0 12px;font-size:14px">device_info 对象结构</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "platform": "windows",        // 平台: windows / android
    "os_version": "Windows 10",   // 操作系统版本
    "is_virtual": false,          // 是否虚拟机
    "virtual_type": ""            // 虚拟机类型: vmware/virtualbox/hyper-v 等
}</div></div>
                        
                        <h4 style="margin:16px 0 12px;font-size:14px">响应示例</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "code": 200,
    "message": "激活成功",
    "data": {
        "token": "eyJhbGciOiJSUzI1NiJ9...",
        "refresh_token": "rf_abc123...",
        "expire_time": "2026-02-13 12:00:00",
        "remain_days": 30
    }
}</div></div>
                    </el-card>
                </div>
                
                <!-- 心跳接口 -->
                <div v-show="tab==='heartbeat'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">心跳接口</span></template>
                        <div class="api-url-box">
                            <span class="method-tag">POST</span>
                            <div class="url-copy-wrap">
                                <span class="url-text"><?php echo $apiUrl; ?>heartbeat.php</span>
                                <el-button type="primary" link class="copy-url-btn" @click="copyUrl('<?php echo $apiUrl; ?>heartbeat.php')"><el-icon><document-copy /></el-icon></el-button>
                            </div>
                        </div>
                        <el-alert type="info" :closable="false" style="margin-bottom:16px">心跳间隔固定5秒，连续15秒无心跳判定离线</el-alert>
                        <h4 style="margin:16px 0 12px;font-size:14px">请求参数</h4>
                        <el-table :data="heartbeatParams" border size="small">
                            <el-table-column prop="name" label="参数" width="120"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag type="danger" size="small">是</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">响应示例</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "code": 200,
    "data": {
        "status": "online",
        "server_time": 1705123456,
        "expire_time": "2026-02-13 12:00:00",
        "remain_seconds": 2592000,
        "cloud": {
            "vars": {
                "download_url": "https://example.com/download",
                "notice_text": "欢迎使用"
            },
            "announcements": [
                {
                    "id": 1,
                    "title": "系统维护通知",
                    "content": "系统将于今晚22:00-24:00进行维护升级，期间可能影响正常使用，请提前保存工作。",
                    "type": "notice",
                    "is_popup": 1,
                    "show_once": 1
                },
                {
                    "id": 2,
                    "title": "新版本发布",
                    "content": "v2.1.0版本已发布，修复了若干已知问题，建议及时更新。",
                    "type": "update",
                    "is_popup": 0,
                    "show_once": 1
                }
            ],
            "latest_version": {
                "version": "2.0.0",
                "version_code": 200,
                "download_url": "https://...",
                "force_update": 0
            },
            "switches": {
                "feature_a": true,
                "maintenance": false
            }
        }
    }
}</div></div>
                        <h4 style="margin:16px 0 12px;font-size:14px">云控制数据说明</h4>
                        <el-table :data="cloudDataDesc" border size="small">
                            <el-table-column prop="name" label="字段" width="150"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        
                        <h4 style="margin:24px 0 12px;font-size:14px">公告处理示例</h4>
                        <el-alert type="info" :closable="false" style="margin-bottom:16px">
                            公告数据在心跳响应的 cloud.announcements 数组中，客户端应根据 type 和 is_popup 字段进行相应处理
                        </el-alert>
                        <div class="code-block"><div class="code-header"><span class="code-lang">C#</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">// 已读公告ID列表（建议持久化存储到本地文件或注册表）
private static HashSet&lt;int&gt; _readAnnouncementIds = new HashSet&lt;int&gt;();
private static bool _isFirstHeartbeat = true;

// 处理心跳响应中的公告数据
if (response.data.cloud?.announcements != null)
{
    foreach (var announcement in response.data.cloud.announcements)
    {
        int id = announcement.id;
        int showOnce = announcement.show_once;  // 1=只显示一次, 0=每次启动显示
        int isPopup = announcement.is_popup;
        
        // 判断是否需要显示
        bool shouldShow = false;
        if (showOnce == 1)
        {
            // 只显示一次模式：检查是否已读
            if (!_readAnnouncementIds.Contains(id))
            {
                shouldShow = true;
            }
        }
        else
        {
            // 每次启动显示模式：只在首次心跳时显示
            if (_isFirstHeartbeat)
            {
                shouldShow = true;
            }
        }
        
        if (shouldShow)
        {
            string typeText = announcement.type switch
            {
                "notice" => "通知",
                "warning" => "警告", 
                "update" => "更新",
                "ad" => "广告",
                _ => "公告"
            };
            
            if (isPopup == 1)
            {
                // 弹窗显示
                MessageBox.Show(
                    announcement.content, 
                    $"[{typeText}] {announcement.title}",
                    MessageBoxButtons.OK,
                    announcement.type == "warning" ? MessageBoxIcon.Warning : MessageBoxIcon.Information
                );
            }
            else
            {
                // 添加到公告列表
                AddAnnouncementToList(id, announcement.title, announcement.content, announcement.type);
            }
            
            // 标记为已读（只对show_once=1的公告记录）
            if (showOnce == 1)
            {
                _readAnnouncementIds.Add(id);
                SaveReadIds(); // 持久化保存
            }
        }
    }
    _isFirstHeartbeat = false;
}</div></div>
                        
                        <div class="code-block"><div class="code-header"><span class="code-lang">Java (Android)</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">// 处理心跳响应中的公告数据
JSONArray announcements = cloudData.optJSONArray("announcements");
if (announcements != null) {
    for (int i = 0; i < announcements.length(); i++) {
        JSONObject announcement = announcements.getJSONObject(i);
        
        int id = announcement.getInt("id");
        String title = announcement.getString("title");
        String content = announcement.getString("content");
        String type = announcement.getString("type");
        int isPopup = announcement.getInt("is_popup");
        
        // 如果需要弹窗显示
        if (isPopup == 1) {
            // 在主线程显示弹窗
            runOnUiThread(() -> {
                new AlertDialog.Builder(this)
                    .setTitle(getTypeText(type) + " " + title)
                    .setMessage(content)
                    .setPositiveButton("确定", null)
                    .show();
            });
        } else {
            // 添加到公告列表
            addAnnouncementToList(id, title, content, type);
        }
    }
}

private String getTypeText(String type) {
    switch (type) {
        case "notice": return "📢 通知";
        case "warning": return "⚠️ 警告";
        case "update": return "🔄 更新";
        case "ad": return "📺 广告";
        default: return "📋 公告";
    }
}</div></div>
                    </el-card>
                </div>

                <!-- 刷新令牌 -->
                <div v-show="tab==='refresh'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">刷新令牌接口</span></template>
                        <div class="api-url-box">
                            <span class="method-tag">POST</span>
                            <div class="url-copy-wrap">
                                <span class="url-text"><?php echo $apiUrl; ?>refresh.php</span>
                                <el-button type="primary" link class="copy-url-btn" @click="copyUrl('<?php echo $apiUrl; ?>refresh.php')"><el-icon><document-copy /></el-icon></el-button>
                            </div>
                        </div>
                        <p style="color:var(--el-text-color-secondary);margin-bottom:16px">JWT令牌24小时有效，过期后1小时内可刷新</p>
                        <h4 style="margin:16px 0 12px;font-size:14px">请求参数</h4>
                        <el-table :data="refreshParams" border size="small">
                            <el-table-column prop="name" label="参数" width="120"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag type="danger" size="small">是</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">响应示例</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "code": 200,
    "message": "刷新成功",
    "data": {
        "token": "eyJhbGciOiJSUzI1NiJ9...",
        "refresh_token": "rf_new123..."
    }
}</div></div>
                    </el-card>
                </div>
                
                <!-- 试用接口 -->
                <div v-show="tab==='trial'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">试用接口</span></template>
                        <div class="api-url-box">
                            <span class="method-tag">POST</span>
                            <div class="url-copy-wrap">
                                <span class="url-text"><?php echo $apiUrl; ?>trial.php</span>
                                <el-button type="primary" link class="copy-url-btn" @click="copyUrl('<?php echo $apiUrl; ?>trial.php')"><el-icon><document-copy /></el-icon></el-button>
                            </div>
                        </div>
                        <el-alert type="warning" :closable="false" style="margin-bottom:16px">每个设备只能试用一次，data字段需RSA加密</el-alert>
                        <h4 style="margin:16px 0 12px;font-size:14px">请求参数（外层）</h4>
                        <el-table :data="trialOuterParams" border size="small">
                            <el-table-column prop="name" label="参数" width="120"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag type="danger" size="small">是</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">加密数据内容</h4>
                        <el-table :data="trialInnerParams" border size="small">
                            <el-table-column prop="name" label="参数" width="120"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag type="danger" size="small">是</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">响应示例</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "code": 200,
    "message": "试用激活成功",
    "data": {
        "token": "eyJhbGciOiJSUzI1NiJ9...",
        "refresh_token": "rf_trial...",
        "expire_time": "2026-01-13 12:30:00",
        "remain_seconds": 1800,
        "is_trial": true
    }
}</div></div>
                    </el-card>
                </div>

                <!-- 扣除点数接口 -->
                <div v-show="tab==='deduct_points'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">扣除点数接口</span></template>
                        <div class="api-url-box">
                            <span class="method-tag">POST</span>
                            <div class="url-copy-wrap">
                                <span class="url-text"><?php echo $apiUrl; ?>deduct_points.php</span>
                                <el-button type="primary" link class="copy-url-btn" @click="copyUrl('<?php echo $apiUrl; ?>deduct_points.php')"><el-icon><document-copy /></el-icon></el-button>
                            </div>
                        </div>
                        <el-alert type="info" :closable="false" style="margin-bottom:16px">点卡扣点接口，用于按次或按时扣除用户点数</el-alert>
                        <h4 style="margin:16px 0 12px;font-size:14px">请求参数</h4>
                        <el-table :data="deductPointsParams" border size="small">
                            <el-table-column prop="name" label="参数" width="140"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag :type="s.row.required?'danger':'info'" size="small">{{s.row.required?'是':'否'}}</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">响应示例</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "code": 200,
    "msg": "扣点成功",
    "data": {
        "remaining_points": 99,
        "deduct_amount": 1,
        "before_points": 100
    }
}</div></div>
                    </el-card>
                </div>

                <!-- 查询点数接口 -->
                <div v-show="tab==='query_points'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">查询点数接口</span></template>
                        <div class="api-url-box">
                            <span class="method-tag">POST</span>
                            <div class="url-copy-wrap">
                                <span class="url-text"><?php echo $apiUrl; ?>query_points.php</span>
                                <el-button type="primary" link class="copy-url-btn" @click="copyUrl('<?php echo $apiUrl; ?>query_points.php')"><el-icon><document-copy /></el-icon></el-button>
                            </div>
                        </div>
                        <el-alert type="info" :closable="false" style="margin-bottom:16px">查询点卡剩余点数和使用情况</el-alert>
                        <h4 style="margin:16px 0 12px;font-size:14px">请求参数</h4>
                        <el-table :data="queryPointsParams" border size="small">
                            <el-table-column prop="name" label="参数" width="120"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag type="danger" size="small">是</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">响应示例</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "code": 200,
    "msg": "查询成功",
    "data": {
        "card_type": 1,
        "total_points": 100,
        "remaining_points": 99,
        "used_points": 1,
        "deduct_type": "per_use",
        "expire_time": "2026-12-31 23:59:59"
    }
}</div></div>
                    </el-card>
                </div>

                <!-- 充值点数接口 -->
                <div v-show="tab==='recharge_points'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">充值点数接口</span></template>
                        <div class="api-url-box">
                            <span class="method-tag">POST</span>
                            <div class="url-copy-wrap">
                                <span class="url-text"><?php echo $apiUrl; ?>recharge_points.php</span>
                                <el-button type="primary" link class="copy-url-btn" @click="copyUrl('<?php echo $apiUrl; ?>recharge_points.php')"><el-icon><document-copy /></el-icon></el-button>
                            </div>
                        </div>
                        <el-alert type="warning" :closable="false" style="margin-bottom:16px">使用充值卡密为现有授权充值点数，充值卡密使用后自动失效</el-alert>
                        <h4 style="margin:16px 0 12px;font-size:14px">请求参数</h4>
                        <el-table :data="rechargePointsParams" border size="small">
                            <el-table-column prop="name" label="参数" width="140"></el-table-column>
                            <el-table-column prop="type" label="类型" width="80"></el-table-column>
                            <el-table-column prop="required" label="必填" width="60"><template #default="s"><el-tag type="danger" size="small">是</el-tag></template></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                        </el-table>
                        <h4 style="margin:16px 0 12px;font-size:14px">响应示例</h4>
                        <div class="code-block"><div class="code-header"><span class="code-lang">JSON</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">{
    "code": 200,
    "msg": "充值成功",
    "data": {
        "before_points": 99,
        "recharge_points": 100,
        "after_points": 199
    }
}</div></div>
                    </el-card>
                </div>

                <!-- 错误码 -->
                <div v-show="tab==='errors'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">错误码说明</span></template>
                        <el-table :data="errorCodes" border>
                            <el-table-column prop="code" label="错误码" width="80"></el-table-column>
                            <el-table-column prop="message" label="错误信息" width="150"></el-table-column>
                            <el-table-column prop="desc" label="说明"></el-table-column>
                            <el-table-column prop="solution" label="解决方案"></el-table-column>
                        </el-table>
                    </el-card>
                </div>
                
                <!-- 安全机制 -->
                <div v-show="tab==='security'">
                    <el-card class="api-card">
                        <template #header><span class="section-title">安全机制</span></template>
                        <h4 style="margin-bottom:12px;font-size:14px">防重放攻击</h4>
                        <p style="color:var(--el-text-color-secondary);margin-bottom:16px">所有请求需携带 timestamp + nonce + sign 三个参数</p>
                        
                        <el-alert type="warning" :closable="false" style="margin-bottom:16px">
                            重要：签名算法只拼接参数的值（value），不包含参数名（key）
                        </el-alert>
                        
                        <el-alert type="success" :closable="false" style="margin-bottom:16px">
                            <template #title>签名算法兼容性</template>
                            服务器同时支持 SHA256（推荐）和 MD5（兼容模式）两种签名算法。<br>
                            • SHA256：64位十六进制字符串，安全性更高，推荐使用<br>
                            • MD5：32位十六进制字符串，兼容易语言等不方便使用SHA256的客户端
                        </el-alert>
                        
                        <div class="code-block"><div class="code-header"><span class="code-lang">签名算法步骤</span><el-button size="small" @click="copy($event)">复制</el-button></div><div class="code-body">1. 将业务参数按key字母顺序排序
2. 只拼接参数的值（不是key=value格式）
3. 拼接字符串: timestamp + nonce + 参数值 + client_secret
4. 计算哈希得到sign（SHA256推荐，MD5兼容）

示例（激活接口）:
  业务参数: app_key="SK_abc123", auth_code="AUTH001"
  排序后: app_key, auth_code（按字母顺序）
  拼接值: "SK_abc123" + "AUTH001" = "SK_abc123AUTH001"
  最终字符串: "1705123456" + "randomnonce123" + "SK_abc123AUTH001" + "your_client_secret"
  
  SHA256签名: sign = SHA256("1705123456randomnonce123SK_abc123AUTH001your_client_secret")
  MD5签名:    sign = MD5("1705123456randomnonce123SK_abc123AUTH001your_client_secret")

示例（心跳接口）:
  业务参数: token="eyJhbGci..."
  最终字符串: timestamp + nonce + token值 + client_secret
  sign = SHA256或MD5("1705123456randomnonce123eyJhbGci...your_client_secret")</div></div>

                        <h4 style="margin:20px 0 12px;font-size:14px">各接口签名参数</h4>
                        <el-table :data="signParamsTable" border size="small" style="margin-bottom:16px">
                            <el-table-column prop="api" label="接口" width="120"></el-table-column>
                            <el-table-column prop="params" label="参与签名的业务参数"></el-table-column>
                            <el-table-column prop="example" label="拼接示例"></el-table-column>
                        </el-table>
                        
                        <h4 style="margin:20px 0 12px;font-size:14px">机器指纹采集</h4>
                        <el-table :data="fingerprintItems" border>
                            <el-table-column prop="platform" label="平台" width="100"></el-table-column>
                            <el-table-column prop="items" label="采集项"></el-table-column>
                        </el-table>
                        <el-alert type="info" :closable="false" style="margin-top:16px">指纹容错：当硬件变更导致指纹匹配率≥80%时触发人工审核，低于80%则拒绝</el-alert>
                    </el-card>
                </div>
                
                <!-- SDK示例 -->
                <div v-show="tab.startsWith('sdk_')">
                    <el-card class="api-card">
                        <template #header>
                            <div style="display:flex;justify-content:space-between;align-items:center">
                                <span class="section-title" style="border:none;margin:0;padding:0">{{ sdkNames[tab] }} SDK 完整示例</span>
                                <el-button v-if="tab !== 'sdk_e'" type="primary" size="small" @click="copyCode(tab)">复制完整代码</el-button>
                            </div>
                        </template>
                        
                        <!-- 易语言SDK - 下载提示 -->
                        <div v-if="tab === 'sdk_e'">
                            <el-alert type="info" :closable="false" style="margin-bottom:20px">
                                易语言SDK已单独开发完成，如需获取完整示例工程，请联系鼠大侠获取。
                            </el-alert>
                            <h4 style="margin-bottom:12px">SDK功能说明</h4>
                            <el-descriptions :column="1" border>
                                <el-descriptions-item label="支持库">精易模块、spec支持库、EThread多线程支持库</el-descriptions-item>
                                <el-descriptions-item label="签名算法">MD5签名（服务端同时支持MD5和SHA256）</el-descriptions-item>
                                <el-descriptions-item label="传输模式">明文模式（不使用RSA加密，适合易语言环境）</el-descriptions-item>
                                <el-descriptions-item label="主要功能">初始化、激活授权、心跳保活、机器指纹采集</el-descriptions-item>
                            </el-descriptions>
                        </div>
                        
                        <!-- 其他SDK - 显示代码 -->
                        <div v-else>
                            <el-alert type="success" :closable="false" style="margin-bottom:16px">
                                以下是完整的SDK实现代码，可直接复制使用。代码中的API地址已自动替换为当前服务器地址。
                            </el-alert>
                            <div class="code-block"><div class="code-header"><span class="code-lang">{{ sdkLangs[tab] }}</span></div><div class="code-body">{{ codes[tab] }}</div></div>
                        </div>
                    </el-card>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const API_URL = '<?php echo $apiUrl; ?>';
const CLIENT_SECRET = '<?php echo $clientSecret; ?>';

const SDK_CODES = {
sdk_csharp: `using System;
using System.Collections.Generic;
using System.Management;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AuthSDK
{
    /// <summary>
    /// V2 授权验证SDK - C# 完整实现 (Visual Studio 2022)
    /// NuGet包: Newtonsoft.Json, System.Management
    /// API地址: {API_URL}
    /// </summary>
    public class AuthVerify
    {
        #region 配置区 - 请修改为你的配置
        private const string API_URL = "{API_URL}";
        private const string APP_KEY = "your_app_key";           // 从后台获取
        private const string CLIENT_SECRET = "{CLIENT_SECRET}";  // 从开发文档获取
        #endregion

        private static AuthVerify _instance;
        private static readonly object _lock = new object();
        private string _publicKey = "";
        private string _token = "";
        private string _refreshToken = "";
        private string _machineCode = "";
        private DateTime _expireTime;
        private Timer _heartbeatTimer;
        private readonly HttpClient _httpClient;
        private bool _isRunning = false;

        // 事件
        public event Action<int, string> OnError;
        public event Action OnExpired;
        public event Action OnOffline;
        public event Action<string> OnHeartbeat;
        public event Action<int, string, string, string, bool> OnAnnouncement; // id, title, content, type, isPopup
        public event Action<string, string> OnRemoteVar; // key, value
        public event Action<string, int, bool> OnVersionUpdate; // version, versionCode, forceUpdate

        public static AuthVerify Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        if (_instance == null)
                            _instance = new AuthVerify();
                    }
                }
                return _instance;
            }
        }

        private AuthVerify()
        {
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(30);
        }

        #region 公开方法

        /// <summary>
        /// 1. 初始化 - 获取RSA公钥
        /// </summary>
        public async Task<bool> InitAsync()
        {
            try
            {
                var response = await PostAsync("init.php", new { app_key = APP_KEY });
                if (response["code"].Value<int>() == 200)
                {
                    _publicKey = response["data"]["public_key"].Value<string>();
                    return true;
                }
                OnError?.Invoke(response["code"].Value<int>(), response["message"]?.Value<string>() ?? "初始化失败");
                return false;
            }
            catch (Exception ex)
            {
                OnError?.Invoke(-1, "初始化异常: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 2. 激活授权
        /// </summary>
        public async Task<bool> ActivateAsync(string authCode)
        {
            try
            {
                if (string.IsNullOrEmpty(_publicKey))
                {
                    OnError?.Invoke(-1, "请先调用InitAsync初始化");
                    return false;
                }

                var fingerprint = GetFingerprint();
                var deviceInfo = GetDeviceInfo();
                var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();
                var nonce = GenerateNonce();
                var sign = CalcSign(new SortedDictionary<string, string> 
                { 
                    ["app_key"] = APP_KEY, 
                    ["auth_code"] = authCode 
                }, timestamp, nonce);

                var innerData = new
                {
                    timestamp = timestamp,
                    nonce = nonce,
                    sign = sign,
                    auth_code = authCode,
                    fingerprint = fingerprint,
                    device_info = deviceInfo
                };

                var encryptedData = RsaEncrypt(JsonConvert.SerializeObject(innerData));
                var response = await PostAsync("activate.php", new { app_key = APP_KEY, data = encryptedData });

                if (response["code"].Value<int>() == 200)
                {
                    _token = response["data"]["token"].Value<string>();
                    _refreshToken = response["data"]["refresh_token"].Value<string>();
                    _machineCode = fingerprint["final"].ToString();
                    _expireTime = DateTime.Parse(response["data"]["expire_time"].Value<string>());
                    StartHeartbeat();
                    return true;
                }
                OnError?.Invoke(response["code"].Value<int>(), response["message"]?.Value<string>() ?? "激活失败");
                return false;
            }
            catch (Exception ex)
            {
                OnError?.Invoke(-1, "激活异常: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 3. 试用申请
        /// </summary>
        public async Task<bool> TrialAsync()
        {
            try
            {
                if (string.IsNullOrEmpty(_publicKey))
                {
                    OnError?.Invoke(-1, "请先调用InitAsync初始化");
                    return false;
                }

                var fingerprint = GetFingerprint();
                var deviceInfo = GetDeviceInfo();
                var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();
                var nonce = GenerateNonce();
                var sign = CalcSign(new SortedDictionary<string, string> { ["app_key"] = APP_KEY }, timestamp, nonce);

                var innerData = new
                {
                    timestamp = timestamp,
                    nonce = nonce,
                    sign = sign,
                    fingerprint = fingerprint,
                    device_info = deviceInfo
                };

                var encryptedData = RsaEncrypt(JsonConvert.SerializeObject(innerData));
                var response = await PostAsync("trial.php", new { app_key = APP_KEY, data = encryptedData });

                if (response["code"].Value<int>() == 200)
                {
                    _token = response["data"]["token"].Value<string>();
                    _refreshToken = response["data"]["refresh_token"].Value<string>();
                    _machineCode = fingerprint["final"].ToString();
                    StartHeartbeat();
                    return true;
                }
                OnError?.Invoke(response["code"].Value<int>(), response["message"]?.Value<string>() ?? "试用申请失败");
                return false;
            }
            catch (Exception ex)
            {
                OnError?.Invoke(-1, "试用申请异常: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 4. 刷新令牌
        /// </summary>
        public async Task<bool> RefreshTokenAsync()
        {
            try
            {
                var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();
                var nonce = GenerateNonce();
                var sign = CalcSign(new SortedDictionary<string, string>
                {
                    ["fingerprint"] = _machineCode,
                    ["refresh_token"] = _refreshToken,
                    ["token"] = _token
                }, timestamp, nonce);

                var response = await PostAsync("refresh.php", new
                {
                    timestamp = timestamp,
                    nonce = nonce,
                    sign = sign,
                    token = _token,
                    refresh_token = _refreshToken,
                    fingerprint = _machineCode
                });

                if (response["code"].Value<int>() == 200)
                {
                    _token = response["data"]["token"].Value<string>();
                    _refreshToken = response["data"]["refresh_token"].Value<string>();
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 停止心跳
        /// </summary>
        public void StopHeartbeat()
        {
            _isRunning = false;
            _heartbeatTimer?.Dispose();
            _heartbeatTimer = null;
        }

        /// <summary>
        /// 获取当前令牌
        /// </summary>
        public string GetToken() => _token;

        /// <summary>
        /// 获取到期时间
        /// </summary>
        public DateTime GetExpireTime() => _expireTime;

        #endregion

        #region 私有方法

        private void StartHeartbeat()
        {
            StopHeartbeat();
            _isRunning = true;
            _heartbeatTimer = new Timer(async _ =>
            {
                if (!_isRunning) return;
                try
                {
                    var timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();
                    var nonce = GenerateNonce();
                    var sign = CalcSign(new SortedDictionary<string, string> { ["token"] = _token }, timestamp, nonce);

                    var response = await PostAsync("heartbeat.php", new
                    {
                        timestamp = timestamp,
                        nonce = nonce,
                        sign = sign,
                        token = _token
                    });

                    var code = response["code"].Value<int>();
                    if (code == 200)
                    {
                        OnHeartbeat?.Invoke("在线");
                        
                        // 处理云控制数据
                        if (response["data"]?["cloud"] != null)
                        {
                            HandleCloudData(response["data"]["cloud"]);
                        }
                    }
                    else if (code == 410)
                    {
                        StopHeartbeat();
                        OnExpired?.Invoke();
                    }
                    else if (code == 403)
                    {
                        StopHeartbeat();
                        OnOffline?.Invoke();
                    }
                }
                catch { }
            }, null, 0, 5000); // 固定5秒心跳
        }
        
        /// <summary>
        /// 处理云控制数据
        /// </summary>
        private void HandleCloudData(JToken cloud)
        {
            // 处理公告
            if (cloud["announcements"] != null)
            {
                foreach (var announcement in cloud["announcements"])
                {
                    int id = announcement["id"].Value<int>();
                    string title = announcement["title"].Value<string>();
                    string content = announcement["content"].Value<string>();
                    string type = announcement["type"].Value<string>();
                    int isPopup = announcement["is_popup"].Value<int>();
                    
                    string typeText = type switch
                    {
                        "notice" => "通知",
                        "warning" => "警告",
                        "update" => "更新",
                        "ad" => "广告",
                        _ => "公告"
                    };
                    
                    // 触发公告事件（需要在类中定义）
                    OnAnnouncement?.Invoke(id, title, content, type, isPopup == 1);
                }
            }
            
            // 处理远程变量
            if (cloud["vars"] != null)
            {
                foreach (var prop in ((JObject)cloud["vars"]).Properties())
                {
                    OnRemoteVar?.Invoke(prop.Name, prop.Value.ToString());
                }
            }
            
            // 处理版本更新
            if (cloud["latest_version"] != null)
            {
                var version = cloud["latest_version"];
                string versionName = version["version"].Value<string>();
                int versionCode = version["version_code"].Value<int>();
                bool forceUpdate = version["force_update"].Value<int>() == 1;
                
                OnVersionUpdate?.Invoke(versionName, versionCode, forceUpdate);
            }
        }

        private async Task<JObject> PostAsync(string api, object data)
        {
            var json = JsonConvert.SerializeObject(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync(API_URL + api, content);
            var responseText = await response.Content.ReadAsStringAsync();
            return JObject.Parse(responseText);
        }

        private string GenerateNonce()
        {
            return Guid.NewGuid().ToString("N").Substring(0, 16);
        }

        private string CalcSign(SortedDictionary<string, string> bizParams, string timestamp, string nonce)
        {
            var sb = new StringBuilder();
            sb.Append(timestamp);
            sb.Append(nonce);
            foreach (var kv in bizParams)
            {
                sb.Append(kv.Value);
            }
            sb.Append(CLIENT_SECRET);

            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString()));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        private string RsaEncrypt(string data)
        {
            var publicKeyPem = _publicKey
                .Replace("-----BEGIN PUBLIC KEY-----", "")
                .Replace("-----END PUBLIC KEY-----", "")
                .Replace("\\n", "")
                .Replace("\n", "")
                .Trim();

            var keyBytes = Convert.FromBase64String(publicKeyPem);
            using (var rsa = RSA.Create())
            {
                rsa.ImportSubjectPublicKeyInfo(keyBytes, out _);
                var dataBytes = Encoding.UTF8.GetBytes(data);
                var maxBlockSize = rsa.KeySize / 8 - 11;

                using (var ms = new MemoryStream())
                {
                    for (int offset = 0; offset < dataBytes.Length; offset += maxBlockSize)
                    {
                        var blockSize = Math.Min(maxBlockSize, dataBytes.Length - offset);
                        var block = new byte[blockSize];
                        Array.Copy(dataBytes, offset, block, 0, blockSize);
                        var encrypted = rsa.Encrypt(block, RSAEncryptionPadding.Pkcs1);
                        ms.Write(encrypted, 0, encrypted.Length);
                    }
                    return Convert.ToBase64String(ms.ToArray());
                }
            }
        }

        private Dictionary<string, object> GetFingerprint()
        {
            // 获取原始硬件信息
            var rawCpu = GetWmiValue("Win32_Processor", "ProcessorId");
            var rawDisk = GetWmiValue("Win32_DiskDrive WHERE Index=0", "SerialNumber");
            var rawMac = GetMacAddress();
            var rawBoard = GetWmiValue("Win32_BaseBoard", "SerialNumber");
            
            // 每个组件单独SHA256哈希（必须是64位十六进制）
            var components = new Dictionary<string, string>
            {
                ["cpu"] = Sha256Hash(rawCpu),
                ["disk"] = Sha256Hash(rawDisk),
                ["mac"] = Sha256Hash(rawMac),
                ["board"] = Sha256Hash(rawBoard)
            };

            // final = SHA256(cpu + disk + mac + board)
            var combined = components["cpu"] + components["disk"] + components["mac"] + components["board"];
            var final = Sha256Hash(combined);
            
            return new Dictionary<string, object>
            {
                ["final"] = final,
                ["components"] = components
            };
        }
        
        private string Sha256Hash(string input)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input ?? ""));
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        private string GetWmiValue(string wmiClass, string property)
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT " + property + " FROM " + wmiClass))
                {
                    foreach (var obj in searcher.Get())
                    {
                        var value = obj[property]?.ToString()?.Trim();
                        if (!string.IsNullOrEmpty(value))
                            return value;
                    }
                }
            }
            catch { }
            return "UNKNOWN";
        }

        private string GetMacAddress()
        {
            try
            {
                var nic = NetworkInterface.GetAllNetworkInterfaces()
                    .FirstOrDefault(n => n.OperationalStatus == OperationalStatus.Up && 
                                        n.NetworkInterfaceType != NetworkInterfaceType.Loopback);
                return nic?.GetPhysicalAddress().ToString() ?? "UNKNOWN";
            }
            catch { return "UNKNOWN"; }
        }

        private Dictionary<string, object> GetDeviceInfo()
        {
            var manufacturer = GetWmiValue("Win32_ComputerSystem", "Manufacturer").ToLower();
            var isVirtual = manufacturer.Contains("vmware") || manufacturer.Contains("virtual") || 
                           manufacturer.Contains("hyper-v") || manufacturer.Contains("xen");
            var virtualType = "";
            if (manufacturer.Contains("vmware")) virtualType = "vmware";
            else if (manufacturer.Contains("virtual")) virtualType = "virtualbox";
            else if (manufacturer.Contains("hyper-v")) virtualType = "hyper-v";

            return new Dictionary<string, object>
            {
                ["platform"] = "windows",
                ["os_version"] = Environment.OSVersion.VersionString,
                ["is_virtual"] = isVirtual,
                ["virtual_type"] = virtualType
            };
        }

        #endregion
    }
}

// ==================== 使用示例 ====================
// 
// public partial class MainForm : Form
// {
//     private async void Form_Load(object sender, EventArgs e)
//     {
//         var auth = AuthVerify.Instance;
//         
//         // 注册事件
//         auth.OnError += (code, msg) => MessageBox.Show($"错误[{code}]: {msg}");
//         auth.OnExpired += () => { MessageBox.Show("授权已过期"); Application.Exit(); };
//         auth.OnOffline += () => { MessageBox.Show("已被强制下线"); Application.Exit(); };
//         
//         // 初始化
//         if (!await auth.InitAsync())
//         {
//             MessageBox.Show("初始化失败");
//             return;
//         }
//         
//         // 激活
//         if (await auth.ActivateAsync("你的授权码"))
//         {
//             MessageBox.Show("激活成功，到期时间: " + auth.GetExpireTime());
//         }
//     }
//     
//     private void Form_Closing(object sender, FormClosingEventArgs e)
//     {
//         AuthVerify.Instance.StopHeartbeat();
//     }
// }`,

sdk_vbnet: `Imports System.Net.Http
Imports System.Security.Cryptography
Imports System.Text
Imports System.Management
Imports System.Net.NetworkInformation
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq

''' <summary>
''' V2 授权验证SDK - VB.NET 完整实现 (Visual Studio 2022)
''' NuGet包: Newtonsoft.Json, System.Management
''' API地址: {API_URL}
''' </summary>
Public Class AuthVerify
    
#Region "配置区 - 请修改为你的配置"
    Private Const API_URL As String = "{API_URL}"
    Private Const APP_KEY As String = "your_app_key"
    Private Const CLIENT_SECRET As String = "{CLIENT_SECRET}"
#End Region

    Private Shared _instance As AuthVerify
    Private Shared ReadOnly _lock As New Object()
    Private _publicKey As String = ""
    Private _token As String = ""
    Private _refreshToken As String = ""
    Private _machineCode As String = ""
    Private _expireTime As DateTime
    Private _heartbeatTimer As Timer
    Private ReadOnly _httpClient As New HttpClient()
    Private _isRunning As Boolean = False

    ' 事件
    Public Event OnError(code As Integer, msg As String)
    Public Event OnExpired()
    Public Event OnOffline()
    Public Event OnHeartbeat(status As String)

    Public Shared ReadOnly Property Instance As AuthVerify
        Get
            If _instance Is Nothing Then
                SyncLock _lock
                    If _instance Is Nothing Then
                        _instance = New AuthVerify()
                    End If
                End SyncLock
            End If
            Return _instance
        End Get
    End Property

    Private Sub New()
        _httpClient.Timeout = TimeSpan.FromSeconds(30)
    End Sub

#Region "公开方法"

    ''' <summary>
    ''' 1. 初始化 - 获取RSA公钥
    ''' </summary>
    Public Async Function InitAsync() As Task(Of Boolean)
        Try
            Dim response = Await PostAsync("init.php", New With {.app_key = APP_KEY})
            If response("code").Value(Of Integer)() = 200 Then
                _publicKey = response("data")("public_key").Value(Of String)()
                Return True
            End If
            RaiseEvent OnError(response("code").Value(Of Integer)(), If(response("message")?.Value(Of String)(), "初始化失败"))
            Return False
        Catch ex As Exception
            RaiseEvent OnError(-1, "初始化异常: " & ex.Message)
            Return False
        End Try
    End Function

    ''' <summary>
    ''' 2. 激活授权
    ''' </summary>
    Public Async Function ActivateAsync(authCode As String) As Task(Of Boolean)
        Try
            If String.IsNullOrEmpty(_publicKey) Then
                RaiseEvent OnError(-1, "请先调用InitAsync初始化")
                Return False
            End If

            Dim fingerprint = GetFingerprint()
            Dim deviceInfo = GetDeviceInfo()
            Dim timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()
            Dim nonce = GenerateNonce()
            Dim bizParams = New SortedDictionary(Of String, String) From {
                {"app_key", APP_KEY},
                {"auth_code", authCode}
            }
            Dim sign = CalcSign(bizParams, timestamp, nonce)

            Dim innerData = New With {
                .timestamp = timestamp,
                .nonce = nonce,
                .sign = sign,
                .auth_code = authCode,
                .fingerprint = fingerprint,
                .device_info = deviceInfo
            }

            Dim encryptedData = RsaEncrypt(JsonConvert.SerializeObject(innerData))
            Dim response = Await PostAsync("activate.php", New With {.app_key = APP_KEY, .data = encryptedData})

            If response("code").Value(Of Integer)() = 200 Then
                _token = response("data")("token").Value(Of String)()
                _refreshToken = response("data")("refresh_token").Value(Of String)()
                _machineCode = fingerprint("final").ToString()
                _expireTime = DateTime.Parse(response("data")("expire_time").Value(Of String)())
                StartHeartbeat()
                Return True
            End If
            RaiseEvent OnError(response("code").Value(Of Integer)(), If(response("message")?.Value(Of String)(), "激活失败"))
            Return False
        Catch ex As Exception
            RaiseEvent OnError(-1, "激活异常: " & ex.Message)
            Return False
        End Try
    End Function

    ''' <summary>
    ''' 3. 试用申请
    ''' </summary>
    Public Async Function TrialAsync() As Task(Of Boolean)
        Try
            If String.IsNullOrEmpty(_publicKey) Then
                RaiseEvent OnError(-1, "请先调用InitAsync初始化")
                Return False
            End If

            Dim fingerprint = GetFingerprint()
            Dim deviceInfo = GetDeviceInfo()
            Dim timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()
            Dim nonce = GenerateNonce()
            Dim sign = CalcSign(New SortedDictionary(Of String, String) From {{"app_key", APP_KEY}}, timestamp, nonce)

            Dim innerData = New With {
                .timestamp = timestamp,
                .nonce = nonce,
                .sign = sign,
                .fingerprint = fingerprint,
                .device_info = deviceInfo
            }

            Dim encryptedData = RsaEncrypt(JsonConvert.SerializeObject(innerData))
            Dim response = Await PostAsync("trial.php", New With {.app_key = APP_KEY, .data = encryptedData})

            If response("code").Value(Of Integer)() = 200 Then
                _token = response("data")("token").Value(Of String)()
                _refreshToken = response("data")("refresh_token").Value(Of String)()
                _machineCode = fingerprint("final").ToString()
                StartHeartbeat()
                Return True
            End If
            Return False
        Catch ex As Exception
            RaiseEvent OnError(-1, "试用申请异常: " & ex.Message)
            Return False
        End Try
    End Function

    ''' <summary>
    ''' 停止心跳
    ''' </summary>
    Public Sub StopHeartbeat()
        _isRunning = False
        _heartbeatTimer?.Dispose()
        _heartbeatTimer = Nothing
    End Sub

    Public Function GetToken() As String
        Return _token
    End Function

    Public Function GetExpireTime() As DateTime
        Return _expireTime
    End Function

#End Region

#Region "私有方法"

    Private Sub StartHeartbeat()
        StopHeartbeat()
        _isRunning = True
        _heartbeatTimer = New Timer(Async Sub(state)
            If Not _isRunning Then Return
            Try
                Dim timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()
                Dim nonce = GenerateNonce()
                Dim sign = CalcSign(New SortedDictionary(Of String, String) From {{"token", _token}}, timestamp, nonce)
                Dim response = Await PostAsync("heartbeat.php", New With {
                    .timestamp = timestamp,
                    .nonce = nonce,
                    .sign = sign,
                    .token = _token
                })
                Dim code = response("code").Value(Of Integer)()
                If code = 200 Then
                    RaiseEvent OnHeartbeat("在线")
                ElseIf code = 410 Then
                    StopHeartbeat()
                    RaiseEvent OnExpired()
                ElseIf code = 403 Then
                    StopHeartbeat()
                    RaiseEvent OnOffline()
                End If
            Catch
            End Try
        End Sub, Nothing, 0, 5000)
    End Sub

    Private Async Function PostAsync(api As String, data As Object) As Task(Of JObject)
        Dim json = JsonConvert.SerializeObject(data)
        Dim content = New StringContent(json, Encoding.UTF8, "application/json")
        Dim response = Await _httpClient.PostAsync(API_URL & api, content)
        Dim responseText = Await response.Content.ReadAsStringAsync()
        Return JObject.Parse(responseText)
    End Function

    Private Function GenerateNonce() As String
        Return Guid.NewGuid().ToString("N").Substring(0, 16)
    End Function

    Private Function CalcSign(bizParams As SortedDictionary(Of String, String), timestamp As String, nonce As String) As String
        Dim sb = New StringBuilder()
        sb.Append(timestamp)
        sb.Append(nonce)
        For Each kv In bizParams
            sb.Append(kv.Value)
        Next
        sb.Append(CLIENT_SECRET)
        Using sha256 = SHA256.Create()
            Dim bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString()))
            Return BitConverter.ToString(bytes).Replace("-", "").ToLower()
        End Using
    End Function

    Private Function RsaEncrypt(data As String) As String
        Dim publicKeyPem = _publicKey.Replace("-----BEGIN PUBLIC KEY-----", "").Replace("-----END PUBLIC KEY-----", "").Replace("\n", "").Trim()
        Dim keyBytes = Convert.FromBase64String(publicKeyPem)
        Using rsa = RSA.Create()
            rsa.ImportSubjectPublicKeyInfo(keyBytes, Nothing)
            Dim dataBytes = Encoding.UTF8.GetBytes(data)
            Dim maxBlockSize = rsa.KeySize \ 8 - 11
            Using ms = New IO.MemoryStream()
                For offset = 0 To dataBytes.Length - 1 Step maxBlockSize
                    Dim blockSize = Math.Min(maxBlockSize, dataBytes.Length - offset)
                    Dim block(blockSize - 1) As Byte
                    Array.Copy(dataBytes, offset, block, 0, blockSize)
                    Dim encrypted = rsa.Encrypt(block, RSAEncryptionPadding.Pkcs1)
                    ms.Write(encrypted, 0, encrypted.Length)
                Next
                Return Convert.ToBase64String(ms.ToArray())
            End Using
        End Using
    End Function

    Private Function GetFingerprint() As Dictionary(Of String, Object)
        ' 获取原始硬件信息
        Dim rawCpu = GetWmiValue("Win32_Processor", "ProcessorId")
        Dim rawDisk = GetWmiValue("Win32_DiskDrive WHERE Index=0", "SerialNumber")
        Dim rawMac = GetMacAddress()
        Dim rawBoard = GetWmiValue("Win32_BaseBoard", "SerialNumber")
        
        ' 每个组件单独SHA256哈希（必须是64位十六进制）
        Dim components = New Dictionary(Of String, String) From {
            {"cpu", Sha256Hash(rawCpu)},
            {"disk", Sha256Hash(rawDisk)},
            {"mac", Sha256Hash(rawMac)},
            {"board", Sha256Hash(rawBoard)}
        }
        
        ' final = SHA256(cpu + disk + mac + board)
        Dim combined = components("cpu") & components("disk") & components("mac") & components("board")
        Return New Dictionary(Of String, Object) From {
            {"final", Sha256Hash(combined)},
            {"components", components}
        }
    End Function
    
    Private Function Sha256Hash(input As String) As String
        Using sha256 = SHA256.Create()
            Dim bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(If(input, "")))
            Return BitConverter.ToString(bytes).Replace("-", "").ToLower()
        End Using
    End Function

    Private Function GetWmiValue(wmiClass As String, prop As String) As String
        Try
            Using searcher = New ManagementObjectSearcher("SELECT " & prop & " FROM " & wmiClass)
                For Each obj In searcher.Get()
                    Dim value = obj(prop)?.ToString()?.Trim()
                    If Not String.IsNullOrEmpty(value) Then Return value
                Next
            End Using
        Catch
        End Try
        Return "UNKNOWN"
    End Function

    Private Function GetMacAddress() As String
        Try
            Dim nic = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(Function(n) n.OperationalStatus = OperationalStatus.Up AndAlso n.NetworkInterfaceType <> NetworkInterfaceType.Loopback)
            Return If(nic?.GetPhysicalAddress().ToString(), "UNKNOWN")
        Catch
            Return "UNKNOWN"
        End Try
    End Function

    Private Function GetDeviceInfo() As Dictionary(Of String, Object)
        Dim manufacturer = GetWmiValue("Win32_ComputerSystem", "Manufacturer").ToLower()
        Dim isVirtual = manufacturer.Contains("vmware") OrElse manufacturer.Contains("virtual")
        Return New Dictionary(Of String, Object) From {
            {"platform", "windows"},
            {"os_version", Environment.OSVersion.VersionString},
            {"is_virtual", isVirtual},
            {"virtual_type", If(isVirtual, "vmware", "")}
        }
    End Function

#End Region

End Class

' ==================== 使用示例 ====================
' 
' Public Class MainForm
'     Private Async Sub Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
'         Dim auth = AuthVerify.Instance
'         AddHandler auth.OnError, Sub(code, msg) MessageBox.Show($"错误[{code}]: {msg}")
'         AddHandler auth.OnExpired, Sub() MessageBox.Show("授权已过期") : Application.Exit()
'         
'         If Not Await auth.InitAsync() Then Return
'         If Await auth.ActivateAsync("你的授权码") Then
'             MessageBox.Show("激活成功")
'         End If
'     End Sub
' End Class`,

sdk_e: `DOWNLOAD_ONLY`,

sdk_python: `"""
V2 授权验证SDK - Python 完整实现
API地址: {API_URL}

安装依赖:
pip install requests pycryptodome

使用方法:
from auth_sdk import AuthVerify
sdk = AuthVerify()
if sdk.init() and sdk.activate("授权码"):
    print("激活成功")
"""

import hashlib
import json
import time
import uuid
import threading
import platform
import base64
import subprocess
import requests
from typing import Dict, Any, Optional, Callable
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5


class AuthVerify:
    """V2 授权验证SDK"""
    
    # ==================== 配置区 ====================
    API_URL = "{API_URL}"
    APP_KEY = "your_app_key"           # 从后台获取
    CLIENT_SECRET = "{CLIENT_SECRET}"  # 从开发文档获取
    # ================================================
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        
        self._public_key: str = ""
        self._token: str = ""
        self._refresh_token: str = ""
        self._machine_code: str = ""
        self._expire_time: str = ""
        self._heartbeat_running: bool = False
        self._heartbeat_thread: Optional[threading.Thread] = None
        
        # 回调函数
        self.on_error: Optional[Callable[[int, str], None]] = None
        self.on_expired: Optional[Callable[[], None]] = None
        self.on_offline: Optional[Callable[[], None]] = None
        self.on_heartbeat: Optional[Callable[[str], None]] = None
    
    def init(self) -> bool:
        """1. 初始化 - 获取RSA公钥"""
        try:
            response = self._post("init.php", {"app_key": self.APP_KEY})
            if response.get("code") == 200:
                self._public_key = response["data"]["public_key"]
                return True
            self._trigger_error(response.get("code", -1), response.get("message", "初始化失败"))
            return False
        except Exception as e:
            self._trigger_error(-1, f"初始化异常: {str(e)}")
            return False
    
    def activate(self, auth_code: str) -> bool:
        """2. 激活授权"""
        try:
            if not self._public_key:
                self._trigger_error(-1, "请先调用init初始化")
                return False
            
            fingerprint = self._get_fingerprint()
            device_info = self._get_device_info()
            timestamp = str(int(time.time()))
            nonce = uuid.uuid4().hex[:16]
            sign = self._calc_sign({"app_key": self.APP_KEY, "auth_code": auth_code}, timestamp, nonce)
            
            inner_data = {
                "timestamp": timestamp,
                "nonce": nonce,
                "sign": sign,
                "auth_code": auth_code,
                "fingerprint": fingerprint,
                "device_info": device_info
            }
            
            encrypted_data = self._rsa_encrypt(json.dumps(inner_data))
            response = self._post("activate.php", {"app_key": self.APP_KEY, "data": encrypted_data})
            
            if response.get("code") == 200:
                self._token = response["data"]["token"]
                self._refresh_token = response["data"]["refresh_token"]
                self._expire_time = response["data"]["expire_time"]
                self._machine_code = fingerprint["final"]
                self._start_heartbeat()
                return True
            
            self._trigger_error(response.get("code", -1), response.get("message", "激活失败"))
            return False
        except Exception as e:
            self._trigger_error(-1, f"激活异常: {str(e)}")
            return False
    
    def trial(self) -> bool:
        """3. 试用申请"""
        try:
            if not self._public_key:
                self._trigger_error(-1, "请先调用init初始化")
                return False
            
            fingerprint = self._get_fingerprint()
            device_info = self._get_device_info()
            timestamp = str(int(time.time()))
            nonce = uuid.uuid4().hex[:16]
            sign = self._calc_sign({"app_key": self.APP_KEY}, timestamp, nonce)
            
            inner_data = {
                "timestamp": timestamp,
                "nonce": nonce,
                "sign": sign,
                "fingerprint": fingerprint,
                "device_info": device_info
            }
            
            encrypted_data = self._rsa_encrypt(json.dumps(inner_data))
            response = self._post("trial.php", {"app_key": self.APP_KEY, "data": encrypted_data})
            
            if response.get("code") == 200:
                self._token = response["data"]["token"]
                self._refresh_token = response["data"]["refresh_token"]
                self._expire_time = response["data"]["expire_time"]
                self._machine_code = fingerprint["final"]
                self._start_heartbeat()
                return True
            return False
        except Exception as e:
            self._trigger_error(-1, f"试用申请异常: {str(e)}")
            return False
    
    def refresh_token(self) -> bool:
        """4. 刷新令牌"""
        try:
            timestamp = str(int(time.time()))
            nonce = uuid.uuid4().hex[:16]
            sign = self._calc_sign({
                "fingerprint": self._machine_code,
                "refresh_token": self._refresh_token,
                "token": self._token
            }, timestamp, nonce)
            
            response = self._post("refresh.php", {
                "timestamp": timestamp,
                "nonce": nonce,
                "sign": sign,
                "token": self._token,
                "refresh_token": self._refresh_token,
                "fingerprint": self._machine_code
            })
            
            if response.get("code") == 200:
                self._token = response["data"]["token"]
                self._refresh_token = response["data"]["refresh_token"]
                return True
            return False
        except:
            return False
    
    def stop_heartbeat(self):
        """停止心跳"""
        self._heartbeat_running = False
    
    def get_token(self) -> str:
        return self._token
    
    def get_expire_time(self) -> str:
        return self._expire_time
    
    # ==================== 私有方法 ====================
    
    def _start_heartbeat(self):
        """启动心跳线程"""
        self.stop_heartbeat()
        self._heartbeat_running = True
        
        def heartbeat_loop():
            while self._heartbeat_running:
                try:
                    timestamp = str(int(time.time()))
                    nonce = uuid.uuid4().hex[:16]
                    sign = self._calc_sign({"token": self._token}, timestamp, nonce)
                    
                    response = self._post("heartbeat.php", {
                        "timestamp": timestamp,
                        "nonce": nonce,
                        "sign": sign,
                        "token": self._token
                    })
                    
                    code = response.get("code")
                    if code == 200:
                        if self.on_heartbeat:
                            self.on_heartbeat("在线")
                    elif code == 410:
                        self.stop_heartbeat()
                        if self.on_expired:
                            self.on_expired()
                    elif code == 403:
                        self.stop_heartbeat()
                        if self.on_offline:
                            self.on_offline()
                except:
                    pass
                time.sleep(5)  # 固定5秒心跳
        
        self._heartbeat_thread = threading.Thread(target=heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()
    
    def _post(self, api: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """发送POST请求"""
        response = requests.post(
            self.API_URL + api,
            json=data,
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        return response.json()
    
    def _calc_sign(self, biz_params: Dict[str, str], timestamp: str, nonce: str) -> str:
        """计算签名"""
        sorted_params = sorted(biz_params.items())
        param_str = "&".join(f"{k}={v}" for k, v in sorted_params)
        sign_str = f"{param_str}&timestamp={timestamp}&nonce={nonce}&client_secret={self.CLIENT_SECRET}"
        return hashlib.sha256(sign_str.encode()).hexdigest()
    
    def _rsa_encrypt(self, data: str) -> str:
        """RSA加密"""
        key = RSA.import_key(self._public_key)
        cipher = PKCS1_v1_5.new(key)
        data_bytes = data.encode()
        max_len = key.size_in_bytes() - 11
        result = b""
        for i in range(0, len(data_bytes), max_len):
            chunk = data_bytes[i:i + max_len]
            result += cipher.encrypt(chunk)
        return base64.b64encode(result).decode()
    
    def _get_fingerprint(self) -> Dict[str, Any]:
        """获取机器指纹（每个组件必须是64位SHA256哈希）"""
        # 获取原始硬件信息
        raw_cpu = self._run_cmd("wmic cpu get processorid")
        raw_disk = self._run_cmd("wmic diskdrive get serialnumber")
        raw_mac = self._run_cmd("getmac /fo csv /nh")
        raw_board = self._run_cmd("wmic baseboard get serialnumber")
        
        # 每个组件单独SHA256哈希
        components = {
            "cpu": hashlib.sha256(raw_cpu.encode()).hexdigest(),
            "disk": hashlib.sha256(raw_disk.encode()).hexdigest(),
            "mac": hashlib.sha256(raw_mac.encode()).hexdigest(),
            "board": hashlib.sha256(raw_board.encode()).hexdigest()
        }
        
        # final = SHA256(cpu + disk + mac + board)
        combined = components["cpu"] + components["disk"] + components["mac"] + components["board"]
        final = hashlib.sha256(combined.encode()).hexdigest()
        return {"final": final, "components": components}
    
    def _run_cmd(self, cmd: str) -> str:
        """执行命令"""
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            lines = [l.strip() for l in result.stdout.strip().split("\\n") if l.strip()]
            return lines[1] if len(lines) > 1 else (lines[0] if lines else "UNKNOWN")
        except:
            return "UNKNOWN"
    
    def _get_device_info(self) -> Dict[str, Any]:
        """获取设备信息"""
        return {
            "platform": "windows",
            "os_version": platform.platform(),
            "is_virtual": False,
            "virtual_type": ""
        }
    
    def _trigger_error(self, code: int, message: str):
        """触发错误回调"""
        if self.on_error:
            self.on_error(code, message)


# ==================== 使用示例 ====================
if __name__ == "__main__":
    sdk = AuthVerify()
    
    # 设置回调
    sdk.on_error = lambda code, msg: print(f"错误[{code}]: {msg}")
    sdk.on_expired = lambda: print("授权已过期")
    sdk.on_offline = lambda: print("已被强制下线")
    
    # 初始化
    if not sdk.init():
        print("初始化失败")
        exit(1)
    
    # 激活
    auth_code = input("请输入授权码: ")
    if sdk.activate(auth_code):
        print(f"激活成功，到期时间: {sdk.get_expire_time()}")
        # 保持程序运行
        input("按回车键退出...")
        sdk.stop_heartbeat()
    else:
        print("激活失败")`,

sdk_android_java: `/**
 * V2 授权验证SDK - Android Java 完整实现 (Android Studio)
 * API地址: {API_URL}
 * 
 * 依赖配置 (build.gradle):
 * implementation 'com.squareup.okhttp3:okhttp:4.12.0'
 * implementation 'com.google.code.gson:gson:2.10.1'
 */
package com.auth.sdk;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.crypto.Cipher;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AuthVerify {
    private static final String TAG = "AuthVerify";
    
    // ==================== 配置区 ====================
    private static final String API_URL = "{API_URL}";
    private static final String APP_KEY = "your_app_key";
    private static final String CLIENT_SECRET = "{CLIENT_SECRET}";
    // ================================================
    
    private static volatile AuthVerify instance;
    private Context context;
    private OkHttpClient httpClient;
    private Gson gson;
    private Handler mainHandler;
    
    private String publicKey = "";
    private String token = "";
    private String refreshToken = "";
    private String machineCode = "";
    private String expireTime = "";
    private Timer heartbeatTimer;
    private boolean isRunning = false;
    
    // 回调接口
    public interface AuthCallback {
        void onSuccess();
        void onError(int code, String message);
    }
    
    public interface AuthListener {
        void onExpired();
        void onOffline();
        void onHeartbeat(String status);
    }
    
    private AuthListener listener;
    
    private AuthVerify(Context context) {
        this.context = context.getApplicationContext();
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
        this.gson = new Gson();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }
    
    public static AuthVerify getInstance(Context context) {
        if (instance == null) {
            synchronized (AuthVerify.class) {
                if (instance == null) {
                    instance = new AuthVerify(context);
                }
            }
        }
        return instance;
    }
    
    public void setListener(AuthListener listener) {
        this.listener = listener;
    }
    
    /**
     * 1. 初始化 - 获取RSA公钥
     */
    public void init(AuthCallback callback) {
        TreeMap<String, Object> params = new TreeMap<>();
        params.put("app_key", APP_KEY);
        
        post("init.php", params, new HttpCallback() {
            @Override
            public void onResponse(JsonObject response) {
                if (response.get("code").getAsInt() == 200) {
                    publicKey = response.getAsJsonObject("data").get("public_key").getAsString();
                    runOnMain(() -> callback.onSuccess());
                } else {
                    String msg = response.has("message") ? response.get("message").getAsString() : "初始化失败";
                    runOnMain(() -> callback.onError(response.get("code").getAsInt(), msg));
                }
            }
            
            @Override
            public void onError(String error) {
                runOnMain(() -> callback.onError(-1, "初始化异常: " + error));
            }
        });
    }
    
    /**
     * 2. 激活授权
     */
    public void activate(String authCode, AuthCallback callback) {
        if (publicKey.isEmpty()) {
            callback.onError(-1, "请先调用init初始化");
            return;
        }
        
        try {
            Map<String, Object> fingerprint = getFingerprint();
            Map<String, Object> deviceInfo = getDeviceInfo();
            String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
            String nonce = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
            
            TreeMap<String, String> bizParams = new TreeMap<>();
            bizParams.put("app_key", APP_KEY);
            bizParams.put("auth_code", authCode);
            String sign = calcSign(bizParams, timestamp, nonce);
            
            TreeMap<String, Object> innerData = new TreeMap<>();
            innerData.put("timestamp", timestamp);
            innerData.put("nonce", nonce);
            innerData.put("sign", sign);
            innerData.put("auth_code", authCode);
            innerData.put("fingerprint", fingerprint);
            innerData.put("device_info", deviceInfo);
            
            String encryptedData = rsaEncrypt(gson.toJson(innerData));
            
            TreeMap<String, Object> params = new TreeMap<>();
            params.put("app_key", APP_KEY);
            params.put("data", encryptedData);
            
            post("activate.php", params, new HttpCallback() {
                @Override
                public void onResponse(JsonObject response) {
                    if (response.get("code").getAsInt() == 200) {
                        JsonObject data = response.getAsJsonObject("data");
                        token = data.get("token").getAsString();
                        refreshToken = data.get("refresh_token").getAsString();
                        expireTime = data.get("expire_time").getAsString();
                        machineCode = (String) fingerprint.get("final");
                        startHeartbeat();
                        runOnMain(() -> callback.onSuccess());
                    } else {
                        String msg = response.has("message") ? response.get("message").getAsString() : "激活失败";
                        runOnMain(() -> callback.onError(response.get("code").getAsInt(), msg));
                    }
                }
                
                @Override
                public void onError(String error) {
                    runOnMain(() -> callback.onError(-1, "激活异常: " + error));
                }
            });
        } catch (Exception e) {
            callback.onError(-1, "激活异常: " + e.getMessage());
        }
    }
    
    /**
     * 3. 试用申请
     */
    public void trial(AuthCallback callback) {
        if (publicKey.isEmpty()) {
            callback.onError(-1, "请先调用init初始化");
            return;
        }
        
        try {
            Map<String, Object> fingerprint = getFingerprint();
            Map<String, Object> deviceInfo = getDeviceInfo();
            String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
            String nonce = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
            
            TreeMap<String, String> bizParams = new TreeMap<>();
            bizParams.put("app_key", APP_KEY);
            String sign = calcSign(bizParams, timestamp, nonce);
            
            TreeMap<String, Object> innerData = new TreeMap<>();
            innerData.put("timestamp", timestamp);
            innerData.put("nonce", nonce);
            innerData.put("sign", sign);
            innerData.put("fingerprint", fingerprint);
            innerData.put("device_info", deviceInfo);
            
            String encryptedData = rsaEncrypt(gson.toJson(innerData));
            
            TreeMap<String, Object> params = new TreeMap<>();
            params.put("app_key", APP_KEY);
            params.put("data", encryptedData);
            
            post("trial.php", params, new HttpCallback() {
                @Override
                public void onResponse(JsonObject response) {
                    if (response.get("code").getAsInt() == 200) {
                        JsonObject data = response.getAsJsonObject("data");
                        token = data.get("token").getAsString();
                        refreshToken = data.get("refresh_token").getAsString();
                        expireTime = data.get("expire_time").getAsString();
                        machineCode = (String) fingerprint.get("final");
                        startHeartbeat();
                        runOnMain(() -> callback.onSuccess());
                    } else {
                        runOnMain(() -> callback.onError(response.get("code").getAsInt(), "试用申请失败"));
                    }
                }
                
                @Override
                public void onError(String error) {
                    runOnMain(() -> callback.onError(-1, "试用申请异常: " + error));
                }
            });
        } catch (Exception e) {
            callback.onError(-1, "试用申请异常: " + e.getMessage());
        }
    }
    
    /**
     * 停止心跳
     */
    public void stopHeartbeat() {
        isRunning = false;
        if (heartbeatTimer != null) {
            heartbeatTimer.cancel();
            heartbeatTimer = null;
        }
    }
    
    public String getToken() { return token; }
    public String getExpireTime() { return expireTime; }

    // ==================== 私有方法 ====================
    
    private void startHeartbeat() {
        stopHeartbeat();
        isRunning = true;
        heartbeatTimer = new Timer();
        heartbeatTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (!isRunning) return;
                
                try {
                    String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
                    String nonce = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
                    
                    TreeMap<String, String> bizParams = new TreeMap<>();
                    bizParams.put("token", token);
                    String sign = calcSign(bizParams, timestamp, nonce);
                    
                    TreeMap<String, Object> params = new TreeMap<>();
                    params.put("timestamp", timestamp);
                    params.put("nonce", nonce);
                    params.put("sign", sign);
                    params.put("token", token);
                    
                    post("heartbeat.php", params, new HttpCallback() {
                        @Override
                        public void onResponse(JsonObject response) {
                            int code = response.get("code").getAsInt();
                            if (code == 200) {
                                if (listener != null) {
                                    runOnMain(() -> listener.onHeartbeat("在线"));
                                }
                            } else if (code == 410) {
                                stopHeartbeat();
                                if (listener != null) {
                                    runOnMain(() -> listener.onExpired());
                                }
                            } else if (code == 403) {
                                stopHeartbeat();
                                if (listener != null) {
                                    runOnMain(() -> listener.onOffline());
                                }
                            }
                        }
                        
                        @Override
                        public void onError(String error) {
                            Log.e(TAG, "心跳异常: " + error);
                        }
                    });
                } catch (Exception e) {
                    Log.e(TAG, "心跳异常", e);
                }
            }
        }, 0, 5000); // 固定5秒心跳
    }
    
    private interface HttpCallback {
        void onResponse(JsonObject response);
        void onError(String error);
    }
    
    private void post(String api, Map<String, Object> params, HttpCallback callback) {
        String json = gson.toJson(params);
        RequestBody body = RequestBody.create(json, MediaType.parse("application/json"));
        Request request = new Request.Builder()
                .url(API_URL + api)
                .post(body)
                .build();
        
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onError(e.getMessage());
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseBody = response.body().string();
                JsonObject jsonResponse = JsonParser.parseString(responseBody).getAsJsonObject();
                callback.onResponse(jsonResponse);
            }
        });
    }
    
    private String calcSign(TreeMap<String, String> bizParams, String timestamp, String nonce) {
        try {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, String> entry : bizParams.entrySet()) {
                if (sb.length() > 0) sb.append("&");
                sb.append(entry.getKey()).append("=").append(entry.getValue());
            }
            sb.append("&timestamp=").append(timestamp);
            sb.append("&nonce=").append(nonce);
            sb.append("&client_secret=").append(CLIENT_SECRET);
            
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(sb.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            return "";
        }
    }
    
    private String rsaEncrypt(String data) throws Exception {
        String publicKeyPem = publicKey
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "")
                .replace("\\n", "")
                .replace("\n", "")
                .trim();
        
        byte[] keyBytes = Base64.decode(publicKeyPem, Base64.DEFAULT);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey pubKey = keyFactory.generatePublic(keySpec);
        
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, pubKey);
        
        byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
        int maxBlockSize = 245; // RSA 2048 - 11
        
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        for (int i = 0; i < dataBytes.length; i += maxBlockSize) {
            int blockSize = Math.min(maxBlockSize, dataBytes.length - i);
            byte[] block = new byte[blockSize];
            System.arraycopy(dataBytes, i, block, 0, blockSize);
            out.write(cipher.doFinal(block));
        }
        
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }
    
    private Map<String, Object> getFingerprint() {
        // 获取原始硬件信息
        String rawAndroidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        String rawBrand = Build.BRAND;
        String rawModel = Build.MODEL;
        String rawMac = getMacAddress();
        
        // 每个组件单独SHA256哈希（必须是64位十六进制）
        TreeMap<String, String> components = new TreeMap<>();
        components.put("android_id", sha256(rawAndroidId != null ? rawAndroidId : ""));
        components.put("brand", sha256(rawBrand != null ? rawBrand : ""));
        components.put("model", sha256(rawModel != null ? rawModel : ""));
        components.put("mac", sha256(rawMac != null ? rawMac : ""));
        
        // final = SHA256(android_id + brand + mac + model) 按key字母排序
        String combined = components.get("android_id") + components.get("brand") + components.get("mac") + components.get("model");
        String finalHash = sha256(combined);
        
        TreeMap<String, Object> result = new TreeMap<>();
        result.put("final", finalHash);
        result.put("components", components);
        return result;
    }
    
    private String getMacAddress() {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : interfaces) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;
                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) return "UNKNOWN";
                StringBuilder sb = new StringBuilder();
                for (byte b : macBytes) {
                    sb.append(String.format("%02X", b));
                }
                return sb.toString();
            }
        } catch (Exception e) {
            Log.e(TAG, "获取MAC地址失败", e);
        }
        return "UNKNOWN";
    }
    
    private Map<String, Object> getDeviceInfo() {
        TreeMap<String, Object> info = new TreeMap<>();
        info.put("platform", "android");
        info.put("os_version", "Android " + Build.VERSION.RELEASE);
        info.put("is_virtual", isEmulator());
        info.put("virtual_type", isEmulator() ? "emulator" : "");
        return info;
    }
    
    private boolean isEmulator() {
        return Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || Build.BRAND.startsWith("generic")
                || Build.DEVICE.startsWith("generic");
    }
    
    private String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            return "";
        }
    }
    
    private void runOnMain(Runnable runnable) {
        mainHandler.post(runnable);
    }
}

// ==================== 使用示例 (MainActivity.java) ====================
// 
// public class MainActivity extends AppCompatActivity {
//     private AuthVerify auth;
//     
//     @Override
//     protected void onCreate(Bundle savedInstanceState) {
//         super.onCreate(savedInstanceState);
//         setContentView(R.layout.activity_main);
//         
//         auth = AuthVerify.getInstance(this);
//         
//         // 设置监听
//         auth.setListener(new AuthVerify.AuthListener() {
//             @Override
//             public void onExpired() {
//                 Toast.makeText(MainActivity.this, "授权已过期", Toast.LENGTH_LONG).show();
//                 finish();
//             }
//             
//             @Override
//             public void onOffline() {
//                 Toast.makeText(MainActivity.this, "已被强制下线", Toast.LENGTH_LONG).show();
//                 finish();
//             }
//             
//             @Override
//             public void onHeartbeat(String status) {
//                 Log.d("Auth", "心跳状态: " + status);
//             }
//         });
//         
//         // 初始化
//         auth.init(new AuthVerify.AuthCallback() {
//             @Override
//             public void onSuccess() {
//                 // 激活
//                 auth.activate("你的授权码", new AuthVerify.AuthCallback() {
//                     @Override
//                     public void onSuccess() {
//                         Toast.makeText(MainActivity.this, "激活成功", Toast.LENGTH_SHORT).show();
//                     }
//                     
//                     @Override
//                     public void onError(int code, String message) {
//                         Toast.makeText(MainActivity.this, "激活失败: " + message, Toast.LENGTH_LONG).show();
//                     }
//                 });
//             }
//             
//             @Override
//             public void onError(int code, String message) {
//                 Toast.makeText(MainActivity.this, "初始化失败: " + message, Toast.LENGTH_LONG).show();
//             }
//         });
//     }
//     
//     @Override
//     protected void onDestroy() {
//         super.onDestroy();
//         if (auth != null) {
//             auth.stopHeartbeat();
//         }
//     }
// }`,

sdk_go: `/*
V2 授权验证SDK - Go 完整实现
API地址: {API_URL}

使用方法:
go mod init your_project
go get github.com/your_project
*/
package main

import (
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"io"
	"net/http"
	"os/exec"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

// ==================== 配置区 ====================
const (
	APIURL       = "{API_URL}"
	AppKey       = "your_app_key"
	ClientSecret = "{CLIENT_SECRET}"
)
// ================================================

type AuthVerify struct {
	publicKey    string
	token        string
	refreshToken string
	machineCode  string
	expireTime   string
	stopChan     chan struct{}
	isRunning    bool
	mutex        sync.Mutex
	
	OnError   func(int, string)
	OnExpired func()
	OnOffline func()
}

var instance *AuthVerify
var once sync.Once

func GetInstance() *AuthVerify {
	once.Do(func() {
		instance = &AuthVerify{
			stopChan: make(chan struct{}),
		}
	})
	return instance
}

// 1. 初始化 - 获取RSA公钥
func (a *AuthVerify) Init() bool {
	response, err := a.post("init.php", map[string]interface{}{
		"app_key": AppKey,
	})
	if err != nil {
		if a.OnError != nil {
			a.OnError(-1, "初始化异常: "+err.Error())
		}
		return false
	}
	
	code := int(response["code"].(float64))
	if code == 200 {
		data := response["data"].(map[string]interface{})
		a.publicKey = data["public_key"].(string)
		return true
	}
	
	if a.OnError != nil {
		msg := "初始化失败"
		if m, ok := response["message"].(string); ok {
			msg = m
		}
		a.OnError(code, msg)
	}
	return false
}

// 2. 激活授权
func (a *AuthVerify) Activate(authCode string) bool {
	if a.publicKey == "" {
		if a.OnError != nil {
			a.OnError(-1, "请先调用Init初始化")
		}
		return false
	}
	
	fingerprint := a.getFingerprint()
	deviceInfo := a.getDeviceInfo()
	timestamp := fmt.Sprintf("%d", time.Now().Unix())
	nonce := a.randomString(16)
	sign := a.calcSign(map[string]string{
		"app_key":   AppKey,
		"auth_code": authCode,
	}, timestamp, nonce)
	
	innerData := map[string]interface{}{
		"timestamp":   timestamp,
		"nonce":       nonce,
		"sign":        sign,
		"auth_code":   authCode,
		"fingerprint": fingerprint,
		"device_info": deviceInfo,
	}
	
	innerJson, _ := json.Marshal(innerData)
	encrypted, err := a.rsaEncrypt(string(innerJson))
	if err != nil {
		if a.OnError != nil {
			a.OnError(-1, "加密失败: "+err.Error())
		}
		return false
	}
	
	response, err := a.post("activate.php", map[string]interface{}{
		"app_key": AppKey,
		"data":    encrypted,
	})
	if err != nil {
		if a.OnError != nil {
			a.OnError(-1, "激活异常: "+err.Error())
		}
		return false
	}
	
	code := int(response["code"].(float64))
	if code == 200 {
		data := response["data"].(map[string]interface{})
		a.token = data["token"].(string)
		a.refreshToken = data["refresh_token"].(string)
		a.expireTime = data["expire_time"].(string)
		a.machineCode = fingerprint["final"].(string)
		a.startHeartbeat()
		return true
	}
	
	if a.OnError != nil {
		msg := "激活失败"
		if m, ok := response["message"].(string); ok {
			msg = m
		}
		a.OnError(code, msg)
	}
	return false
}

// 3. 试用申请
func (a *AuthVerify) Trial() bool {
	if a.publicKey == "" {
		if a.OnError != nil {
			a.OnError(-1, "请先调用Init初始化")
		}
		return false
	}
	
	fingerprint := a.getFingerprint()
	deviceInfo := a.getDeviceInfo()
	timestamp := fmt.Sprintf("%d", time.Now().Unix())
	nonce := a.randomString(16)
	sign := a.calcSign(map[string]string{"app_key": AppKey}, timestamp, nonce)
	
	innerData := map[string]interface{}{
		"timestamp":   timestamp,
		"nonce":       nonce,
		"sign":        sign,
		"fingerprint": fingerprint,
		"device_info": deviceInfo,
	}
	
	innerJson, _ := json.Marshal(innerData)
	encrypted, _ := a.rsaEncrypt(string(innerJson))
	
	response, err := a.post("trial.php", map[string]interface{}{
		"app_key": AppKey,
		"data":    encrypted,
	})
	if err != nil {
		return false
	}
	
	code := int(response["code"].(float64))
	if code == 200 {
		data := response["data"].(map[string]interface{})
		a.token = data["token"].(string)
		a.refreshToken = data["refresh_token"].(string)
		a.expireTime = data["expire_time"].(string)
		a.machineCode = fingerprint["final"].(string)
		a.startHeartbeat()
		return true
	}
	return false
}

// 停止心跳
func (a *AuthVerify) StopHeartbeat() {
	a.mutex.Lock()
	defer a.mutex.Unlock()
	
	if a.isRunning {
		a.isRunning = false
		close(a.stopChan)
		a.stopChan = make(chan struct{})
	}
}

func (a *AuthVerify) GetToken() string     { return a.token }
func (a *AuthVerify) GetExpireTime() string { return a.expireTime }

// ==================== 私有方法 ====================

func (a *AuthVerify) startHeartbeat() {
	a.StopHeartbeat()
	a.mutex.Lock()
	a.isRunning = true
	a.mutex.Unlock()
	
	go func() {
		ticker := time.NewTicker(5 * time.Second) // 固定5秒心跳
		defer ticker.Stop()
		
		for {
			select {
			case <-a.stopChan:
				return
			case <-ticker.C:
				a.doHeartbeat()
			}
		}
	}()
}

func (a *AuthVerify) doHeartbeat() {
	timestamp := fmt.Sprintf("%d", time.Now().Unix())
	nonce := a.randomString(16)
	sign := a.calcSign(map[string]string{"token": a.token}, timestamp, nonce)
	
	response, err := a.post("heartbeat.php", map[string]interface{}{
		"timestamp": timestamp,
		"nonce":     nonce,
		"sign":      sign,
		"token":     a.token,
	})
	if err != nil {
		return
	}
	
	code := int(response["code"].(float64))
	switch code {
	case 410:
		a.StopHeartbeat()
		if a.OnExpired != nil {
			a.OnExpired()
		}
	case 403:
		a.StopHeartbeat()
		if a.OnOffline != nil {
			a.OnOffline()
		}
	}
}

func (a *AuthVerify) post(api string, data map[string]interface{}) (map[string]interface{}, error) {
	body, _ := json.Marshal(data)
	resp, err := http.Post(APIURL+api, "application/json", bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	
	respBody, _ := io.ReadAll(resp.Body)
	var result map[string]interface{}
	json.Unmarshal(respBody, &result)
	return result, nil
}

func (a *AuthVerify) calcSign(bizParams map[string]string, timestamp, nonce string) string {
	keys := make([]string, 0, len(bizParams))
	for k := range bizParams {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	
	var sb strings.Builder
	for i, k := range keys {
		if i > 0 {
			sb.WriteString("&")
		}
		sb.WriteString(k + "=" + bizParams[k])
	}
	sb.WriteString("&timestamp=" + timestamp)
	sb.WriteString("&nonce=" + nonce)
	sb.WriteString("&client_secret=" + ClientSecret)
	
	hash := sha256.Sum256([]byte(sb.String()))
	return hex.EncodeToString(hash[:])
}

func (a *AuthVerify) rsaEncrypt(data string) (string, error) {
	publicKeyPem := strings.ReplaceAll(a.publicKey, "\\n", "\n")
	block, _ := pem.Decode([]byte(publicKeyPem))
	if block == nil {
		return "", fmt.Errorf("failed to parse PEM block")
	}
	
	pub, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return "", err
	}
	
	rsaPub := pub.(*rsa.PublicKey)
	dataBytes := []byte(data)
	maxBlockSize := rsaPub.Size() - 11
	
	var result []byte
	for i := 0; i < len(dataBytes); i += maxBlockSize {
		end := i + maxBlockSize
		if end > len(dataBytes) {
			end = len(dataBytes)
		}
		encrypted, err := rsa.EncryptPKCS1v15(rand.Reader, rsaPub, dataBytes[i:end])
		if err != nil {
			return "", err
		}
		result = append(result, encrypted...)
	}
	
	return base64.StdEncoding.EncodeToString(result), nil
}

func (a *AuthVerify) randomString(n int) string {
	const letters = "abcdefghijklmnopqrstuvwxyz0123456789"
	b := make([]byte, n)
	rand.Read(b)
	for i := range b {
		b[i] = letters[int(b[i])%len(letters)]
	}
	return string(b)
}

func (a *AuthVerify) getFingerprint() map[string]interface{} {
	// 获取原始硬件信息
	rawCpu := a.runCmd("wmic cpu get processorid")
	rawDisk := a.runCmd("wmic diskdrive get serialnumber")
	rawMac := a.runCmd("getmac /fo csv /nh")
	rawBoard := a.runCmd("wmic baseboard get serialnumber")
	
	// 每个组件单独SHA256哈希（必须是64位十六进制）
	components := map[string]string{
		"cpu":   a.sha256Hash(rawCpu),
		"disk":  a.sha256Hash(rawDisk),
		"mac":   a.sha256Hash(rawMac),
		"board": a.sha256Hash(rawBoard),
	}
	
	// final = SHA256(cpu + disk + mac + board)
	combined := components["cpu"] + components["disk"] + components["mac"] + components["board"]
	
	return map[string]interface{}{
		"final":      a.sha256Hash(combined),
		"components": components,
	}
}

func (a *AuthVerify) sha256Hash(input string) string {
	hash := sha256.Sum256([]byte(input))
	return hex.EncodeToString(hash[:])
}

func (a *AuthVerify) runCmd(cmd string) string {
	if runtime.GOOS != "windows" {
		return "UNKNOWN"
	}
	out, err := exec.Command("cmd", "/C", cmd).Output()
	if err != nil {
		return "UNKNOWN"
	}
	lines := strings.Split(strings.TrimSpace(string(out)), "\n")
	if len(lines) > 1 {
		return strings.TrimSpace(lines[1])
	}
	return "UNKNOWN"
}

func (a *AuthVerify) getDeviceInfo() map[string]interface{} {
	return map[string]interface{}{
		"platform":     "windows",
		"os_version":   runtime.GOOS + " " + runtime.GOARCH,
		"is_virtual":   false,
		"virtual_type": "",
	}
}

// ==================== 使用示例 ====================
func main() {
	sdk := GetInstance()
	
	// 设置回调
	sdk.OnError = func(code int, msg string) {
		fmt.Printf("错误[%d]: %s\n", code, msg)
	}
	sdk.OnExpired = func() {
		fmt.Println("授权已过期")
	}
	sdk.OnOffline = func() {
		fmt.Println("已被强制下线")
	}
	
	// 初始化
	if !sdk.Init() {
		fmt.Println("初始化失败")
		return
	}
	
	// 激活
	if sdk.Activate("你的授权码") {
		fmt.Printf("激活成功，到期时间: %s\n", sdk.GetExpireTime())
		
		// 保持程序运行
		fmt.Println("按Ctrl+C退出...")
		select {}
	} else {
		fmt.Println("激活失败")
	}
}`,

sdk_php: <?php echo json_encode($phpSdkCode); ?>

};


const { createApp, ref } = Vue;
const app = createApp({
    setup() {
        const tab = ref('quickstart');
        const isDark = ref(false);
        
        const tabNames = {
            quickstart: '快速开始', init: '初始化', activate: '激活授权',
            heartbeat: '心跳保活', refresh: '刷新令牌', trial: '试用申请', 
            deduct_points: '扣除点数', query_points: '查询点数', recharge_points: '充值点数',
            errors: '错误码',
            security: '安全机制', sdk_csharp: 'C# SDK', sdk_vbnet: 'VB.NET SDK', sdk_e: '易语言 SDK',
            sdk_python: 'Python SDK', sdk_android_java: 'Android SDK',
            sdk_go: 'Go SDK', sdk_php: 'PHP SDK'
        };
        
        const sdkNames = {
            sdk_csharp: 'C# (Visual Studio 2022)', sdk_vbnet: 'VB.NET (Visual Studio 2022)', sdk_e: '易语言',
            sdk_python: 'Python', sdk_android_java: 'Android Studio',
            sdk_go: 'Go', sdk_php: 'PHP'
        };
        
        const sdkLangs = {
            sdk_csharp: 'C#', sdk_vbnet: 'VB.NET', sdk_e: '易语言', sdk_python: 'Python',
            sdk_android_java: 'Java', sdk_go: 'Go', sdk_php: 'PHP'
        };
        
        const codes = ref({});
        for (const [lang, code] of Object.entries(SDK_CODES)) {
            codes.value[lang] = code.replace(/\{API_URL\}/g, API_URL).replace(/\{CLIENT_SECRET\}/g, CLIENT_SECRET);
        }
        
        const configTable = ref([
            { name: 'API基础地址', value: API_URL, desc: '所有接口的基础URL' },
            { name: '客户端密钥', value: CLIENT_SECRET, desc: '用于签名计算，必须与服务端一致' },
            { name: '请求方式', value: 'POST', desc: '所有接口均使用POST' },
            { name: '数据格式', value: 'application/json', desc: '请求和响应均为JSON' },
            { name: '心跳间隔', value: '5秒', desc: '固定值，不可配置' },
            { name: '令牌有效期', value: '24小时', desc: '过期后可刷新' }
        ]);
        
        const initParams = ref([{ name: 'app_key', type: 'string', required: true, desc: '软件AppKey，从后台获取' }]);
        const activateOuterParams = ref([{ name: 'app_key', type: 'string', desc: '软件AppKey（明文）' }, { name: 'data', type: 'string', desc: 'RSA加密后的Base64字符串' }]);
        const activateInnerParams = ref([
            { name: 'timestamp', type: 'number', desc: '当前时间戳（秒）' }, { name: 'nonce', type: 'string', desc: '16位随机字符串' },
            { name: 'sign', type: 'string', desc: 'SHA-256签名' }, { name: 'auth_code', type: 'string', desc: '授权码' },
            { name: 'fingerprint', type: 'object', desc: '机器指纹 {final, components}' }, { name: 'device_info', type: 'object', desc: '设备信息' }
        ]);
        const heartbeatParams = ref([
            { name: 'timestamp', type: 'number', desc: '当前时间戳（秒）' }, { name: 'nonce', type: 'string', desc: '16位随机字符串' },
            { name: 'sign', type: 'string', desc: 'SHA-256签名' }, { name: 'token', type: 'string', desc: 'JWT令牌' }
        ]);
        const refreshParams = ref([
            { name: 'timestamp', type: 'number', desc: '当前时间戳（秒）' }, { name: 'nonce', type: 'string', desc: '16位随机字符串' },
            { name: 'sign', type: 'string', desc: 'SHA-256签名' }, { name: 'token', type: 'string', desc: '当前JWT令牌' },
            { name: 'refresh_token', type: 'string', desc: '刷新令牌' }, { name: 'fingerprint', type: 'string', desc: '当前机器指纹' }
        ]);
        const trialOuterParams = ref([{ name: 'app_key', type: 'string', desc: '软件AppKey（明文）' }, { name: 'data', type: 'string', desc: 'RSA加密后的Base64字符串' }]);
        const trialInnerParams = ref([
            { name: 'timestamp', type: 'number', desc: '当前时间戳（秒）' }, { name: 'nonce', type: 'string', desc: '16位随机字符串' },
            { name: 'sign', type: 'string', desc: 'SHA-256签名' }, { name: 'fingerprint', type: 'object', desc: '机器指纹对象' }, { name: 'device_info', type: 'object', desc: '设备信息对象' }
        ]);
        const deductPointsParams = ref([
            { name: 'timestamp', type: 'number', required: true, desc: '当前时间戳（秒）' },
            { name: 'nonce', type: 'string', required: true, desc: '16位随机字符串' },
            { name: 'sign', type: 'string', required: true, desc: 'SHA-256签名' },
            { name: 'token', type: 'string', required: true, desc: '用户令牌' },
            { name: 'deduct_amount', type: 'number', required: false, desc: '扣除点数，默认1' },
            { name: 'reason', type: 'string', required: false, desc: '扣点原因，默认"使用功能"' }
        ]);
        const queryPointsParams = ref([
            { name: 'timestamp', type: 'number', required: true, desc: '当前时间戳（秒）' },
            { name: 'nonce', type: 'string', required: true, desc: '16位随机字符串' },
            { name: 'sign', type: 'string', required: true, desc: 'SHA-256签名' },
            { name: 'token', type: 'string', required: true, desc: '用户令牌' }
        ]);
        const rechargePointsParams = ref([
            { name: 'timestamp', type: 'number', required: true, desc: '当前时间戳（秒）' },
            { name: 'nonce', type: 'string', required: true, desc: '16位随机字符串' },
            { name: 'sign', type: 'string', required: true, desc: 'SHA-256签名' },
            { name: 'token', type: 'string', required: true, desc: '用户令牌' },
            { name: 'recharge_code', type: 'string', required: true, desc: '充值卡密' }
        ]);
        const errorCodes = ref([
            { code: 200, message: '成功', desc: '请求成功', solution: '-' },
            { code: 400, message: '参数错误', desc: '缺少必需参数或格式错误', solution: '检查请求参数' },
            { code: 401, message: '令牌无效', desc: 'JWT令牌无效或已过期', solution: '刷新令牌或重新激活' },
            { code: 403, message: '禁止访问', desc: '设备被禁用或被强制下线', solution: '联系管理员' },
            { code: 404, message: '不存在', desc: '软件或授权码不存在', solution: '检查AppKey或授权码' },
            { code: 410, message: '已过期', desc: '授权已过期', solution: '续费或重新购买' },
            { code: 423, message: '待审核', desc: '设备变更或风险设备待审核', solution: '等待管理员审核' },
            { code: 429, message: '请求过频', desc: '请求频率超限', solution: '降低请求频率' },
            { code: 500, message: '服务器错误', desc: '服务器内部错误', solution: '联系管理员' }
        ]);
        const fingerprintItems = ref([
            { platform: 'Windows', items: 'CPU序列号、硬盘序列号、MAC地址、主板序列号' },
            { platform: 'Android', items: 'Android ID、设备品牌、设备型号、MAC地址' }
        ]);
        const signParamsTable = ref([
            { api: 'activate.php', params: 'app_key, auth_code', example: 'timestamp + nonce + app_key值 + auth_code值 + client_secret' },
            { api: 'heartbeat.php', params: 'token', example: 'timestamp + nonce + token值 + client_secret' },
            { api: 'refresh.php', params: 'fingerprint, refresh_token, token', example: 'timestamp + nonce + fingerprint值 + refresh_token值 + token值 + client_secret' },
            { api: 'trial.php', params: 'app_key', example: 'timestamp + nonce + app_key值 + client_secret' }
        ]);
        const cloudDataDesc = ref([
            { name: 'cloud.vars', type: 'object', desc: '远程变量，key-value形式，用于动态配置' },
            { name: 'cloud.announcements', type: 'array', desc: '公告列表数组，每个公告对象包含以下字段' },
            { name: '├─ id', type: 'int', desc: '公告ID，唯一标识（客户端需记录已读ID）' },
            { name: '├─ title', type: 'string', desc: '公告标题' },
            { name: '├─ content', type: 'string', desc: '公告内容，支持换行符' },
            { name: '├─ type', type: 'string', desc: '公告类型：notice(通知)、warning(警告)、update(更新)、ad(广告)' },
            { name: '├─ is_popup', type: 'int', desc: '是否弹窗显示：1=弹窗显示，0=不弹窗' },
            { name: '└─ show_once', type: 'int', desc: '显示模式：1=只显示一次（确认后不再显示），0=每次启动显示' },
            { name: 'cloud.latest_version', type: 'object', desc: '最新版本信息，包含version、download_url、force_update等' },
            { name: 'cloud.switches', type: 'object', desc: '远程开关，key为开关名，value为布尔值' }
        ]);
        
        const toggleDark = () => {
            document.documentElement.classList.toggle('dark', isDark.value);
        };
        
        const copy = (e) => {
            try {
                let codeBlock;
                if (e.target.tagName === 'BUTTON') {
                    codeBlock = e.target.closest('.code-block');
                } else if (e.target.tagName === 'SPAN') {
                    codeBlock = e.target.closest('button').closest('.code-block');
                } else {
                    codeBlock = e.target.closest('.code-block');
                }
                
                if (!codeBlock) {
                    ElementPlus.ElMessage.error('无法找到代码块');
                    return;
                }
                
                const codeBody = codeBlock.querySelector('.code-body');
                if (!codeBody) {
                    ElementPlus.ElMessage.error('无法找到代码内容');
                    return;
                }
                
                const code = codeBody.textContent;
                
                // 使用传统的复制方法，更兼容
                const textarea = document.createElement('textarea');
                textarea.value = code;
                textarea.style.position = 'fixed';
                textarea.style.opacity = '0';
                document.body.appendChild(textarea);
                textarea.select();
                
                try {
                    const successful = document.execCommand('copy');
                    document.body.removeChild(textarea);
                    if (successful) {
                        ElementPlus.ElMessage.success('已复制到剪贴板');
                    } else {
                        ElementPlus.ElMessage.error('复制失败，请手动复制');
                    }
                } catch (err) {
                    document.body.removeChild(textarea);
                    ElementPlus.ElMessage.error('复制失败，请手动复制');
                }
            } catch (error) {
                console.error('复制错误:', error);
                ElementPlus.ElMessage.error('复制失败，请手动复制');
            }
        };
        
        const copyUrl = (url) => {
            const textarea = document.createElement('textarea');
            textarea.value = url;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            
            try {
                const successful = document.execCommand('copy');
                document.body.removeChild(textarea);
                if (successful) {
                    ElementPlus.ElMessage.success('接口地址已复制');
                } else {
                    ElementPlus.ElMessage.error('复制失败');
                }
            } catch (err) {
                document.body.removeChild(textarea);
                ElementPlus.ElMessage.error('复制失败');
            }
        };
        
        const copyCode = (lang) => {
            const code = codes.value[lang];
            if (!code) {
                ElementPlus.ElMessage.error('代码不存在');
                return;
            }
            
            const textarea = document.createElement('textarea');
            textarea.value = code;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            
            try {
                const successful = document.execCommand('copy');
                document.body.removeChild(textarea);
                if (successful) {
                    ElementPlus.ElMessage.success('已复制完整代码');
                } else {
                    ElementPlus.ElMessage.error('复制失败');
                }
            } catch (err) {
                document.body.removeChild(textarea);
                ElementPlus.ElMessage.error('复制失败');
            }
        };
        
        return {
            tab, isDark, tabNames, sdkNames, sdkLangs, codes, configTable,
            initParams, activateOuterParams, activateInnerParams, heartbeatParams,
            refreshParams, trialOuterParams, trialInnerParams, 
            deductPointsParams, queryPointsParams, rechargePointsParams,
            errorCodes, fingerprintItems, signParamsTable, cloudDataDesc,
            toggleDark, copy, copyUrl, copyCode
        };
    }
});

for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component);
}
app.use(ElementPlus);
app.mount('#app');
</script>
</body>
</html>
